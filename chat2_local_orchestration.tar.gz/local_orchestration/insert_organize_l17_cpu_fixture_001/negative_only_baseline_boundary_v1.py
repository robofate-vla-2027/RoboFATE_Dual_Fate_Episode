"""Owner metadata only: continue independent negatives after positive quota is full."""
from pathlib import Path
import hashlib
import closed_baseline_resource_v1 as closed

if hashlib.sha256(Path(closed.__file__).read_bytes()).hexdigest() != 'a80220ac24361c63c785352c126deb460204888498343263f6669f760b7bc2b8':
    raise ValueError('Pinned closed-baseline checks changed')

OWNER = '01a16807-8085-7903-be07-66eb332ebf95'
TASK = 'insert_tubes'


def check(ledger, evidence, evidence_ref):
    """Return actual process checks; never alter data, counters, or reservations."""
    need = closed.need
    n = ledger['nodes']['perdon-hou']
    t = ledger['tasks'][TASK]
    need(ledger['campaign_id'] == 'refate-20261022-97baf70d5128'
         and n['active_chat_id'] == OWNER and n['current_task'] == TASK
         and TASK in n['fixed_tasks'] and t['assigned_host'] == 'perdon-hou',
         'Wrong campaign, owner, or task')
    need(not n['user_pause_active'] and not n['user_stop']
         and not n.get('owned_resource_launch_hold', False), 'Launch held')
    need(n['active_run_id'] is None and n['active_real_simulators'] == 0
         and not n['launch_inflight']
         and n['baseline_accounting']['baseline_attempts_running'] == 0,
         'Owned work remains active')
    need(len(n['completed_pending_sources']) <= 2
         and len(n['common_pending_readback_run_ids']) <= 2, 'Readback backlog')
    need(t['qualified_count'] == t['positive_quota'] == 10 and t['reserved_count'] == 0
         and t['negative_count'] + t['negative_reserved_count'] < t['negative_quota'],
         'Not a positive-full negative deficit')
    checks = closed.baseline_checks(evidence)
    need(evidence['task'] == TASK and evidence['execution_owner'] == OWNER
         and evidence['native_budget'] == 500 and evidence['native_success'] is False
         and evidence['first_readback_passed'] is True
         and evidence['new_positive'] == evidence['new_negative'] == 0,
         'Not a complete native failure of this task')
    need(evidence['source_id'] not in ('insert_tubes_b0_l2_94207e0808afb12a',
         'insert_tubes_b0_l14_63cac7ed4ebd31b9'), 'Protected source')
    source = ledger['source_index'][evidence['source_id']]
    row = ledger['reservations'][evidence['source_id']]
    need(source['host'] == 'perdon-hou' and source['task'] == TASK
         and source['source_started'] is True and source['complete_readback'] is True
         and source['native_success'] is False and source['native_budget'] == 500
         and source['run_id'] == row['run_id'] == evidence['run_id']
         and source['context'] == evidence['context']
         and source['source_owner'] == evidence['source_owner']
         and source['settlement'] == row['settlement'] == evidence_ref,
         'Source or settlement binding differs')
    need(row['status'] == 'settled_native_failure_no_quota'
         and row['positive_slots'] == row['negative_slots'] == 0
         and row.get('quota_reserved') is False
         and row.get('negative_quota_reserved') is False, 'Reservation not released')
    need(not source.get('active_teacher_attempt') and not source.get('teacher_attempt_history')
         and not source.get('provider_safety_refusal')
         and source.get('qualified_count', 0) == source.get('negative_count', 0) == 0,
         'Teacher history, refusal, or source already counted')
    return checks
