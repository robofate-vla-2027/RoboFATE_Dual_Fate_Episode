"""Preserve frozen Insert append provenance in the existing pure reservation."""
from copy import deepcopy
from pathlib import Path
import hashlib
import common_owner_reservation_v2 as prior

BASE_SHA = 'db5f25d6dfb593a4ba552c3f469d99f9e58ca717c4204d9c058f3240d136f3c7'
if hashlib.sha256(Path(prior.__file__).read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError('Pinned predecessor reservation changed')
SCHEMA = 'refate.common_collector.source_sequence_binding.v1'
_settled_predecessor = prior._settled_predecessor
_inherited_prefix = prior._inherited_prefix


def _insert_checkpoint(ledger, boundary, source):
    prepared = boundary['next_preparation']['prepared']
    if prepared.get('binding_schema') != SCHEMA or source.get('task') != 'insert_tubes':
        return None
    cp = boundary.get('insert_prefix_checkpoint', {})
    old = ledger['source_index'].get(cp.get('source_id'), {})
    old_prepared = cp.get('prepared', {})
    previous = old_prepared.get('source', {})
    frozen = ledger['split_manifests']['insert_tubes']
    frozen_ref = {k: frozen[k] for k in ('path', 'sha256')}
    prefix = source['required_accounted_prefix']
    ordinal = source['layout_id']
    valid = (
        prepared.get('native_step_limit') == 500
        and ledger['nodes']['perdon-hou']['current_dispatch']['native_wall_seconds'] == 2400
        and old.get('task') == previous.get('task') == source['task']
        and old.get('host') == 'perdon-hou' and old.get('source_started') is True
        and old.get('complete_readback') is True
        and old.get('source_id') == previous.get('source_id') == cp.get('source_id')
        and old.get('settlement') is not None and old['settlement'] == cp.get('settlement_ref')
        and old.get('source_preparation_ref') == cp.get('preparation_ref')
        and old_prepared.get('binding_schema') == SCHEMA
        and previous.get('source_sequence') == prefix == frozen['initial_source_sequence']
        and prefix and previous.get('layout_id') == prefix[-1] and ordinal == prefix[-1] + 1
        and source['source_sequence'] == prefix + [ordinal]
        and source['accounted_historical_prefix'] == previous.get('accounted_historical_prefix')
        == frozen['accounted_historical_prefix'] == [0]
        and source['required_used_prefix'] == prefix[1:]
        and cp.get('split_ref') == prepared['provenance']['prior_split'] == frozen_ref
        and cp.get('sequence_ref') == prepared['provenance']['prior_sequence']
        == frozen['source_sequence_extension']
        and cp.get('split', {}).get('initial_source_sequence') == prefix
        and ordinal not in frozen['reserved_final']
    )
    prior.need(valid, 'Insert append checkpoint is not the latest settled frozen prefix')
    return cp


def _conditional_prefix(ledger, boundary, source, ordinal):
    cp = _insert_checkpoint(ledger, boundary, source)
    return cp is not None and ordinal in source['required_accounted_prefix']


def append_manifest(prepared, previous_split, extension_ref, at):
    source = prepared['source']; ordinal = source['layout_id']; group = source['group_id']
    prior.need(prepared['binding_schema'] == SCHEMA and source['task'] == 'insert_tubes'
               and previous_split['initial_source_sequence'] == source['required_accounted_prefix']
               and str(ordinal) not in previous_split['layouts']
               and ordinal not in previous_split['original_partition']['reserved_final'],
               'Invalid immediate Insert append')
    out = deepcopy(previous_split)
    out['layouts'][str(ordinal)] = deepcopy(prepared['split_addition_proposal'])
    out['layout_to_group'][str(ordinal)] = group
    out['families'][group]['layouts'].append(deepcopy(prepared['family_addition_proposal']))
    out['materialized_layouts'] = deepcopy(source['source_sequence'])
    out['initial_source_sequence'] = deepcopy(source['source_sequence'])
    out['prior_frozen_manifest'] = deepcopy(prepared['provenance']['prior_split'])
    out['source_sequence_extension'] = deepcopy(extension_ref)
    out['append_prepared_at'] = at
    out['appended_materialized_layouts'] = [ordinal]
    return out


def _dispatch_split(ledger, boundary, prepared):
    if prepared.get('binding_schema') != SCHEMA:
        return deepcopy(prepared['provenance']['split'])
    cp = _insert_checkpoint(ledger, boundary, prepared['source'])
    publication = boundary['insert_sequence_publication']
    expected = append_manifest(prepared, cp['split'], publication['extension_ref'], publication['at'])
    prior.need(publication['manifest'] == expected, 'Append changed prior grouping or other frozen content')
    prior.need(set(publication['manifest_ref']) == {'path', 'sha256'}
               and set(publication['extension_ref']) == {'path', 'sha256'}, 'Explicit append references required')
    return deepcopy(publication['manifest_ref'])


_text = prior._text
_old = "(len(matches) == 1 and matches[0].get('settlement') is not None) or _inherited_prefix(ledger, b, source, i)"
prior.need(_text.count(_old) == 1, 'Original prefix check seam changed')
_text = _text.replace(_old, _old + ' or _conditional_prefix(ledger, b, source, i)', 1)
_old = "deepcopy(prepared['provenance']['split'])"
prior.need(_text.count(_old) == 1, 'Original split seam changed')
_text = _text.replace(_old, '_dispatch_split(ledger, b, prepared)', 1)
exec(compile(_text, str(Path(prior.__file__).with_name('common_owner_reservation.py'))
             + '::conditional_insert_v3', 'exec'), globals())
