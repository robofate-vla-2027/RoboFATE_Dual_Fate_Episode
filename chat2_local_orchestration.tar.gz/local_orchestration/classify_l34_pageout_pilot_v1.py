"""One cold, closed-run, 16 MiB file pageout; no anonymous pressure or signals."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import closed_classify_l34_cache_inspect_v1 as scope
from closed_private_cache_pilot_v1 import resident, validate


def run(inspection_path, binary_path, expected_binary_sha):
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert os.uname().nodename == "nb-5pl2apckdj-0"
    assert os.environ["CUDA_VISIBLE_DEVICES"] == ""
    binary = Path(binary_path)
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_binary_sha
    raw = Path(inspection_path).read_bytes()
    plan = json.loads(raw)
    assert plan["run_id"] == scope.RUN.name and plan["execution_owner"] == scope.OWNER
    assert plan["cache_root"] == str(scope.CACHE) and plan["exclusion_complete"]
    terminal_raw = (scope.RUN / "MAIN_TERMINAL_OBSERVATION_001.json").read_bytes()
    assert hashlib.sha256(terminal_raw).hexdigest() == scope.TERMINAL_SHA
    terminal = json.loads(terminal_raw)
    assert terminal["safe_for_next_simulator"] and terminal["execution_owner"] == scope.OWNER
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert boot == plan["boot_id"]
    for row in terminal["own_process_checks"]:
        old = row["identity"]
        try:
            actual = scope.identity(old["pid"])
        except FileNotFoundError:
            continue
        assert boot != old["boot_id"] or actual["start_ticks"] != old["start_ticks"]
    row = max(plan["candidates"], key=lambda item: item["resident_bytes"])
    path, before, length = validate(row, scope.CACHE, time.time_ns())
    assert path.stat().st_nlink == 1, "Shared inode is outside the private pilot"
    processes, errors, users = scope.inspect_live({(before[0], before[1])})
    assert not errors and not users, (errors, users)
    mem0, res0 = scope.memory(), resident(path)
    assert res0 >= length and scope.signature(path) == before
    assert mem0["stat"]["total_writeback"] == 0, "Concurrent writeback"
    result = subprocess.run(
        [str(binary), str(path), str(before[0]), str(before[1]), str(before[3]),
         str(before[4]), str(length)], capture_output=True, text=True, timeout=15)
    first = dict(memory=scope.memory(), resident_bytes=resident(path))
    time.sleep(3)
    second = dict(memory=scope.memory(), resident_bytes=resident(path))
    checks = []
    for process in processes:
        if process["pid"] == os.getpid():
            continue
        try:
            actual = scope.identity(process["pid"])
            checks.append(dict(pid=process["pid"],
                               identity_unchanged=actual["start_ticks"] == process["start_ticks"]))
        except FileNotFoundError:
            checks.append(dict(pid=process["pid"], identity_unchanged=False,
                               absent_after=True))
    after = scope.signature(path)
    output = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        data_kind="actual_bounded_closed_private_file_pageout", run_id=scope.RUN.name,
        execution_owner=scope.OWNER, boot_id=boot, path=str(path), length=length,
        binary_sha256=expected_binary_sha, inspection_sha256=hashlib.sha256(raw).hexdigest(),
        signature_before=before, signature_after=after,
        helper_exit=result.returncode, helper_stdout=result.stdout, helper_stderr=result.stderr,
        memory_before=mem0, resident_before=res0, post_snapshots=[first, second],
        resident_reduction_bytes=res0-second["resident_bytes"],
        protected_identity_checks=checks, no_global_controls=True, no_signals=True,
        no_file_data_writes=True, no_anonymous_pressure=True, scientific_samples_added=0)
    print(json.dumps(output), flush=True)
    assert result.returncode == 0 and after == before, "Pilot failed; preserve result"
    assert all(row["identity_unchanged"] for row in checks), "Protected identity changed"
    assert all(post["memory"]["oom_control"] == mem0["oom_control"] and
               post["memory"]["failcnt"] == mem0["failcnt"] for post in (first, second))


if __name__ == "__main__":
    run(*sys.argv[1:])
