set -eu
cd /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
env PYTHONDONTWRITEBYTECODE=1 /vla/mxk/projects/Robodojo/.runtime-env/bin/python -B - <<'PY'
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Source metadata only: " + event)


sys.addaudithook(deny_live)
import source_binding as original
import task_catalog_binding as binding
import task_family_binding as family

A = Path.cwd()
task = "pick_from_conveyor_by_image"
i = 10
prior = A / "task_sources" / task / "SPLIT_MANIFEST_L9_APPEND_001.json"
prior_ref = dict(path=str(prior), sha256=hashlib.sha256(prior.read_bytes()).hexdigest())
assert prior_ref["sha256"] == "8e1428f6537549dd301e848231b9c5f4c2a76239ff608f0d292029674653fa40"
old = original.decode(binding.read_ref(prior_ref))
assert old["materialized_layouts"] == list(range(i))
assert i not in old["original_partition"]["reserved_final"]
assert not (A.parent / "preparations/CONVEYOR_L10_COMMON_PREPARATION_001.json").exists()


def asset(j):
    assert 0 <= j <= i and j not in old["original_partition"]["reserved_final"]
    return binding.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{task}_{j}.json"


def load(j):
    p = asset(j)
    ref = dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    return original.decode(binding.read_ref(ref, expected_path=p)), ref


def differences(a, b, path=""):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            target = path + "/" + key
            result += ([target] if key not in a or key not in b else
                       differences(a[key], b[key], target))
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [path]
        return [p for k, (left, right) in enumerate(zip(a, b))
                for p in differences(left, right, path + "/" + str(k))]
    return [] if a == b else [path]


raw, raw_ref = load(i)
f = family.family(raw)
gid = task + "/task_content_family/" + f["content_sha256"]
closest = []
for group, value in old["families"].items():
    j = value["layouts"][0]["layout_id"]
    previous, _ = load(j)
    prior_family = family.family(previous)
    assert task + "/task_content_family/" + prior_family["content_sha256"] == group
    paths = differences(prior_family["normalized_layout"], f["normalized_layout"])
    closest.append(dict(group_id=group, layout=j, different_nonpose_paths=paths))
best = min(closest, key=lambda x: (len(x["different_nonpose_paths"]), x["layout"]))
labels = [v["split"] for v in old["families"].values()]
target = min(len(labels), max(1, (len(labels) + 1) // 5))
split = ("student_dev" if labels.count("student_dev") < target else "student_train")
if gid in old["families"]:
    split = old["families"][gid]["split"]
review = dict(new_layout=i, new_group=gid, outcomes_read=False,
              next_original_ordinal=True, closest_existing=best)
print(json.dumps(dict(layout=i, raw_sha256=raw_ref["sha256"], group_id=gid,
    new_family_review=review, new_family_split=split, prior_manifest=prior_ref,
    outcomes_read=False, reserved_layouts_read=[],
    execution_owner="01a19072-9e5e-7e02-b77a-8f115cfc9bd0")))
PY
