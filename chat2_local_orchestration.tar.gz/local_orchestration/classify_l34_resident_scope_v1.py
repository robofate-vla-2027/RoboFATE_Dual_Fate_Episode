"""Bounded fincore inventory of cold files in the same closed private cache."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import closed_classify_l34_cache_inspect_v1 as scope


def main():
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert os.uname().nodename == "nb-5pl2apckdj-0"
    assert os.environ["CUDA_VISIBLE_DEVICES"] == ""
    raw = (scope.RUN / "MAIN_TERMINAL_OBSERVATION_001.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == scope.TERMINAL_SHA
    terminal = json.loads(raw)
    assert terminal["execution_owner"] == scope.OWNER and terminal["safe_for_next_simulator"]
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    for row in terminal["own_process_checks"]:
        old = row["identity"]
        try:
            actual = scope.identity(old["pid"])
        except FileNotFoundError:
            continue
        assert boot != old["boot_id"] or actual["start_ticks"] != old["start_ticks"]
    assert scope.CACHE.resolve(strict=True) == scope.CACHE
    started, inspected, candidates = time.monotonic(), 0, []
    for directory, dirs, names in os.walk(scope.CACHE, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(directory) / name).is_symlink()]
        for name in names:
            if inspected >= 2048 or time.monotonic() - started > 4:
                break
            inspected += 1
            path = Path(directory) / name
            sig = scope.signature(path)
            if (sig[3] >= 1024**2 and path.stat().st_nlink == 1 and
                    time.time_ns() - sig[4] >= 300 * 10**9):
                candidates.append(dict(path=str(path), signature=sig))
        if inspected >= 2048 or time.monotonic() - started > 4:
            break
    candidates = sorted(candidates, key=lambda row: row["signature"][3], reverse=True)[:256]
    assert candidates
    rows = json.loads(subprocess.run(
        ["fincore", "-J", "-b", "-o", "FILE,SIZE,RES,PAGES"] +
        [row["path"] for row in candidates],
        check=True, text=True, capture_output=True, timeout=10).stdout)["fincore"]
    by_path = {row["file"]: row for row in rows}
    for row in candidates:
        assert scope.signature(Path(row["path"])) == row["signature"]
        row["resident_bytes"] = int(by_path[row["path"]]["res"])
    processes, errors, used = scope.inspect_live(
        {(row["signature"][0], row["signature"][1]) for row in candidates})
    print(json.dumps(dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        data_kind="read_only_private_cache_scope_inspection", mutation_performed=False,
        run_id=scope.RUN.name, execution_owner=scope.OWNER, cache_root=str(scope.CACHE),
        boot_id=boot, terminal_sha256=scope.TERMINAL_SHA,
        scan_file_cap=2048, scan_time_cap_seconds=4, candidate_cap=256,
        files_inspected=inspected, candidates=candidates,
        resident_bytes=sum(row["resident_bytes"] for row in candidates),
        processes=processes, process_inspection_errors=errors, live_candidate_users=used,
        exclusion_complete=not errors and not used, memory=scope.memory())))


if __name__ == "__main__":
    main()
