#!/bin/bash
# Manually invoked once after the actual foreground exits.
set -euo pipefail
set -C
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'PY'
import json
from pathlib import Path
d = json.loads(Path("dolls_l11_teacher_foreground.exit.json").read_bytes())
assert d["run_id"] == "c2_sort_nesting_dolls_by_size_l11_evo_common_teacher_0001_01a16807"
assert type(d["tool_returncode"]) is int
PY
remote_env='env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 PYTHONDONTWRITEBYTECODE=1'
py=/vla/mxk/projects/Robodojo/.runtime-env/bin/python
a=/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
sh ./remote.sh --command "$remote_env $py -B $a/teacher_terminal_handoff_v7.py" \
    < dolls_l11_teacher_foreground.exit.json > dolls_l11_teacher_terminal.result.json \
    2> dolls_l11_teacher_terminal.stderr.log
python3 - <<'PY'
import base64
import json
from pathlib import Path
with Path("dolls_l11_teacher_settlement.args.json").open("x") as stream:
    json.dump(dict(evidence_b64=base64.b64encode(
        Path("dolls_l11_teacher_terminal.result.json").read_bytes()).decode()), stream)
PY
python3 ./ledger_transaction.py snapshot ./dolls_l11_teacher_settlement \
    --arguments ./dolls_l11_teacher_settlement.args.json
gzip -c dolls_l11_teacher_settlement.request.json | \
    sh ./remote.sh --command "bash -o pipefail -c 'gzip -dc | $remote_env $py -B $a/teacher_settle_handoff_v7.py | gzip -c'" \
    > dolls_l11_teacher_settlement.result.json.gz \
    2> dolls_l11_teacher_settlement.stderr.log
gzip -dc dolls_l11_teacher_settlement.result.json.gz > dolls_l11_teacher_settlement.result.json
python3 ./ledger_transaction.py commit ./dolls_l11_teacher_settlement
