#!/bin/bash
# Manually invoke after L8 is settled; this script never starts a simulator.
set -euo pipefail
set -C
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'PY'
import datetime
import json
from pathlib import Path

ledger = json.loads(Path("../ReFATE_collection_progress.json").read_bytes())
node = ledger["nodes"]["perdon-hou"]
task = ledger["tasks"]["classify_objects"]
terminal = json.loads(Path("classify_l8_teacher_terminal.result.json").read_bytes())
settled = json.loads(Path("classify_l8_teacher_settlement.receipt.json").read_bytes())
prior = "c2_classify_objects_l8_evo_common_teacher_0001_01a16807"
assert terminal["run_id"] == settled["run_id"] == prior
assert terminal["safe_for_next_simulator"] and settled["safe_for_next_simulator"]
assert node["active_chat_id"] == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
assert node["current_task"] == "classify_objects" and node["active_run_id"] is None
assert node["active_real_simulators"] == 0 and not node["launch_inflight"]
assert not any(node[k] for k in ("user_pause_active", "user_stop", "owned_resource_launch_hold"))
assert node["last_owned_resource_settlement"] == terminal["evidence_ref"]
now = datetime.datetime.now(datetime.timezone.utc)
start = datetime.datetime.fromisoformat(task["latest_segment_started_at"])
clocks = {}
for label, field, count, quota in (
    ("core", "last_core_gain_at", task["core_count"], task["core_quota"]),
    ("negative", "last_negative_gain_at", task["negative_count"], task["negative_quota"]),
):
    gain = datetime.datetime.fromisoformat(task[field]) if task.get(field) else start
    elapsed = (now - max(start, gain)).total_seconds()
    clocks[label] = elapsed
    assert count >= quota or elapsed < 5400, "Original low-yield boundary review is due"
assert task["qualified_count"] < task["positive_quota"]
assert task["negative_count"] < task["negative_quota"]
preparation = json.loads(Path("classify_l27_preparation.result.json").read_bytes())
assert preparation["source_id"] == "classify_objects_b0_l27_542373acd9c1c7f2"
assert preparation["native_budget"] == 1100
assert preparation["source_id"] not in ledger["source_index"]
review = dict(
    at=now.isoformat(), data_kind="actual_settled_boundary_scheduling_review",
    prior_run_id=prior, next_source_id=preparation["source_id"],
    ledger_revision=ledger["revision"], elapsed_seconds=clocks,
    original_segment_started_at=task["latest_segment_started_at"],
    negative_clock_reset=False, same_task_continuation=True,
    native_budget=1100, baseline_wall_seconds=2400,
    source_reserved=False, actual_launch=False,
)
with Path("classify_l27_boundary_review_001.json").open("x") as stream:
    json.dump(review, stream, indent=2)
    stream.write("\n")
PY
remote_env='env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 PYTHONDONTWRITEBYTECODE=1'
py=/vla/mxk/projects/Robodojo/.runtime-env/bin/python
a=/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
sh ./remote.sh --command "$remote_env $py -B $a/boundary_configured_handoff_v2.py" \
    < classify_l27_boundary.args.json > classify_l27_boundary.result.json \
    2> classify_l27_boundary.stderr.log
python3 - <<'PY'
import json
from pathlib import Path
boundary = json.loads(Path("classify_l27_boundary.result.json").read_bytes())
with Path("classify_l27_reservation.args.json").open("x") as stream:
    json.dump(dict(
        boundary_ref=boundary["boundary_ref"], task="classify_objects", native_budget=1100,
        ledger_note="L8 teacher preaction infrastructure interruption settled0/0; original core and independent-negative "
                    "windows reviewed at the boundary. Continue the existing frozen sequence "
                    "with prepared L27, without replay, clock reset or release change.",
    ), stream)
PY
python3 ./ledger_transaction.py snapshot ./classify_l27_reservation \
    --arguments ./classify_l27_reservation.args.json
gzip -c classify_l27_reservation.request.json |
    sh ./remote.sh --command "bash -o pipefail -c 'gzip -dc | $remote_env $py -B $a/reserve_content_handoff_v1.py | gzip -c'" \
    > classify_l27_reservation.result.json.gz 2> classify_l27_reservation.stderr.log
gzip -dc classify_l27_reservation.result.json.gz > classify_l27_reservation.result.json
python3 ./ledger_transaction.py commit ./classify_l27_reservation
python3 - <<'PY'
import json
from pathlib import Path
receipt = json.loads(Path("classify_l27_reservation.receipt.json").read_bytes())
with Path("classify_l27_binding.args.json").open("x") as stream:
    json.dump(dict(dispatch=receipt["dispatch"]), stream)
PY
sh ./remote.sh --command "$remote_env $py -B $a/baseline_bind_handoff_v1.py" \
    < classify_l27_binding.args.json > classify_l27_binding.result.json \
    2> classify_l27_binding.stderr.log
python3 - <<'PY'
import base64
import json
from pathlib import Path
with Path("classify_l27_binding.localargs.json").open("x") as stream:
    json.dump(dict(
        binding_b64=base64.b64encode(Path("classify_l27_binding.result.json").read_bytes()).decode(),
        receipt_name="ReFATE_chat2_handoff_20261031_01a19072/classify_l27_binding.receipt.json",
    ), stream)
PY
python3 ./record_baseline_binding.py < classify_l27_binding.localargs.json \
    > classify_l27_binding.localresult.json
python3 - <<'PY'
import json
from pathlib import Path
old = json.loads(Path("classify_l8_binding.result.json").read_bytes())
new = json.loads(Path("classify_l27_binding.result.json").read_bytes())
script = Path("classify_l8_launch.sh").read_text()
assert script.count(old["context"]["sha256"]) == 1
script = script.replace("classify_l8", "classify_l27").replace(old["run_id"], new["run_id"])
script = script.replace(old["context"]["sha256"], new["context"]["sha256"])
with Path("classify_l27_launch.sh").open("x") as stream:
    stream.write(script)
script = Path("general_l23_settle.sh").read_text().replace("general_l23", "classify_l27")
script = script.replace("c2_general_pickup_l23_common_baseline_0001_01a16807", new["run_id"])
with Path("classify_l27_settle.sh").open("x") as stream:
    stream.write(script)
with Path("classify_l27_health.args.json").open("x") as stream:
    json.dump(dict(run_id=new["run_id"]), stream)
print(json.dumps(dict(bound_not_launched=True, run_id=new["run_id"], context=new["context"])))
PY
sh -n classify_l27_launch.sh
bash -n classify_l27_settle.sh
