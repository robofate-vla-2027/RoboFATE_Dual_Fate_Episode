set -eu
export PYTHONDONTWRITEBYTECODE=1
/vla/mxk/projects/Robodojo/.runtime-env/bin/python -B - <<'PY'
import datetime
import hashlib
import json
from pathlib import Path
import sys


def metadata_only(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Source metadata preparation prohibits live effects")


sys.addaudithook(metadata_only)
A = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026")
sys.path.insert(0, str(A))
import task_configured_binding as configured
import task_catalog_binding as catalog

owner = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
task = "pick_from_conveyor_by_image"
directory = A / "task_sources" / task
prior_path = directory / "PREPARATION_L5_001.json"
prior_raw = prior_path.read_bytes()
assert hashlib.sha256(prior_raw).hexdigest() == "2a49d2f072ff851c5531fb91e364439509c7000a118a9766b35624aacdbf419c"
prior = json.loads(prior_raw)
configured.load_native_layout(prior)
assert prior["source"]["source_sequence"] == list(range(7))
assert prior["source"]["layout_id"] == 5 and prior["native_step_limit"] == 700
output = directory / "PREPARATION_L6_CONFIGURED_001.json"
existing = list(directory.glob("PREPARATION_L6*.json"))
assert existing in ([], [output]), "An existing L6 preparation must be reviewed, not replaced"
if output.exists():
    prepared = json.loads(output.read_bytes())
    reused = True
else:
    prepared, raw = configured.prepare_source(task=task, layout_id=6,
        split_ref=prior["provenance"]["split"], native_total=700,
        task_ref=prior["provenance"]["task_implementation"])
    configured.load_native_layout(prepared)
    original, original_raw = catalog.prepare_source(task=task, layout_id=6,
        split_ref=prior["provenance"]["split"])
    comparable = dict(prepared)
    comparable["binding_schema"] = original["binding_schema"]
    assert comparable == original and raw == original_raw
    with output.open("x") as stream:
        json.dump(prepared, stream, indent=2)
        stream.write("\n")
    reused = False
configured.load_native_layout(prepared)
assert prepared["source"]["required_accounted_prefix"] == list(range(6))
assert prepared["source"]["source_sequence"] == prior["source"]["source_sequence"]
assert prepared["source"]["layout_id"] == 6 and prepared["native_step_limit"] == 700


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


receipt_path = directory / "L6_PREPARATION_HANDOFF_20261101_01a19072.json"
receipt = dict(schema="refate.configured_source_metadata_preparation.v1",
    data_kind="metadata_only_no_scientific_data", at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prepared_by=owner, execution_owner=owner, preparation_ref=ref(output),
    prior_preparation_ref=ref(prior_path), split_ref=prior["provenance"]["split"],
    source_id=prepared["source"]["source_id"], native_budget=700,
    frozen_descriptor_owners={k: prepared["source"][k] for k in ("source_owner", "execution_owner")},
    frozen_descriptor_is_not_execution_authority=True, original_split_and_sequence_unchanged=True,
    original_layout_and_task_implementation_unchanged=True, sealed_layout_content_read=False,
    configuration_equivalent_to_original_catalog=True, reused_preparation=reused,
    source_reserved=False, native_started=False, teacher_started=False, qualification=False)
if receipt_path.exists():
    old = json.loads(receipt_path.read_bytes())
    assert old["prepared_by"] == owner and old["preparation_ref"] == ref(output)
    receipt = old
else:
    with receipt_path.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
receipt["receipt_ref"] = ref(receipt_path)
print(json.dumps(receipt))
PY
