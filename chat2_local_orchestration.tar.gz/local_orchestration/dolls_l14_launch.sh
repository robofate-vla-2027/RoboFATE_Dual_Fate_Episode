#!/bin/sh
set -euC
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'GUARD'
import json
from pathlib import Path
n = json.loads(Path('../ReFATE_collection_progress.json').read_bytes())['nodes']['perdon-hou']
assert n['active_chat_id'] == '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'
assert n['active_run_id'] == 'c2_sort_nesting_dolls_by_size_l14_common_baseline_0015_01a16807'
assert n['launch_inflight'] and n['active_real_simulators'] == 0
assert not n['user_pause_active'] and not n['user_stop'] and not n['owned_resource_launch_hold']
GUARD
test ! -e dolls_l14_foreground.result.json
test ! -e dolls_l14_foreground.exit.json
set +e
sh ./remote.sh --command 'env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 CUDA_VISIBLE_DEVICES=0,1 CUDA_DEVICE_ORDER=PCI_BUS_ID MODEL_UPSTREAM=http://127.0.0.1:28181 PYTHONDONTWRITEBYTECODE=1 /vla/mxk/projects/Robodojo/.runtime-env/bin/python -B /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/collect_recording_content_v1.py --context /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs/c2_sort_nesting_dolls_by_size_l14_common_baseline_0015_01a16807/CONTEXT_001.json --sha256 8ac7faec36ba05e0fd2a548e8d803827db832d96df2a8b1be315cf58d8c46195' > dolls_l14_foreground.result.json 2> dolls_l14_foreground.stderr.log
rc=$?
set -e
printf '{"run_id":"c2_sort_nesting_dolls_by_size_l14_common_baseline_0015_01a16807","tool_returncode":%s}\n' "$rc" > dolls_l14_foreground.exit.json
cat dolls_l14_foreground.exit.json
exit "$rc"
