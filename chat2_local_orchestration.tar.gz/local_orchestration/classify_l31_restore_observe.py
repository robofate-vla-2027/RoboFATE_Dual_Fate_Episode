"""Read saved restoration evidence and this run's process identity only."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

RUN = "c2_classify_objects_l31_evo_common_teacher_0001_01a16807"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher/runs") / RUN


def read(name):
    return json.loads((ROOT / name).read_bytes())


def ref(name):
    p = ROOT / name
    return dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())


c = read("CONTEXT_001.json")
aux = read("restore_auxiliary_render_comparison.json")
state = read("restore_state_comparison.json")
t1 = read("actual_t1_verified.json")
native = read("native_started.json")
identity = read("owned_native.json")["identity"]
proc = Path("/proc") / str(identity["pid"])
fields = (proc / "stat").read_text().rsplit(")", 1)[1].split()
assert identity["start_ticks"] == int(fields[19])
assert identity["boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
assert native["pid"] == identity["pid"]
env = dict(v.split(b"=", 1) for v in (proc / "environ").read_bytes().split(b"\0") if b"=" in v)
selected = {k: env.get(k.encode(), b"").decode()
            for k in ("CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER")}
assert selected["CUDA_VISIBLE_DEVICES"] == "0,1"
assert c["t1"] == 42 and c["native_limit"] == 1100 and c["remaining_steps"] == 1058
assert state["context_budget"] == dict(total=1100, t1=42, remaining=1058)
assert aux["rtx_profile_exact"] and aux["requested_rtx_profile_exact"]
assert state["all_compared_fields_within_candidate_rules"] and state["no_new_missing_fields"]
rows = subprocess.check_output(
    ["nvidia-smi", "--query-compute-apps=pid,gpu_uuid,used_memory",
     "--format=csv,noheader,nounits"], text=True)
print(json.dumps(dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(), run_id=RUN,
    t1=42, total=1100, remaining=1058, actual_t1=t1,
    auxiliary_ref=ref("restore_auxiliary_render_comparison.json"),
    state_ref=ref("restore_state_comparison.json"),
    auxiliary_comparison=aux["task_auxiliary"],
    rtx_profile_exact=aux["rtx_profile_exact"],
    original_physical_rules_pass=state["all_compared_fields_within_candidate_rules"],
    no_new_missing_fields=state["no_new_missing_fields"],
    original_restore_qualified_field=state["restore_qualified"],
    comparison_status=state["comparison_status"],
    actual_native_t1_marker=ref("actual_t1_verified.json"),
    identity=identity, selected_environment=selected,
    actual_gpu_rows=[r for r in rows.splitlines() if r.split(",")[0].strip() == str(identity["pid"])],
    native_start_wall_ns=native["wall_ns"],
    original_native_deadline_wall_ns=native["wall_ns"] + 3600 * 10**9,
    sample_qualified=False, production_restore_changed=False, RGB_decoded=False)))
