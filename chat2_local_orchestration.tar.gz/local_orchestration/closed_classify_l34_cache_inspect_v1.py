"""Read-only, bounded inspection of one settled run's private runtime cache."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")
RUN = ROOT / "runs/c2_classify_objects_l34_evo_common_teacher_0001_01a16807"
CACHE = RUN / "runtime/cache"
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
TERMINAL_SHA = "bfad4f6f59f3c75596eb7e79dbe20038bfbcc6cf3670f92424946b06d9bd21dc"


def identity(pid):
    values = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": int(pid), "start_ticks": int(values[19])}


def signature(path):
    s = path.stat()
    if path.resolve(strict=True) != path or not stat.S_ISREG(s.st_mode):
        raise ValueError("Canonical regular private file required")
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def inspect_live(keys):
    processes, errors, used = [], [], []
    initial = {p.name for p in Path("/proc").iterdir() if p.name.isdigit()}
    for name in sorted(initial, key=int):
        p = Path("/proc") / name
        try:
            before = identity(name)
            status = p.joinpath("status").read_text()
            row = dict(before, name=p.joinpath("comm").read_text().strip(),
                       rss_kib=next((int(line.split()[1]) for line in status.splitlines()
                                     if line.startswith("VmRSS:")), 0),
                       cgroup=p.joinpath("cgroup").read_text())
            for line in p.joinpath("maps").read_text().splitlines():
                fields = line.split(None, 5)
                major, minor = (int(v, 16) for v in fields[3].split(":"))
                key = (os.makedev(major, minor), int(fields[4]))
                if key in keys:
                    used.append(dict(pid=int(name), kind="mapped", key=list(key)))
            for fd in p.joinpath("fd").iterdir():
                try:
                    s = fd.stat()
                except FileNotFoundError:
                    continue
                if (s.st_dev, s.st_ino) in keys:
                    used.append(dict(pid=int(name), kind="open", key=[s.st_dev, s.st_ino]))
            if identity(name) != before:
                raise RuntimeError("PID identity changed during inspection")
            processes.append(row)
        except FileNotFoundError:
            if p.exists():
                errors.append(dict(pid=int(name), error="Live process metadata disappeared"))
        except (OSError, ValueError, RuntimeError) as error:
            errors.append(dict(pid=int(name), error_type=type(error).__name__, error=str(error)))
    final = {p.name for p in Path("/proc").iterdir() if p.name.isdigit()}
    if final - initial:
        errors.append(dict(error="New processes require a fresh exclusion scan",
                           pids=sorted(map(int, final - initial))))
    return processes, errors, used


def memory():
    p = Path("/sys/fs/cgroup/memory")
    result = {key: int((p / name).read_text()) for key, name in
              (("usage_bytes", "memory.usage_in_bytes"),
               ("limit_bytes", "memory.limit_in_bytes"),
               ("failcnt", "memory.failcnt"))}
    result["headroom_bytes"] = result["limit_bytes"] - result["usage_bytes"]
    result["stat"] = dict((k, int(v)) for k, v in
                          (line.split() for line in (p / "memory.stat").read_text().splitlines()))
    result["oom_control"] = dict((k, int(v)) for k, v in
                                 (line.split() for line in (p / "memory.oom_control").read_text().splitlines()))
    return result


def main():
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert os.uname().nodename == "nb-5pl2apckdj-0"
    assert os.environ["CUDA_VISIBLE_DEVICES"] == ""
    raw = (RUN / "MAIN_TERMINAL_OBSERVATION_001.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == TERMINAL_SHA
    terminal = json.loads(raw)
    assert terminal["execution_owner"] == OWNER and terminal["safe_for_next_simulator"]
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    for row in terminal["own_process_checks"]:
        old = row["identity"]
        try:
            actual = identity(old["pid"])
        except FileNotFoundError:
            continue
        assert boot != old["boot_id"] or actual["start_ticks"] != old["start_ticks"]
    assert CACHE.resolve(strict=True) == CACHE
    started = time.monotonic()
    candidates, inspected = [], 0
    for directory, dirs, names in os.walk(CACHE, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(directory) / name).is_symlink()]
        for name in names:
            if inspected >= 2048 or time.monotonic() - started > 4:
                break
            inspected += 1
            p = Path(directory) / name
            s = signature(p)
            if s[3] >= 1024**2 and time.time_ns() - s[4] >= 300 * 10**9:
                candidates.append(dict(path=str(p), signature=s))
        if inspected >= 2048 or time.monotonic() - started > 4:
            break
    candidates = sorted(candidates, key=lambda r: r["signature"][3], reverse=True)[:16]
    rows = []
    if candidates:
        rows = json.loads(subprocess.run(
            ["fincore", "-J", "-b", "-o", "FILE,SIZE,RES,PAGES"] +
            [row["path"] for row in candidates], check=True, text=True,
            capture_output=True).stdout)["fincore"]
    by_path = {row["file"]: row for row in rows}
    for row in candidates:
        assert signature(Path(row["path"])) == row["signature"]
        row["resident_bytes"] = by_path[row["path"]]["res"]
    keys = {(row["signature"][0], row["signature"][1]) for row in candidates}
    processes, errors, used = inspect_live(keys)
    print(json.dumps(dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        data_kind="read_only_private_cache_scope_inspection", mutation_performed=False,
        run_id=RUN.name, execution_owner=OWNER, cache_root=str(CACHE), boot_id=boot,
        terminal_ref=dict(path=str(RUN / "MAIN_TERMINAL_OBSERVATION_001.json"),
                          sha256=TERMINAL_SHA),
        scan_file_cap=2048, scan_time_cap_seconds=4, files_inspected=inspected,
        candidates=candidates, resident_bytes=sum(row["resident_bytes"] for row in candidates),
        processes=processes, process_inspection_errors=errors, live_candidate_users=used,
        memory=memory(), exclusion_complete=not errors and not used)))


if __name__ == "__main__":
    main()
