#!/bin/bash
# Manually invoke only after the actual Dolls L12 teacher has been settled.
set -euo pipefail
set -C
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'PY'
import datetime,json
from pathlib import Path
d=json.loads(Path('../ReFATE_collection_progress.json').read_bytes())
n=d['nodes']['perdon-hou'];t=d['tasks']['sort_nesting_dolls_by_size']
terminal=json.load(open('dolls_l12_teacher_terminal.result.json'))
settled=json.load(open('dolls_l12_teacher_settlement.receipt.json'))
assert terminal['run_id']==settled['run_id']=='c2_sort_nesting_dolls_by_size_l12_evo_common_teacher_0001_01a16807'
assert terminal['safe_for_next_simulator'] and settled['safe_for_next_simulator']
assert n['current_task']=='sort_nesting_dolls_by_size' and n['active_run_id'] is None
assert n['active_real_simulators']==0 and not n['launch_inflight']
start=datetime.datetime.fromisoformat(t['latest_segment_started_at'])
gain=datetime.datetime.fromisoformat(t['last_negative_gain_at'])
assert (datetime.datetime.now(datetime.timezone.utc)-max(start,gain)).total_seconds()>=5400
p=json.load(open('general_l23_preparation.result.json'))
reason=('At the real settled Dolls L12 teacher boundary, the original independent-negative shortage '
        'window since2026-11-03T03:51:06.411743Z has elapsed; teacher positives do not reset it. '
        'Preserve both Dolls deficits and prepared L13. General is due after more than two other '
        'segments, has10positive/1negative, and its next frozen L23 is prepared using the unchanged '
        'native200/common recording entry. Arrange nonsealed registered sources are exhausted; '
        'the bounded Insert L41 original-preparer check rejected the actual new-owner L40 sequence, '
        'so preserve that failure without impersonating the old executor. General is a ready '
        'short-budget negative opportunity; no redundant teacher, source replay, sealed access, '
        'clock reset or production-runtime change. Metadata adapters passed9local/9remote syntheticCPU tests.')
with Path('general_l23_switch.args.json').open('x') as f:
 json.dump(dict(terminal_ref=terminal['evidence_ref'],preparation_ref=p['preparation_ref'],reason=reason),f)
PY
env_args='env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 PYTHONDONTWRITEBYTECODE=1'
py=/vla/mxk/projects/Robodojo/.runtime-env/bin/python
a=/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
python3 ./ledger_transaction.py snapshot ./general_l23_switch --arguments ./general_l23_switch.args.json
gzip -c general_l23_switch.request.json |
    sh ./remote.sh --command "bash -o pipefail -c 'gzip -dc | $env_args $py -B $a/switch_dolls_teacher_to_general_l23_v1.py | gzip -c'" \
    > general_l23_switch.result.json.gz 2> general_l23_switch.stderr.log
gzip -dc general_l23_switch.result.json.gz > general_l23_switch.result.json
python3 ./ledger_transaction.py commit ./general_l23_switch
python3 - <<'PY'
import json
from pathlib import Path
p=json.load(open('general_l23_preparation.result.json'))
old=json.load(open('general_l22_preparation.result.json'))
t=json.load(open('dolls_l12_teacher_terminal.result.json'))
with Path('general_l23_boundary.args.json').open('x') as f:
 json.dump(dict(prior_source_run='c2_general_pickup_l22_common_baseline_0001_01a16807',
     run_id='c2_general_pickup_l23_common_baseline_0001_01a16807',
     from_task='sort_nesting_dolls_by_size',preparation_ref=p['preparation_ref'],
     prior_preparation_ref=old['preparation_ref'],resource_settlement_ref=t['evidence_ref'],
     resource_run_id=t['run_id']),f)
PY
sh ./remote.sh --command "$env_args $py -B $a/due_general_l23_from_dolls_boundary_v1.py" \
    < general_l23_boundary.args.json > general_l23_boundary.result.json \
    2> general_l23_boundary.stderr.log
python3 - <<'PY'
import json
from pathlib import Path
b=json.load(open('general_l23_boundary.result.json'))
with Path('general_l23_reservation.args.json').open('x') as f:
 json.dump(dict(boundary_ref=b['boundary_ref']),f)
PY
python3 ./ledger_transaction.py snapshot ./general_l23_reservation --arguments ./general_l23_reservation.args.json
gzip -c general_l23_reservation.request.json |
    sh ./remote.sh --command "bash -o pipefail -c 'gzip -dc | $env_args $py -B $a/reserve_general_append_handoff_v1.py | gzip -c'" \
    > general_l23_reservation.result.json.gz 2> general_l23_reservation.stderr.log
gzip -dc general_l23_reservation.result.json.gz > general_l23_reservation.result.json
python3 ./ledger_transaction.py commit ./general_l23_reservation
python3 - <<'PY'
import json
from pathlib import Path
r=json.load(open('general_l23_reservation.receipt.json'))
with Path('general_l23_binding.args.json').open('x') as f:
 json.dump(dict(dispatch=r['dispatch']),f)
PY
sh ./remote.sh --command "$env_args $py -B $a/baseline_bind_handoff_v1.py" \
    < general_l23_binding.args.json > general_l23_binding.result.json \
    2> general_l23_binding.stderr.log
python3 - <<'PY'
import base64,json
from pathlib import Path
with Path('general_l23_binding.localargs.json').open('x') as f:
 json.dump(dict(binding_b64=base64.b64encode(Path('general_l23_binding.result.json').read_bytes()).decode(),
     receipt_name='ReFATE_chat2_handoff_20261031_01a19072/general_l23_binding.receipt.json'),f)
PY
python3 ./record_baseline_binding.py < general_l23_binding.localargs.json > general_l23_binding.localresult.json
python3 - <<'PY'
import json
from pathlib import Path
old=json.load(open('general_l22_binding.result.json'));new=json.load(open('general_l23_binding.result.json'))
s=Path('general_l22_launch.sh').read_text()
assert s.count(old['context']['sha256'])==1
s=s.replace('general_l22','general_l23').replace(old['run_id'],new['run_id'])
s=s.replace(old['context']['sha256'],new['context']['sha256'])
with Path('general_l23_launch.sh').open('x') as f:f.write(s)
s=Path('dolls_l12_settle.sh').read_text().replace('dolls_l12','general_l23')
s=s.replace('c2_sort_nesting_dolls_by_size_l12_common_baseline_0013_01a16807',new['run_id'])
with Path('general_l23_settle.sh').open('x') as f:f.write(s)
with Path('general_l23_health.args.json').open('x') as f:json.dump(dict(run_id=new['run_id']),f)
print(json.dumps(dict(bound_not_launched=True,run_id=new['run_id'],context=new['context'])))
PY
sh -n general_l23_launch.sh
bash -n general_l23_settle.sh
