"""Bind the existing bounded cache helper to one verified closed private run."""
import hashlib
from pathlib import Path
import sys

import closed_classify_cache_pass_v2 as original

RUN_ID = "c2_pick_from_conveyor_by_image_l10_evo_common_teacher_0001_01a16807"
TERMINAL_SHA = "1977f27640d824cc277d8dc82920b7ce496588c5325314aa85671eb8bd87f672"
PARENT_SHA = "624abb7e8f11aac8ad9a96b61856c684a93643862c113fa678227202f079f9e9"


def configure(layout):
    assert type(layout) is int and layout == 10, "Different closed private run"
    assert hashlib.sha256(Path(original.__file__).read_bytes()).hexdigest() == PARENT_SHA
    original.scope.RUN = original.scope.ROOT / "runs" / RUN_ID
    original.scope.CACHE = original.scope.RUN / "runtime/cache"
    original.scope.TERMINAL_SHA = TERMINAL_SHA
    original.scope.inspect_live = original.live_scope.inspect_live


def main():
    original.configure = configure
    mode = sys.argv[1]
    if mode == "inspect":
        original.inspect(10, sys.argv[2])
    elif mode == "reclaim":
        original.reclaim(10, sys.argv[2], sys.argv[3])
    else:
        raise ValueError("Explicit inspection or bounded pass required")


if __name__ == "__main__":
    main()
