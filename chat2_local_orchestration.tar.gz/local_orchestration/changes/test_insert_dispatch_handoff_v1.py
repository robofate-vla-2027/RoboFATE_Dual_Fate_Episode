"""Offline source-level dispatch checks; no subprocess, ledger, or live request."""
from pathlib import Path
import unittest

import baseline_bind_insert_handoff_v1 as current


class DispatchTests(unittest.TestCase):
    def test_only_the_binder_path_changes(self):
        text = current.source()
        self.assertEqual(
            text.replace("bind_insert_sequence_content_v1.py", "bind_recording_content_v1.py"),
            Path(current.__file__).with_name("baseline_bind_handoff_v1.py").read_text(),
        )

    def test_matching_entry_retains_explicit_devices_and_dispatch_pin(self):
        text = current.source()
        self.assertIn("bind_insert_sequence_content_v1.py", text)
        self.assertNotIn("bind_recording_content_v1.py", text)
        self.assertIn("CUDA_VISIBLE_DEVICES='0,1'", text)
        self.assertIn("'--sha256',hashlib.sha256(p.read_bytes()).hexdigest()", text)
        compile(text, "<offline-insert-dispatch>", "exec")


if __name__ == "__main__":
    unittest.main()
