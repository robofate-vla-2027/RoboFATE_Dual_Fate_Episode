"""Offline synthetic scheduling only; no real ledger, model, API, or Native."""
import copy
import json
import unittest

import test_switch_retained_play_v1 as fixture
import switch_play_to_retained_conveyor_v1 as current


class PlayConveyorTests(unittest.TestCase):
    def setUp(self):
        fixture.RetainedPlayTests.setUp(self)
        tasks = self.d["tasks"]
        self.d["tasks"] = {
            "play_stacking_toy": tasks["organize_table"],
            "pick_from_conveyor_by_image": tasks["play_stacking_toy"],
        }
        self.e["task"] = "play_stacking_toy"
        node = self.d["nodes"]["perdon-hou"]
        node["current_task"] = "play_stacking_toy"
        node["fixed_tasks"] = ["play_stacking_toy", "pick_from_conveyor_by_image"]
        self.d["source_index"]["old"].update(
            task="play_stacking_toy", host="perdon-hou")
        self.d["source_index"]["retained"].update(
            task="pick_from_conveyor_by_image", native_steps=700, native_budget=700,
            synthetic_ns=1793715871844637287)

    def run_switch(self):
        return current.switch_due(self.d, self.e, self.ref, self.retained,
                                  self.at, "Synthetic fixture, not scientific data")

    def test_only_task_and_native_budget_bindings_change(self):
        text = current.source().replace(
            "play_stacking_toy", "general_pickup").replace(
            "pick_from_conveyor_by_image", "classify_objects").replace(
            '== s["native_budget"] == 700', '== s["native_budget"] == 1100')
        self.assertEqual(text, current.parent.source())

    def test_preserves_sources_peers_counts_and_nanoseconds(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"],
                         "pick_from_conveyor_by_image")
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        self.assertEqual(json.loads(json.dumps(out))["ledger"]["source_index"],
                         before["source_index"])

    def test_teacher_positive_does_not_reset_negative_window(self):
        self.e["summary"]["qualified_positive"] = True
        self.d["tasks"]["play_stacking_toy"].update(
            qualified_count=3, last_core_gain_at="2026-10-31T11:30:00+00:00")
        self.run_switch()
        event = self.d["nodes"]["perdon-hou"]["task_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_or_recent_negative_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["tasks"]["play_stacking_toy"].update(
            negative_count=1, last_negative_gain_at="2026-10-31T11:30:00+00:00",
            last_core_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_unsettled_or_not_due_rejected(self):
        self.d["nodes"]["perdon-hou"]["active_real_simulators"] = 1
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_retained_attempt_refusal_or_invalid_source_rejected(self):
        for key, value in (
            ("teacher_attempt_history", [{"synthetic": True}]),
            ("provider_safety_refusal", {"synthetic": True}),
            ("teacher_replay_prohibited", True), ("counted_in_quota", True),
            ("complete_readback", False), ("native_budget", 1200),
            ("native_steps", 699), ("task", "play_stacking_toy"),
        ):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_unsafe_resource_or_wrong_executor_rejected(self):
        self.e["safe_for_next_simulator"] = False
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["execution_owner"] = "synthetic-wrong-owner"
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
