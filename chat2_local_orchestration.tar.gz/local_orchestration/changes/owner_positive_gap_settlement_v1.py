"""Same actual-readback settlement; separate qualified backups from core count."""
from pathlib import Path
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
text = gap.pinned_text(Path(__file__).with_name("common_owner_settlement_v2.py"),
                       "1a27374955b2cbee923e2d354f92fa39d42e72c3f2f148dea93359cce2ed2375")
_namespace = gap.namespace()
exec(compile(gap.settlement_source(text), __file__ + "::capacity", "exec"), _namespace)
_namespace["OWNER"] = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
settle = _namespace["settle"]
export_current_counts = _namespace["export_current_counts"]
