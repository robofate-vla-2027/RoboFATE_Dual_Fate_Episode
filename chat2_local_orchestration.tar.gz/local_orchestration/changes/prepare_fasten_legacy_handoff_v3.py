"""Reuse the frozen Fasten projection through its last admitted original L6."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("prepare_fasten_legacy_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "1096ef710832385025628729f9bf75d71d968cdbbda4d82204c5863efa5a129e"):
        raise ValueError("Original Fasten metadata preparation changed")
    text = raw.decode()
    for old, new in (
        ("layout not in (2, 3)", "layout not in (2, 3, 4, 5, 6)"),
        ("Only frozen Fasten L2 descriptor and next L3 are in scope",
         "Only frozen Fasten descriptors L2 through L6 are in scope"),
    ):
        if text.count(old) != 1:
            raise ValueError("Original Fasten preparation interface changed")
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::original_l5_l6", "exec"), globals())
