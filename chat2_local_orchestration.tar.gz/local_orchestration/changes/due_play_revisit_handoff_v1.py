import sys,json,base64,datetime,copy,hashlib
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import owner_reservation_handoff_v1 as helper;import common_runtime as runtime
assert helper.OWNER=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0'
def verify_ordered_play_append(source, manifest, prior):
 i=source['layout_id']
 assert type(i) is int and i>=7
 assert source['task']==manifest['task']==prior['task']=='play_stacking_toy'
 assert prior['initial_source_sequence']==list(range(i))
 assert source['required_accounted_prefix']==list(range(i))
 assert source['source_sequence']==manifest['initial_source_sequence']==list(range(i+1))
 assert manifest['original_partition']==prior['original_partition']
 assert i<prior['original_partition']['available_layout_count'] and i not in prior['original_partition']['reserved_final']
 extension=manifest['source_sequence_extension']
 assert extension['prior_sequence']==list(range(i)) and extension['source_sequence']==list(range(i+1)) and extension['added_layout']==i
 for k,v in prior['layouts'].items():assert manifest['layouts'][k]==v
 row=manifest['layouts'][str(i)]
 for k in ['layout_id','layout_ref','initialization_content_sha256','group_id','split']:assert row[k]==source[k]
 return i


x=json.load(sys.stdin);d=json.loads(base64.b64decode(x['ledger_b64']));b=runtime.document(runtime.read_pin(x['boundary_ref']));n=d['nodes']['perdon-hou'];at=datetime.datetime.now(datetime.timezone.utc).isoformat();release=runtime.document(runtime.read_pin(b['runtime_release']))
now=datetime.datetime.fromisoformat(at);old=d['tasks'][x['from_task']];t=d['tasks']['play_stacking_toy'];assert x['from_task']=='plug_in_charger' and n['current_task']==x['from_task'] and n['active_run_id'] is None and n['active_real_simulators']==0 and not n['launch_inflight']
current=b['resource_predecessor'];r=d['reservations'][current['source_id']];sr=d['source_index'][current['source_id']]
assert current['safe_for_next_simulator'] and n['last_owned_resource_settlement']==current['ref'] and r['positive_slots']==r['negative_slots']==0 and r['quota_reserved'] is False and r['negative_quota_reserved'] is False and sr['task']==x['from_task'] and sr['complete_readback'] is True
if current['schema']=='closed_teacher_resource_v1':
 a=sr['active_teacher_attempt'];assert r['status']=='shared_Evo_teacher_settled' and r['current_attempt_settlement']==current['summary_ref'] and a['run_id']==current['run_id'] and a['status']=='settled' and a['terminal_observation']==current['ref']
else:
 assert current['schema']=='closed_baseline_resource_v1' and r['status'].startswith('settled_') and r['run_id']==current['run_id'] and r['settlement']==current['settlement_ref'] and sr['settlement']==current['settlement_ref']
start=datetime.datetime.fromisoformat(old['latest_segment_started_at']);last_gain=datetime.datetime.fromisoformat(old['last_core_gain_at']) if old.get('last_core_gain_at') else start;elapsed=(now-max(last_gain,start)).total_seconds()
def negative_shortfall_window(task, now):
 if task['negative_count']>=task['negative_quota']:return None
 start=datetime.datetime.fromisoformat(task['latest_segment_started_at'])
 last=task.get('last_negative_gain_at')
 if last is None:
  return (now-start).total_seconds() if task['negative_count']==0 else None
 return (now-max(start,datetime.datetime.fromisoformat(last))).total_seconds()
negative_elapsed=negative_shortfall_window(old,now)
assert elapsed>=5400 or (negative_elapsed is not None and negative_elapsed>=5400),'No existing low-yield window reached'
assert t['scheduling_state']=='deferred' and t['qualified_count']<t['quota'] and t['negative_count']<t['negative_quota']
arrange_deferred=datetime.datetime.fromisoformat(t['deferred_at']);segments=[z for z in n['task_segments'] if z.get('task') not in ['play_stacking_toy',x['from_task']] and datetime.datetime.fromisoformat(z['ended_at'])>arrange_deferred];assert segments and datetime.datetime.fromisoformat(segments[-1]['ended_at'])<=start
reason=x['reason']
event=dict(at=at,task=x['from_task'],started_at=old['latest_segment_started_at'],ended_at=at,duration_minutes=(now-start).total_seconds()/60,outcome='deferred_after_low_yield_review',seconds_since_last_core_gain=elapsed,last_core_gain_at=old.get('last_core_gain_at'),seconds_since_last_negative_gain=negative_elapsed,last_negative_gain_at=old.get('last_negative_gain_at'),negative_shortfall_clock_reset=False,counts_at_end={'positive':old['qualified_count'],'negative':old['negative_count']},deficits={'positive':old['quota']-old['qualified_count'],'negative':old['negative_quota']-old['negative_count']},last_settlement=current['summary_ref'],resource_terminal=current['ref'],reason=reason)
n.setdefault('task_segments',[]).append(event);old.setdefault('scheduling_history',[]).append(copy.deepcopy(event));old.update(status='pending',phase='deferred_after_settled_no_gain',scheduling_state='deferred',deferred_current=True,deferred_at=at,deferred_reason=reason,revisit_condition='Next safe boundary after one other task completes or two other task work segments end; preserve sources,counts,costs.',active_run_id=None,updated_at=at)
t.setdefault('scheduling_history',[]).append(dict(at=at,event='activate_due_revisit_after_two_other_segments',previous_segment_started_at=t['latest_segment_started_at'],prior_deferred_at=t['deferred_at'],prior_deferred_reason=t.get('deferred_reason'),source_id=b['next_preparation']['prepared']['source']['source_id'],positive_gap=t['quota']-t['qualified_count'],negative_gap=t['negative_quota']-t['negative_count'],reason=reason,completed_other_segments=[segments[-1],event]))
t.update(status='pending',phase='due_revisit_prepared',scheduling_state='active',deferred_current=False,latest_segment_started_at=at,updated_at=at);n.update(current_task='play_stacking_toy',updated_at=at)
n['last_owned_resource_settlement']=current['ref']
old.setdefault('retained_failed_source_revisit_records',[]).append(dict(source_id=current['source_id'],resource_run_id=current['run_id'],source_run_id=sr['run_id'],settlement=current['settlement_ref'],native_budget=sr['native_budget'],teacher_attempted=current['schema']=='closed_teacher_resource_v1',kept_for_revisit=True,automatic_replay=False,blocking_diagnosis='No diagnosis inferred from deferral; retain the actual source result and all previous interruptions'))
assert not n.get('owned_resource_launch_hold',False) and n['active_chat_id']=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0' and n['current_task']=='play_stacking_toy' and n['active_run_id'] is None and n['active_real_simulators']==0
assert b['next_preparation']['prepared']['native_step_limit']==1200 and b['next_preparation']['prepared']['source']['task']=='play_stacking_toy'
assert n['last_owned_resource_settlement']==b['resource_predecessor']['ref'] and b['resource_predecessor']['safe_for_next_simulator'] is True
assert release['native_wall_seconds']==2400 and release['teacher_wall_seconds']==3600 and release['foreground_entry']=='/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/collect_recording_content_v1.py'
n.setdefault('runtime_adoption_history',[]).append(copy.deepcopy(n['current_runtime_adoption']));n['current_runtime_adoption']={'at':at,'runtime_release':b['runtime_release'],'stage':'baseline_prelaunch_adoption','actual_native_started':False,'actual_teacher_verified':False,'actual_full_readback_verified':False};n.setdefault('dispatch_history',[]).append(copy.deepcopy(n['current_dispatch']));n['current_dispatch']={'data_kind':'baseline_wall_defaults_not_dispatch','native_wall_seconds':release['native_wall_seconds'],'teacher_wall_seconds':3600};n['current_common_foreground']['actual_entry']=release['foreground_entry']
out,dispatch=helper.reserve(d,b,at);node=out['nodes']['perdon-hou'];dispatch.update(outline_sha256=x['outline_sha256'],directive_sha256=x['directive_sha256']);node['current_dispatch']=copy.deepcopy(dispatch);out['reservations'][dispatch['source_id']]['dispatch']=copy.deepcopy(dispatch);
import collection_group_binding as group_binding
prepared=b['next_preparation']['prepared'];group_binding.load_native_layout(prepared);assert prepared['binding_schema']==group_binding.SCHEMA
source=prepared['source'];row=out['source_index'][dispatch['source_id']];assert row['source_group_id']==source['group_id']
row.update(group_id=source['group_id'],preparation=b['next_preparation']['ref'],required_accounted_prefix=copy.deepcopy(source['required_accounted_prefix']),source_sequence=copy.deepcopy(source['source_sequence']),layout_id=source['layout_id'])
# Append only the next source manifest; historical member labels stay intact.
task=out['tasks']['play_stacking_toy'];registry=out['split_manifests']['play_stacking_toy'];newref=b['next_preparation']['prepared']['provenance']['split'];sp=Path(newref['path']);assert hashlib.sha256(sp.read_bytes()).hexdigest()==newref['sha256'];sd=json.loads(sp.read_bytes());extension=sd['source_sequence_extension'];parent=extension['parent_manifest'];pp=Path(parent['path']);ps=pp.stat();pb=pp.read_bytes();assert pp.is_file() and len(pb)==ps.st_size<8*1024**2 and (pp.stat().st_size,pp.stat().st_mtime_ns)==(ps.st_size,ps.st_mtime_ns);assert hashlib.sha256(pb).hexdigest()==parent['sha256'];import source_binding as original;prior=original.decode(pb);verify_ordered_play_append(source,sd,prior);assert {'path':registry['path'],'sha256':registry['sha256']}==parent and {'path':task['split_manifest_ref'],'sha256':task['split_manifest_sha256']}==parent;assert extension['original_partition_preserved'] is True and extension['prior_member_labels_preserved'] is True and extension['sealed_content_read'] is False;adoption=dict(at=at,event='next_Play_collection_source_manifest_append',prior_manifest=parent,manifest=newref,source_id=source['source_id'],run_id=dispatch['run_id'],actual_adoption=True,native_started=False,original_memberships_preserved=True,positive_delta=0,negative_delta=0);registry.setdefault('manifest_history',[]).append(copy.deepcopy(adoption));registry.update(path=newref['path'],sha256=newref['sha256'],scope='original_bank0_ordered_collection_append_prior_labels_preserved');task.setdefault('split_manifest_history',[]).append(copy.deepcopy(adoption));task.update(split_manifest_ref=newref['path'],split_manifest_sha256=newref['sha256']);node.setdefault('source_sequence_adoption_history',[]).append(copy.deepcopy(adoption))
node['current_reservation_helper']=b['metadata_adapter'];node['last_ledger_update_note']=reason
receipt={'revision':out['revision'],'at':at,'run_id':dispatch['run_id'],'source_id':dispatch['source_id'],'dispatch':dispatch,'boundary_ref':x['boundary_ref'],'positive_delta':0,'negative_delta':0,'node_positive':node['qualified_count'],'node_negative':node['negative_count'],'metadata_helper':b['metadata_adapter'],'scheduling_event':event};print(json.dumps({'ledger':out,'receipt':receipt},ensure_ascii=False))
