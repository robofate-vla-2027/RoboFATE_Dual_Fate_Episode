"""Same metadata operation, with matching Fasten1900 entry references."""
from pathlib import Path
import common_runtime as runtime
import teacher_settle_handoff_v5 as previous

CHANGES = (('teacher_ledger_owner_handoff_v4', 'teacher_ledger_owner_handoff_v5'),)


def source():
    runtime.read_pin({"path": str(Path(__file__).with_name('teacher_settle_handoff_v5.py')),
                      "sha256": '02e215218e35e6e2539d67b75e7c77df0b8e2424139eb5478ff88391655f4371'})
    text = previous.source()
    for old, new in CHANGES:
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten1900_metadata", "exec"), globals())
