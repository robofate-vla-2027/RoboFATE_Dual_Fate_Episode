"""Use the exact Conveyor legacy settlement view in the existing boundary helper."""
import hashlib
from pathlib import Path

parent = Path(__file__).with_name("conveyor_boundary_handoff_v1.py")
raw = parent.read_bytes()
if hashlib.sha256(raw).hexdigest() != "7c75e68f276b50d11e9460f57a458ca63e246aeb1079c958253cd64ab2c99efb":
    raise ValueError("Conveyor boundary parent changed")
text = raw.decode()
before = "import preparation_metadata_compat_v4 as legacy"
if text.count(before) != 1:
    raise ValueError("Legacy projection import seam changed")
text = text.replace(before, "import preparation_metadata_conveyor_v1 as legacy", 1)
exec(compile(text, str(parent) + "::conveyor_legacy_view", "exec"), globals())
