"""Observe an auxiliary-restore failure before actor creation; do not qualify it."""
import hashlib
from pathlib import Path

NATIVE_SHA = "e9d1f23b5ae9dc931bc8615f2f163fc02e4ba0b7ed0564d2b9fc56ab52d0dcdb"


def verified_pre_actor_auxiliary_failure(context, failure, comparison, artifacts,
                                        native_sha, auxiliary_pairs):
    if native_sha != NATIVE_SHA:
        return False
    if not all(isinstance(v, dict) for v in (context, failure, comparison, artifacts)):
        return False
    if len(artifacts) != 7 or any(v is not False for v in artifacts.values()):
        return False
    t1, total = context.get("t1"), context.get("native_limit")
    if type(t1) is not int or type(total) is not int or not 0 < t1 < total:
        return False
    if context.get("remaining_steps") != total - t1:
        return False
    expected = dict(source_id=context.get("source_id"), run_id=context.get("run_id"),
                    stage="initial_boundary_saved", type="RuntimeError",
                    message="Task auxiliary state mismatch", native_used=t1,
                    actual_control_steps=10*t1, native_done=False, native_success=False,
                    qualified=False, provider_retry_allowed=False)
    if any(type(failure.get(k)) is not type(v) or failure.get(k) != v
           for k, v in expected.items()):
        return False
    if any(comparison.get(k) is not v for k, v in (
        ("qualified", False), ("old_suffix_reuse_allowed", False),
        ("rtx_profile_exact", True), ("requested_rtx_profile_exact", True))):
        return False
    rows = comparison.get("task_auxiliary")
    names = ["initial_task_auxiliary.json", f"task_auxiliary_{t1:06d}.json"]
    if not isinstance(rows, list) or len(rows) != 2 or set(auxiliary_pairs) != set(names):
        return False
    for row, name in zip(rows, names):
        if row.get("file") != name or type(row.get("typed_json_exact")) is not bool:
            return False
        pair = auxiliary_pairs[name]
        if row.get("sha256") != pair["sha256"]:
            return False
        if row["typed_json_exact"] is not pair["typed_json_exact"]:
            return False
    return any(row["typed_json_exact"] is False for row in rows)


def source(parent_text=None):
    import inspect
    if parent_text is None:
        import teacher_terminal_handoff_v6 as previous
        parent = Path(previous.__file__)
        if hashlib.sha256(parent.read_bytes()).hexdigest() != (
                "02071841ad1d4dbe30856c10c9cfd649eb2823a1df9e462700f84ebad09d7225"):
            raise ValueError("Pinned terminal observer changed")
        parent_text = previous.source()
    prefix = ("NATIVE_SHA = " + repr(NATIVE_SHA) + "\n" +
              inspect.getsource(verified_pre_actor_auxiliary_failure) + "\n")
    old = "x=json.load(sys.stdin);fg=collect.base;"
    if parent_text.count(old) != 1:
        raise ValueError("Terminal entry seam changed")
    text = parent_text.replace(old, prefix + old, 1)
    old = "pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha)"
    new = """aux_path=run/'restore_auxiliary_render_comparison.json'
aux=doc(aux_path) if aux_path.exists() else None
pairs={}
if isinstance(aux,dict):
 source_run=Path(c['source_context_ref']['path']).parent
 for name in ['initial_task_auxiliary.json',f"task_auxiliary_{c['t1']:06d}.json"]:
  paths=[source_run/name,run/name]
  assert all(p.is_file() and not p.is_symlink() for p in paths)
  exact=len({json.dumps(doc(p),sort_keys=True,allow_nan=False) for p in paths})==1
  pairs[name]=dict(sha256=[ref(p)['sha256'] for p in paths],typed_json_exact=exact)
pre_aux=bool(comparison is None and verified_pre_actor_auxiliary_failure(c,failure,aux,artifacts,native_source_sha,pairs))
pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha) or pre_aux"""
    if text.count(old) != 1:
        raise ValueError("Pre-actor observation seam changed")
    text = text.replace(old, new, 1)
    old = "p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json');"
    new = """d['actor_role_observation'].update(auxiliary_pre_actor_failure_verified=pre_aux,auxiliary_comparison_ref=ref(aux_path) if aux else None,auxiliary_file_pairs=pairs)
p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json');"""
    if text.count(old) != 1:
        raise ValueError("Terminal evidence seam changed")
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::auxiliary_pre_actor_observation", "exec"),
         globals())
