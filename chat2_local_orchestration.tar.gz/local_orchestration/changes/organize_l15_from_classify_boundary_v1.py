"""Reuse the Organize source/resource boundary without changing production."""
import hashlib
from pathlib import Path


def validate_pair(prepared, baseline, teacher):
    source = prepared["source"]
    if not (
        prepared["native_step_limit"] == 1000
        and source["task"] == baseline["task"] == teacher["task"] == "organize_table"
        and source["source_id"] == "organize_table_b0_l15_5e2f05f1dbd6a2fb"
        and source["layout_id"] == 15
        and source["source_sequence"] == list(range(16))
        and source["required_accounted_prefix"] == list(range(15))
        and baseline["source_id"] == teacher["source_id"]
        == "organize_table_b0_l14_ab614f8c58a8a134"
    ):
        raise ValueError("Not the retained Organize L14 to L15 boundary")


def source():
    path = Path(__file__).with_name("organize_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "4395da6aab171a405a3d74167143e8a5df3f5778a8d35eb853ec330ed4a4a98f"):
        raise ValueError("Frozen resource boundary changed")
    text = raw.decode()
    for old, new in (
        ("current['task']=='insert_tubes'", "current['task']=='classify_objects'"),
        ("current=doc(x['current_resource_ref']);",
         "validate_pair(prepared,be,te)\ncurrent=doc(x['current_resource_ref']);"),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen resource parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::classify_organize_l15", "exec"),
         globals())
