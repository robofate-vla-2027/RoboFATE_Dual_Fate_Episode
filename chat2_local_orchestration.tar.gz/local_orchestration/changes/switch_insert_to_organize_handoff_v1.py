import sys,json,base64,datetime,hashlib
from pathlib import Path
def switch_due(d,e,eref,at,review=None):
 import copy,datetime
 owner='01a19072-9e5e-7e02-b77a-8f115cfc9bd0';n=d['nodes']['perdon-hou'];p=d['tasks']['insert_tubes'];t=d['tasks']['organize_table'];now=datetime.datetime.fromisoformat(at)
 assert d['campaign_id']=='refate-20261022-97baf70d5128' and n['active_chat_id']==owner and n['current_task']=='insert_tubes'
 assert not n['user_pause_active'] and not n['user_stop'] and not n.get('owned_resource_launch_hold',False)
 assert n['active_run_id'] is None and n['active_real_simulators']==0 and not n['launch_inflight'] and n['baseline_accounting']['baseline_attempts_running']==0
 assert len(n['completed_pending_sources'])<=2 and len(n['common_pending_readback_run_ids'])<=2
 assert e['execution_owner']==owner and e['task']=='insert_tubes' and e['safe_for_next_simulator'] is True and n['last_owned_resource_settlement']==eref
 assert e['summary'] and e['summary']['run_id']==e['run_id'] and e['new_positive']==e['new_negative']==0 and e['native_success'] is False and e['first_readback_passed'] is True
 assert d['source_index'][e['source_id']]['host']=='perdon-hou' and d['source_index'][e['source_id']]['task']=='insert_tubes'
 s=d['source_index'][e['source_id']];r=d['reservations'][e['source_id']]
 assert e['schema']=='refate.common_baseline.main_settlement.v1' and s['run_id']==r['run_id']==e['run_id'] and s['context']==e['context']
 assert s['settlement']==r['settlement']==eref and s['complete_readback']
 assert r['status']=='settled_native_failure_no_quota' and r['positive_slots']==r['negative_slots']==0 and not r['quota_reserved'] and not r['negative_quota_reserved']
 assert not s.get('teacher_attempt_history') and not s.get('active_teacher_attempt') and not s.get('provider_safety_refusal')
 assert not s.get('qualified_count',0) and not s.get('negative_count',0)
 assert p['reserved_count']==p['negative_reserved_count']==t['reserved_count']==t['negative_reserved_count']==0
 start=datetime.datetime.fromisoformat(p['latest_segment_started_at']);gain=datetime.datetime.fromisoformat(p['last_core_gain_at']) if p.get('last_core_gain_at') else start
 no_gain=(now-max(start,gain)).total_seconds()
 if review is None:
  import negative_shortfall_deferral_handoff_v1 as checker
  review=checker.review
 shortfall=review(d,e['source_id'])
 assert shortfall['trigger']=='negative_only_five_consecutive_independent_DM_failures' and shortfall['negative_shortfall_clock_reset'] is False
 assert 'organize_table' in n['fixed_tasks'] and t['assigned_host']=='perdon-hou' and t['scheduling_state']=='deferred'
 assert p['qualified_count']==p['positive_quota']==10 and p['negative_count']<p['negative_quota']==10
 assert 0<=t['qualified_count']<t['positive_quota']==10 and t['negative_count']<t['negative_quota']==10
 deferred=datetime.datetime.fromisoformat(t['deferred_at']);due=[v for v in n['task_segments'] if v['task']!='organize_table' and datetime.datetime.fromisoformat(v['ended_at'])>deferred]
 assert len(due)>=2
 transition=dict(at=at,from_task='insert_tubes',to_task='organize_table',terminal=eref,reason='Actual settled Insert independent DM failure; original five-consecutive-failure review satisfied with positive quota full. Revisit due Organize using its next unused prepared L13, budget1000. No teacher on positive-full Insert; no source replay, counter reset or sealed-layout use.',seconds_since_last_core_gain=no_gain,insert_positive_deficit=p['positive_quota']-p['qualified_count'],insert_negative_deficit=p['negative_quota']-p['negative_count'],organize_negative_deficit=t['negative_quota']-t['negative_count'],source_order_preserved=True,negative_lowyield_counters_reset=False)
 segment=dict(at=at,task='insert_tubes',started_at=p['latest_segment_started_at'],ended_at=at,duration_minutes=(now-start).total_seconds()/60,outcome='deferred_after_low_yield_review',seconds_since_last_core_gain=no_gain,last_core_gain_at=p.get('last_core_gain_at'),counts_at_end=dict(positive=p['qualified_count'],negative=p['negative_count']),deficits=dict(positive=transition['insert_positive_deficit'],negative=transition['insert_negative_deficit']),last_settlement=e['summary_ref'],resource_terminal=eref,reason=transition['reason'])
 p.setdefault('scheduling_history',[]).append({k:copy.deepcopy(p.get(k)) for k in ['status','scheduling_state','latest_segment_started_at','last_core_gain_at','deferred_at']});p.update(status='pending',scheduling_state='deferred',deferred_current=True,deferred_reason=transition['reason'],deferred_at=at,latest_deferral=transition,active_run_id=None,phase='low_yield_deferred_after_settlement',updated_at=at)
 t.setdefault('scheduling_history',[]).append({k:copy.deepcopy(t.get(k)) for k in ['status','scheduling_state','latest_segment_started_at','deferred_at']});t.update(status='collecting',scheduling_state='active',deferred_current=False,last_revisit_at=at,latest_segment_started_at=at,revisit_reason=transition['reason'],phase='due_revisit_preparation',updated_at=at)
 p.setdefault('retained_failed_source_revisit_records',[]).append(dict(source_id=e['source_id'],source_run_id=e['run_id'],settlement=eref,native_budget=e['native_budget'],teacher_attempted=False,kept_as_failed_baseline=True,teacher_needed=False,automatic_replay=False));segment['negative_shortfall_review']=shortfall;segment['scheduling_trigger']=shortfall['trigger'];n.setdefault('task_segments',[]).append(segment);n.setdefault('scheduling_history',[]).append(transition);n.update(current_task='organize_table',phase='due_revisit_preparation',updated_at=at)
 d['revision']+=1;d['updated_at']=at
 return dict(ledger=d,receipt=dict(schema='refate.due_task_revisit.v1',at=at,revision=d['revision'],transition=transition,positive_delta=0,negative_delta=0,node_positive=n['qualified_count'],node_negative=n['negative_count'],lock_inode=27555308))

x=json.load(sys.stdin);d=json.loads(base64.b64decode(x['ledger_b64']));eref=x['terminal_ref'];p=Path(eref['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==eref['sha256'];e=json.loads(p.read_text());out=switch_due(d,e,eref,datetime.datetime.now(datetime.timezone.utc).isoformat());print(json.dumps(out))
