import sys,json,datetime
from pathlib import Path
x=json.load(sys.stdin);run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];c=json.loads((run/'CONTEXT_001.json').read_text());session=Path(c['runtime_binding']['run_dir']);o={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':x['run_id']}
def tail(p,n):
 if not p.exists():return None
 with p.open('rb') as f:f.seek(max(0,p.stat().st_size-n));return f.read().decode(errors='replace')
for name in ['actual_t1_verified.json','recording_progress.json','writer_close.json','result.json','failure.json','native_wait.json']:
 p=run/name
 if p.exists() and p.stat().st_size<64000:o[name]=json.loads(p.read_text())
for rel in ['agent/provider_safety.json','oci/LIFECYCLE.json','session-result.json']:
 p=session/rel
 if p.exists() and p.stat().st_size<20000:o[rel]=json.loads(p.read_text())
p=run/'native_actions.jsonl'
if p.exists():
 with p.open() as f:
  a=[json.loads(l) for l in f]
 o['last_action']={k:a[-1].get(k) for k in ['index','role','native_count_after','actual_control_steps','native_success','terminated','truncated','wall_before_ns','wall_after_ns']} if a else None;o['actual_teacher_actions']=sum(e.get('index',-1)>=c['t1'] and 'prefix' not in e.get('role','') for e in a)
o['native_log_tail']=tail(run/'stdout.log',1000);print(json.dumps(o))
