"""Synthetic pure metadata checks. No ledger, model, network, or Native calls."""
import ast
import copy
import datetime
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
TEXT = (HERE / "due_play_revisit_handoff_v1.py").read_text()
TREE = ast.parse(TEXT)
NAMES = {"negative_shortfall_window", "verify_ordered_play_append"}
FUNCTIONS = [node for node in TREE.body if isinstance(node, ast.FunctionDef)
             and node.name in NAMES]
assert {node.name for node in FUNCTIONS} == NAMES
namespace = {"datetime": datetime}
exec(compile(ast.Module(body=FUNCTIONS, type_ignores=[]), "<synthetic-pure-metadata>",
             "exec"), namespace)
window = namespace["negative_shortfall_window"]
verify = namespace["verify_ordered_play_append"]
NOW = datetime.datetime(2026, 10, 31, 10, 0, tzinfo=datetime.timezone.utc)


def reject_live_effect(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in {
        "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn",
    }:
        raise RuntimeError("Synthetic metadata test forbids " + event)


sys.addaudithook(reject_live_effect)


def task():
    return dict(negative_count=0, negative_quota=10,
                latest_segment_started_at=(NOW-datetime.timedelta(hours=2)).isoformat(),
                last_core_gain_at=(NOW-datetime.timedelta(minutes=1)).isoformat())


def ordered_case(i=11):
    prior = dict(task="play_stacking_toy", initial_source_sequence=list(range(i)),
                 original_partition={"available_layout_count": 55, "reserved_final": [53, 54]},
                 layouts={str(k): {"synthetic": k} for k in range(i)})
    source = dict(task="play_stacking_toy", layout_id=i,
                  required_accounted_prefix=list(range(i)), source_sequence=list(range(i+1)),
                  layout_ref={"path": "/synthetic/not_authority.json", "sha256": "a"*64},
                  initialization_content_sha256="b"*64, group_id="synthetic_group",
                  split="student_dev")
    manifest = copy.deepcopy(prior)
    manifest["initial_source_sequence"] = list(range(i+1))
    manifest["source_sequence_extension"] = dict(prior_sequence=list(range(i)),
        source_sequence=list(range(i+1)), added_layout=i)
    manifest["layouts"][str(i)] = {k: copy.deepcopy(source[k]) for k in (
        "layout_id", "layout_ref", "initialization_content_sha256", "group_id", "split")}
    return source, manifest, prior


class Tests(unittest.TestCase):
    def test_zero_negative_window_ignores_recent_teacher_positive(self):
        value = task()
        before = copy.deepcopy(value)
        self.assertEqual(window(value, NOW), 7200)
        self.assertEqual(value, before)
        value["last_core_gain_at"] = NOW.isoformat()
        self.assertEqual(window(value, NOW), 7200)

    def test_real_negative_gain_and_segment_bound_are_preserved(self):
        value = task()
        value.update(negative_count=1,
                     last_negative_gain_at=(NOW-datetime.timedelta(minutes=30)).isoformat())
        self.assertEqual(window(value, NOW), 1800)
        value["last_negative_gain_at"] = (NOW-datetime.timedelta(hours=3)).isoformat()
        self.assertEqual(window(value, NOW), 7200)

    def test_unknown_timestamp_with_existing_negatives_is_not_invented(self):
        value = task()
        value["negative_count"] = 1
        self.assertIsNone(window(value, NOW))
        value["negative_count"] = 10
        self.assertIsNone(window(value, NOW))

    def test_original_ordered_append_accepts_only_unchanged_prefix(self):
        source, manifest, prior = ordered_case()
        self.assertEqual(verify(source, manifest, prior), 11)
        manifest["layouts"]["0"]["synthetic"] = "changed"
        with self.assertRaises(AssertionError):
            verify(source, manifest, prior)

    def test_reordered_and_sealed_sources_are_rejected(self):
        source, manifest, prior = ordered_case()
        source["source_sequence"] = list(reversed(source["source_sequence"]))
        with self.assertRaises(AssertionError):
            verify(source, manifest, prior)
        with self.assertRaises(AssertionError):
            verify(*ordered_case(53))

    def test_binding_retains_original_budget_and_current_content_entry(self):
        self.assertIn("native_step_limit']==1200", TEXT)
        self.assertIn("x['from_task']=='plug_in_charger'", TEXT)
        self.assertIn("n['current_task']=='play_stacking_toy'", TEXT)
        self.assertIn("/collect_recording_content_v1.py'", TEXT)
        self.assertIn("native_wall_seconds']==2400", TEXT)
        self.assertIn("teacher_wall_seconds']==3600", TEXT)
        self.assertIn("verify_ordered_play_append(source,sd,prior)", TEXT)


if __name__ == "__main__":
    unittest.main()
