"""Keep General's resource boundary distinct from the Classify L27 predecessor."""
import hashlib
from pathlib import Path

import due_classify_l47_boundary_v1 as previous

SEQUENCE = previous.SEQUENCE


def validate_pair(previous_preparation, prepared):
    ps, ns = previous_preparation["source"], prepared["source"]
    if not (ps["task"] == ns["task"] == "classify_objects"
            and ps["source_sequence"] == ns["source_sequence"] == SEQUENCE
            and ps["layout_id"] == 27 and ns["layout_id"] == 37
            and ps["required_accounted_prefix"] == SEQUENCE[:19]
            and ns["required_accounted_prefix"] == SEQUENCE[:20]
            and ns["required_accounted_prefix"] ==
            ps["required_accounted_prefix"] + [ps["layout_id"]]):
        raise ValueError("Not the next original Classify source after settled L27")


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != (
            "8e9bb4d94a2821e979acee4a41cf0d5b8a682e13713bb2b34efbc0ec7ff686e9"):
        raise ValueError("Frozen resource boundary changed")
    return previous.source()


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::classify_l37_metadata", "exec"),
         globals())
