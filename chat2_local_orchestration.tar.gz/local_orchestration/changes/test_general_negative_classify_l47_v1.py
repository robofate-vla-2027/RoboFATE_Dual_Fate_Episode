"""Synthetic CPU metadata only; no live ledger, model, simulator, or peer calls."""
import copy
import unittest
from unittest.mock import patch

import test_dolls_bottles_revisit_v1 as original
import switch_general_negative_to_classify_l47_v1 as current

original.OLD, original.NEXT = "general_pickup", "classify_objects"
REAL_REVIEW = current.review_negative_shortfall


class GeneralNegativeMetadataTests(unittest.TestCase):
    def setUp(self):
        original.DueBottlesTests.setUp(self)
        self.at = "2026-10-31T10:30:00+00:00"
        task = self.d["tasks"]["general_pickup"]
        task.update(qualified_count=10, negative_count=1,
                    last_negative_gain_at="2026-10-31T10:01:00+00:00",
                    last_core_gain_at="2026-10-31T10:29:00+00:00",
                    source_sequence=[1, 2, 3, 4, 0] + list(range(5, 23)))
        self.prep["native_step_limit"] = 1100
        self.prep["source"].update(layout_id=47, source_sequence=list(current.SEQUENCE),
                                   required_accounted_prefix=current.SEQUENCE[:15])
        self.d["source_index"], self.d["reservations"], self.docs = {}, {}, {}
        for i in range(18, 23):
            sid = f"general_pickup_b0_l{i}_synthetic"
            ref = dict(path="synthetic/" + sid, sha256=f"{i:064x}")
            context = {"synthetic_context": i}
            evidence = dict(
                schema="refate.common_baseline.main_settlement.v1", data_kind="actual",
                task="general_pickup", source_id=sid, run_id=sid,
                execution_owner=current.OWNER, context=context, native_budget=200,
                first_readback_passed=True, native_success=False, new_positive=0,
                new_negative=0, safe_for_next_simulator=True, summary_ref=ref,
                summary={"native_success": False, "qualified_negative": False},
                process_closure={"checks": [
                    {"role": role, "original_process_absent": True,
                     "identity": {"pid": 1001 + j, "start_ticks": 2**63 + j,
                                  "boot_id": "synthetic-boot"}}
                    for j, role in enumerate(("native", "policy"))]})
            self.docs[ref["path"]] = evidence
            self.d["source_index"][sid] = dict(
                source_id=sid, task="general_pickup", host="perdon-hou", run_id=sid,
                context=context, settlement=ref, source_started=True,
                complete_readback=True, native_success=False, negative_count=0,
                qualified_count=int(i == 18), initialization_content_sha256=f"{i:064x}",
                original_wall_ns=1793637062037726392)
            self.d["reservations"][sid] = dict(
                run_id=sid, settlement=ref, positive_slots=0, negative_slots=0,
                quota_reserved=False, negative_quota_reserved=False,
                status="shared_Evo_teacher_settled" if i == 18
                else "settled_native_failure_no_quota")
        self.sid, self.ref, self.e = sid, ref, evidence
        self.d["nodes"]["perdon-hou"]["last_owned_resource_settlement"] = ref

    def review(self):
        return REAL_REVIEW(self.d, self.sid, lambda ref: self.docs[ref["path"]])

    def run_switch(self):
        with patch.object(current, "review_negative_shortfall",
                          lambda d, sid: REAL_REVIEW(d, sid, lambda ref: self.docs[ref["path"]])):
            return current.switch_due(self.d, self.e, self.ref, self.prep, self.prep_ref,
                                      self.at, "Synthetic CPU fixture, not scientific evidence")

    def test_five_failures_preserve_teacher_positive_and_distinctness(self):
        result = self.review()
        self.assertEqual(result["preserved_consecutive_tail"], [18, 19, 20, 21, 22])
        self.assertFalse(result["negative_shortfall_clock_reset"])
        self.assertEqual(self.d["source_index"]["general_pickup_b0_l18_synthetic"]["qualified_count"], 1)

    def test_short_segment_switch_preserves_sources_counts_and_nanoseconds(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "classify_objects")
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        event = self.d["nodes"]["perdon-hou"]["task_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertEqual(event["seconds_since_last_negative_gain"], 1740)
        self.assertEqual(event["deficits"], {"positive": 0, "negative": 9})
        self.assertEqual(event["scheduling_trigger"],
                         "negative_only_five_consecutive_independent_DM_failures")

    def test_one_success_or_unread_failure_rejects_window(self):
        for key, value in (("native_success", True), ("complete_readback", False),
                           ("source_started", False), ("negative_count", 1)):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["general_pickup_b0_l18_synthetic"][key] = value
                with self.assertRaises(ValueError):
                    self.run_switch()

    def test_reservation_duplicate_budget_or_scope_rejects_window(self):
        for kind in ("reserved", "duplicate", "budget", "owner", "positive_gap"):
            with self.subTest(kind=kind):
                self.setUp()
                if kind == "reserved":
                    self.d["reservations"][self.sid]["negative_quota_reserved"] = True
                elif kind == "duplicate":
                    self.d["source_index"][self.sid]["initialization_content_sha256"] = f"{18:064x}"
                elif kind == "budget":
                    self.e["native_budget"] = 500
                elif kind == "owner":
                    self.d["nodes"]["perdon-hou"]["active_chat_id"] = "foreign"
                else:
                    self.d["tasks"]["general_pickup"]["qualified_count"] = 9
                with self.assertRaises((ValueError, AssertionError)):
                    self.run_switch()

    def test_live_resources_and_unsettled_source_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"), ("active_real_simulators", 1),
                           ("launch_inflight", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.assertRaises(AssertionError):
                self.run_switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.run_switch()

    def test_wrong_sequence_sealed_duplicate_or_not_due_rejected(self):
        for kind in ("sequence", "sealed", "duplicate", "not_due"):
            self.setUp()
            if kind == "sequence":
                self.prep["source"]["required_accounted_prefix"] = [0]
            elif kind == "sealed":
                self.prep["source"]["layout_id"] = 53
            elif kind == "duplicate":
                self.d["source_index"]["synthetic_new"] = {"synthetic": True}
            else:
                self.d["nodes"]["perdon-hou"]["task_segments"] = []
            with self.assertRaises(AssertionError):
                self.run_switch()

    def test_parent_checks_are_reused_without_runtime_edits(self):
        text, parent = current.source(), current.baseline.source()
        start = "    baseline_checks(terminal)"
        end = '    assert reservation["positive_slots"]'
        self.assertEqual(text[text.index(start):text.index(end)],
                         parent[parent.index(start):parent.index(end)])
        self.assertNotIn('terminal["summary"]["qualified_positive"]', text)


if __name__ == "__main__":
    unittest.main()
