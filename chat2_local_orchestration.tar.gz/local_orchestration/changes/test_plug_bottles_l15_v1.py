"""Synthetic CPU bookkeeping only; no real ledger, peer, API or simulator."""
import unittest

import test_dolls_bottles_revisit_v1 as frozen
import switch_plug_teacher_to_bottles_l15_v1 as updated
import bottles_from_plug_boundary_v1 as boundary

# The frozen suite's audit hook blocks live network and process side effects.
frozen.OLD = "plug_in_charger"


class PlugBottlesTests(frozen.DueBottlesTests):
    def setUp(self):
        super().setUp()
        self.prep["source"].update(
            layout_id=15, source_sequence=list(range(16)),
            required_accounted_prefix=list(range(15)))

    def run_switch(self):
        return updated.switch_due(
            self.d, self.e, self.ref, self.prep, self.prep_ref, self.at,
            "Synthetic Plug-to-Bottles fixture; not a scientific outcome")

    def test_only_future_task_and_layout_bindings_changed(self):
        expected = updated.PARENT.read_text().replace(
            "sort_nesting_dolls_by_size", "plug_in_charger")
        expected = expected.replace(
            's["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
            's["layout_id"] == 15 and s["source_sequence"] == list(range(16))')
        expected = expected.replace(
            's["required_accounted_prefix"] == list(range(12))',
            's["required_accounted_prefix"] == list(range(15))')
        self.assertEqual(updated.source(), expected)
        self.assertEqual(
            boundary.source(),
            boundary.PARENT.read_text().replace(
                "assert x['from_task']=='sort_nesting_dolls_by_size'",
                "assert x['from_task']=='plug_in_charger'"))

    def test_zero_negative_window_survives_recent_teacher_gain(self):
        old = self.d["tasks"][frozen.OLD]
        old.update(negative_count=0, last_core_gain_at="2026-10-31T11:30:00+00:00")
        old.pop("last_negative_gain_at")
        self.e["summary"]["qualified_positive"] = True
        event = self.run_switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_wrong_layout_prefix_or_native_budget_rejected(self):
        for field, value in (("layout_id", 14), ("source_sequence", list(range(15))),
                             ("required_accounted_prefix", list(range(14)))):
            self.setUp()
            self.prep["source"][field] = value
            with self.assertRaises(AssertionError):
                self.run_switch()
        self.setUp()
        self.prep["native_step_limit"] = 400
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_teacher_attempt_identity_and_reservation_mismatch_rejected(self):
        self.d["source_index"]["old"]["active_teacher_attempt"]["run_id"] = "other"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["reservations"]["old"]["current_attempt_run_id"] = "other"
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
