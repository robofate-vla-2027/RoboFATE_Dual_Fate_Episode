"""Keep raw scientific evidence; update gain clocks only for actual core gain."""
from pathlib import Path
import hashlib
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
path = Path(__file__).with_name("baseline_settle_handoff_v1.py")
text = gap.pinned_text(path, "fa7d05bd63d5f6807470095c8962794cddea31ba060f6d28581ff6e7b2f963b9")
text = gap.change(text, "import owner_settlement_handoff_v1 as helper",
                  "import owner_positive_gap_settlement_v1 as helper")
text = gap.change(text, "if e['new_negative']:", "if receipt.get('negative_delta',0):")
text = gap.change(text, "print(json.dumps({'ledger':d,'receipt':receipt}))",
                  "receipt['actual_capacity_adapter']=capacity_adapter;"
                  "print(json.dumps({'ledger':d,'receipt':receipt}))")
capacity_adapter = dict(path=str(Path(__file__)), sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
if __name__ == "__main__":
    exec(compile(text, str(path) + "::positive_gap", "exec"), globals())
