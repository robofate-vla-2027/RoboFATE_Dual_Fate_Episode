"""Offline synthetic bookkeeping; no real peers, model, simulator, or ledger."""
import ast
import copy
from pathlib import Path
import sys
import unittest

from switch_dolls_to_prepared_bottles_v1 import OWNER, switch_due


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic test cannot affect live processes or peers")


sys.addaudithook(reject_live)
OLD = "sort_nesting_dolls_by_size"
NEXT = "put_bottles_into_dustbin"


class DueBottlesTests(unittest.TestCase):
    def setUp(self):
        ref = lambda tag: dict(path="synthetic/" + tag, sha256=tag)
        self.ref, self.prep_ref = ref("terminal"), ref("preparation")
        self.e = dict(task=OLD, execution_owner=OWNER, safe_for_next_simulator=True,
                      source_id="old", run_id="teacher", summary_ref=ref("summary"),
                      summary={"qualified_positive": False})
        task = dict(assigned_host="perdon-hou", assigned_role="chat2",
                    reserved_count=0, negative_reserved_count=0, active_run_id=None,
                    positive_quota=10, negative_quota=10, qualified_count=5,
                    negative_count=2, latest_segment_started_at="2026-10-31T10:00:00+00:00",
                    last_negative_gain_at="2026-10-30T10:00:00+00:00")
        node = dict(active_chat_id=OWNER, current_task=OLD, active_run_id=None,
                    active_real_simulators=0, baseline_accounting={"baseline_attempts_running": 0},
                    completed_pending_sources=[], common_pending_readback_run_ids=[],
                    last_owned_resource_settlement=self.ref, fixed_tasks=[OLD, NEXT],
                    qualified_count=36, negative_count=18,
                    task_segments=[dict(task="synthetic_other", ended_at="2026-10-31T10:00:00+00:00")])
        self.d = dict(campaign_id="refate-20261022-97baf70d5128", revision=7,
                      nodes={"perdon-hou": node, "h20_8": {"ns": 2**63+111}},
                      tasks={OLD: dict(task), NEXT: dict(task, scheduling_state="deferred",
                               deferred_at="2026-10-31T08:00:00+00:00")},
                      source_index={"old": dict(task=OLD, host="perdon-hou",
                          active_teacher_attempt=dict(status="settled",
                              terminal_observation=self.ref, run_id="teacher"))},
                      reservations={"old": dict(positive_slots=0, negative_slots=0,
                          quota_reserved=False, negative_quota_reserved=False,
                          status="shared_Evo_teacher_settled",
                          current_attempt_settlement=self.e["summary_ref"],
                          current_attempt_run_id="teacher")})
        self.prep = dict(binding_schema="refate.common_collector.configured_task_binding.v1",
                         native_step_limit=700, mode="independent_baseline",
                         source=dict(source_id="synthetic_new", task=NEXT, layout_id=12,
                             source_sequence=list(range(13)), required_accounted_prefix=list(range(12)),
                             split="student_train", native_bank=0))
        self.at = "2026-10-31T11:31:00+00:00"

    def run_switch(self):
        return switch_due(self.d, self.e, self.ref, self.prep, self.prep_ref,
                          self.at, "synthetic fixture, not a scientific result")

    def test_preserves_history_counts_peers_and_nanoseconds(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["node_negative"], 18)
        self.assertFalse(out["receipt"]["transition"]["source_registered"])
        self.assertFalse(out["receipt"]["transition"]["reserved"])

    def test_recent_teacher_positive_does_not_reset_negative_window(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        self.e["summary"]["qualified_positive"] = True
        out = self.run_switch()
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_or_recent_negative_gain_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["tasks"][OLD].update(last_core_gain_at="2026-10-31T11:30:00+00:00",
                                   last_negative_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_unknown_nonzero_negative_origin_is_not_invented(self):
        old = self.d["tasks"][OLD]
        old.pop("last_negative_gain_at")
        old["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_and_unsettled_rejected(self):
        for key, value in (("active_run_id", "synthetic_live"), ("active_real_simulators", 1),
                           ("owned_resource_launch_hold", True), ("launch_inflight", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.assertRaises(AssertionError):
                self.run_switch()
        self.setUp()
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_duplicate_wrong_source_or_not_due_rejected(self):
        self.d["source_index"]["synthetic_new"] = {"synthetic": True}
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.prep["source"]["layout_id"] = 53
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_boundary_reuses_original_resource_checks_and_release(self):
        here = Path(__file__).parent
        old = (here / "due_plug_boundary_handoff_v1.py").read_text()
        expected = old.replace("collection_append_binding_v1", "task_configured_binding")
        expected = expected.replace("plug_in_charger", NEXT).replace(
            "native_step_limit']==400", "native_step_limit']==700")
        new = (here / "due_bottles_boundary_handoff_v1.py").read_text()
        extra = (
            "assert x['from_task']=='sort_nesting_dolls_by_size'\n"
            "previous=doc(x['prior_preparation_ref']);binding.load_native_layout(previous)\n"
            "ps,ns=previous['source'],prepared['source']\n"
            "assert ps['task']==ns['task']=='put_bottles_into_dustbin'\n"
            "assert ns['required_accounted_prefix']==ps['source_sequence']==ps['required_accounted_prefix']+[ps['layout_id']]\n"
            "assert ns['source_sequence']==ps['source_sequence']+[ns['layout_id']]\n")
        self.assertEqual(new.replace(extra, "").replace("assert sid==ps['source_id']\n", ""), expected)
        ast.parse(new)
        self.assertIn("latest['own_process_checks']", new)
        self.assertIn("ref=x['resource_settlement_ref']", new)
        self.assertIn("'last_teacher_settlement':teacher['summary_ref']", new)


if __name__ == "__main__":
    unittest.main()
