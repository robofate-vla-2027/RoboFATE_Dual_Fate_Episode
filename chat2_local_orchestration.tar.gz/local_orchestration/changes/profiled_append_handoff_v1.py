"""Current executor around the existing profiled source-metadata archive."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys

import dolls_append_handoff_v1 as reused
from dolls_append_handoff_v1 import EXECUTOR, ROOT, ADAPTER, put, ref, reject_live_effect, script

ARCHIVE = ROOT / "preparations/MAIN_PROFILED_SOURCE_METADATA_HELPERS_20261031_001.json"
ARCHIVE_SHA = "0fde594282b659a616f64651392f394734a04f78e1949a3cdfd4bc5de9681000"
HELPER_SHA = "43cfdaa52c79378d55cba09c25847b7620d1dc6938ea2053821088a1ac69e120"


def evaluate(text, arguments):
    output = io.StringIO()
    previous = sys.stdin
    try:
        sys.stdin = io.StringIO(json.dumps(arguments))
        with contextlib.redirect_stdout(output):
            exec(compile(text, str(ARCHIVE) + "::executor_handoff", "exec"),
                 {"__name__": "__main__", "EXECUTOR": EXECUTOR})
    finally:
        sys.stdin = previous
    return json.loads(output.getvalue())


def main():
    sys.addaudithook(reject_live_effect)
    assert ref(Path(reused.__file__))["sha256"] == "09330f5793faf578b2af9cc21d29ea0217425ec2874c1aa69fc0cb0dc7af6e52"
    sys.path.insert(0, str(ADAPTER))
    sys.path.insert(0, str(ROOT / "preparations"))
    import execution_owner_binding_v1 as execution
    import configured_source_registration_v2_20261031 as metadata
    handoff = execution.install()
    assert ref(Path(metadata.__file__))["sha256"] == HELPER_SHA
    args = json.load(sys.stdin)
    assert args["execution_owner"] == EXECUTOR
    task = args["task"]
    profile = metadata.profile(task)
    raw = ARCHIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ARCHIVE_SHA
    mode = args["operation"]
    text = script(mode, json.loads(raw))
    if mode == "prepare":
        i = args["layout"]
        assert type(i) is int and 7 <= i < profile["reserved_final"][0]
        paths = [profile["root"] / f"SPLIT_APPEND_L{i}_001.json",
                 profile["root"] / f"PREPARATION_L{i}_CONFIGURED_001.json",
                 ROOT / f"preparations/{task}_L{i}_SOURCE_REGISTRATION_PREPARATION_001.json"]
        assert not any(p.exists() for p in paths), "Inspect existing preparation; do not recreate"
        result = evaluate(text, args)
        prepared = metadata.document(result["preparation_ref"])
        assert prepared["source"]["task"] == task
        assert prepared["native_step_limit"] == profile["native_budget"]
        record = {
            "schema": "refate.source_preparation.execution_handoff.v1",
            "data_kind": "actual_source_metadata_not_execution",
            "task": task, "layout": i, "native_budget": profile["native_budget"],
            "execution_owner": EXECUTOR,
            "source_owner": prepared["source"]["source_owner"],
            "canonical_descriptor_legacy_execution_owner": prepared["source"]["execution_owner"],
            "canonical_descriptor_identity_is_not_current_executor": True,
            "source_id": result["source_id"],
            "preparation": result["preparation_ref"], "split": result["append_manifest"],
            "predecessor_split": args["prior_manifest"], "handoff": handoff,
            "archived_metadata_helpers": ref(ARCHIVE),
            "actual_metadata_check": result["actual_metadata_check"],
            "original_split_owners_preserved": True,
            "source_reserved": False, "actual_launch": False,
            "positive_delta": 0, "negative_delta": 0,
        }
        evidence = put(profile["root"] / f"APPEND_L{i}_EXECUTION_HANDOFF_01a19072_001.json", record)
        result.update(execution_owner=EXECUTOR, execution_handoff=evidence)
    elif mode == "register":
        pin = args["execution_handoff"]
        record = metadata.document(pin)
        assert record["task"] == task and record["execution_owner"] == EXECUTOR
        assert record["handoff"] == handoff and record["actual_metadata_check"] == args["preparation_check"]
        check = metadata.document(args["preparation_check"])
        assert check["task"] == task and check["source_id"] == record["source_id"]
        result = evaluate(text, args)
        assert result["receipt"]["source_id"] == record["source_id"]
        result["receipt"].update(execution_owner=EXECUTOR, execution_handoff=pin)
        if not result["receipt"]["idempotent_reuse"]:
            result["ledger"]["tasks"][task]["source_registration_history"][-1].update(
                execution_owner=EXECUTOR, execution_handoff=pin)
    else:
        raise ValueError("Unknown metadata operation")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
