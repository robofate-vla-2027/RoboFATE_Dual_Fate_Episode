"""Original v11 preparation, using the same content-aware teacher entry set."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import prepare_shared_teacher_v11 as previous

text = previous._source
for old, new in (
    ("import native_shared_teacher_v12 as native_shared_teacher\n",
     "import native_teacher_content_v1 as native_shared_teacher\n"),
    ("import common_recording\n", "import common_recording_content_v2 as common_recording\n"),
    ("import shared_dependency_binding\n", "import shared_dependency_content_v1 as shared_dependency_binding\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("prepare_shared_teacher.py")) +
             "::content_preparation", "exec"), globals())
