"""Summarize existing successful readback diagnostics without decoding payloads."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher")


def ref(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


x = json.load(sys.stdin)
run = ROOT / "runs" / x["run_id"]
assert run.parent == ROOT / "runs" and run.name.startswith("c2_")
summary_path = run / "readback_once_001/SUMMARY.json"
summary = json.loads(summary_path.read_bytes())
assert summary["run_id"] == run.name and summary["file_recording_readback_passed"] is True
report_path = run / "readback_once_001/REPORT.json"
assert ref(report_path) == summary["report"]
report = json.loads(report_path.read_bytes())
assert report["source_id"] == summary["source_id"]
assert report["file_recording_readback_passed"] is True
observations = report["observations"]
assert len(observations) == summary["decoded_observation_count"]
constants = []
for observation in observations:
    diagnostics = observation["observation_content_diagnostics"]
    assert set(diagnostics) == {"cam_head", "cam_left_wrist", "cam_right_wrist"}
    for camera, value in diagnostics.items():
        assert type(value["constant_pixel_values"]) is bool
        assert value["constant_pixel_values"] == (value["std"] == 0)
        if value["constant_pixel_values"]:
            constants.append(dict(folder=observation["folder"], camera=camera,
                                  rgb_sha256=observation["rgb_sha256"][camera]))
print(json.dumps(dict(
    schema="refate.existing_readback.content_diagnostics.v1",
    data_kind="actual_report_metadata_not_new_decode",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    run_id=run.name, source_id=summary["source_id"],
    summary_ref=ref(summary_path), report_ref=summary["report"],
    observed_boundaries=len(observations),
    decoded_RGB_images=summary["decoded_RGB_images"],
    constant_rgb_frames=constants,
    real_constant_frame_scenario_verified=bool(constants),
    full_payload_decode_repeated=False,
    qualification_changed=False, positive_delta=0, negative_delta=0)))
