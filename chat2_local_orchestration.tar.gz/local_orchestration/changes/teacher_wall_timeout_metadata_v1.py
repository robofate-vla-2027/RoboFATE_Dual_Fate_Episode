"""Observe a closed post-takeover timeout; update cost metadata, never runtime."""
import ast
import base64
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
STATS_SHA = "59a447ccbe077cc4d33f6b7485902353826c6aeb72a8de93efc9aa0622a2ab4b"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def read_pin(value):
    path = Path(value["path"])
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == value["sha256"]
    return json.loads(raw)


def validate(c, error, actions, verified_t1, *, has_result, has_refusal, safe):
    assert safe and not has_result and not has_refusal
    assert c["execution_owner"] == OWNER and c["native_wall_seconds"] == 3600
    assert error["type"] == "TimeoutExpired"
    assert error["message"].endswith("timed out after 3600 seconds")
    t1, total = c["t1"], c["native_limit"]
    assert 0 < t1 < total and c["remaining_steps"] == total - t1
    assert verified_t1["stage"] == "actual_t1_verified"
    assert t1 < len(actions) < total
    for i, row in enumerate(actions):
        assert row["index"] == i and row["native_count_after"] == i + 1
        assert (i < t1) == ("prefix" in row["role"])
        assert all(row[k] is False for k in ("native_success", "terminated", "truncated"))
    assert actions[t1]["wall_before_ns"] > verified_t1["wall_ns"]
    return {"actual_teacher_actions": len(actions) - t1,
            "actual_native_steps": len(actions),
            "interruption_category": "original_foreground_wall_timeout",
            "native_terminal_observed": False, "original_wall_seconds": 3600}


def observe(x):
    run_id = x["run_id"]
    assert re.fullmatch(r"c2_[a-z0-9_]+_evo_common_teacher_[0-9]{4}_01a16807", run_id)
    run = ROOT / "runs" / run_id
    pins = {k: ref(run / name) for k, name in {
        "context": "CONTEXT_001.json", "original_error": "foreground_error.json",
        "actual_t1": "actual_t1_verified.json",
        "terminal": "MAIN_TERMINAL_OBSERVATION_001.json",
    }.items()}
    c, error, t1, terminal = (read_pin(pins[k]) for k in
                              ("context", "original_error", "actual_t1", "terminal"))
    assert c["run_id"] == terminal["run_id"] == run_id
    assert c["source_id"] == terminal["source_id"] and terminal["context"] == pins["context"]
    session = Path(c["runtime_binding"]["run_dir"])
    action_path = run / "native_actions.jsonl"
    before = action_path.stat()
    assert before.st_size < 32 * 1024**2
    raw = action_path.read_bytes()
    after = action_path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
    actions = [json.loads(line) for line in raw.splitlines()]
    counts = validate(c, error, actions, t1, has_result=(run / "result.json").exists(),
                      has_refusal=(session / "agent/provider_safety.json").exists(),
                      safe=terminal["safe_for_next_simulator"])
    assert terminal["summary"]["qualified_positive"] is False
    assert terminal["summary"]["native_result"] is None
    value = dict(schema="refate.post_takeover_wall_timeout_metadata.v1", data_kind="actual",
                 at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 execution_owner=OWNER, run_id=run_id, source_id=c["source_id"],
                 task=c["task"], source_owner=c["source_owner"], evidence=pins,
                 metadata_observer=ref(Path(__file__)),
                 actions={"path": str(action_path), "sha256": hashlib.sha256(raw).hexdigest()},
                 source_mtime_ns=after.st_mtime_ns, source_size_bytes=after.st_size,
                 complete_teacher_recording_verified=False, qualified_sample=False,
                 original_failed_summary_unchanged=True, **counts)
    output = run / "MAIN_WALL_TIMEOUT_OBSERVATION_001.json"
    if output.exists():
        saved = json.loads(output.read_bytes())
        assert all(saved[k] == value[k] for k in value if k != "at")
        value = saved
    else:
        with output.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
    value["evidence_ref"] = ref(output)
    return value


def statistics(path):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == STATS_SHA
    tree = ast.parse(raw)
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "current_stats"]
    assert len(nodes) == 1
    namespace = {}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), namespace)
    return namespace["current_stats"]


def apply_metadata(ledger, e, at, stats):
    d = copy.deepcopy(ledger)
    n = d["nodes"]["perdon-hou"]
    assert n["active_chat_id"] == e["execution_owner"] == OWNER
    assert e["data_kind"] == "actual" and e["qualified_sample"] is False
    s = d["source_index"][e["source_id"]]
    t = d["tasks"][e["task"]]
    assert s["host"] == "perdon-hou" and s["task"] == e["task"]
    assert s["source_owner"] == e["source_owner"] and not s.get("provider_safety_refusal")
    rows = [a for a in s["teacher_attempt_history"] if a["run_id"] == e["run_id"]]
    assert len(rows) == 1
    row = rows[0]
    assert row["native_result"] is None and row["teacher_effective_failure"] is False
    assert row["positive_delta"] == row["negative_delta"] == 0
    receipt = dict(at=at, run_id=e["run_id"], source_id=e["source_id"],
                   positive_delta=0, negative_delta=0, observation=e["evidence_ref"])
    if row.get("wall_timeout_observation") == e["evidence_ref"]:
        return {"ledger": d, "receipt": dict(receipt, idempotent_reuse=True)}
    fields = ("actual_teacher_actions", "actual_native_steps", "interruption_category",
              "native_terminal_observed", "original_wall_seconds")
    row.update({k: e[k] for k in fields})
    row["wall_timeout_observation"] = e["evidence_ref"]
    s.setdefault("history", []).append(dict(receipt, event="post_takeover_wall_timeout_observed"))
    active = n.get("active_run_id") or ""
    inflight = n["current_dispatch"]["source_id"] if (
        n.get("current_task") == e["task"] and "_evo_common_teacher_" in active) else None
    updated = stats(d, e["task"], inflight)
    st = t["teacher_statistics"]["EmbodiedEvo"]
    t.setdefault("teacher_statistics_history", []).append({
        "at": at, "reason": "Observed teacher actions precede the original wall timeout; not a pre-takeover failure",
        "changed_fields_before": {k: copy.deepcopy(st.get(k)) for k in updated},
        "evidence": e["evidence_ref"],
    })
    st.update(updated)
    d.update(revision=d["revision"] + 1, updated_at=at)
    return {"ledger": d, "receipt": dict(receipt, **{k: e[k] for k in fields})}


def main():
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert socket.gethostname() == "nb-5pl2apckdj-0"
    x = json.load(sys.stdin)
    if x["mode"] == "observe":
        result = observe(x)
    else:
        assert x["mode"] == "compute"
        e = json.loads(base64.b64decode(x["evidence_b64"]))
        assert read_pin(e["evidence_ref"]) == {k: v for k, v in e.items() if k != "evidence_ref"}
        for pin in e["evidence"].values():
            read_pin(pin)
        assert hashlib.sha256(Path(e["actions"]["path"]).read_bytes()).hexdigest() == e["actions"]["sha256"]
        stats = statistics(ROOT / "perdon_adapter_20261026/teacher_settle_handoff_v2.py")
        result = apply_metadata(json.loads(base64.b64decode(x["ledger_b64"])), e,
                                datetime.datetime.now(datetime.timezone.utc).isoformat(), stats)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
