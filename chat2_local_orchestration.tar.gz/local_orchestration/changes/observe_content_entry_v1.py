"""Observe saved runtime adoption only; no launch, decode, or qualification."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
POLICY_SHA = "0c0f8c218e52bd62b0142b3eae8f75d6176d6b1aa8cc3097d8f38a090633b2da"
CAPTURE_SHA = "e906c8cb505aece4c04ece5a657bcb57d09b501e479033756eb8983ef0cc2d2c"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(path):
    return json.loads(path.read_bytes())


x = json.load(sys.stdin)
run = ROOT / "runs" / x["run_id"]
assert run.parent == ROOT / "runs" and run.name.startswith("c2_")
c = document(run / "CONTEXT_001.json")
assert c["run_id"] == run.name and c["execution_owner"] == OWNER
boundary = c.get("t1", 0)
runtime_path = run / f"runtime_evidence_{boundary:06d}.json"
runtime = document(runtime_path)
owned = document(run / "owned_native.json")
assert all(runtime[key] == owned["identity"][key] for key in ("pid", "start_ticks", "boot_id"))
assert runtime["CUDA_VISIBLE_DEVICES"] == "0,1"
assert runtime["native_used"] == boundary
policy = runtime["observation_content_policy"]
assert policy["policy"] == ref(ROOT / "perdon_adapter_20261026/common_recording_content_v2.py")
assert policy["policy"]["sha256"] == POLICY_SHA
assert policy["unchanged_pt_capture_sha256"] == CAPTURE_SHA
assert policy["pixel_variance_is_data_gate"] is False and policy["raw_rgb_preserved"] is True
stats = document(run / "initial/image_stats.json")
assert set(stats) == {"cam_head", "cam_left_wrist", "cam_right_wrist"}
assert all(v["shape"] == [480, 640, 3] and type(v["constant_pixel_values"]) is bool
           for v in stats.values())
value = {
    "schema": "refate.content_policy.actual_entry.v1",
    "data_kind": "actual_partial_recording_not_qualified",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": OWNER, "source_owner": c["source_owner"],
    "source_id": c["source_id"], "run_id": run.name,
    "context": ref(run / "CONTEXT_001.json"),
    "owned_native": ref(run / "owned_native.json"),
    "runtime_evidence": ref(runtime_path), "content_policy": policy,
    "runtime_boundary": boundary, "initial_stats": ref(run / "initial/image_stats.json"),
    "full_source_readback_complete": False,
    "real_constant_frame_scenario_verified": False,
    "full_payload_decode_repeated": False, "positive_delta": 0, "negative_delta": 0,
}
output = run / "CONTENT_ACTUAL_ENTRY_001.json"
if output.exists():
    saved = document(output)
    assert saved["run_id"] == run.name and saved["content_policy"] == policy
    value = saved
else:
    with output.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
value["evidence_ref"] = ref(output)
print(json.dumps(value))
