"""Bind the unchanged closed-teacher revisit to prepared Play L14."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"):
        raise ValueError("Frozen scheduling dependency changed")
    text = raw.decode().replace("sort_nesting_dolls_by_size", "organize_table")
    text = text.replace("put_bottles_into_dustbin", "play_stacking_toy")
    for old, new in (
        ('"refate.common_collector.configured_task_binding.v1"',
         '"refate.common_collector.collection_group_binding.v1"'),
        ('import task_configured_binding as binding',
         'import collection_group_binding as binding'),
        ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 1200'),
        ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
         's["layout_id"] == 14 and s["source_sequence"] == list(range(15))'),
        ('s["required_accounted_prefix"] == list(range(12))',
         's["required_accounted_prefix"] == list(range(14))'),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::organize_teacher_play_l14", "exec"),
     globals())
