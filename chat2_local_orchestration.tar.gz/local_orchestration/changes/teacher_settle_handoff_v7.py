"""Existing Fasten settlement with the bounded current-publication read seam."""
import hashlib
from pathlib import Path
import teacher_settle_handoff_v6 as previous

PARENT_SHA = "6af170b2a608b1a94c8bee84916cad9c375e5c7313d8d65a1c9dec49f4d70b4a"
OLD = "owner_core.bind_cli(cli)"
NEW = ("import publication_manifest_size_v1 as manifest_metadata\n"
       "manifest_metadata.bind_cli(cli)\n"
       "owner_core.bind_cli(cli)")


def source():
    need = previous.runtime.stage.need
    need(hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() == PARENT_SHA,
         "Frozen Fasten settlement entry changed")
    text = previous.source()
    need(text.count(OLD) == 1, "Owner-safe settlement binding seam changed")
    return text.replace(OLD, NEW, 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::bounded_publication_manifest", "exec"),
         globals())
