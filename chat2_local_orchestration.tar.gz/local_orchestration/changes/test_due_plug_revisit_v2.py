"""Offline synthetic scheduling only; no live ledger, peers, model, or simulator."""
import ast
import datetime
import hashlib
from pathlib import Path
import sys
import unittest


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata tests have no live effects")


sys.addaudithook(reject_live)
HERE = Path(__file__).parent
OLD = (HERE / "due_plug_revisit_handoff_v1.py").read_bytes()
NEW = (HERE / "due_plug_revisit_handoff_v2.py").read_text()
assert hashlib.sha256(OLD).hexdigest() == "2feb042807b7f22f8f7f7188c9a6ed6faddb6d093a38e852de9e7a7e34251133"
TREE = ast.parse(NEW)
function = next(n for n in TREE.body if isinstance(n, ast.FunctionDef)
                and n.name == "negative_shortfall_window")
ns = {"datetime": datetime}
exec(compile(ast.Module(body=[function], type_ignores=[]), "<synthetic-clock>", "exec"), ns)
window = ns["negative_shortfall_window"]
route = next(n.test for n in ast.walk(TREE)
             if isinstance(n, ast.Assert) and "put_bottles_into_dustbin" in ast.unparse(n.test))


class DuePlugTests(unittest.TestCase):
    def task(self, negative=0):
        return dict(negative_count=negative, negative_quota=10,
                    latest_segment_started_at="2026-10-31T10:00:00+00:00")

    def test_zero_negative_clock_ignores_new_positive(self):
        task = self.task()
        task.update(qualified_count=4, last_core_gain_at="2026-10-31T11:40:00+00:00")
        now = datetime.datetime.fromisoformat("2026-10-31T11:45:00+00:00")
        self.assertEqual(window(task, now), 6300)
        self.assertNotIn("last_negative_gain_at", task)

    def test_known_negative_gain_and_unknown_origin(self):
        task = self.task(1)
        now = datetime.datetime.fromisoformat("2026-10-31T11:45:00+00:00")
        self.assertIsNone(window(task, now))
        task["last_negative_gain_at"] = "2026-10-31T11:30:00+00:00"
        self.assertEqual(window(task, now), 900)
        task["last_negative_gain_at"] = "2026-10-30T11:30:00+00:00"
        self.assertEqual(window(task, now), 6300)
        self.assertIsNone(window(self.task(10), now))

    def test_only_two_explicit_predecessors_and_no_live_run(self):
        code = compile(ast.Expression(route), "<synthetic-route>", "eval")
        for task in ("put_bottles_into_dustbin", "play_stacking_toy"):
            x = {"from_task": task}
            n = dict(current_task=task, active_run_id=None, active_real_simulators=0,
                     launch_inflight=False)
            self.assertTrue(eval(code, {"x": x, "n": n}))
            n["active_run_id"] = "synthetic-live"
            self.assertFalse(eval(code, {"x": x, "n": n}))
        x = {"from_task": "foreign_task"}
        n = dict(current_task="foreign_task", active_run_id=None, active_real_simulators=0,
                 launch_inflight=False)
        self.assertFalse(eval(code, {"x": x, "n": n}))

    def test_other_guards_and_reservation_unchanged(self):
        expected = OLD.decode().replace(
            "x['from_task']=='put_bottles_into_dustbin'",
            "x['from_task'] in ('put_bottles_into_dustbin','play_stacking_toy')").replace(
            " if last is None:return None",
            " if last is None:return (now-start).total_seconds() if task['negative_count']==0 else None")
        self.assertEqual(NEW, expected)
        self.assertIn("r['current_attempt_settlement']==current['summary_ref']", NEW)
        self.assertIn("a['status']=='settled'", NEW)
        self.assertIn("release['native_wall_seconds']==2400", NEW)
        self.assertIn("release['teacher_wall_seconds']==3600", NEW)
        self.assertIn("native_step_limit']==400", NEW)


if __name__ == "__main__":
    unittest.main()
