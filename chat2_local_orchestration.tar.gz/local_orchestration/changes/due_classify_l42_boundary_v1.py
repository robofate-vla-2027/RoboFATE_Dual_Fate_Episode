"""Reuse the resource boundary with a distinct, settled Classify predecessor."""
import hashlib
from pathlib import Path

from switch_general_to_classify_l42_v1 import SEQUENCE


def validate_pair(previous, prepared):
    ps, ns = previous["source"], prepared["source"]
    if not (ps["task"] == ns["task"] == "classify_objects"
            and ps["source_sequence"] == ns["source_sequence"] == SEQUENCE
            and ps["layout_id"] == 0 and ns["layout_id"] == 42
            and ps["required_accounted_prefix"] == SEQUENCE[:6]
            and ns["required_accounted_prefix"] == SEQUENCE[:7]
            and ns["required_accounted_prefix"] ==
            ps["required_accounted_prefix"] + [ps["layout_id"]]):
        raise ValueError("Not the next original Classify source after settled L0")


def source():
    path = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"):
        raise ValueError("Frozen resource boundary changed")
    text = raw.decode().replace("put_bottles_into_dustbin", "classify_objects")
    text = text.replace("sort_nesting_dolls_by_size", "general_pickup")
    for old, new in (
        ("prepared['native_step_limit']==700", "prepared['native_step_limit']==1100"),
        ("assert ns['required_accounted_prefix']==ps['source_sequence']=="
         "ps['required_accounted_prefix']+[ps['layout_id']]\n"
         "assert ns['source_sequence']==ps['source_sequence']+[ns['layout_id']]",
         "validate_pair(previous, prepared)"),
        (";bref=write(run/'MAIN_BOUNDARY_001.json',b)",
         ";b['inherited_prefix']={'source_id':sid,"
         "'preparation_ref':x['prior_preparation_ref'],'prepared_source':ps}"
         ";bref=write(run/'MAIN_BOUNDARY_001.json',b)"),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen boundary interface changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::classify_l42_metadata", "exec"), globals())
