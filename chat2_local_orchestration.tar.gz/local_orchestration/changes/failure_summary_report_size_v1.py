"""Keep the original projection; allow bounded long-episode REPORT metadata."""
import hashlib
from pathlib import Path

PARENT_SHA = "f8363fbbb70a5061ed2fdbd71a1173f8036a068f18b4a7e91b282230a6b885e4"
OLD = "0 < before[3] <= 8 * 1024**2"
NEW = "0 < before[3] <= _metadata_limit(path)"


def _metadata_limit(path):
    if (path.name == "REPORT.json" and path.parent.name == "readback_once_001"
            and path.parent.parent.parent == stage.SHARED / "runs"):
        return 16 * 1024**2
    return 8 * 1024**2


def source():
    path = Path(__file__).with_name("failure_summary_binding.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PARENT_SHA:
        raise ValueError("Frozen failure projection changed")
    text = raw.decode()
    if text.count(OLD) != 1:
        raise ValueError("Frozen metadata size seam changed")
    return text.replace(OLD, NEW, 1)


exec(compile(source(), str(Path(__file__)) + "::bounded_report_metadata", "exec"), globals())
