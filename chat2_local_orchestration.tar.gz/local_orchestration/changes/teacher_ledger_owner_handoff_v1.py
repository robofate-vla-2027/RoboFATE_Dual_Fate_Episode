"""Original positive transaction with separate current and historical owners."""
from pathlib import Path
import execution_owner_binding_v1 as execution
import common_runtime as runtime

execution.install()
runtime.read_pin({
    "path": str(Path(__file__).with_name("shared_teacher_ledger_v10.py")),
    "sha256": "d4d519e1c6bbf0399857b832ec9533708d181a75cc63d29b5fe6a50237f11107",
})
import shared_teacher_ledger_v10 as previous

_BINDINGS = dict(previous._BINDINGS)
collection_groups = previous.collection_groups
_TEXT = runtime.edit(
    previous._TEXT,
    "    for a,b in edits:text=common_runtime.edit(text,a,b)",
    """    edits.append(("\\nOWNER = '01a16807-8085-7903-be07-66eb332ebf95'\\n",
                  "\\nOWNER = "+repr(stage.OWNER)+"\\n"))
    edits.append(("source['owner_chat'] == SOURCE_OWNER",
                  "source.get('source_owner', source['owner_chat']) == SOURCE_OWNER"))
    for a,b in edits:text=common_runtime.edit(text,a,b)""",
)
exec(compile(_TEXT, str(Path(__file__)) + "::explicit_executor_transaction", "exec"), globals())


def bind_cli(cli):
    import sys
    current = sys.modules[__name__]
    assert cli.ledger_core in (previous, current)
    assert cli._transaction.ledger_core in (previous, current)
    cli.ledger_core = current
    cli._transaction.ledger_core = current
    assert cli._transaction.compute.__globals__["ledger_core"] is current
