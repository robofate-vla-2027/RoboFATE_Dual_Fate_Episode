"""Source metadata only; no model, network, subprocess, signal, or simulation."""
import sys
def reject_live_effect(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event in ('os.system','os.kill','os.killpg','os.fork','os.posix_spawn'):
        if event != 'socket.gethostname':
            raise RuntimeError('SOURCE_METADATA_ONLY ' + event)
sys.addaudithook(reject_live_effect)
import sys,json,hashlib,copy,datetime
from pathlib import Path
A=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');sys.path.insert(0,str(A));import collection_group_binding as binding,task_family_binding as family,source_binding as original
import execution_owner_binding_v1 as execution
execution.install()
x=json.load(sys.stdin);assert x['execution_owner']==execution.NEW
task='play_stacking_toy';i=x['layout'];root=A/'task_sources'/task
paths=[root/f'SPLIT_MANIFEST_L{i}_APPEND_001.json',root/f'PREPARATION_L{i}_COLLECTION_GROUP_001.json',root/f'L{i}_APPEND_ASSEMBLY_001.json'];assert all(not p.exists() for p in paths)
def ref(p):return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def doc(r):
 p=Path(r['path']);assert ref(p)==r;return original.decode(p.read_bytes())
def put(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write(chr(10))
 return ref(p)
old=doc(x['prior_ref']);raw=doc(x['layout_ref']);assert old['task']==task and old['initial_source_sequence']==list(range(i)) and i not in old['original_partition']['reserved_final'] and i<old['original_partition']['available_layout_count'];assert old['owner_chat']=='01a16807-8085-7903-be07-66eb332ebf95' and old['campaign_id']=='refate-20261022-97baf70d5128' and x['native_budget']==1200
assert ref(Path(binding.__file__))=={'path':'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/collection_group_binding.py','sha256':'7104d2fe89c592146d866b47c4aef125fee95f518f2f213b0bb0c0d4117f3b80'}
f=family.family(raw);gid=task+'/task_content_family/'+f['content_sha256'];assert gid==x['new_group'];content=hashlib.sha256(original.canonical(raw).encode()).hexdigest();assert content==x['initialization_content_sha256'] and content not in {v['initialization_content_sha256'] for v in old['layouts'].values()}
def differences(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   q=path+'/'+k;out+=([q] if k not in a or k not in b else differences(a[k],b[k],q))
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [path+'/length']
  return [p for j,(u,v) in enumerate(zip(a,b)) for p in differences(u,v,path+'/'+str(j))]
 return [] if a==b else [path]
m=copy.deepcopy(old);review=None
if gid not in old['families']:
 reviews=[]
 for key,g in old['families'].items():
  row=g['layouts'][0];other=doc({'path':row['path'],'sha256':row['sha256']});delta=differences(family.family(other)['normalized_layout'],f['normalized_layout']);assert delta;reviews.append(dict(group_id=key,layout=row['layout_id'],different_nonpose_paths=delta))
 review=min(reviews,key=lambda z:(len(z['different_nonpose_paths']),z['layout']))
 valid=[g['split'] for g in old['families'].values() if g['split']!=binding.SENTINEL];assert valid and all(v in ('student_train','student_dev') for v in valid)
 target=max(1,(len(valid)+1)//5);split='student_dev' if valid.count('student_dev')<target else 'student_train'
 m['families'][gid]=dict(group_id=gid,split=split,layouts=[])
else:
 split=old['families'][gid]['split'];assert split in ('student_train','student_dev'),'Appending mixed legacy member needs its own exact compatibility binding'
row=dict(layout_id=i,layout_ref=x['layout_ref'],initialization_content_sha256=content,group_id=gid,split=split,native_bank=0,initialization_distinct_from_preceding=True)
m['layouts'][str(i)]=row;m['layout_to_group'][str(i)]=gid;m['families'][gid]['layouts'].append(dict(layout_id=i,bank=0,split=split,**x['layout_ref']));m['initial_source_sequence']=list(range(i+1));at=datetime.datetime.now(datetime.timezone.utc).isoformat()
m.setdefault('source_sequence_extension_history',[]).append(copy.deepcopy(old['source_sequence_extension']))
m['source_sequence_extension']=dict(schema='refate.appended_collection_source_metadata.v1',data_kind='preparation_only',at=at,execution_owner=execution.NEW,parent_manifest=x['prior_ref'],prior_sequence=list(range(i)),source_sequence=list(range(i+1)),added_layout=i,ordering='next ascending original bank0 layout, selected before any result',original_partition_preserved=True,added_membership=split,sealed_layouts=old['original_partition']['reserved_final'],sealed_content_read=False,prior_member_labels_preserved=True,independent_development_claimed=False,independent_evaluation_claimed=False,limitation='Prior mixed labels stay unchanged. New collection family does not assert clean evaluation or independent development; no sealed layouts read.',closest_existing_nonpose_difference=review,source_reserved=False,launch_authority=False)
for k in old['layouts']:assert m['layouts'][k]==old['layouts'][k] and m['layout_to_group'][k]==old['layout_to_group'][k]
for k,g in old['families'].items():
 check=copy.deepcopy(m['families'][k])
 if k==gid:check['layouts']=check['layouts'][:-1]
 assert check==g
assert m['original_partition']==old['original_partition'] and m['group_conflicts']==old['group_conflicts']
sr=put(paths[0],m);prepared,loaded=binding.prepare_source(task=task,layout_id=i,split_ref=sr,native_total=1200,task_ref=x['task_ref']);assert binding.load_native_layout(prepared)==loaded==raw and prepared['native_step_limit']==1200
import teacher_catalog_binding_v4 as teacher
assert teacher.load_native_layout(prepared)==raw and teacher.TASK_TOTALS[task]==1200
pr=put(paths[1],prepared);ar=put(paths[2],dict(schema='refate.actual_source_metadata_assembly.v1',at=at,task=task,execution_owner=execution.NEW,source_owner=prepared['source']['source_owner'],canonical_descriptor_legacy_execution_owner=prepared['source']['execution_owner'],canonical_descriptor_identity_is_not_current_executor=True,execution_handoff=execution.install(),layout=i,source_id=prepared['source']['source_id'],split_ref=sr,preparation_ref=pr,parent_split_ref=x['prior_ref'],prepared_by_actual_entry=ref(Path(binding.__file__)),actual_load_native_layout_passed=True,actual_teacher_metadata_loader_passed=True,budget_checked_against_installed_task=1200,all_prior_rows_and_families_preserved=True,original_sealed_partition_preserved=True,distinct_initialization=True,closest_existing_nonpose_difference=review,native_started=False,source_reserved=False,outcome_observed=False,actual_adoption=False))
print(json.dumps(dict(preparation_ref=pr,split_ref=sr,extension_evidence=ar,source_id=prepared['source']['source_id'],layout=i,budget=1200,group_id=gid,split=split,closest_difference=review,preparation_executor=execution.NEW,reserved=False,actual_launch=False)))