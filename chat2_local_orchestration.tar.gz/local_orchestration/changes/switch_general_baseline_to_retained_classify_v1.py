"""Same retained-source revisit, using the existing closed-baseline checks."""
import hashlib
from pathlib import Path

import closed_baseline_resource_v1 as closed
import switch_fasten_to_prepared_general_v1 as baseline
import switch_general_to_retained_classify_v1 as retained

baseline_checks = closed.baseline_checks


def source():
    for module, expected in (
        (retained, "c548e0f262f4de991c20367c3dd8b9296f0f164815b73086d54d50232883aebc"),
        (baseline, "273196f3e43cda557a096ef708e7894f740b6180292362217aff1399361cde5b"),
        (closed, "a80220ac24361c63c785352c126deb460204888498343263f6669f760b7bc2b8"),
    ):
        if hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen baseline-revisit dependency changed")
    text, original = retained.source(), baseline.source()
    teacher_start = '    assert source["active_teacher_attempt"]["status"] == "settled"'
    baseline_start = '    baseline_checks(terminal)'
    end = '    assert reservation["positive_slots"] == reservation["negative_slots"] == 0'
    for value, start in ((text, teacher_start), (original, baseline_start)):
        if value.count(start) != 1 or value.count(end) != 1:
            raise ValueError("Frozen predecessor-validation seam changed")
    text = retained.replace_exact(
        text, text[text.index(teacher_start):text.index(end)],
        original[original.index(baseline_start):original.index(end)])
    text = retained.replace_exact(
        text, 'type(terminal["summary"]["qualified_positive"]) is bool',
        'type(terminal["summary"]["qualified_negative"]) is bool')
    return retained.replace_exact(
        text, 'phase="deferred_after_settled_no_gain"',
        'phase="deferred_after_settled_negative_shortfall"')


exec(compile(source(), str(Path(__file__)) + "::closed_general_retained_classify", "exec"),
     globals())
