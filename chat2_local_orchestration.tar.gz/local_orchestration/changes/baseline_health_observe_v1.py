import sys,json,datetime
from pathlib import Path
x=json.load(sys.stdin);p=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':x['run_id']}
for n in ['recording_progress.json','result.json','failure.json','writer_close.json']:
 q=p/n
 if q.exists() and q.stat().st_size<64000:
  v=json.loads(q.read_text())
  if n=='writer_close.json':v={k:v.get(k) for k in ['status','failed','submitted_boundaries','committed_boundaries','primary_error','uncommitted_control_records']}
  out[n]=v
q=p/'stdout.log'
if q.exists():
 with q.open('rb') as f:f.seek(max(0,q.stat().st_size-800));out['log_tail']=f.read().decode(errors='replace')
print(json.dumps(out))
