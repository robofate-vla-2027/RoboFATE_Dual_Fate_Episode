"""Offline Fasten1900 entry tests; no model/API/simulation or data qualification."""
import json
from pathlib import Path
import re
import sys
import unittest


def no_live_effects(event, args):
    if (event.startswith("socket.") and event != "socket.gethostname") or event.startswith("subprocess.") or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic CPU checks cannot call peers or launch processes")


sys.addaudithook(no_live_effects)
import teacher_catalog_binding_v12 as old_catalog
import teacher_catalog_binding_v13 as catalog
import native_teacher_content_v5 as old_native
import native_teacher_content_v6 as native
import collect_teacher_content_v5 as old_collect
import collect_teacher_content_v6 as collect
import prepare_teacher_content_v5 as old_prepare
import prepare_teacher_content_v6 as prepare
import teacher_ledger_owner_handoff_v4 as old_accounting
import teacher_ledger_owner_handoff_v5 as accounting


class FastenContentTests(unittest.TestCase):
    def test_only_fasten_budget_added(self):
        self.assertNotIn("fasten_screws", old_catalog.TASK_TOTALS)
        self.assertEqual(catalog.TASK_TOTALS, dict(old_catalog.TASK_TOTALS, fasten_screws=1900))
        self.assertEqual(catalog.budget("fasten_screws", 1900, 25), 1900)
        for total, t1 in ((700, 25), (1900, 0), (1900, 1900), (1900, True)):
            with self.assertRaises((ValueError, AssertionError)):
                catalog.budget("fasten_screws", total, t1)

    def test_actual_entry_set_keeps_content_recorder_and_reader(self):
        self.assertIs(collect.native, native)
        self.assertIs(native.restore, catalog.restore)
        self.assertIs(collect.restore, catalog.restore)
        self.assertIs(prepare.restore, catalog.restore)
        self.assertIs(native.recording, old_native.recording)
        self.assertIs(prepare.common_recording, native.recording)
        self.assertEqual(collect.dependency.__name__, "shared_dependency_content_v1")
        self.assertEqual(prepare.shared_dependency_binding.__name__, "shared_dependency_content_v1")

    def test_native_only_catalog_imports_change(self):
        self.assertEqual(native.text.replace("teacher_catalog_binding_v13", "teacher_catalog_binding_v12"),
                         old_native.text)

    def test_foreground_only_matching_entry_references_change(self):
        restored = collect.text.replace("native_teacher_content_v6", "native_teacher_content_v5")
        restored = restored.replace("teacher_catalog_binding_v13", "teacher_catalog_binding_v12")
        self.assertEqual(restored, old_collect.text)

    def test_preparation_only_matching_entry_references_change(self):
        restored = prepare.text.replace("native_teacher_content_v6", "native_teacher_content_v5")
        restored = restored.replace("teacher_catalog_binding_v13", "teacher_catalog_binding_v12")
        self.assertEqual(restored, old_prepare.text)

    def test_accounting_adds_only_fasten_tuple(self):
        self.assertNotIn("fasten_screws", old_accounting._BINDINGS)
        bindings = dict(accounting._BINDINGS)
        total, pattern = bindings.pop("fasten_screws")
        self.assertEqual(bindings, old_accounting._BINDINGS)
        self.assertEqual(total, 1900)
        self.assertTrue(re.fullmatch(pattern, "c2_fasten_screws_l7_evo_common_teacher_0001_01a16807"))
        self.assertEqual(accounting._TEXT, old_accounting._TEXT)


if __name__ == "__main__":
    unittest.main()
