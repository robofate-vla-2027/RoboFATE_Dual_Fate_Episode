"""Reuse an unchanged selection with the current pinned v6 preparation entry."""
import hashlib
import io
import json
from pathlib import Path
import sys

PREPARATION_SHA = "477ebb206acfd0e498682146366deae22656c8a47393399aa01e52c95a5efa85"
REUSE_SHA = "b90abb2d7aa84466cb3552b160a60e621779bdd07ccae29db6274aa6d8d0a754"


def patched_source(text):
    marker = "sel=write("
    if text.count(marker) != 1:
        raise ValueError("Expected exactly one selection-write seam")
    return text.replace(marker, "sel=reuse_saved_selection(", 1)


def main():
    here = Path(__file__).parent
    for name, expected in (
        ("teacher_prepare_metadata_handoff_v6.py", PREPARATION_SHA),
        ("teacher_prepare_metadata_resume_v1.py", REUSE_SHA),
    ):
        if hashlib.sha256((here / name).read_bytes()).hexdigest() != expected:
            raise ValueError("Pinned preparation/reuse helper changed")
    import teacher_prepare_metadata_handoff_v6 as preparation
    import teacher_prepare_metadata_resume_v1 as reuse

    args = json.load(sys.stdin)
    expected = args.pop("reuse_selection_ref")
    text = patched_source(preparation.source())
    namespace = {
        "__name__": "__main__",
        "__file__": str(here / "teacher_prepare_metadata_handoff_v6.py"),
        "reuse_saved_selection": lambda path, value: reuse.reuse_selection(
            path, value, expected
        ),
    }
    sys.stdin = io.StringIO(json.dumps(args))
    exec(compile(text, __file__ + "::reuse_unchanged_v6_selection", "exec"), namespace)


if __name__ == "__main__":
    main()
