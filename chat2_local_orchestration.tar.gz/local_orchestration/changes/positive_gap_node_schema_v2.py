"""Use the existing task reservation counter; no node counter is invented."""
from pathlib import Path
import baseline_positive_gap_v1 as base

BASE_SHA = "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663"
base.pinned_text(Path(base.__file__), BASE_SHA)
_original = base.positive_gap


def positive_gap(node, task):
    for scope in (node, task):
        for key in ("negative_count", "negative_quota", "negative_reserved_count",
                    "qualified_count", "positive_quota"):
            base.need(type(scope.get(key)) is int and scope[key] >= 0,
                      "Exact nonnegative quota counters required")
        base.need(scope["negative_count"] <= scope["negative_quota"]
                  and scope["negative_reserved_count"] == 0, "Negative capacity conflict")
    base.need(type(task.get("reserved_count")) is int and task["reserved_count"] >= 0,
              "Exact task positive reservation counter required")
    base.need(task["qualified_count"] + task["reserved_count"] < task["positive_quota"]
              and node["qualified_count"] < node["positive_quota"],
              "No remaining positive capacity")
    base.need(task["negative_count"] == task["negative_quota"], "Task negative quota not full")
    return True


def install():
    base.pinned_text(Path(base.__file__), BASE_SHA)
    base.need(base.positive_gap in (_original, positive_gap), "Capacity hook changed")
    base.positive_gap = positive_gap
