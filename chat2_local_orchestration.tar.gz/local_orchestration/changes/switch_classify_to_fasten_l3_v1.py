"""Original low-yield/revisit bookkeeping, for Classify to prepared Fasten L3."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"):
        raise ValueError("Original scheduling helper changed")
    text = raw.decode().replace("sort_nesting_dolls_by_size", "classify_objects")
    text = text.replace("put_bottles_into_dustbin", "fasten_screws")
    for old, new in (
        ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 1900'),
        ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
         's["layout_id"] == 3 and s["source_sequence"] == list(range(7))'),
        ('s["required_accounted_prefix"] == list(range(12))',
         's["required_accounted_prefix"] == [0, 1, 2]'),
        ('prior_segment_started_at=target["latest_segment_started_at"]',
         'prior_segment_started_at=target.get("latest_segment_started_at", target.get("segment_started_at"))'),
        ('phase="deferred_after_settled_no_gain"', 'phase="deferred_after_settled_negative_shortfall"'),
    ):
        if text.count(old) != 1:
            raise ValueError("Original scheduling interface changed")
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::fasten_l3_metadata", "exec"), globals())
