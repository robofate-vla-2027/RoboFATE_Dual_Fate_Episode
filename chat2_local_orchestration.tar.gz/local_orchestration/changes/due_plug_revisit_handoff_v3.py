"""Add the settled Conveyor predecessor to the existing Plug revisit metadata."""
import hashlib
from pathlib import Path

PREVIOUS = Path(__file__).with_name("due_plug_revisit_handoff_v2.py")
PREVIOUS_SHA = "8c1aed046e4c75ad2720ddfce549625faa1efa09cdaec6bc58860db08fa76f2e"
OLD = "x['from_task'] in ('put_bottles_into_dustbin','play_stacking_toy')"
NEW = "x['from_task'] in ('put_bottles_into_dustbin','play_stacking_toy','pick_from_conveyor_by_image')"


def source():
    raw = PREVIOUS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PREVIOUS_SHA:
        raise ValueError("Pinned Plug scheduling dependency changed")
    text = raw.decode()
    if text.count(OLD) != 1:
        raise ValueError("Plug predecessor seam changed")
    return text.replace(OLD, NEW, 1)


if __name__ == "__main__":
    exec(compile(source(), str(PREVIOUS) + "::conveyor_predecessor", "exec"), globals())
