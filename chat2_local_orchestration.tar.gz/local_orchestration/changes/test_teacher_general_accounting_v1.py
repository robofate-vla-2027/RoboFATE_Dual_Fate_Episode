"""Synthetic General200 qualification transactions; no real ledger or data writes."""
from copy import deepcopy
import re
import sys
import unittest


def offline(event, args):
    if (event.startswith("socket.") and event != "socket.gethostname") or event.startswith("subprocess.") or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic accounting only")


sys.addaudithook(offline)
import test_teacher_ledger_owner_handoff_v1 as handoff
import test_teacher_bottles_accounting as original
import teacher_ledger_owner_handoff_v4 as core
import shared_teacher_ledger_cli_v12 as cli

core.bind_cli(cli)
NOW = "2026-11-01T01:00:00+00:00"


def fixture():
    d, q = handoff.fixture()
    task, old_sid = q["task"], q["source_id"]
    target, sid = "general_pickup", "general_pickup_b0_l99_SYNTHETIC"
    d["tasks"][target] = d["tasks"].pop(task)
    d["source_index"][sid] = d["source_index"].pop(old_sid)
    d["reservations"][sid] = d["reservations"].pop(old_sid)
    q.update(task=target, source_id=sid, native_total_steps=200, t1=23, remaining_steps=177,
             run_id="c2_general_pickup_l99_evo_common_teacher_0001_01a16807")
    for row in (d["source_index"][sid], d["reservations"][sid]):
        row.update(task=target, source_id=sid)
    d["reservations"][sid]["current_attempt_run_id"] = q["run_id"]
    return d, q


def apply(d, q):
    return core.apply_commit(d, q, now=NOW, lock_inode=27555308, synthetic=True)


class GeneralAccountingTests(unittest.TestCase):
    def test_count_once_preserves_peers_owners_and_nanoseconds(self):
        d, q = fixture()
        d["source_index"]["peer"]["synthetic_ns"] = 2**63 + 17
        before = deepcopy(d)
        out, receipt = apply(d, q)
        self.assertEqual(d, before)
        self.assertEqual(receipt["positive_delta"], 1)
        self.assertEqual(out["source_index"]["peer"], before["source_index"]["peer"])
        self.assertEqual(out["nodes"]["h20_10"], before["nodes"]["h20_10"])
        self.assertEqual(out["source_index"][q["source_id"]]["source_owner"], handoff.OLD)
        twice, reused = apply(out, q)
        self.assertEqual(twice, out)
        self.assertTrue(reused["idempotent_reuse"])

    def test_native_failure_and_missing_conditions_rejected(self):
        for key in ("1.1", "1.2", "1.3"):
            d, q = fixture()
            q["conditions"][key] = False
            with self.assertRaises(ValueError):
                apply(d, q)
        d, q = fixture()
        q["native_teacher_success"] = False
        with self.assertRaises(ValueError):
            apply(d, q)

    def test_budget_reset_and_type_errors_rejected(self):
        for key, value in (("native_total_steps", 700), ("native_total_steps", 200.0),
                           ("t1", True), ("remaining_steps", 200), ("remaining_steps", 176)):
            d, q = fixture()
            q[key] = value
            with self.assertRaises(ValueError):
                apply(d, q)

    def test_refusal_sealed_and_existing_negative_rejected(self):
        for kind in ("refusal", "sealed", "negative"):
            d, q = fixture()
            if kind == "refusal":
                d["source_index"][q["source_id"]]["provider_safety_refusal"] = {"synthetic": True}
            elif kind == "sealed":
                q["split"] = "sealed_eval"
            else:
                d["source_index"][q["source_id"]]["negative_count"] = 1
            with self.assertRaises(ValueError):
                apply(d, q)

    def test_real_cli_interface_reuses_mocked_small_verdict_without_decode(self):
        namespace = dict(original.__dict__, fixture=fixture, core=core, cli=cli)
        code = original._code.replace("shared_teacher_ledger_v9", "teacher_ledger_owner_handoff_v4")
        code = re.sub(r"\b700\b", "200", code)
        code = re.sub(r"\b677\b", "177", code)
        exec(compile(code, "<synthetic-General200-CLI>", "exec"), namespace)
        namespace["test_actual_entry_uses_new_core_no_full_report_read"](self)


if __name__ == "__main__":
    unittest.main()
