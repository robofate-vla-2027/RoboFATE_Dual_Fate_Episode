"""Existing content-aware Native implementation with the Classify1100 catalog."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import native_teacher_content_v1 as previous
import teacher_catalog_binding_v9 as catalog

text = previous.text
for old, new in (
    ("from teacher_catalog_binding_v8 import restore, budget as _bound_budget\n",
     "from teacher_catalog_binding_v9 import restore, budget as _bound_budget\n"),
    ("from teacher_catalog_binding_v8 import persistence as teacher_persistence_binding\n",
     "from teacher_catalog_binding_v9 import persistence as teacher_persistence_binding\n"),
    ("import teacher_catalog_binding_v8 as source_sequence_binding\n",
     "import teacher_catalog_binding_v9 as source_sequence_binding\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("native_shared_teacher.py")) +
             "::classify1100_content", "exec"), globals())
