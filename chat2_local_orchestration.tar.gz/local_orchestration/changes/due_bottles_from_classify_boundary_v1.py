"""Keep the Bottles source predecessor distinct from closed Classify resources."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"):
        raise ValueError("Pinned cross-task resource boundary changed")
    text = raw.decode()
    old = "assert x['from_task']=='sort_nesting_dolls_by_size'"
    if text.count(old) != 1:
        raise ValueError("Existing resource predecessor interface changed")
    return text.replace(old, "assert x['from_task']=='classify_objects'", 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::classify_resource_boundary", "exec"),
         globals())
