"""Same owner-safe three-condition transaction, with the Classify1100 task tuple."""
from pathlib import Path
import sys
import teacher_ledger_owner_handoff_v1 as previous

collection_groups = previous.collection_groups
_BINDINGS = dict(previous._BINDINGS)
_BINDINGS["classify_objects"] = (
    1100, r"c2_classify_objects_l[0-9]+_evo_common_teacher_[0-9]{4}_01a16807")
_TEXT = previous._TEXT
exec(compile(_TEXT, str(Path(__file__)) + "::classify1100_executor_transaction", "exec"), globals())


def bind_cli(cli):
    current = sys.modules[__name__]
    allowed = (previous.previous, previous, current)
    assert cli.ledger_core in allowed and cli._transaction.ledger_core in allowed
    cli.ledger_core = current
    cli._transaction.ledger_core = current
    assert cli._transaction.compute.__globals__["ledger_core"] is current
