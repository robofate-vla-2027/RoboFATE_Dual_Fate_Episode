"""Retained Classify revisit using the already adopted negative-shortfall rule."""
import hashlib
from pathlib import Path

PARENT_SHA = "9a2dd1931935a29b3fc07b19f89412bb93bbf60a5105e5fbd99c87a2220794b8"
WINDOW_SHA = "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"


def frozen_text(name, expected):
    raw = Path(__file__).with_name(name).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("Frozen scheduling metadata dependency changed: " + name)
    return raw.decode()


def replace_exact(text, old, new, count=1):
    if text.count(old) != count:
        raise ValueError("Frozen scheduling seam changed: " + old[:80])
    return text.replace(old, new)


def source():
    text = frozen_text("switch_organize_to_retained_play_v1.py", PARENT_SHA)
    window = frozen_text("switch_dolls_to_prepared_bottles_v1.py", WINDOW_SHA)
    start = '    start = datetime.datetime.fromisoformat(old["latest_segment_started_at"])'
    end = '    for task in (old, target):'
    for original in (text, window):
        if original.count(start) != 1 or original.count(end) != 1:
            raise ValueError("Frozen low-yield block changed")
    old_block = text[text.index(start):text.index(end)]
    new_block = window[window.index(start):window.index(end)]
    text = replace_exact(text, old_block, new_block)
    text = replace_exact(text, "organize_table", "general_pickup", 6)
    text = replace_exact(text, "play_stacking_toy", "classify_objects", 6)
    text = replace_exact(text, '== s["native_budget"] == 1200',
                         '== s["native_budget"] == 1100')
    text = replace_exact(
        text, 'assert terminal["summary"]["qualified_positive"] is False',
        'assert type(terminal["summary"]["qualified_positive"]) is bool')
    text = replace_exact(
        text, '    assert source["active_teacher_attempt"]["status"] == "settled"',
        '    assert source["task"] == terminal["task"] and source["host"] == "perdon-hou"\n'
        '    assert source["active_teacher_attempt"]["status"] == "settled"')
    text = replace_exact(
        text, '        last_core_gain_at=old.get("last_core_gain_at"),',
        '        seconds_since_last_negative_gain=negative_elapsed,\n'
        '        last_core_gain_at=old.get("last_core_gain_at"),')
    return text


exec(compile(source(), str(Path(__file__)) + "::general_classify_revisit", "exec"),
     globals())
