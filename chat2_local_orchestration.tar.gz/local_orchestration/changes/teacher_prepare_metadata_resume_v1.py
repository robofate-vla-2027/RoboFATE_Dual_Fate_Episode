"""Resume one interrupted metadata preparation without replacing its selection."""
import hashlib
import io
import json
from pathlib import Path
import sys

ORIGINAL = "teacher_prepare_metadata_handoff_v2.py"
ORIGINAL_SHA256 = "f6bbc80b05338401a52351794002998c929b21e44486f609d01efcb0ea4a96ee"


def reuse_selection(path, value, expected):
    path = Path(path)
    assert str(path) == expected["path"], "Unexpected selection path"
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected["sha256"], "Selection changed"
    saved = json.loads(raw)
    assert saved["data_kind"] == "actual_source_metadata_not_restore_admission"
    for key in ("actual_restore_verified", "teacher_started", "qualified",
                "source_reexecuted", "full_payload_redecoded", "dispatch_issued", "reserved"):
        assert saved[key] is False, "Selection is not unstarted metadata"
    # Only preparation time may differ; every source, cutoff and evidence field must match.
    assert {k: v for k, v in saved.items() if k != "at"} == {
        k: v for k, v in value.items() if k != "at"
    }, "Saved selection differs from current source-derived metadata"
    assert path.read_bytes() == raw, "Selection changed during verification"
    return dict(expected)


def patched_source(raw):
    assert hashlib.sha256(raw).hexdigest() == ORIGINAL_SHA256, "Original helper changed"
    text = raw.decode()
    marker = "sel=write("
    assert text.count(marker) == 1
    return text.replace(marker, "sel=reuse_saved_selection(", 1)


def main():
    args = json.load(sys.stdin)
    expected = args.pop("reuse_selection_ref")
    original = Path(__file__).with_name(ORIGINAL)
    text = patched_source(original.read_bytes())
    namespace = {
        "__name__": "__main__",
        "__file__": str(original),
        "reuse_saved_selection": lambda path, value: reuse_selection(path, value, expected),
    }
    sys.stdin = io.StringIO(json.dumps(args))
    exec(compile(text, str(original) + "::reuse_unchanged_selection", "exec"), namespace)


if __name__ == "__main__":
    main()
