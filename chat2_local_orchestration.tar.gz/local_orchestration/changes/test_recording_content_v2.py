"""Offline synthetic tests. No model, API, simulator, GPU, or scientific data."""
import copy
import hashlib
import inspect
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


def forbid(event, args):
    if event in {"socket.connect", "socket.connect_ex", "socket.bind",
                 "socket.getaddrinfo", "subprocess.Popen", "os.system",
                 "os.fork", "os.posix_spawn", "os.kill", "os.killpg"}:
        raise RuntimeError("SYNTHETIC_CPU_NO_EXTERNAL_EFFECT: " + event)


sys.addaudithook(forbid)
import numpy as np
import collect_recording_content_v1 as baseline
import collect_teacher_content_v1 as teacher
import common_recording_content_v2 as content
import reader_content_binding_v1 as reader_binding

MODULES = content.load_core()
IO = MODULES["observation_io"]
PT = MODULES["pt_capture"]
PAIRED = teacher.dependency.paired_reader()
PUBLIC = PAIRED.decoder()
CAMERAS = sorted(content.CAMERAS)


def observation(constant=False):
    frame = (np.full((480, 640, 3), 37, dtype=np.uint8) if constant else
             np.arange(480 * 640 * 3, dtype=np.uint32).reshape(480, 640, 3).astype(np.uint8))
    return {
        "instruction": "SYNTHETIC CPU ONLY",
        "vision": {name: {"color": frame.copy()} for name in CAMERAS},
        "state": {"left_arm_joint_state": np.zeros(6, dtype=np.float32)},
        "action": {"left_arm_joint_state": np.ones(6, dtype=np.float32)},
        "additional_info": {"synthetic": True},
    }


def descriptor(folder):
    def ref(name):
        return {"path": name, "sha256": hashlib.sha256((folder / name).read_bytes()).hexdigest()}
    return {"format": "refate-observation-native25-v1",
            "json": ref("observation.json"), "arrays": ref("arrays.npz"),
            "pngs": {c + ".png": ref(c + ".png") for c in CAMERAS}}


def baseline_module(run):
    (run / "source_identity.json").write_text(json.dumps({
        "source_id": "SYNTHETIC_SOURCE", "task": "SYNTHETIC_TASK"}))
    reader = reader_binding.load_baseline_reader(
        expected_source_id="SYNTHETIC_SOURCE", task="SYNTHETIC_TASK",
        run=run, read_root=reader_binding.HERE, owner_chat=baseline.execution.NEW,
        campaign="refate-20261022-97baf70d5128")
    previous = inspect.getclosurevars(reader.audit).nonlocals["previous_audit"]
    return inspect.getclosurevars(previous).nonlocals["module"]


class RecordingContentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="content-only-", dir=reader_binding.HERE / "SYNTHETIC")
        self.root = Path(self.temp.name)
        self.reader = baseline_module(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, obs, name="macro_obs_000000"):
        folder = self.root / name
        writer = IO.OrderedObservationWriter(self.root)
        try:
            writer.submit(0, folder, obs, {}, {})
            writer.close()
            self.assertEqual(writer.committed, 1)
        finally:
            if not writer.closed:
                writer.close()
        return folder

    def read_both(self, folder, original):
        report = self.reader.read_observation(folder)
        view = PUBLIC.decode_archive(descriptor(folder), lambda n: (folder / n).read_bytes(),
                                     archive_folder=str(folder))
        stats = json.loads((folder / "image_stats.json").read_bytes())
        for name in CAMERAS:
            self.assertTrue(np.array_equal(original["vision"][name]["color"], view["vision"][name]["color"]))
            diagnostic = PAIRED._content_policy.validate_rgb(view["vision"][name]["color"], stats[name])
            self.assertEqual(diagnostic, report["observation_content_diagnostics"][name])
        return stats

    def capture(self, *, advance=1, physical_change=False, missing=False):
        settings_data = {"/rtx/externalFrameCounter": 0}
        settings = types.SimpleNamespace(get=settings_data.get,
            set_int=lambda k, v: settings_data.__setitem__(k, v))
        clock = types.SimpleNamespace(current_time=3.0)
        obs = observation(True)

        def render():
            if physical_change:
                clock.current_time += 0.04

        def get_obs(**kwargs):
            if missing:
                raise RuntimeError("SYNTHETIC actual get_obs failure")
            return [obs]

        native = types.SimpleNamespace(step_lim=700, sim=types.SimpleNamespace(sim=clock),
            obs_manager=types.SimpleNamespace(collect_interval=10, render_for_capture=render, get_obs=get_obs))
        task = types.SimpleNamespace(_refate_rtx_profile="pt_spatial4_collection_candidate_v1",
            _refate_pt_capture_index=0, native=native, max_steps=700, control_steps=0)
        context = types.SimpleNamespace(get_stage_loading_status=lambda: (0, 0, 0),
                                        get_stage_streaming_status=lambda: False)
        def snapshot(*args, **kwargs):
            count = 50 + (advance if kwargs["phase"] == "after_existing_capture" else 0)
            return {"dispatcher_reference_time": {"status": "stable_read",
                                                  "first": [count, 0], "second": [count, 0]}}
        with patch.object(PT, "snapshot", side_effect=snapshot):
            return PT.capture(task, 0, initial=True, settings=settings, graph=object(), context=context,
                observer=lambda *args: {"actual_settings": {"/rtx/rendermode": "PathTracing"}})

    def test_fresh_constant_roundtrip_actual_writer_and_both_readers(self):
        obs, evidence = self.capture()
        self.assertEqual(evidence["requested_external_counter"], 1)
        stats = self.read_both(self.write(obs), obs)
        self.assertTrue(all(v["constant_pixel_values"] for v in stats.values()))

    def test_ordinary_roundtrip_unchanged(self):
        obs = observation()
        stats = self.read_both(self.write(obs), obs)
        self.assertTrue(all(not v["constant_pixel_values"] for v in stats.values()))

    def test_initial_and_direct_shared_save_accept_constant_verbatim(self):
        obs = observation(True)
        folder = self.root / "initial"
        MODULES["collect_source"].save_observation(folder, obs)
        decoded = IO.decode_observation(folder)
        for name in CAMERAS:
            self.assertTrue(np.array_equal(decoded["vision"][name]["color"], obs["vision"][name]["color"]))
        self.reader.read_observation(folder)
        self.assertTrue(all(v["constant_pixel_values"] for v in
                            json.loads((folder / "image_stats.json").read_bytes()).values()))

    def test_missing_camera_and_malformed_dtype_and_size_rejected(self):
        for kind in ("missing", "dtype", "size"):
            with self.subTest(kind=kind):
                obs = observation(True)
                if kind == "missing":
                    del obs["vision"][CAMERAS[0]]
                elif kind == "dtype":
                    obs["vision"][CAMERAS[0]]["color"] = np.ones((480, 640, 3), dtype=np.float32)
                else:
                    obs["vision"][CAMERAS[0]]["color"] = np.ones((479, 640, 3), dtype=np.uint8)
                with self.assertRaises((ValueError, KeyError, TypeError)):
                    IO.OrderedObservationWriter._encode(obs)

    def test_corrupted_image_rejected_by_both_decoders(self):
        folder = self.write(observation(True))
        (folder / (CAMERAS[0] + ".png")).write_bytes(b"SYNTHETIC corrupt PNG")
        with self.assertRaises(Exception):
            self.reader.read_observation(folder)
        with self.assertRaises(Exception):
            PUBLIC.decode_archive(descriptor(folder), lambda n: (folder / n).read_bytes(), archive_folder=str(folder))

    def test_missing_image_rejected_by_both_decoders(self):
        folder = self.write(observation(True))
        desc = descriptor(folder)
        (folder / (CAMERAS[0] + ".png")).unlink()
        with self.assertRaises(Exception):
            self.reader.read_observation(folder)
        with self.assertRaises(Exception):
            PUBLIC.decode_archive(desc, lambda n: (folder / n).read_bytes(), archive_folder=str(folder))

    def test_hash_or_diagnostic_inconsistency_rejected(self):
        folder = self.write(observation(True))
        stats = json.loads((folder / "image_stats.json").read_bytes())
        for key, value in (("sha256", "0" * 64), ("constant_pixel_values", False)):
            with self.subTest(key=key):
                changed = copy.deepcopy(stats)
                changed[CAMERAS[0]][key] = value
                (folder / "image_stats.json").write_text(json.dumps(changed))
                with self.assertRaises(ValueError):
                    self.reader.read_observation(folder)
                with self.assertRaises(ValueError):
                    PAIRED._content_policy.validate_rgb(observation(True)["vision"][CAMERAS[0]]["color"], changed[CAMERAS[0]])

    def test_freshness_frame_completion_and_physics_still_fail_closed(self):
        for kwargs in ({"advance": 0}, {"advance": 2}, {"physical_change": True}, {"missing": True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(RuntimeError):
                self.capture(**kwargs)

    def test_real_filesystem_write_exception_stops_writer(self):
        folder = self.root / "macro_obs_000000"
        folder.mkdir()
        (folder / (CAMERAS[0] + ".png")).mkdir()
        writer = IO.OrderedObservationWriter(self.root)
        try:
            try:
                writer.submit(0, folder, observation(True), {}, {})
            except OSError:
                pass
            with self.assertRaises(OSError):
                writer.close()
            self.assertTrue(writer.receipt()["failed"])
            self.assertEqual(writer.committed, 0)
            with self.assertRaises(OSError):
                writer.check()
        finally:
            if not writer.closed:
                try:
                    writer.close()
                except OSError:
                    pass

    def test_actual_entry_composition_and_original_capture_pin(self):
        self.assertIs(baseline.previous.core.foreground.baseline.recording, content)
        self.assertIs(baseline.previous.core.finish.reader_binding, reader_binding)
        self.assertIs(teacher.native.recording, content)
        self.assertEqual(teacher.dependency.__name__, "shared_dependency_content_v1")
        self.assertIn("_content_policy", PAIRED.review.__code__.co_names)
        self.assertEqual(MODULES["observation_io"].content_policy["unchanged_pt_capture_sha256"],
                         hashlib.sha256(content.stage.pinned_source("effective/native/pt_capture.py")).hexdigest())
        self.assertIn("baseline_recording_content_v1.py", baseline.wiring.source("foreground_common"))
        self.assertEqual(content.stage.OWNER, baseline.execution.NEW)


if __name__ == "__main__":
    unittest.main(verbosity=2)
