"""Synthetic CPU metadata only; no live ledger, peers, API, model or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.insert(0, str(snapshot))

import test_dolls_bottles_revisit_v1 as fixtures
import switch_classify_baseline_to_fasten_l6_v1 as scheduling
import due_fasten_l6_boundary_v1 as boundary

sys.addaudithook(fixtures.reject_live)
OLD, NEXT = "classify_objects", "fasten_screws"
SEQUENCE = list(range(7))


def rename(value):
    if isinstance(value, str):
        return value.replace("sort_nesting_dolls_by_size", OLD).replace(
            "put_bottles_into_dustbin", NEXT)
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class ClosedClassifyTests(unittest.TestCase):
    def setUp(self):
        self.f = fixtures.DueBottlesTests()
        self.f.setUp()
        self.d, self.e, self.prep = map(rename, (self.f.d, self.f.e, self.f.prep))
        self.e.update(
            schema="refate.common_baseline.main_settlement.v1", data_kind="actual",
            first_readback_passed=True, native_success=False,
            context={"synthetic": "context"},
            summary={"native_success": False, "qualified_negative": False},
            process_closure={"checks": [
                {"role": role, "original_process_absent": True,
                 "identity": {"pid": i + 9001, "start_ticks": 2**63 + i,
                              "boot_id": "synthetic-boot"}}
                for i, role in enumerate(("native", "policy"))]})
        self.d["source_index"]["old"] = dict(
            task=OLD, host="perdon-hou", run_id=self.e["run_id"],
            context=deepcopy(self.e["context"]), settlement=self.f.ref,
            synthetic_ns=1793496102759665601)
        self.d["reservations"]["old"] = dict(
            status="settled_native_failure_no_quota", run_id=self.e["run_id"],
            settlement=self.f.ref, positive_slots=0, negative_slots=0,
            quota_reserved=False, negative_quota_reserved=False)
        self.prep["native_step_limit"] = 1900
        self.prep["source"].update(layout_id=6, source_sequence=SEQUENCE,
                                   required_accounted_prefix=SEQUENCE[:-1])

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
            at or self.f.at, "Synthetic fixture, no scientific credit")

    def test_preserves_counts_peers_history_and_nanoseconds(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        self.assertEqual((out["receipt"]["positive_delta"],
                          out["receipt"]["negative_delta"]), (0, 0))

    def test_recent_positive_does_not_reset_negative_window(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_recent_negative_or_early_boundary_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["tasks"][OLD].update(last_core_gain_at="2026-10-31T11:30:00+00:00",
                                   last_negative_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.switch()

    def test_missing_negative_origin_not_invented(self):
        self.d["tasks"][OLD].pop("last_negative_gain_at")
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        with self.assertRaises(AssertionError):
            self.switch()

    def test_two_other_segments_required(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_paused_or_held_resource_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"), ("launch_inflight", True),
                           ("active_real_simulators", 1), ("user_stop", True),
                           ("user_pause_active", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.switch()

    def test_wrong_scope_context_or_unsettled_source_rejected(self):
        for key, value in (("run_id", "different"), ("context", {}),
                           ("settlement", {}), ("host", "foreign")):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.d["reservations"]["old"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.switch()

    def test_source_order_budget_sealed_and_duplicate_rejected(self):
        for key, value in (("layout_id", 53), ("source_sequence", list(range(11))),
                           ("required_accounted_prefix", SEQUENCE[:-2])):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 700
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_settled_negative_is_not_recounted(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        self.assertEqual(self.switch()["receipt"]["negative_delta"], 0)


class BoundaryTests(unittest.TestCase):
    def test_original_full_sequence_pair(self):
        ps = dict(task=NEXT, source_sequence=SEQUENCE, layout_id=5,
                  required_accounted_prefix=SEQUENCE[:5])
        ns = dict(task=NEXT, source_sequence=SEQUENCE, layout_id=6,
                  required_accounted_prefix=SEQUENCE[:6])
        boundary.validate_pair({"source": ps}, {"source": ns})
        for key, value in (("layout_id", 53), ("task", "foreign"),
                           ("source_sequence", SEQUENCE[:-1]),
                           ("required_accounted_prefix", SEQUENCE[:5])):
            wrong = dict(ns, **{key: value})
            with self.subTest(key=key), self.assertRaises(ValueError):
                boundary.validate_pair({"source": ps}, {"source": wrong})

    def test_resource_tail_and_existing_predecessor_roles_preserved(self):
        current = boundary.source()
        original = Path(boundary.__file__).with_name(
            "due_bottles_boundary_handoff_v1.py").read_text()
        start, end = "boot=Path('/proc/sys/kernel/random/boot_id')", ";bref=write("
        extra = (";b['inherited_prefix']={'source_id':sid,"
                 "'preparation_ref':x['prior_preparation_ref'],'prepared_source':ps}")
        self.assertEqual(current[current.index(start):current.index(end)],
                         original[original.index(start):original.index(end)] + extra)
        for text in ("x['resource_settlement_ref']", "x['prior_source_run']",
                     "closed_baseline_resource_v1", "closed_teacher_resource_v1"):
            self.assertIn(text, current)
        ast.parse(current)

    def test_binding_keeps_original_budget_and_no_extra_runtime(self):
        text = boundary.source()
        self.assertIn("prepared['native_step_limit']==1900", text)
        self.assertIn("assert x['from_task']=='classify_objects'", text)
        self.assertIn("validate_pair(previous, prepared)", text)
        self.assertIn("memory_headroom(120)", text)


if __name__ == "__main__":
    unittest.main()
