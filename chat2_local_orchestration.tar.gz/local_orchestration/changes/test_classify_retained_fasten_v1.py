"""Offline synthetic scheduling metadata; no real ledger or scientific data."""
import copy
import unittest

import test_general_retained_classify_v1 as teacher_fixture
import test_general_baseline_retained_classify_v1 as baseline_fixture
import switch_classify_to_retained_fasten_v1 as teacher
import switch_classify_baseline_to_retained_fasten_v1 as baseline

# Imported fixtures deny network, subprocess, and signaling audit events.


class Cases:
    def setUp(self):
        self.fixture.setUp(self)
        tasks = self.d["tasks"]
        tasks["fasten_screws"] = tasks.pop("classify_objects")
        tasks["classify_objects"] = tasks.pop("general_pickup")
        tasks["classify_objects"].update(
            negative_count=2, last_negative_gain_at="2026-10-31T09:00:00+00:00")
        node = self.d["nodes"]["perdon-hou"]
        node.update(current_task="classify_objects",
                    fixed_tasks=["classify_objects", "fasten_screws"])
        self.e["task"] = "classify_objects"
        self.d["source_index"]["old"]["task"] = "classify_objects"
        self.d["source_index"]["retained"].update(
            task="fasten_screws", native_steps=1900, native_budget=1900,
            original_wall_ns=1793605964449687636)

    def run_switch(self):
        return self.current.switch_due(
            self.d, self.e, self.ref, self.retained, self.at,
            "Explicitly synthetic metadata fixture, not scientific evidence")

    def test_preserves_peers_sources_nanoseconds_and_counts(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "fasten_screws")
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["revision"], before["revision"] + 1)
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        event = out["receipt"]["transition"]
        for key in ("baseline_replay", "source_started", "reserved"):
            self.assertFalse(event[key])
        self.assertEqual(len(event["completed_other_segments"]), 2)

    def test_teacher_gain_does_not_reset_negative_window(self):
        self.d["tasks"]["classify_objects"].update(
            qualified_count=4, last_core_gain_at="2026-10-31T11:30:00+00:00")
        if self.current is teacher:
            self.e["summary"]["qualified_positive"] = True
        out = self.run_switch()
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_original_90_minute_window_required(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_recent_negative_or_unknown_nonzero_origin_rejected(self):
        for value in ("2026-10-31T11:30:00+00:00", None):
            with self.subTest(value=value):
                self.setUp()
                self.d["tasks"]["classify_objects"].update(
                    last_negative_gain_at=value,
                    last_core_gain_at="2026-10-31T11:30:00+00:00")
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_two_other_segments_required(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_resources_and_user_holds_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"),
                           ("active_real_simulators", 1),
                           ("owned_resource_launch_hold", True),
                           ("launch_inflight", True), ("user_pause_active", True),
                           ("user_stop", True), ("active_chat_id", "foreign-owner")):
            with self.subTest(key=key):
                self.setUp()
                self.d["nodes"]["perdon-hou"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_refused_attempted_unread_or_wrong_budget_source_rejected(self):
        for key, value in (
                ("active_teacher_attempt", {"status": "settled"}),
                ("teacher_attempt_history", [{"synthetic": True}]),
                ("provider_safety_refusal", {"synthetic": True}),
                ("teacher_replay_prohibited", True), ("counted_in_quota", True),
                ("counted_in_negative_quota", True), ("complete_readback", False),
                ("reusable_DM_failure", False), ("native_success", True),
                ("native_budget", 1100), ("native_steps", 1100),
                ("task", "general_pickup"), ("host", "foreign"), ("context", {})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_full_target_or_pending_reservation_rejected(self):
        self.d["tasks"]["fasten_screws"]["qualified_count"] = 10
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["reservations"]["retained"]["negative_quota_reserved"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_predecessor_binding_and_closed_boundary_required(self):
        for key, value in (("task", "foreign"), ("host", "foreign")):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["old"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.e["safe_for_next_simulator"] = False
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_effective_source_changes_only_task_names_and_budget(self):
        expected = self.current.parent.source()
        expected = expected.replace("classify_objects", "fasten_screws")
        expected = expected.replace("general_pickup", "classify_objects")
        expected = expected.replace('== s["native_budget"] == 1100',
                                    '== s["native_budget"] == 1900')
        self.assertEqual(self.current.source(), expected)


class TeacherTests(Cases, unittest.TestCase):
    fixture = teacher_fixture.RetainedClassifyTests
    current = teacher

    def test_unsettled_teacher_rejected(self):
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()


class BaselineTests(Cases, unittest.TestCase):
    fixture = baseline_fixture.ClosedGeneralRetainedTests
    current = baseline

    def test_live_birth_identity_rejected(self):
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.run_switch()

    def test_missing_readback_or_mismatched_outcome_rejected(self):
        self.e["first_readback_passed"] = False
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_negative"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
