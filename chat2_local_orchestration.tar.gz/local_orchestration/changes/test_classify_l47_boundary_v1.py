"""Offline synthetic source-pair tests; no live ledger or process operations."""
import ast
import copy
import unittest

import test_dolls_bottles_revisit_v1
import due_classify_l47_boundary_v1 as boundary


class ClassifyL47BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.previous = {"source": dict(
            task="classify_objects", layout_id=34,
            source_sequence=list(boundary.SEQUENCE),
            required_accounted_prefix=boundary.SEQUENCE[:14])}
        self.prepared = {"source": dict(
            task="classify_objects", layout_id=47,
            source_sequence=list(boundary.SEQUENCE),
            required_accounted_prefix=boundary.SEQUENCE[:15])}

    def test_exact_pair_preserves_original_memberships(self):
        before = copy.deepcopy((self.previous, self.prepared))
        boundary.validate_pair(self.previous, self.prepared)
        self.assertEqual((self.previous, self.prepared), before)

    def test_wrong_predecessor_prefix_task_or_sealed_layout_rejected(self):
        for side, key, value in (
            ("previous", "layout_id", 44), ("prepared", "layout_id", 53),
            ("prepared", "task", "foreign"),
            ("previous", "required_accounted_prefix", [0]),
            ("prepared", "source_sequence", list(reversed(boundary.SEQUENCE))),
        ):
            self.setUp()
            getattr(self, side)["source"][key] = value
            with self.assertRaises(ValueError):
                boundary.validate_pair(self.previous, self.prepared)

    def test_resource_checks_and_release_unchanged(self):
        text = boundary.source()
        self.assertEqual(text, boundary.previous.source())
        ast.parse(text)
        for marker in ("memory_headroom(120)", "fcntl.LOCK_NB",
                       "latest['own_process_checks']", "latest['process_closure']['checks']",
                       "'inherited_prefix'", "'native_step_limit']==1100",
                       "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"):
            self.assertIn(marker, text)


if __name__ == "__main__":
    unittest.main()
