"""Synthetic CPU bookkeeping only; no real ledger, processes, model or network."""
import ast
from copy import deepcopy
from pathlib import Path
import unittest
from unittest.mock import patch

import due_dolls_l11_boundary_v1 as boundary
import switch_conveyor_baseline_to_dolls_l11_v1 as scheduling
from test_fasten_general_boundary_v1 import ClosedFastenTests

OLD, NEXT = "pick_from_conveyor_by_image", "sort_nesting_dolls_by_size"


def rename(value):
    if isinstance(value, str):
        return value.replace("fasten_screws", OLD).replace("general_pickup", NEXT)
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class SchedulingTests(unittest.TestCase):
    def setUp(self):
        f = ClosedFastenTests()
        f.setUp()
        self.f = f
        self.d, self.e, self.prep = rename(f.d), rename(f.e), rename(f.prep)
        self.prep["native_step_limit"] = 1050
        self.prep["source"].update(layout_id=11, source_sequence=list(range(12)),
                                   required_accounted_prefix=list(range(11)),
                                   split="student_train")

    def switch(self, at=None):
        return scheduling.switch_due(self.d, self.e, self.f.f.ref, self.prep,
                                     self.f.f.prep_ref, at or self.f.f.at,
                                     "Synthetic due boundary, zero scientific credit")

    def test_history_peers_counts_and_nanoseconds_preserved(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))

    def test_teacher_positive_does_not_reset_negative_shortage(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_recent_negative_and_missing_segment_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["tasks"][OLD].update(last_core_gain_at="2026-10-31T11:30:00+00:00",
                                    last_negative_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_and_unsettled_resources_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"), ("active_real_simulators", 1),
                           ("launch_inflight", True), ("user_stop", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.switch()

    def test_source_order_sealed_budget_and_duplicate_rejected(self):
        for key, value in (("layout_id", 28), ("source_sequence", list(range(11))),
                           ("required_accounted_prefix", list(range(10)))):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 700
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_source_identity_context_and_settlement_rejected(self):
        for key, value in (("host", "foreign"), ("run_id", "foreign"),
                           ("context", {}), ("settlement", {})):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()

    def test_qualified_negative_not_recounted(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        self.assertEqual(self.switch()["receipt"]["negative_delta"], 0)


class BoundaryTests(unittest.TestCase):
    def test_resource_checks_unchanged_and_source_separate(self):
        text = boundary.source()
        old = (Path(boundary.__file__).parent / "due_bottles_boundary_handoff_v1.py").read_text()
        start = "boot=Path('/proc/sys/kernel/random/boot_id')"
        self.assertEqual(text[text.index(start):], old[old.index(start):])
        for seam in ("x['resource_settlement_ref']", "x['prior_source_run']",
                     "closed_baseline_resource_v1", "closed_teacher_resource_v1"):
            self.assertIn(seam, text)
        ast.parse(text)

    def test_changed_pins_rejected(self):
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed dependency"):
            with self.assertRaises(ValueError):
                boundary.source()
            with self.assertRaises(ValueError):
                scheduling.source()


if __name__ == "__main__":
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (SchedulingTests, BoundaryTests))
    result = unittest.TextTestRunner().run(suite)
    raise SystemExit(not result.wasSuccessful())
