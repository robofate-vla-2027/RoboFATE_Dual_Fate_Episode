"""Offline synthetic metadata tests; no live ledger, network, model or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.insert(0, str(snapshot))

from test_fasten_teacher_general_revisit_v1 import TeacherRevisitTests
from test_dolls_bottles_revisit_v1 import reject_live
from test_general_append_reservation_v1 import general_fixture
from test_common_owner_reservation import AT, REF
import reserve_general_append_handoff_v1 as reservation
import switch_fasten_teacher_to_general_l12_v1 as scheduling
import due_general_l12_boundary_handoff_v1 as boundary

sys.addaudithook(reject_live)
SEQUENCE = [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10, 11, 12]


class GeneralL12RevisitTests(TeacherRevisitTests):
    def setUp(self):
        super().setUp()
        self.prep["source"].update(
            layout_id=12, source_sequence=SEQUENCE[:],
            required_accounted_prefix=SEQUENCE[:-1])
        self.d["source_index"]["old"]["synthetic_ns"] = 1793598121725316875

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
            at or self.f.at, "Synthetic metadata only, no scientific credit")

    def test_only_original_parameters_change(self):
        text = scheduling.source()
        for old, new in reversed(scheduling.CHANGES):
            text = text.replace(new, old, 1)
        self.assertEqual(text, scheduling.previous.source())

    def test_layout_prefix_owner_and_sealed_rejected(self):
        for key, value in (("layout_id", 10), ("layout_id", 53),
                           ("required_accounted_prefix", SEQUENCE[:-2])):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["active_chat_id"] = "synthetic-other-owner"
        with self.assertRaises(AssertionError):
            self.switch()


class GeneralL12BoundaryTests(unittest.TestCase):
    def test_only_boundary_parameter_changes(self):
        text = boundary.source()
        self.assertEqual(text.replace(boundary.NEW, boundary.OLD, 1),
                         boundary.previous.source())
        ast.parse(text)
        for seam in ("x['resource_settlement_ref']", "x['prior_source_run']",
                     "closed_teacher_resource_v1", "fg.helpers().memory_headroom(120)",
                     "general_previous_preparation"):
            self.assertIn(seam, text)

    def test_exact_source_predecessor_is_required(self):
        nodes = [n for n in ast.parse(boundary.source()).body
                 if isinstance(n, ast.Assert)
                 and ("ns[" in ast.unparse(n.test) or "ps[" in ast.unparse(n.test))]
        self.assertEqual(len(nodes), 4)
        code = compile(ast.Module(body=nodes, type_ignores=[]), "<synthetic-prefix>", "exec")
        ps = dict(task="general_pickup", layout_id=11, source_id="synthetic-prior",
                  source_sequence=SEQUENCE[:-1], required_accounted_prefix=SEQUENCE[:-2])
        ns = dict(task="general_pickup", layout_id=12, source_sequence=SEQUENCE[:],
                  required_accounted_prefix=SEQUENCE[:-1])
        exec(code, dict(ps=ps, ns=ns, sid="synthetic-prior"))
        for key, value in (("required_accounted_prefix", SEQUENCE[:-2]),
                           ("source_sequence", SEQUENCE + [53]), ("layout_id", 13)):
            with self.subTest(key=key), self.assertRaises(AssertionError):
                exec(code, dict(ps=ps, ns=dict(ns, **{key: value}), sid="synthetic-prior"))

    def test_parent_pin_changes_rejected(self):
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed bytes"):
            for module in (boundary, scheduling):
                with self.subTest(module=module.__name__), self.assertRaises(ValueError):
                    module.source()

    def test_existing_append_reserver_accepts_l12_without_budget_change(self):
        d, b, previous, release = general_fixture()
        sid = b["settlement"]["source_id"]
        old = d["source_index"][sid]
        old.update(layout_id=11, source_sequence=SEQUENCE[:-1],
                   required_accounted_prefix=SEQUENCE[:-2])
        previous["prepared"]["source"] = deepcopy(old)
        d["tasks"]["general_pickup"]["source_sequence"] = SEQUENCE[:-1]
        b["next_preparation"]["prepared"]["source"].update(
            layout_id=12, source_sequence=SEQUENCE[:], required_accounted_prefix=SEQUENCE[:-1])
        original = deepcopy(d)
        out = reservation.reserve_next(d, b, REF, previous, release, AT)
        self.assertEqual(d, original)
        self.assertEqual(out["ledger"]["nodes"]["h20_8"], original["nodes"]["h20_8"])
        self.assertEqual(out["ledger"]["source_index"][sid], old)
        dispatch = out["receipt"]["dispatch"]
        self.assertEqual((dispatch["native_total_steps"], dispatch["native_wall_seconds"],
                          dispatch["teacher_wall_seconds"]), (200, 2400, 3600))
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))


if __name__ == "__main__":
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (GeneralL12RevisitTests, GeneralL12BoundaryTests))
    result = unittest.TextTestRunner().run(suite)
    raise SystemExit(not result.wasSuccessful())
