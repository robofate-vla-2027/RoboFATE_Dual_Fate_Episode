"""Retain six metadata checks and exercise the actual Play boundary budget assertion."""
import ast
from pathlib import Path
import unittest

from test_play_revisit_metadata_v1 import Tests

SOURCE = (Path(__file__).resolve().parent / "due_play_boundary_handoff_v2.py").read_text()
TREE = ast.parse(SOURCE)
CHECKS = [node for node in TREE.body if isinstance(node, ast.Assert)
          and "prepared['native_step_limit']" in ast.unparse(node.test)]
assert len(CHECKS) == 1
CHECK = compile(ast.Module(body=CHECKS, type_ignores=[]), "<synthetic-boundary-budget>", "exec")


class BoundaryTests(unittest.TestCase):
    def test_actual_boundary_assertion_preserves_original_1200_budget(self):
        for prepared_budget, requested_budget, task, accepted in (
            (1200, 1200, "play_stacking_toy", True),
            (400, 1200, "play_stacking_toy", False),
            (1200, 400, "play_stacking_toy", False),
            (1200, 1200, "plug_in_charger", False),
        ):
            with self.subTest(prepared=prepared_budget, requested=requested_budget, task=task):
                value = {"prepared": {"source": {"task": task},
                                     "native_step_limit": prepared_budget,
                                     "mode": "independent_baseline"},
                         "x": {"native_budget": requested_budget}}
                if accepted:
                    exec(CHECK, value)
                else:
                    with self.assertRaises(AssertionError):
                        exec(CHECK, value)


if __name__ == "__main__":
    unittest.main()
