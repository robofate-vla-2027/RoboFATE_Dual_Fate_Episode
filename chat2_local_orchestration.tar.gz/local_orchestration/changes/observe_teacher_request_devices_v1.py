"""Read saved request configuration and live owned Native identity; no requests."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
assert socket.gethostname() == "nb-5pl2apckdj-0"
assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
assert os.environ["REFATE_EXECUTION_OWNER"] == OWNER
x = json.load(sys.stdin)
run = ROOT / "runs" / x["run_id"]
assert run.parent == ROOT / "runs" and run.name.startswith("c2_")
context = json.loads((run / "CONTEXT_001.json").read_bytes())
assert context["execution_owner"] == OWNER and context["run_id"] == run.name
session = Path(context["runtime_binding"]["run_dir"])
assert session.parent == ROOT / "sessions"
fields, refs = {}, {}
for name in ("resolved.json", "agent/runtime.json"):
    path = session / name
    data = json.loads(path.read_bytes())
    selected = data["agent"] if name == "resolved.json" else data
    fields[name] = {key: selected[key] for key in ("model", "reasoning_effort")}
    assert fields[name] == dict(model="gt-6-as-a", reasoning_effort="xhigh")
    refs[name] = dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
identity = json.loads((run / "owned_native.json").read_bytes())["identity"]
process = Path("/proc") / str(identity["pid"])
stat = (process / "stat").read_text().rsplit(")", 1)[1].split()
assert int(stat[19]) == identity["start_ticks"]
assert Path("/proc/sys/kernel/random/boot_id").read_text().strip() == identity["boot_id"]
environment = dict(row.split(b"=", 1) for row in
                   (process / "environ").read_bytes().split(b"\0") if b"=" in row)
assert environment[b"CUDA_VISIBLE_DEVICES"] == b"0,1"
with (run / "stdout.log").open("rb") as stream:
    rows = [line for line in stream.read(512 * 1024).decode(errors="replace").splitlines()
            if line.startswith("| ") and "NVIDIA H200" in line]
assert [int(line.split("|")[1].strip()) for line in rows
        if line.split("|")[3].strip().startswith("Yes:")] == [1]
started = json.loads((run / "native_started.json").read_bytes())
assert context["native_wall_seconds"] == 3600
print(json.dumps(dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(), run_id=run.name,
    fields=fields, refs=refs, native_identity=identity,
    native_environment={"CUDA_VISIBLE_DEVICES": "0,1"},
    renderer_active_gpu_rows=rows, native_started_wall_ns=started["wall_ns"],
    original_native_deadline_wall_ns=started["wall_ns"] + 3600 * 10**9,
    RGB_decoded=False, provider_request_made=False,
    provider_backend_certified=False, qualification_changed=False,
)))
