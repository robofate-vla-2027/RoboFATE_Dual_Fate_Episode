"""Synthetic CPU metadata tests; no model, network, simulator or GPU calls."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

import prepare_fasten_legacy_handoff_v1 as module


def fixture(layout=3):
    original = {
        "task": module.TASK, "owner_chat": module.SOURCE_OWNER,
        "initial_source_sequence": list(range(7)), "opaque_reserved_layouts": [53, 54],
        "previous_plan": {"partition": {"reserved_final": [53, 54], "train": [0, 1, 2, 3, 4]}},
        "reserved_content_read": False, "unadmitted_layouts": list(range(7, 53)),
        "layout_to_group": {}, "families": {}, "historical_ns": 1800000000000000001,
    }
    for index in range(7):
        group = "synthetic_" + str({4: 2, 6: 3}.get(index, index))
        original["layout_to_group"][str(index)] = group
        family = original["families"].setdefault(
            group, {"split": "student_dev" if index == 5 else "student_train", "layouts": []})
        family["layouts"].append(dict(bank=0, layout_id=index,
                                      path=f"/synthetic/{index}.json", sha256=str(index) * 64))
    projected = deepcopy(original)
    projected.update(campaign_id=module.CAMPAIGN, historical_manifest_owner=module.SOURCE_OWNER,
                     original_partition=deepcopy(original["previous_plan"]["partition"]), layouts={})
    for index in range(layout + 1):
        group = original["layout_to_group"][str(index)]
        family = original["families"][group]
        member = next(m for m in family["layouts"] if m["layout_id"] == index)
        projected["layouts"][str(index)] = dict(
            layout_id=index, native_bank=0, group_id=group, split=family["split"],
            layout_ref={k: member[k] for k in ("path", "sha256")},
            initialization_distinct_from_preceding=True)
    return original, projected


class ProjectionTests(unittest.TestCase):
    def test_preserves_original_fields_and_integer_precision(self):
        original, projected = fixture()
        before = deepcopy((original, projected))
        module.validate_projection(original, projected, 3)
        self.assertEqual((original, projected), before)
        self.assertEqual(json.loads(json.dumps(projected))["historical_ns"], 1800000000000000001)
        self.assertNotIn("campaign_id", original)

    def test_historical_l2_descriptor_is_only_metadata(self):
        original, projected = fixture(2)
        module.validate_projection(original, projected, 2)
        self.assertEqual(set(projected["layouts"]), {"0", "1", "2"})

    def test_rejects_other_and_sealed_layouts(self):
        original, _ = fixture()
        for layout in (0, 1, 4, 5, 6, 7, 53, 54, True):
            with self.subTest(layout=layout), self.assertRaises(ValueError):
                module.validate_original(original, layout)

    def test_rejects_changed_original_identity_or_sequence(self):
        original, _ = fixture()
        for key, value in (("task", "foreign"), ("owner_chat", "foreign"),
                           ("initial_source_sequence", [0, 2, 1, 3, 4, 5, 6]),
                           ("opaque_reserved_layouts", [51, 52]), ("reserved_content_read", True)):
            with self.subTest(key=key), self.assertRaises(ValueError):
                changed = deepcopy(original)
                changed[key] = value
                module.validate_original(changed, 3)

    def test_campaign_addition_is_not_an_original_field(self):
        original, projected = fixture()
        original["campaign_id"] = module.CAMPAIGN
        with self.assertRaises(ValueError):
            module.validate_projection(original, projected, 3)

    def test_rejects_membership_and_hash_changes(self):
        original, projected = fixture()
        for key, value in (("group_id", "different"), ("split", "student_dev"),
                           ("native_bank", 1), ("layout_ref", {"path": "/changed", "sha256": "b"})):
            with self.subTest(key=key), self.assertRaises(ValueError):
                changed = deepcopy(projected)
                changed["layouts"]["3"][key] = value
                module.validate_projection(original, changed, 3)

    def test_rejects_extra_source_and_duplicate_initialization(self):
        original, projected = fixture()
        changed = deepcopy(projected)
        changed["layouts"]["4"] = deepcopy(changed["layouts"]["3"])
        with self.assertRaises(ValueError):
            module.validate_projection(original, changed, 3)
        projected["layouts"]["3"]["initialization_distinct_from_preceding"] = False
        with self.assertRaises(ValueError):
            module.validate_projection(original, projected, 3)

    def test_rejects_modification_of_historical_fields(self):
        original, projected = fixture()
        projected["historical_ns"] -= 1
        with self.assertRaises(ValueError):
            module.validate_projection(original, projected, 3)

    def test_keeps_original_partition(self):
        original, projected = fixture()
        projected["original_partition"]["reserved_final"] = [51, 52]
        with self.assertRaises(ValueError):
            module.validate_projection(original, projected, 3)

    def test_existing_metadata_cannot_be_replaced(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "synthetic.json"
            value = {"synthetic_only": True, "ns": 1800000000000000001}
            pin = module.save(path, value)
            raw = path.read_bytes()
            self.assertEqual(module.save(path, value), pin)
            with self.assertRaises(ValueError):
                module.save(path, {"synthetic_only": False})
            self.assertEqual(path.read_bytes(), raw)


if __name__ == "__main__":
    unittest.main()
