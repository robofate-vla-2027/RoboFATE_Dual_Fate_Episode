"""Existing content recorder with the explicit Insert sequence-author binding."""
from pathlib import Path
import types

import insert_sequence_handoff_v1 as handoff
handoff.install()
import common_runtime as runtime
import collection_recording_content_v1 as previous

HERE = Path(__file__).resolve().parent


def source(name):
    text = previous.source(name)
    if name == "baseline_native":
        return text
    text = runtime.edit(
        text, "from collection_recording_content_v1 import baseline_module as baseline\n",
        "from collection_insert_sequence_content_v1 import baseline_module as baseline\n",
    )
    return runtime.edit(
        text, "node.stage.HERE/'baseline_recording_content_v1.py'",
        "node.stage.HERE/'baseline_insert_sequence_content_v1.py'",
    )


def load(name):
    module = types.ModuleType("_refate_insert_sequence_" + name)
    module.__file__ = str(HERE / (name + ".py"))
    exec(compile(source(name), module.__file__ + "::sequence_handoff", "exec"), module.__dict__)
    return module


baseline_module = load("baseline_native")
