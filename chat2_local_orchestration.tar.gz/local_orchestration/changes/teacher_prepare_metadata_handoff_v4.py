"""Original source-cut preparation with the matching General200 release."""
from pathlib import Path
import common_runtime as runtime


def source():
    path = Path(__file__).with_name("teacher_prepare_metadata_handoff_v3.py")
    text = runtime.read_pin({"path": str(path), "sha256":
        "db04b92ed28c1fa4879bd1fdc5b8e6754d33b1dd09f2b7d7be0a1baa00429577"}).decode()
    for old, new in (
        ("from teacher_catalog_binding_v11 import", "from teacher_catalog_binding_v12 import"),
        ("import collect_teacher_content_v4 as collect", "import collect_teacher_content_v5 as collect"),
        ("'pick_from_conveyor_by_image':'CONVEYOR'}",
         "'pick_from_conveyor_by_image':'CONVEYOR','general_pickup':'GENERAL'}"),
        ("TEACHER_CONVEYOR_CONTENT_RELEASE_V2_20261101_01a19072.json",
         "TEACHER_GENERAL_CONTENT_RELEASE_20261101_01a19072.json"),
        ("74d2cdf5bb0ad1b688c002d792ae67f2b2af168a7314435e32abc5911dbb1ffd",
         "d1aa841ebeee87001dcfa2239fc0809ff212b8855469563eeed5f5ce749d35e5"),
    ):
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general200_metadata", "exec"), globals())
