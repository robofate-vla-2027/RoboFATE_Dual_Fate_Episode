"""Reuse the original binder while separating historical source and executor."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime


def historical_preparer_allowed(source):
    return (source.get("execution_owner") in (
        "01a16807-8085-7903-be07-66eb332ebf95", execution.NEW)
        and source.get("source_owner") in (
            "01a16338-bd36-78e3-ac27-56c3e62e3333",
            "01a16807-8085-7903-be07-66eb332ebf95", execution.NEW))


path = Path(__file__).with_name("bind_catalog_context.py")
text = runtime.read_pin({"path": str(path), "sha256":
    "ed809c02c01e6324afc0e10b81418baafac2b11057fc06eb8146553b44a088ec"}).decode()
for old, new in (
    ("import collect_with_extensions as collection\n", "import collect_recording_content_v1 as collection\n"),
    ("stage.HERE / 'collect_with_extensions.py'", "stage.HERE / 'collect_recording_content_v1.py'"),
    ("and source['execution_owner'] == stage.OWNER, 'Source lineage differs')",
     "and historical_preparer_allowed(source), 'Source lineage differs')"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(path) + "::explicit_executor_content_binding", "exec"), globals())
