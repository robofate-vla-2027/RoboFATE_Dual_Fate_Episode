"""Original reservation with one explicitly verified legacy Fasten prefix."""
import hashlib
from pathlib import Path

import owner_reservation_handoff_v1 as previous
from owner_reservation_handoff_v1 import historical_preparer_allowed, _settled_predecessor
from fasten_prefix_handoff_v1 import NEXT_SOURCE, TASK, fasten_original_prefix_accounted

path = Path(__file__).with_name("owner_reservation_handoff_v1.py")
if hashlib.sha256(path.read_bytes()).hexdigest() != (
        "23585fef5f5b08a7c775ab4644c54923c1f4ee7508a5d2ad89d4745fe9603d20"):
    raise ValueError("Original reservation helper changed")


def _inherited_prefix(ledger, boundary, source, ordinal):
    if source.get("task") == TASK and source.get("source_id") == NEXT_SOURCE:
        return fasten_original_prefix_accounted(ledger, boundary, source, ordinal)
    return previous._inherited_prefix(ledger, boundary, source, ordinal)


exec(compile(previous.text, str(path) + "::fasten_legacy_prefix", "exec"), globals())
