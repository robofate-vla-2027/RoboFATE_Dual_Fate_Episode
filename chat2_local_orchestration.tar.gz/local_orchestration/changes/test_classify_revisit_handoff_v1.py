"""Synthetic scheduling and pure reservation checks; no actual runtime launch."""
from copy import deepcopy
import unittest

from classify_prefix_handoff_v1 import ADAPTER, NEXT_SOURCE, OWNER, TASK, metadata_hash, reserver
from classify_revisit_handoff_v1 import switch_due

AT = "2026-11-01T02:00:00+00:00"


def fixture():
    pin = lambda name: {"path": "/synthetic/" + name, "sha256": "1" * 64}
    terminal_ref, summary_ref, prep_ref = (pin(v) for v in ("terminal.json", "summary.json", "prep.json"))
    prior_sid = "plug_in_charger_b0_l17_synthetic"
    prior_run = "c2_plug_in_charger_l17_evo_common_teacher_0001_01a16807"
    terminal = {"task": "plug_in_charger", "execution_owner": OWNER,
                "safe_for_next_simulator": True, "source_id": prior_sid,
                "run_id": prior_run, "summary_ref": summary_ref}
    prior = {"qualified_count": 6, "negative_count": 0, "positive_quota": 10, "negative_quota": 10,
             "reserved_count": 0, "negative_reserved_count": 0,
             "latest_segment_started_at": "2026-11-01T00:00:00+00:00",
             "last_core_gain_at": "2026-11-01T01:59:00+00:00"}
    target = {"assigned_host": "perdon-hou", "scheduling_state": "deferred",
              "status": "pending", "qualified_count": 0, "negative_count": 1,
              "positive_quota": 10, "negative_quota": 10, "reserved_count": 0,
              "negative_reserved_count": 0, "deferred_at": "2026-10-24T00:00:00+00:00"}
    node = {"active_chat_id": OWNER, "current_task": "plug_in_charger",
            "user_pause_active": False, "user_stop": False, "owned_resource_launch_hold": False,
            "active_run_id": None, "active_real_simulators": 0, "launch_inflight": False,
            "baseline_accounting": {"baseline_attempts_running": 0},
            "last_owned_resource_settlement": terminal_ref, "completed_pending_sources": [],
            "common_pending_readback_run_ids": [], "fixed_tasks": [TASK, "plug_in_charger"],
            "qualified_count": 35, "negative_count": 18, "negative_reserved_count": 0,
            "negative_quota": 210,
            "task_segments": [{"task": "synthetic_other", "ended_at": t} for t in
                              ("2026-10-30T00:00:00+00:00", "2026-10-31T00:00:00+00:00")]}
    reservation = {"status": "shared_Evo_teacher_settled", "current_attempt_run_id": prior_run,
                   "current_attempt_settlement": summary_ref, "positive_slots": 0,
                   "negative_slots": 0, "quota_reserved": False, "negative_quota_reserved": False,
                   "settled_at": "2026-11-01T01:59:30+00:00"}
    ledger = {"revision": 1, "campaign_id": "refate-20261022-97baf70d5128",
              "started_at": "2026-10-22T18:46:58+08:00", "synthetic_fixture": True,
              "nodes": {"perdon-hou": node, "h20_8": {"unrelated": True}},
              "tasks": {"plug_in_charger": prior, TASK: target},
              "source_index": {}, "reservations": {prior_sid: reservation}}
    review = {"schema": "refate.classify.original_prefix.accounted.v1",
              "next_source_id": NEXT_SOURCE, "preparation_ref": prep_ref,
              "old_source_qualification_changed": False, "old_sources_replayed": False,
              "live_referenced_processes": [], "entries": []}
    for i in range(1, 6):
        sid = f"{TASK}_b0_l{i}_synthetic"
        row = {"source_id": sid, "host": "perdon-hou", "task": TASK, "counted_in_quota": False}
        ledger["source_index"][sid] = row
        review["entries"].append({"layout": i, "source_id": sid, "source_metadata_sha256": metadata_hash(row),
                                  "source_consumed": True, "new_positive": 0, "new_negative": 0})
    ledger["source_index"][prior_sid] = {"source_id": prior_sid, "host": "perdon-hou",
                                       "task": "plug_in_charger", "settlement": pin("baseline.json")}
    source = {"source_id": NEXT_SOURCE, "task": TASK, "layout_id": 6,
              "required_accounted_prefix": [1, 2, 3, 4, 5], "source_sequence": [1, 2, 3, 4, 5, 6, 0],
              "execution_owner": "01a16807-8085-7903-be07-66eb332ebf95",
              "source_owner": "01a16807-8085-7903-be07-66eb332ebf95", "group_id": "synthetic_group",
              "split": "student_dev", "layout_sha256": "2" * 64,
              "initialization_content_sha256": "3" * 64}
    prepared = {"source": source, "native_step_limit": 1100, "mode": "independent_baseline",
                "requested_initial_native_count": 0, "renderer_profile": "synthetic_matched",
                "prospective_teacher_renderer_profile": "synthetic_matched",
                "provenance": {"split": pin("split.json")}}
    return ledger, terminal, terminal_ref, prepared, prep_ref, review


class RevisitTests(unittest.TestCase):
    def test_recent_positive_does_not_reset_negative_window(self):
        args = fixture()
        original = deepcopy(args[0])
        result = switch_due(*args, AT)
        transition = result["receipt"]["transition"]
        self.assertEqual(transition["seconds_since_last_core_gain"], 60)
        self.assertEqual(transition["seconds_since_last_negative_gain"], 7200)
        self.assertEqual(result["ledger"]["source_index"], original["source_index"])
        self.assertEqual(result["ledger"]["nodes"]["h20_8"], original["nodes"]["h20_8"])
        self.assertEqual(args[0], original)
        self.assertEqual(result["ledger"]["started_at"], original["started_at"])

    def test_before_ninety_minutes_rejected(self):
        args = fixture()
        args[0]["tasks"]["plug_in_charger"]["latest_segment_started_at"] = "2026-11-01T01:00:00+00:00"
        with self.assertRaises(ValueError):
            switch_due(*args, AT)

    def test_unsettled_slot_rejected(self):
        args = fixture()
        next(iter(args[0]["reservations"].values()))["quota_reserved"] = True
        with self.assertRaises(ValueError):
            switch_due(*args, AT)

    def test_active_simulator_rejected(self):
        args = fixture()
        args[0]["nodes"]["perdon-hou"]["active_real_simulators"] = 1
        with self.assertRaises(ValueError):
            switch_due(*args, AT)

    def test_changed_old_source_rejected(self):
        args = fixture()
        next(iter(args[0]["source_index"].values()))["counted_in_quota"] = True
        with self.assertRaises(ValueError):
            switch_due(*args, AT)

    @unittest.skipUnless(ADAPTER.exists(), "Actual pinned metadata modules are on the authorized server")
    def test_actual_original_reservation_function_with_synthetic_ledger(self):
        args = fixture()
        d = switch_due(*args, AT)["ledger"]
        _, terminal, terminal_ref, prepared, prep_ref, review = args
        pin = lambda name: {"path": "/synthetic/" + name, "sha256": "1" * 64}
        release = pin("release.json")
        n = d["nodes"]["perdon-hou"]
        n["current_runtime_adoption"] = {"runtime_release": release}
        n["current_dispatch"] = {"native_wall_seconds": 2400, "teacher_wall_seconds": 3600}
        n["current_common_foreground"] = {"actual_entry": "/synthetic/existing_baseline.py"}
        prior_sid = terminal["source_id"]
        boundary = {
            "at": AT, "next_preparation": {"prepared": prepared, "ref": prep_ref},
            "legacy_prefix_review": review, "runtime_release": release,
            "resource_precheck": {"summary": {"run_id": "c2_classify_objects_l6_common_baseline_0001_01a16807"},
                                 "ref": pin("resource.json")},
            "settlement": {"source_id": prior_sid, "safe_for_next_simulator": True,
                           "settlement_ref": d["source_index"][prior_sid]["settlement"]},
            "last_teacher_settlement": terminal["summary_ref"], "teacher_supplement_present": True,
        }
        # The original predecessor interface requires the summary to identify its exact run.
        summary = dict(terminal["summary_ref"], path="/synthetic/" + terminal["run_id"] + "/reader/SUMMARY.json")
        boundary["last_teacher_settlement"] = summary
        d["reservations"][prior_sid]["current_attempt_settlement"] = summary
        before = deepcopy(d["source_index"])
        out, dispatch = reserver()(d, boundary, AT)
        for sid, row in before.items():
            self.assertEqual(out["source_index"][sid], row)
        self.assertEqual(dispatch["native_total_steps"], 1100)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["owner_chat"], OWNER)
        self.assertEqual(out["reservations"][NEXT_SOURCE]["negative_slots"], 1)
        self.assertEqual(out["nodes"]["perdon-hou"]["negative_count"], 18)
        self.assertEqual(out["nodes"]["perdon-hou"]["negative_reserved_count"], 1)


if __name__ == "__main__":
    unittest.main()
