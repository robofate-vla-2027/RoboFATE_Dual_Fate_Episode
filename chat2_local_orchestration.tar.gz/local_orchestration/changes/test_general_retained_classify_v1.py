"""Synthetic metadata only; no real peers, signaling, model or ledger writes."""
import copy
import sys
import unittest

import test_switch_retained_play_v1 as fixture
import switch_general_to_retained_classify_v1 as current


def deny_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.posix_spawn", "os.posix_spawnp", "os.kill", "os.killpg"):
        raise RuntimeError("Offline synthetic metadata fixture denies live effects")


sys.addaudithook(deny_live_effects)


class RetainedClassifyTests(unittest.TestCase):
    def setUp(self):
        fixture.RetainedPlayTests.setUp(self)
        self.d["tasks"]["general_pickup"] = self.d["tasks"].pop("organize_table")
        self.d["tasks"]["classify_objects"] = self.d["tasks"].pop("play_stacking_toy")
        n = self.d["nodes"]["perdon-hou"]
        n["current_task"] = "general_pickup"
        n["fixed_tasks"] = ["general_pickup", "classify_objects"]
        self.e["task"] = "general_pickup"
        self.d["source_index"]["old"].update(task="general_pickup", host="perdon-hou")
        self.d["source_index"]["retained"].update(
            task="classify_objects", native_steps=1100, native_budget=1100,
            original_wall_ns=1793605964449687636)

    def run_switch(self):
        return current.switch_due(self.d, self.e, self.ref, self.retained,
                                  self.at, "synthetic fixture, not real collection")

    def test_due_preserves_sources_peers_counts_and_nanoseconds(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "classify_objects")
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        transition = out["receipt"]["transition"]
        self.assertFalse(transition["baseline_replay"])
        self.assertFalse(transition["source_started"])
        self.assertFalse(transition["reserved"])
        self.assertEqual(len(transition["completed_other_segments"]), 2)

    def test_teacher_positive_does_not_reset_negative_window(self):
        self.e["summary"]["qualified_positive"] = True
        task = self.d["tasks"]["general_pickup"]
        task.update(last_core_gain_at="2026-10-31T11:30:00+00:00", qualified_count=7)
        self.run_switch()
        event = self.d["nodes"]["perdon-hou"]["task_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_window_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_recent_negative_or_unknown_nonzero_origin_rejected(self):
        for recent_negative in ("2026-10-31T11:30:00+00:00", None):
            with self.subTest(recent_negative=recent_negative):
                self.setUp()
                self.d["tasks"]["general_pickup"].update(
                    last_core_gain_at="2026-10-31T11:30:00+00:00",
                    negative_count=2, last_negative_gain_at=recent_negative)
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_two_other_segments_still_required(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_resources_and_user_holds_rejected(self):
        for key, value in (("active_run_id", "live"), ("active_real_simulators", 1),
                           ("owned_resource_launch_hold", True), ("launch_inflight", True),
                           ("user_pause_active", True), ("user_stop", True)):
            with self.subTest(key=key):
                self.setUp()
                self.d["nodes"]["perdon-hou"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_retained_attempts_refusals_and_unread_data_rejected(self):
        for key, value in (("active_teacher_attempt", {"status": "settled"}),
                           ("teacher_attempt_history", [{"synthetic": True}]),
                           ("provider_safety_refusal", {"synthetic": True}),
                           ("teacher_replay_prohibited", True),
                           ("counted_in_quota", True), ("counted_in_negative_quota", True),
                           ("complete_readback", False), ("reusable_DM_failure", False),
                           ("native_success", True), ("native_budget", 1200)):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_unsettled_or_unknown_outcome_rejected(self):
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_positive"] = None
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_owner_source_and_budget_binding_rejected(self):
        for key, value in (("task", "general_pickup"), ("host", "another-host"),
                           ("context", {"path": "synthetic/mismatch", "sha256": "mismatch"})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["active_chat_id"] = "synthetic-other-owner"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_full_positive_target_or_outstanding_reservation_rejected(self):
        self.d["tasks"]["classify_objects"]["qualified_count"] = 10
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["reservations"]["retained"]["negative_quota_reserved"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
