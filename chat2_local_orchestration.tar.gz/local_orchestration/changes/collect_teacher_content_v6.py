"""Same foreground, model and readers with the matching Fasten1900 Native."""
from pathlib import Path
import common_runtime as runtime
import collect_teacher_content_v5 as previous

text = previous.text
for old, new in (
    ("import native_teacher_content_v5 as native", "import native_teacher_content_v6 as native"),
    ("stage.HERE/'native_teacher_content_v5.py'", "stage.HERE/'native_teacher_content_v6.py'"),
    ("from teacher_catalog_binding_v12 import restore\n", "from teacher_catalog_binding_v13 import restore\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("collect_shared_teacher.py")) +
             "::fasten1900_content", "exec"), globals())
