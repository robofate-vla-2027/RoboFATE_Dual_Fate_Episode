"""Synthetic saved-record fixtures only; no model, network, process, or live ledger."""
from copy import deepcopy
from pathlib import Path
import shutil
import sys
import tempfile
import unittest


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata tests prohibit live effects")


sys.addaudithook(reject_live)
HERE = Path(__file__).parent
if (HERE.parent / "snapshot").exists():
    STAGED = tempfile.TemporaryDirectory(prefix="refate-synthetic-conveyor-legacy-")
    for name in ("preparation_metadata_compat_v1.py", "preparation_metadata_compat_v3.py"):
        shutil.copyfile(HERE.parent / "snapshot" / name, Path(STAGED.name) / name)
    shutil.copyfile(HERE / "preparation_metadata_conveyor_v1.py",
                    Path(STAGED.name) / "preparation_metadata_conveyor_v1.py")
    sys.path.insert(0, STAGED.name)
else:
    sys.path.insert(0, str(HERE))
import preparation_metadata_conveyor_v1 as subject

TASK = "pick_from_conveyor_by_image"


def fixture():
    summary = dict(source_id="synthetic-conveyor", run_id="synthetic-run",
                   file_recording_readback_passed=True, native_success=False,
                   native_steps=700, actual_controls=7000)
    cleanup = {role: dict(identity=dict(pid=index + 1, start_ticks=1793470102279866547,
                        boot_id="synthetic-boot"), original_process_absent=True)
               for index, role in enumerate(("native", "policy"))}
    document = dict(schema="refate.common_baseline.settlement.v1", task=TASK,
                    source_id=summary["source_id"], run_id=summary["run_id"],
                    summary=deepcopy(summary), cleanup=deepcopy(cleanup),
                    first_readback_passed=True, new_positive=0, new_negative=0,
                    synthetic_test_fixture=True)
    return document, summary, cleanup


def project(data):
    return subject.failed_baseline_view(*data, source_id="synthetic-conveyor", task=TASK)


class LegacyTests(unittest.TestCase):
    def test_lossless_failure_view(self):
        data = fixture()
        before = deepcopy(data)
        out = project(data)
        self.assertEqual(data, before)
        for key, value in data[0].items():
            self.assertEqual(out[key], value)
        self.assertFalse(out["native_success"])
        self.assertEqual(out["new_positive"], 0)
        self.assertEqual(out["new_negative"], 0)
        self.assertEqual(out["process_closure"]["checks"][0]["identity"]["start_ticks"],
                         1793470102279866547)

    def test_reject_budget_mismatch(self):
        for value in (699, 701, 700.0):
            data = fixture()
            data[1]["native_steps"] = value
            data[0]["summary"] = deepcopy(data[1])
            with self.assertRaises(ValueError):
                project(data)

    def test_reject_missing_observation_readback_and_success_relabeling(self):
        for key, value in (("file_recording_readback_passed", False),
                           ("native_success", True), ("actual_controls", 6990)):
            data = fixture()
            data[1][key] = value
            data[0]["summary"] = deepcopy(data[1])
            with self.assertRaises(ValueError):
                project(data)

    def test_reject_changed_referenced_metadata_or_missing_identity(self):
        data = fixture()
        data[1]["native_steps"] = 699
        with self.assertRaises(ValueError):
            project(data)
        data = fixture()
        data[2]["native"]["identity"].pop("start_ticks")
        data[0]["cleanup"] = deepcopy(data[2])
        with self.assertRaises(ValueError):
            project(data)

    def test_unrelated_scope_and_restore_admission_not_extended(self):
        data = fixture()
        with self.assertRaises(ValueError):
            subject.failed_baseline_view(*data, source_id="synthetic-conveyor", task="foreign-task")
        with self.assertRaises(ValueError):
            subject.before_object_translation({}, {}, {}, task=TASK, t1=1, total=700,
                                              object_key="synthetic", later_step=2)


if __name__ == "__main__":
    unittest.main()
