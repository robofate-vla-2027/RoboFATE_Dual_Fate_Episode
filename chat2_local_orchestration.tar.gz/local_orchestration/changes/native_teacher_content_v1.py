"""Original v12 teacher Native with the new executor and recording policy."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import native_shared_teacher_v12 as previous

text = runtime.edit(previous._source, "import common_recording as recording\n",
                    "import common_recording_content_v2 as recording\n")
exec(compile(text, str(Path(__file__).with_name("native_shared_teacher.py")) +
             "::content_recording", "exec"), globals())
