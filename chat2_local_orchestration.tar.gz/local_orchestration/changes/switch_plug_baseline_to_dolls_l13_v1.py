"""Reuse the closed-baseline revisit for the already prepared Dolls L13."""
import hashlib
from pathlib import Path

import switch_conveyor_baseline_to_dolls_l11_v1 as previous
from closed_baseline_resource_v1 import baseline_checks

PARENT_SHA = "2f56c5be2d28f0f98e3a68ea9437961294b92fc7adf49f689e71913db9a3fa03"
CHANGES = (
    ("pick_from_conveyor_by_image", "plug_in_charger"),
    ('s["layout_id"] == 11 and s["source_sequence"] == list(range(12))',
     's["layout_id"] == 13 and s["source_sequence"] == list(range(14))'),
    ('s["required_accounted_prefix"] == list(range(11))',
     's["required_accounted_prefix"] == list(range(13))'),
)


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Pinned closed-baseline scheduling helper changed")
    text = previous.source()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Existing scheduling parameter seam changed: " + old)
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::plug_dolls_l13", "exec"), globals())
