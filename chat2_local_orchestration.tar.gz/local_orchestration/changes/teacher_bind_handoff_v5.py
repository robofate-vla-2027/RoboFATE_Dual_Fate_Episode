"""Same metadata operation, with matching Fasten1900 entry references."""
from pathlib import Path
import common_runtime as runtime
import teacher_bind_handoff_v4 as previous

CHANGES = (('prepare_teacher_content_v5', 'prepare_teacher_content_v6'),)


def source():
    runtime.read_pin({"path": str(Path(__file__).with_name('teacher_bind_handoff_v4.py')),
                      "sha256": '3b20af3288d865cbce42f50b1afe02c3ce226db76af26b1097f8e6e0301ad164'})
    text = previous.source()
    for old, new in CHANGES:
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten1900_metadata", "exec"), globals())
