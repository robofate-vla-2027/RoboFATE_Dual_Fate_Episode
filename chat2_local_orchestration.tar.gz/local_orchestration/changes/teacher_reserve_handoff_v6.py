"""Same metadata operation, with matching Fasten1900 entry references."""
from pathlib import Path
import common_runtime as runtime
import teacher_reserve_handoff_v5 as previous

CHANGES = (('teacher_catalog_binding_v12', 'teacher_catalog_binding_v13'), ("'general_pickup':'general'}", "'general_pickup':'general','fasten_screws':'fasten'}"))


def source():
    runtime.read_pin({"path": str(Path(__file__).with_name('teacher_reserve_handoff_v5.py')),
                      "sha256": '0f3caf904d7ae290ddca142265f2e009c6a2612804646013241203254f0f7e3d'})
    text = previous.source()
    for old, new in CHANGES:
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten1900_metadata", "exec"), globals())
