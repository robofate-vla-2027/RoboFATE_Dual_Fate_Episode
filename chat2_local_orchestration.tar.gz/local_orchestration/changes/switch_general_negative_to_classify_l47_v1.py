"""Bind the existing five-DM-failure review and closed-source revisit to General."""
import hashlib
from pathlib import Path

import closed_baseline_resource_v1 as closed
import switch_fasten_to_prepared_general_v1 as baseline
import switch_general_to_classify_l22_v1 as previous

SEQUENCE = previous.SEQUENCE
baseline_checks = closed.baseline_checks


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Frozen metadata seam changed: " + old)
    return text.replace(old, new, 1)


def pinned(path, expected):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("Frozen scheduling dependency changed")
    return raw.decode()


def review_negative_shortfall(ledger, source_id, read_document=None):
    path = Path(__file__).with_name("negative_shortfall_deferral_v1.py")
    text = pinned(path, "01f89d4aad4dfe2d8d6edd9ae334243a65d5f37d68850e1480ad393eb910aefc")
    for old, new in (
        ("task = 'insert_tubes'", "task = 'general_pickup'"),
        ("n['active_chat_id'] == '01a16807-8085-7903-be07-66eb332ebf95'",
         "n['active_chat_id'] == '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'"),
        ("ledger['split_manifests'][task]['initial_source_sequence']",
         "ledger['tasks'][task]['source_sequence']"),
        ("e['native_budget'] == 500", "e['native_budget'] == 200"),
    ):
        text = replace_once(text, old, new)
    namespace = {"__name__": "_general_five_source_metadata", "__file__": str(path)}
    exec(compile(text, str(path) + "::general200", "exec"), namespace)
    args = () if read_document is None else (read_document,)
    return namespace["review"](ledger, source_id, *args)


def source():
    pinned(previous.__file__, "1bc489babdf794c348abc55a274aae9fe1312a9480cbe92ec5b1f638894258c6")
    pinned(baseline.__file__, "273196f3e43cda557a096ef708e7894f740b6180292362217aff1399361cde5b")
    pinned(closed.__file__, "a80220ac24361c63c785352c126deb460204888498343263f6669f760b7bc2b8")
    text, original = previous.source(), baseline.source()
    teacher_start = '    assert source["active_teacher_attempt"]["status"] == "settled"'
    baseline_start = "    baseline_checks(terminal)"
    end = '    assert reservation["positive_slots"] == reservation["negative_slots"] == 0'
    for value, start in ((text, teacher_start), (original, baseline_start)):
        if value.count(start) != 1 or value.count(end) != 1:
            raise ValueError("Frozen predecessor-validation seam changed")
    text = replace_once(
        text, text[text.index(teacher_start):text.index(end)],
        original[original.index(baseline_start):original.index(end)])
    for old, new in (
        ('type(terminal["summary"]["qualified_positive"]) is bool',
         'type(terminal["summary"]["qualified_negative"]) is bool'),
        ('s["layout_id"] == 22 and s["source_sequence"] == SEQUENCE',
         's["layout_id"] == 47 and s["source_sequence"] == SEQUENCE'),
        ('s["required_accounted_prefix"] == SEQUENCE[:9]',
         's["required_accounted_prefix"] == SEQUENCE[:15]'),
        ('    assert elapsed >= 5400 or (negative_elapsed is not None and negative_elapsed >= 5400), "Original low-yield window not reached"',
         '    shortfall = review_negative_shortfall(d, terminal["source_id"])'),
        ('        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason)',
         '        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason,\n'
         '        negative_shortfall_review=shortfall, scheduling_trigger=shortfall["trigger"])'),
        ('phase="deferred_after_settled_no_gain"',
         'phase="deferred_after_settled_negative_shortfall"'),
    ):
        text = replace_once(text, old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::general_negative_classify47", "exec"),
     globals())
