"""Synthetic metadata only; no real sources, model calls, network, or simulator."""
from copy import deepcopy
import unittest

from prepare_classify_legacy_handoff_v1 import (
    CATALOG_OWNER, LEGACY_OWNER, TASK, validate_projection,
)


def fixture():
    original = {
        "task": TASK, "owner_chat": LEGACY_OWNER, "initial_source_sequence": [1, 6],
        "previous_plan": {"partition": {"reserved_final": [53, 54]}},
        "layout_to_group": {"1": "synthetic_a", "6": "synthetic_b"},
        "families": {},
        "frozen_nanoseconds": 1793461079151749929,
    }
    projected = deepcopy(original)
    projected.update(owner_chat=CATALOG_OWNER, historical_manifest_owner=LEGACY_OWNER,
                     original_partition=deepcopy(original["previous_plan"]["partition"]),
                     layouts={})
    for i, group in ((1, "synthetic_a"), (6, "synthetic_b")):
        member = {"bank": 0, "layout_id": i, "path": f"/synthetic/layout_{i}.json",
                  "sha256": str(i) * 64}
        family = {"split": "student_train", "layouts": [member]}
        original["families"][group] = deepcopy(family)
        projected["families"][group] = deepcopy(family)
        projected["layouts"][str(i)] = {
            "layout_id": i, "native_bank": 0, "group_id": group, "split": "student_train",
            "layout_ref": {k: member[k] for k in ("path", "sha256")},
            "initialization_distinct_from_preceding": True,
        }
    return original, projected


class ProjectionTests(unittest.TestCase):
    def test_preserves_frozen_fields_and_integer(self):
        original, projected = fixture()
        before = deepcopy(original)
        self.assertTrue(validate_projection(original, projected, 6))
        self.assertEqual(original, before)
        self.assertEqual(projected["frozen_nanoseconds"], 1793461079151749929)

    def test_rejects_reordered_sequence(self):
        original, projected = fixture()
        projected["initial_source_sequence"].reverse()
        with self.assertRaises(ValueError):
            validate_projection(original, projected, 6)

    def test_rejects_sealed_source(self):
        original, projected = fixture()
        original["previous_plan"]["partition"]["reserved_final"].append(6)
        with self.assertRaises(ValueError):
            validate_projection(original, projected, 6)

    def test_rejects_duplicate_initialization(self):
        original, projected = fixture()
        projected["layouts"]["6"]["initialization_distinct_from_preceding"] = False
        with self.assertRaises(ValueError):
            validate_projection(original, projected, 6)

    def test_rejects_member_hash_change(self):
        original, projected = fixture()
        projected["layouts"]["6"]["layout_ref"]["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            validate_projection(original, projected, 6)

    def test_rejects_extra_layout(self):
        original, projected = fixture()
        projected["layouts"]["7"] = deepcopy(projected["layouts"]["6"])
        with self.assertRaises(ValueError):
            validate_projection(original, projected, 6)


if __name__ == "__main__":
    unittest.main()
