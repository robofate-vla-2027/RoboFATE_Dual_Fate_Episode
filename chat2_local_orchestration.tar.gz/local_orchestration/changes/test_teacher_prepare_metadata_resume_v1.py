"""Synthetic local-files-only tests; no network, model, simulator or subprocess."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import teacher_prepare_metadata_resume_v1 as target


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "synthetic_selection.json"
        self.saved = dict(
            data_kind="actual_source_metadata_not_restore_admission",
            at="synthetic-original-time", source_id="synthetic-source",
            t1=40, remaining_steps=1060, native_limit=1100,
            source_reference={"path": "synthetic-only", "sha256": "fixture"},
            actual_restore_verified=False, teacher_started=False, qualified=False,
            source_reexecuted=False, full_payload_redecoded=False,
            dispatch_issued=False, reserved=False, nanoseconds=1800000000000000001,
        )
        self.raw = (json.dumps(self.saved) + "\n").encode()
        self.path.write_bytes(self.raw)
        self.ref = dict(path=str(self.path), sha256=hashlib.sha256(self.raw).hexdigest())

    def test_reuse_keeps_original_bytes_and_large_integer(self):
        value = copy.deepcopy(self.saved)
        value["at"] = "synthetic-new-time"
        self.assertEqual(target.reuse_selection(self.path, value, self.ref), self.ref)
        self.assertEqual(self.path.read_bytes(), self.raw)
        self.assertEqual(json.loads(self.raw)["nanoseconds"], 1800000000000000001)

    def test_each_source_or_budget_change_rejected(self):
        for key in ("source_id", "t1", "remaining_steps", "native_limit", "source_reference"):
            with self.subTest(key=key), self.assertRaises(AssertionError):
                changed = copy.deepcopy(self.saved)
                changed[key] = "changed"
                target.reuse_selection(self.path, changed, self.ref)

    def test_hash_change_rejected(self):
        self.path.write_bytes(self.raw + b" ")
        with self.assertRaises(AssertionError):
            target.reuse_selection(self.path, self.saved, self.ref)

    def test_path_change_rejected(self):
        with self.assertRaises(AssertionError):
            target.reuse_selection(self.path, self.saved, dict(self.ref, path="different"))

    def test_missing_record_rejected(self):
        self.path.unlink()
        with self.assertRaises(FileNotFoundError):
            target.reuse_selection(self.path, self.saved, self.ref)

    def test_corrupt_record_rejected(self):
        self.path.write_bytes(b"not json")
        ref = dict(self.ref, sha256=hashlib.sha256(b"not json").hexdigest())
        with self.assertRaises(json.JSONDecodeError):
            target.reuse_selection(self.path, self.saved, ref)

    def test_started_metadata_rejected(self):
        saved = dict(self.saved, teacher_started=True)
        raw = json.dumps(saved).encode()
        self.path.write_bytes(raw)
        ref = dict(self.ref, sha256=hashlib.sha256(raw).hexdigest())
        with self.assertRaises(AssertionError):
            target.reuse_selection(self.path, saved, ref)

    def test_exact_original_patch_compiles_without_executing(self):
        raw = Path(target.__file__).with_name(target.ORIGINAL).read_bytes()
        text = target.patched_source(raw)
        compile(text, "synthetic-compile-only", "exec")
        self.assertIn("sel=reuse_saved_selection(", text)
        with self.assertRaises(AssertionError):
            target.patched_source(raw + b"\n")


if __name__ == "__main__":
    unittest.main()
