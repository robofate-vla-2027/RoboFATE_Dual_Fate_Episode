"""Same preparation with matching Fasten1900 Native and unchanged wall limits."""
from pathlib import Path
import common_runtime as runtime
import prepare_teacher_content_v5 as previous

text = previous.text
for old, new in (
    ("import native_teacher_content_v5 as native_shared_teacher\n",
     "import native_teacher_content_v6 as native_shared_teacher\n"),
    ("from teacher_catalog_binding_v12 import restore, budget as _bound_budget\n",
     "from teacher_catalog_binding_v13 import restore, budget as _bound_budget\n"),
    ("from teacher_catalog_binding_v12 import persistence as teacher_persistence_binding\n",
     "from teacher_catalog_binding_v13 import persistence as teacher_persistence_binding\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("prepare_shared_teacher.py")) +
             "::fasten1900_content", "exec"), globals())
