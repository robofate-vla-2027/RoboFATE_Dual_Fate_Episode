import sys,json,hashlib,datetime
def no_live_effect(event,args):
 if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.kill','os.killpg'):
  raise RuntimeError('SOURCE_METADATA_ONLY '+event)
sys.addaudithook(no_live_effect)
from pathlib import Path
x=json.load(sys.stdin);sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import collection_append_binding_v1 as binding
import execution_owner_binding_v1 as execution
execution.install()
assert x['execution_owner']==execution.NEW
old=binding.document(x['current_preparation']);binding.load_native_layout(old)
assert old['source']['task']=='plug_in_charger' and old['native_step_limit']==400
prior_ref=old['provenance']['split'];prior=binding.lineage(prior_ref);layout=len(prior['initial_source_sequence'])
assert old['source']['layout_id']==layout-1
if layout>=53:print(json.dumps({'next_source':None,'nonsealed_sequence_exhausted':True,'current_layout':layout-1}));raise SystemExit(0)
p=binding.metadata.NATIVE/f'Assets/Eval_Layout/RoboDojo/arx_x5/0/plug_in_charger_{layout}.json'
layout_ref=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest());manifest=binding.build_next(prior_ref,layout_ref)
def save(p,value):
 if p.exists():assert binding.metadata.original.same(binding.metadata.original.decode(p.read_bytes()),value)
 else:
  with p.open('x') as f:json.dump(value,f,indent=2);f.write(chr(10))
 return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
split=save(binding.path_for(layout),manifest)
canonical_path=binding.DIRECTORY/f'PREPARATION_L{layout}_APPEND_001.json'
canonical_preexisted=canonical_path.exists()
prepared,_=binding.prepare_source(task='plug_in_charger',layout_id=layout,split_ref=split,native_total=400,task_ref=old['provenance']['task_implementation']);binding.load_native_layout(prepared)
preparation=save(binding.DIRECTORY/f'PREPARATION_L{layout}_APPEND_001.json',prepared)
# The canonical descriptor retains the original catalog identity, not launch authority.
record=dict(schema='refate.source_preparation.execution_handoff.v1',data_kind='preparation_only',
 at=datetime.datetime.now(datetime.timezone.utc).isoformat(),prepared_by=execution.NEW,
 execution_owner=execution.NEW,source_owner=prepared['source']['source_owner'],
 canonical_descriptor_legacy_execution_owner=prepared['source']['execution_owner'],
 canonical_descriptor_identity_is_not_current_executor=True,
 source_id=prepared['source']['source_id'],layout=layout,native_budget=400,
 preparation=preparation,split=split,predecessor_preparation=x['current_preparation'],
 created_canonical_preparation=not canonical_preexisted,handoff=execution.install(),
 fixed_source_order_preserved=True,original_split_owners_preserved=True,
 current_inflight_not_changed=True,source_reserved=False,actual_launch=False,
 positive_delta=0,negative_delta=0)
receipt_path=binding.DIRECTORY/f'PREPARATION_L{layout}_EXECUTION_HANDOFF_01a19072_001.json'
if receipt_path.exists():
 existing=binding.metadata.original.decode(receipt_path.read_bytes())
 for key in ('prepared_by','execution_owner','source_owner','source_id','preparation','split','handoff'):
  assert existing[key]==record[key]
 record=existing
receipt=save(receipt_path,record)
print(json.dumps(dict(preparation_ref=preparation,split_ref=split,source_id=prepared['source']['source_id'],
 layout=layout,budget=400,required_accounted_prefix=prepared['source']['required_accounted_prefix'],
 preparation_executor=execution.NEW,execution_handoff=receipt,
 current_inflight_not_changed=True,reservation_issued=False,actual_launch=False)))
