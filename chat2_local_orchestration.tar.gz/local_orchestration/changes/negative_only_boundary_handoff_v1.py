"""Current controller, preserving the recorded executor of an old DM source."""
from pathlib import Path
import hashlib
import negative_only_baseline_boundary_v1 as previous

raw = Path(previous.__file__).read_bytes()
assert hashlib.sha256(raw).hexdigest() == "b43066e357fa1a68bc2b40f4f283d637f2487a19124520e65c5d6cd82bbf365a"
text = raw.decode()
for before, after in (
    ("OWNER = '01a16807-8085-7903-be07-66eb332ebf95'",
     "OWNER = '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'"),
    ("evidence['execution_owner'] == OWNER",
     "evidence['execution_owner'] in ('01a16807-8085-7903-be07-66eb332ebf95', OWNER)"
     " and evidence['execution_owner'] == ledger['source_index'][evidence['source_id']].get('execution_owner')"),
):
    assert text.count(before) == 1
    text = text.replace(before, after, 1)
exec(compile(text, str(Path(__file__)) + "::historical_predecessor", "exec"), globals())
