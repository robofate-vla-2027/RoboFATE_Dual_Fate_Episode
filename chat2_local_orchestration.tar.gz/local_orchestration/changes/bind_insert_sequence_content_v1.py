"""Reuse the existing binder and bind the paired future Insert entry."""
from pathlib import Path
import insert_sequence_handoff_v1 as handoff
handoff.install()
import common_runtime as runtime

path = Path(__file__).with_name("bind_recording_content_v1.py")
text = runtime.read_pin({
    "path": str(path),
    "sha256": "a0472625dfa7f9df017541729ca78f0624edf5280ca0736e7894c2dac155befc",
}).decode()
text = runtime.edit(text, "collect_recording_content_v1",
                    "collect_insert_sequence_content_v1", count=2)
exec(compile(text, str(path) + "::sequence_handoff", "exec"), globals())
