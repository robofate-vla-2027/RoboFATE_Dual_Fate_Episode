"""Record actual constant RGB; retain independent capture and integrity checks."""
import hashlib
from pathlib import Path
import sys

import common_recording as previous
import common_runtime as runtime
import isolation_stage as stage
from common_recording import initialize_recording, execute_action, publisher, need

CAMERAS = {"cam_head", "cam_left_wrist", "cam_right_wrist"}


def policy_reference():
    path = Path(__file__).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def validate_rgb(image, stats):
    import numpy as np
    need(isinstance(image, np.ndarray) and image.dtype == np.uint8
         and image.shape == (480, 640, 3), "Malformed or wrong-size actual RGB")
    need(stats["shape"] == list(image.shape)
         and stats["sha256"] == hashlib.sha256(image.tobytes()).hexdigest(),
         "Actual RGB and saved statistics differ")
    constant = bool(image.std() == 0)
    if "constant_pixel_values" in stats:
        need(type(stats["constant_pixel_values"]) is bool
             and stats["constant_pixel_values"] == constant,
             "Saved constant-pixel diagnostic differs from actual RGB")
    return {"constant_pixel_values": constant, "std": float(image.std())}


def observation_source(raw):
    text = raw.decode() if isinstance(raw, bytes) else raw
    edits = (
        ("        if stats[camera]['std'] == 0:\n            raise ValueError('Constant camera observation')",
         "        stats[camera]['constant_pixel_values'] = stats[camera]['std'] == 0"),
        ("            if not std > 0:\n                raise ValueError('Constant camera observation')",
         "            # Contrast is diagnostic; pt_capture verifies frame freshness."),
        ("'std': std, 'sha256': hashlib.sha256(frame.tobytes()).hexdigest()}",
         "'std': std, 'sha256': hashlib.sha256(frame.tobytes()).hexdigest(),\n"
         "                           'constant_pixel_values': std == 0}"),
    )
    for old, new in edits:
        text = runtime.edit(text, old, new)
    return text


def adapt_modules(modules):
    io = modules["observation_io"]
    path = stage.REFERENCE / "effective/native/observation_io.py"
    need(Path(io.__file__) == path, "Different observation implementation")
    raw = stage.pinned_source("effective/native/observation_io.py")
    text = observation_source(raw)
    identity = {
        "policy": policy_reference(),
        "original_observation_source_sha256": hashlib.sha256(raw).hexdigest(),
        "effective_observation_source_sha256": hashlib.sha256(text.encode()).hexdigest(),
        "pixel_variance_is_data_gate": False, "raw_rgb_preserved": True,
        "unchanged_pt_capture_sha256": hashlib.sha256(
            stage.pinned_source("effective/native/pt_capture.py")).hexdigest(),
    }
    old = getattr(io, "content_policy", None)
    if old is not None:
        need(old == identity, "Conflicting observation content policy")
        return modules
    namespace = dict(io.__dict__)
    exec(compile(text, str(path) + "::content_diagnostic_v2", "exec"), namespace)
    io.save_observation = namespace["save_observation"]
    io.OrderedObservationWriter = namespace["OrderedObservationWriter"]
    io.content_policy = identity
    return modules


def load_core():
    return adapt_modules(previous.load_core())


def runtime_snapshot(task):
    value = previous.runtime_snapshot(task)
    value["observation_content_policy"] = sys.modules["observation_io"].content_policy
    return value


def baseline_source(text):
    text = runtime.edit(text, "    hashes={}\n    for name,data in obs['vision'].items():",
                        "    hashes={};content_diagnostics={}\n    for name,data in obs['vision'].items():")
    text = runtime.edit(text,
        "        need(list(image.shape)==stats[name]['shape'] and image.std()>0,'Image shape/constant check')",
        "        content_diagnostics[name]=_content_policy.validate_rgb(image,stats[name])")
    text = runtime.edit(text, "'arrays_sha256':digest(folder/'arrays.npz'),'rgb_sha256':hashes}",
                        "'arrays_sha256':digest(folder/'arrays.npz'),'rgb_sha256':hashes,"
                        "'observation_content_diagnostics':content_diagnostics}")
    return text + "\nimport common_recording_content_v2 as _content_policy\n"


def teacher_source(text):
    text = runtime.edit(text, "    public=decoder();decoded=0",
                        "    public=decoder();decoded=0;constant_rgb_diagnostics=[]")
    old = ("            array=view['vision'][c]['color'];need(list(array.shape)==[480,640,3] "
           "and str(array.dtype)=='uint8' and sha(array.tobytes())==stats[c]['sha256'], "
           "'1.3', 'Decoded camera does not match saved boundary: '+str(folder)+'/'+c)")
    text = runtime.edit(text, old, old + "\n"
        "            diagnostic=_content_policy.validate_rgb(array,stats[c])\n"
        "            if diagnostic['constant_pixel_values']:\n"
        "                constant_rgb_diagnostics.append(dict(native_index=i,camera=c,**diagnostic))")
    text = runtime.edit(text, "    diagnostics['t1_rgb_exact_match']=t1_rgb_exact_match",
                        "    diagnostics['t1_rgb_exact_match']=t1_rgb_exact_match\n"
                        "    diagnostics['observation_content_policy']=_content_policy.policy_reference()\n"
                        "    diagnostics['constant_rgb_frames']=constant_rgb_diagnostics")
    return text + "\nimport common_recording_content_v2 as _content_policy\n"
