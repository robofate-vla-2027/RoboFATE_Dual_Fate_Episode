"""Reuse the original reservation and explicitly accounted historical prefix."""
import ast
import base64
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys

from general_prefix_handoff_v1 import ADAPTER, NEXT_SOURCE, OWNER, PREFIX, TASK, document, ref, reserver
from prepare_general_l7_handoff_v1 import metadata_only

path = Path(__file__).with_name("classify_revisit_handoff_v1.py")
raw = path.read_bytes()
if hashlib.sha256(raw).hexdigest() != "cc1f904364bd0e95bf39772d129ec35c2ad33234994e3497f523810d94e20739":
    raise ValueError("Frozen reservation adapter changed")
tree = ast.parse(raw)
matches = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "reserve_next"]
if len(matches) != 1:
    raise ValueError("Frozen reservation entry changed")
text = ast.get_source_segment(raw.decode(), matches[0])
if text.count("layout_id=6") != 1:
    raise ValueError("Frozen ordinal interface changed")
text = text.replace("layout_id=6", "layout_id=7", 1).replace("Classify L6", "General L7").replace("Classify", "General")
exec(compile(text, str(path) + "::general200_existing_reservation", "exec"), globals())


if __name__ == "__main__":
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    ledger = json.loads(base64.b64decode(x["ledger_b64"]))
    boundary = document(x["boundary_ref"])
    source = boundary["next_preparation"]["prepared"]["source"]
    if (source["source_id"] != NEXT_SOURCE or source["required_accounted_prefix"] != PREFIX
            or boundary["next_preparation"]["prepared"]["native_step_limit"] != 200):
        raise ValueError("Only the prepared original General L7 source can be reserved")
    result = reserve_next(ledger, boundary, x["boundary_ref"],
                          datetime.datetime.now(datetime.timezone.utc).isoformat())
    task = result["ledger"]["tasks"][TASK]
    if task["source_sequence"] != PREFIX:
        raise ValueError("Original source sequence changed before reservation")
    task.setdefault("source_sequence_history", []).append({
        "at": result["receipt"]["at"], "previous": deepcopy(PREFIX),
        "adoption": boundary["next_preparation"]["ref"],
        "prefix_accounting": boundary["legacy_prefix_ref"],
        "original_memberships_unchanged": True, "old_sources_replayed": False,
    })
    task["source_sequence"] = PREFIX + [7]
    task["current_source_projection"] = boundary["next_preparation"]["prepared"]["provenance"]["split"]
    task["next_independent_source_preparation"] = boundary["next_preparation"]["ref"]
    result["receipt"]["source_sequence_appended"] = PREFIX + [7]
    print(json.dumps(result))
