"""Same owner-safe accounting transaction, adding only the General200 tuple."""
from pathlib import Path
import sys
import teacher_ledger_owner_handoff_v3 as previous

collection_groups = previous.collection_groups
_BINDINGS = dict(previous._BINDINGS)
_BINDINGS["general_pickup"] = (
    200, r"c2_general_pickup_l[0-9]+_evo_common_teacher_[0-9]{4}_01a16807")
_TEXT = previous._TEXT
exec(compile(_TEXT, str(Path(__file__)) + "::general200_executor_transaction", "exec"), globals())


def bind_cli(cli):
    current = sys.modules[__name__]
    previous.bind_cli(cli)
    assert cli.ledger_core is previous and cli._transaction.ledger_core is previous
    cli.ledger_core = current
    cli._transaction.ledger_core = current
    assert cli._transaction.compute.__globals__["ledger_core"] is current
