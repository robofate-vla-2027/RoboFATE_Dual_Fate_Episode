"""Reuse the closed-baseline low-yield revisit for prepared Bottles L26."""
import hashlib
from pathlib import Path

import switch_plug_baseline_to_dolls_l13_v1 as previous
from closed_baseline_resource_v1 import baseline_checks

CHANGES = (
    ("plug_in_charger", "classify_objects"),
    ("sort_nesting_dolls_by_size", "put_bottles_into_dustbin"),
    ('prepared["native_step_limit"] == 1050', 'prepared["native_step_limit"] == 700'),
    ('s["layout_id"] == 13 and s["source_sequence"] == list(range(14))',
     's["layout_id"] == 26 and s["source_sequence"] == list(range(27))'),
    ('s["required_accounted_prefix"] == list(range(13))',
     's["required_accounted_prefix"] == list(range(26))'),
)


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != (
            "c70aa471da50b477ba10be03d5f1218abd9bf6bd7c25e5c0ee39c6d70d3b52ab"):
        raise ValueError("Pinned closed-baseline scheduling helper changed")
    text = previous.source()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Existing scheduling parameter seam changed: " + old)
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::classify_bottles_l26", "exec"),
     globals())
