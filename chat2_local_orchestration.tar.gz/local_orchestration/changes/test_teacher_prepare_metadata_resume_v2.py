"""Offline synthetic metadata tests; no simulation, subprocess or model calls."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import teacher_prepare_metadata_resume_v1 as old
import teacher_prepare_metadata_resume_v2 as new


class ResumeGuards(unittest.TestCase):
    def test_only_selection_write_seam_changes(self):
        text = "release='current-v6'\nsel=write(path, selection)\nrun.mkdir()\n"
        self.assertEqual(
            new.patched_source(text),
            "release='current-v6'\nsel=reuse_saved_selection(path, selection)\nrun.mkdir()\n",
        )

    def test_missing_or_duplicate_seam_fails(self):
        for text in ("write(path, selection)", "sel=write(a)\nsel=write(b)"):
            with self.assertRaises(ValueError):
                new.patched_source(text)

    def test_exact_metadata_reuse_preserves_original_bytes(self):
        with tempfile.TemporaryDirectory(prefix="refate_synthetic_selection_") as tmp:
            path = Path(tmp) / "selection.json"
            value = {
                "data_kind": "actual_source_metadata_not_restore_admission",
                "at": "synthetic-original-time",
                "t1": 44,
                "actual_restore_verified": False,
                "teacher_started": False,
                "qualified": False,
                "source_reexecuted": False,
                "full_payload_redecoded": False,
                "dispatch_issued": False,
                "reserved": False,
            }
            raw = json.dumps(value).encode()
            path.write_bytes(raw)
            ref = {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}
            self.assertEqual(
                old.reuse_selection(path, dict(value, at="synthetic-new-time"), ref), ref
            )
            self.assertEqual(path.read_bytes(), raw)
            for changed in (dict(value, t1=55), dict(value, teacher_started=True)):
                with self.assertRaises(AssertionError):
                    old.reuse_selection(path, changed, ref)
            with self.assertRaises(AssertionError):
                old.reuse_selection(path, value, dict(ref, sha256="0" * 64))


if __name__ == "__main__":
    unittest.main()
