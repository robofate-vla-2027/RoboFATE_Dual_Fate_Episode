"""Same pure reservation rules, with current executor distinct from preparer."""
from pathlib import Path
import hashlib
import common_owner_reservation_v2 as previous
from common_owner_reservation_v2 import _settled_predecessor, _inherited_prefix

path = Path(__file__).with_name("common_owner_reservation_v2.py")
if hashlib.sha256(path.read_bytes()).hexdigest() != "db5f25d6dfb593a4ba552c3f469d99f9e58ca717c4204d9c058f3240d136f3c7":
    raise ValueError("Original owner reservation changed")


def historical_preparer_allowed(source):
    return (source.get("execution_owner") in (
        "01a16807-8085-7903-be07-66eb332ebf95",
        "01a19072-9e5e-7e02-b77a-8f115cfc9bd0")
        and source.get("source_owner") in (
            "01a16338-bd36-78e3-ac27-56c3e62e3333",
            "01a16807-8085-7903-be07-66eb332ebf95",
            "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"))


text = previous._text
for old, new in (
    ("OWNER = '01a16807-8085-7903-be07-66eb332ebf95'",
     "OWNER = '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'"),
    ("and source['execution_owner'] == OWNER", "and historical_preparer_allowed(source)"),
):
    if text.count(old) != 1:
        raise ValueError("Reservation executor interface changed")
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::explicit_executor", "exec"), globals())
