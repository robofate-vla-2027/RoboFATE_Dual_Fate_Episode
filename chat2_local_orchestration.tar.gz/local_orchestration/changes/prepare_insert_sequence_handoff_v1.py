"""Prepare one conditional Insert append, without issuance or simulation."""
import hashlib
import json
from pathlib import Path
import sys

import insert_sequence_handoff_v1 as handoff


def metadata_only(event, args):
    if event == "socket.gethostname":
        return
    if event.startswith(("socket.", "subprocess.", "os.spawn")) or event == "os.system":
        raise RuntimeError("Source metadata preparation forbids live effects: " + event)


def ref(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    if set(x) != {
        "execution_owner", "task", "encoded_seed", "expected_raw_sha256",
        "prior_split_ref", "prior_sequence_ref",
    } or x["execution_owner"] != handoff.EXECUTOR:
        raise ValueError("Explicit current executor and pinned append inputs required")
    proof = handoff.install()
    import source_sequence_binding as sequence

    layout = x["encoded_seed"]
    if type(layout) is not int or not 8 <= layout < 53:
        raise ValueError("Only the next nonsealed Insert ordinal is eligible")
    directory = Path(sequence.__file__).parent.parent / "preparations"
    path = directory / f"INSERT_L{layout}_COMMON_PREPARATION_001.json"
    evidence_path = directory / f"INSERT_L{layout}_EXECUTION_HANDOFF_01a19072_001.json"
    if path.exists() or evidence_path.exists():
        raise ValueError("Preparation exists; inspect and reuse, never overwrite")
    arguments = {k: v for k, v in x.items() if k != "execution_owner"}
    prepared = sequence.prepare_source(**arguments)
    sequence.load_native_layout(prepared)
    before = {key: ref(Path(x[key]["path"]))
              for key in ("prior_split_ref", "prior_sequence_ref")}
    if any(before[key] != x[key] for key in before):
        raise ValueError("Prior source evidence changed")
    preparation = save(path, prepared)
    result = dict(
        data_kind="preparation_only", execution_owner=handoff.EXECUTOR,
        source_owner=prepared["source"]["source_owner"],
        canonical_descriptor_legacy_execution_owner=prepared["source"]["execution_owner"],
        canonical_descriptor_identity_is_not_current_executor=True,
        source_id=prepared["source"]["source_id"], preparation_ref=preparation,
        prior_split=x["prior_split_ref"], prior_sequence=x["prior_sequence_ref"],
        handoff=proof, validator=ref(Path(handoff.__file__)),
        frozen_validator=ref(Path(sequence.__file__)),
        native_budget=prepared["native_step_limit"],
        required_accounted_prefix=prepared["source"]["required_accounted_prefix"],
        source_registered=False, source_reserved=False, actual_launch=False,
        original_documents_modified=False, sealed_content_read=False,
        future_entry_adoption_required=True, positive_delta=0, negative_delta=0,
    )
    result["evidence_ref"] = save(evidence_path, result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
