"""Synthetic metadata tests only; no model, provider, simulator, or process calls."""
from copy import deepcopy
import unittest

import prepare_general_l7_handoff_v1 as prep


def fixture():
    original = {
        "task": prep.TASK,
        "owner_chat": prep.LEGACY_OWNER,
        "initial_source_sequence": list(prep.PREFIX),
        "previous_plan": {"partition": {"reserved_final": [53, 54]}},
        "families": {},
        "layout_to_group": {},
    }
    rows = {}
    for i in prep.PREFIX + [7]:
        group = f"synthetic-family-{i}"
        member = {"bank": 0, "layout_id": i, "path": f"/synthetic/{i}.json", "sha256": f"{i:064x}"}
        original["families"][group] = {"group_id": group, "split": "student_train", "layouts": [member]}
        original["layout_to_group"][str(i)] = group
        rows[str(i)] = {
            "layout_id": i, "native_bank": 0, "group_id": group, "split": "student_train",
            "layout_ref": {k: member[k] for k in ("path", "sha256")},
            "initialization_distinct_from_preceding": True,
        }
    projected = prep.extended_manifest(original)
    projected.update(owner_chat=prep.CATALOG_OWNER, historical_manifest_owner=prep.LEGACY_OWNER,
                     original_partition=deepcopy(original["previous_plan"]["partition"]), layouts=rows)
    return original, projected


class GeneralMetadataTests(unittest.TestCase):
    def test_original_noncontiguous_order_and_families_preserved(self):
        original, projected = fixture()
        before = deepcopy(original)
        self.assertTrue(prep.validate_projection(original, projected))
        self.assertEqual(original, before)
        self.assertEqual(projected["initial_source_sequence"], [1, 2, 3, 4, 0, 5, 6, 7])

    def test_changed_order_rejected(self):
        original, projected = fixture()
        projected["initial_source_sequence"] = list(range(8))
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_family_reassignment_rejected(self):
        original, projected = fixture()
        projected["families"]["synthetic-family-7"]["split"] = "student_dev"
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_source_bytes_reference_change_rejected(self):
        original, projected = fixture()
        projected["layouts"]["7"]["layout_ref"]["sha256"] = "f" * 64
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_sealed_family_rejected(self):
        original, projected = fixture()
        original["families"]["synthetic-family-7"]["split"] = "sealed_eval"
        projected["families"]["synthetic-family-7"]["split"] = "sealed_eval"
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_duplicate_initialization_rejected(self):
        original, projected = fixture()
        projected["layouts"]["7"]["initialization_distinct_from_preceding"] = False
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_extra_source_projection_rejected(self):
        original, projected = fixture()
        projected["layouts"]["8"] = deepcopy(projected["layouts"]["7"])
        with self.assertRaises(ValueError):
            prep.validate_projection(original, projected)

    def test_owner_and_sealed_boundary_rejected(self):
        original, projected = fixture()
        for key, value in [("owner_chat", prep.OWNER), ("original_partition", {"reserved_final": []})]:
            changed = deepcopy(projected)
            changed[key] = value
            with self.assertRaises(ValueError):
                prep.validate_projection(original, changed)


if __name__ == "__main__":
    import sys
    sys.addaudithook(prep.metadata_only)
    unittest.main()
