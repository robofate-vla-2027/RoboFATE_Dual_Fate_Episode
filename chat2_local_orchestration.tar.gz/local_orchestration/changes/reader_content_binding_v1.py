"""Original source-identity reader with contrast diagnostics, not a new audit."""
from pathlib import Path
import common_runtime as runtime
import common_recording_content_v2 as content
import isolation_stage as stage

path = Path(__file__).with_name("reader_identity_binding.py")
text = runtime.read_pin({"path": str(path), "sha256":
    "1cd1e37b8c54d089c54e597c641a43b603157ec256aa13c9b454337365d30731"}).decode()
text = runtime.edit(text, "        text = previous(raw)",
                    "        text = content.baseline_source(previous(raw))")
text = runtime.edit(text, "    previous = base._baseline_source",
                    "    base.OWNER_CHAT = stage.OWNER\n    previous = base._baseline_source")
exec(compile(text, str(path) + "::content_diagnostic_binding", "exec"), globals())
