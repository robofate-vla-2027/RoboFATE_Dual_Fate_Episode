"""Reuse the current closed-resource boundary for prepared Fasten L3."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("boundary_content_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "57c899ca5072edd49875716198b553ce6ceeeb8586f331fc85d80a4d16edd315"):
        raise ValueError("Original resource boundary changed")
    text = raw.decode()
    for old, new in (
        ("import collection_append_binding_v1 as binding",
         "import task_configured_binding as binding"),
        ("settlement_ref=ref(prior/",
         "from fasten_prefix_handoff_v1 import validate_review\n"
         "review=doc(x['legacy_prefix_ref']);validate_review(review,x['preparation_ref'],prepared['source'])\n"
         "assert prepared['native_step_limit']==1900\n"
         "settlement_ref=ref(prior/"),
        (";bref=write(run/'MAIN_BOUNDARY_001.json',b)",
         ";b['legacy_prefix_ref']=x['legacy_prefix_ref']"
         ";b['legacy_prefix_review']=review"
         ";b['legacy_prefix_adapter']=ref(Path(__file__).with_name('fasten_prefix_handoff_v1.py'))"
         ";bref=write(run/'MAIN_BOUNDARY_001.json',b)"),
    ):
        if text.count(old) != 1:
            raise ValueError("Original boundary interface changed")
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten_metadata", "exec"), globals())
