"""Fresh resource boundary for one prepared source; no simulator or model launch."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import sys

from classify_prefix_handoff_v1 import ADAPTER, NEXT_SOURCE, ROOT, document, ref


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def main():
    x = json.load(sys.stdin)
    sys.path.insert(0, str(ADAPTER))
    import collect_recording_content_v1 as collection
    import task_configured_binding as configured
    fg = collection.core.foreground
    fg.host()
    prepared = document(x["preparation_ref"])
    configured.load_native_layout(prepared)
    if prepared["source"]["source_id"] != NEXT_SOURCE or prepared["native_step_limit"] != 1100:
        raise ValueError("Wrong next Classify source")
    terminal = document(x["terminal_ref"])
    if not (terminal["task"] == "plug_in_charger" and terminal["safe_for_next_simulator"] is True):
        raise ValueError("Previous teacher resources are not closed")
    review = document(x["prefix_ref"])
    if review["preparation_ref"] != x["preparation_ref"] or review["live_referenced_processes"]:
        raise ValueError("Legacy source accounting does not match")
    referenced_runs = set()
    for entry in review["entries"]:
        receipt = document(entry["saved_disposition"])
        referenced_runs.update(receipt[k] for k in ("run_id", "episode_id", "source_run_id") if k in receipt)
    for path in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            raw = path.read_bytes()
            if any(run.encode() in raw for run in referenced_runs):
                raise ValueError("A referenced historical Classify process is live")
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    for row in terminal["own_process_checks"]:
        identity = row["identity"]
        path = Path("/proc") / str(identity["pid"]) / "stat"
        if (path.exists() and boot == identity["boot_id"]
                and int(path.read_text().rsplit(")", 1)[1].split()[19]) == identity["start_ticks"]):
            raise ValueError("Previous owned process is still live")
    prior_run = ADAPTER.parent / "runs/c2_plug_in_charger_l17_common_baseline_0018_01a16807"
    settlement_ref = ref(prior_run / "MAIN_SETTLEMENT_001.json")
    settlement = document(settlement_ref)
    if not (settlement["source_id"] == terminal["source_id"]
            and settlement["first_readback_passed"] and settlement["safe_for_next_simulator"]):
        raise ValueError("Source predecessor is not settled")
    # Historical run naming is separate from the explicitly bound current executor.
    run = ADAPTER.parent / "runs/c2_classify_objects_l6_common_baseline_0001_01a16807"
    if run.exists():
        raise ValueError("Next run already exists; inspect rather than repeating preparation")
    allocation = fg.allocation()
    memory = fg.helpers().memory_headroom(120)
    with fg.LOCK.open("r+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(lock, fcntl.LOCK_UN)
    run.mkdir()
    peers = []
    for line in allocation["existing_processes"].splitlines():
        pid = int(line.split(",")[0])
        path = Path("/proc") / str(pid)
        peers.append({"identity": fg.identity(pid), "uid": path.stat().st_uid,
                      "executable": os.readlink(path / "exe")})
    disks = {str(p): os.statvfs(p).f_bavail * os.statvfs(p).f_frsize for p in ("/", str(run))}
    if disks["/"] <= 256 * 1024**2 or disks[str(run)] <= 30 * 1024**3:
        raise ValueError("Original disk safety margin unavailable")
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    resource = {
        "schema": "refate.actual_resource_precheck.v1", "data_kind": "actual", "at": at,
        "host": "perdon-hou", "hostname": "nb-5pl2apckdj-0",
        "ssh_endpoint": "root@116.198.70.4:1122", "run_id": run.name, "source_id": NEXT_SOURCE,
        "allocation": allocation, "memory_precheck": memory, "existing_processes": peers,
        "disk_free_bytes": disks, "exclusive_native_lock_available": True,
        "estimated_native_gpu1_mib": 18000, "policy_gpu0_reserve_mib": 15000,
        "safety_headroom_mib": 12000, "temporary_logs_cache_root": str(run / "runtime"),
        "actual_launch": False, "existing_peers_untouched": True,
    }
    resource_ref = save(run / "RESOURCE_PRECHECK_001.json", resource)
    release = ref(ADAPTER / "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json")
    if release["sha256"] != "b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131":
        raise ValueError("Existing content recording release changed")
    boundary = {
        "schema": "refate.actual_boundary_preparation.v1", "at": at,
        "next_preparation": {"prepared": prepared, "ref": x["preparation_ref"]},
        "resource_precheck": {"summary": resource, "ref": resource_ref},
        "settlement": {"source_id": settlement["source_id"], "settlement_ref": settlement_ref,
                       "safe_for_next_simulator": True},
        "last_teacher_settlement": terminal["summary_ref"],
        "resource_predecessor": {"source_id": terminal["source_id"], "run_id": terminal["run_id"],
                                "summary_ref": terminal["summary_ref"],
                                "safe_for_next_simulator": True, "ref": x["terminal_ref"]},
        "runtime_release": release, "metadata_adapter": ref(ADAPTER / "owner_reservation_handoff_v1.py"),
        "native_kit_extensions": [], "teacher_supplement_present": True,
        "legacy_prefix_ref": x["prefix_ref"], "legacy_prefix_review": review,
        "prospective_classify_teacher_binding_verified": False,
    }
    boundary_ref = save(run / "MAIN_BOUNDARY_001.json", boundary)
    print(json.dumps({"boundary_ref": boundary_ref, "source_id": NEXT_SOURCE, "resource": resource}))


if __name__ == "__main__":
    main()
