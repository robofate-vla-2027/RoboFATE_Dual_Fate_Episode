"""Read only the current source's bounded publication manifest at settlement."""
import hashlib
from pathlib import Path
import stat

SHARED = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
              "20261022_collection_chat2_01a16338/teacher/shared_teacher")
TRANSACTION_SHA = "da5ae115e214cc4fdc2584c04d1eb8c1dbf1f3d679fc5a6a6b37bea59acb6230"
OLD = "manifest=r.document(published['manifest'])"
NEW = "manifest=_read_publication_manifest(published['manifest'],c)"
LIMIT = 16 * 1024**2


def need(value, message):
    if not value:
        raise ValueError(message)


def signature(path):
    value = path.stat()
    need(path.resolve(strict=True) == path and stat.S_ISREG(value.st_mode),
         "Canonical regular publication manifest required")
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def read_manifest(reference, context):
    import common_runtime
    need(type(reference) is dict and set(reference) == {"path", "sha256"},
         "Exact publication reference required")
    for key in ("task", "source_id"):
        value = context.get(key)
        need(type(value) is str and value not in ("", ".", "..")
             and Path(value).name == value and "/" not in value,
             "Single source component required")
    path = Path(reference["path"])
    expected = SHARED / "published" / context["task"] / context["source_id"] / "manifest.json"
    need(path == expected and path.is_absolute(), "Wrong current-source manifest")
    before = signature(path)
    need(0 < before[3] <= LIMIT, "Bounded publication manifest required")
    raw = path.read_bytes()
    need(signature(path) == before and len(raw) == before[3]
         and hashlib.sha256(raw).hexdigest() == reference["sha256"],
         "Publication manifest changed")
    return common_runtime.document(raw)


def bind_cli(cli):
    text = cli._text
    need(hashlib.sha256(text.encode()).hexdigest() == TRANSACTION_SHA,
         "Frozen settlement transaction changed")
    need(text.count(OLD) == 1, "Publication manifest read seam changed")
    updated = text.replace(OLD, NEW, 1)
    transaction = cli._transaction
    transaction._read_publication_manifest = read_manifest
    exec(compile(updated, str(Path(__file__)) + "::manifest_metadata_only", "exec"),
         transaction.__dict__)
    need(cli.r is transaction.r, "Original metadata reader changed")
    cli.ledger_core = transaction.ledger_core
    need("_read_publication_manifest" in transaction.compute.__code__.co_names,
         "Manifest adapter not bound to actual compute")
    return hashlib.sha256(updated.encode()).hexdigest()
