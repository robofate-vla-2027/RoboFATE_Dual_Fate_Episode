"""Offline synthetic checks only; no Native, provider, or real ledger edits."""
import base64
import copy
import json
import sys
import types
import unittest
from unittest.mock import patch

import dolls_append_handoff_v1 as helper


class MetadataTests(unittest.TestCase):
    def test_prepare_is_byte_identical(self):
        archive = json.loads(helper.ARCHIVE.read_bytes())
        self.assertEqual(helper.script("prepare", archive), archive["prepare"])

    def test_only_executor_comparison_changes(self):
        archive = json.loads(helper.ARCHIVE.read_bytes())
        text = helper.script("register", archive)
        self.assertEqual(text.replace("n['active_chat_id']==EXECUTOR",
                                     "n['active_chat_id']==m.OWNER", 1), archive["register"])

    def test_changed_interface_rejected(self):
        with self.assertRaises(ValueError):
            helper.script("register", {"register": "pass"})

    def test_large_integer_roundtrip(self):
        value = 1793480694148823008
        result = helper.evaluate("import json,sys;print(json.dumps(json.load(sys.stdin)))",
                                 {"wall_ns": value})
        self.assertEqual(result["wall_ns"], value)

    def test_original_register_preserves_foreign_and_historical_data(self):
        archive = json.loads(helper.ARCHIVE.read_bytes())
        old = {"path": "synthetic/old", "sha256": "a" * 64}
        new = {"path": "synthetic/new", "sha256": "b" * 64}
        module = types.ModuleType("dolls_source_registration_20261030")
        module.__file__ = "synthetic/original_helper"
        module.TASK = "sort_nesting_dolls_by_size"
        module.OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
        module.CAMPAIGN = "synthetic_campaign"
        module.ref = lambda path: {"path": path, "sha256": "c" * 64}
        check = {
            "schema": "refate.actual_metadata_preparation.v1",
            "data_kind": "actual_source_metadata_not_execution",
            "task": module.TASK, "native_budget": 1050,
            "metadata_helper": module.ref(module.__file__),
            "actual_configuration_roundtrip_passed": True, "runtime_files_modified": False,
            "append_manifest": new, "prior_manifest": old,
            "cpu_tests": "synthetic_tests", "source_id": "synthetic_dolls_l10",
        }
        module.document = lambda pin: check if pin == "synthetic_check" else {
            "data_kind": "synthetic_not_actual_admission", "actual_test_exit": 0}
        module.lineage = lambda pin: {"collection_append": {
            "prior_split": old, "metadata_helper": check["metadata_helper"], "added_layout": 10}}
        foreign = {"wall_ns": 1793480694148823008, "owner": "synthetic_chat1"}
        ledger = {
            "campaign_id": module.CAMPAIGN, "revision": 17,
            "nodes": {"perdon-hou": {"active_chat_id": helper.EXECUTOR,
                      "current_task": module.TASK, "active_run_id": None, "active_real_simulators": 0},
                      "h20_8": copy.deepcopy(foreign)},
            "tasks": {module.TASK: {"assigned_host": "perdon-hou"}, "synthetic_chat1": copy.deepcopy(foreign)},
            "split_manifests": {module.TASK: copy.deepcopy(old)},
            "source_index": {"synthetic_old": {"source_owner": module.OWNER, **foreign}},
        }
        args = {"ledger_b64": base64.b64encode(json.dumps(ledger).encode()).decode(),
                "preparation_check": "synthetic_check"}
        with patch.dict(sys.modules, {"dolls_source_registration_20261030": module}):
            result = helper.evaluate(helper.script("register", archive), args)
            updated = result["ledger"]
            self.assertEqual(updated["nodes"]["h20_8"], ledger["nodes"]["h20_8"])
            self.assertEqual(updated["tasks"]["synthetic_chat1"], foreign)
            self.assertEqual(updated["source_index"], ledger["source_index"])
            self.assertEqual(module.OWNER, "01a16807-8085-7903-be07-66eb332ebf95")
            self.assertEqual(updated["revision"], 18)
            args["ledger_b64"] = base64.b64encode(json.dumps(updated).encode()).decode()
            reused = helper.evaluate(helper.script("register", archive), args)
            self.assertTrue(reused["receipt"]["idempotent_reuse"])
            self.assertEqual(reused["ledger"], updated)
            ledger["nodes"]["perdon-hou"]["active_run_id"] = "synthetic_inflight"
            args["ledger_b64"] = base64.b64encode(json.dumps(ledger).encode()).decode()
            with self.assertRaises(AssertionError):
                helper.evaluate(helper.script("register", archive), args)


if __name__ == "__main__":
    unittest.main()
