"""Reuse settled General prefix metadata without replay or scientific relabeling."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys

from prepare_general_l7_handoff_v1 import ADAPTER, ORIGINAL, OWNER, PREFIX, ROOT, TASK, metadata_only, need

NEXT_SOURCE = "general_pickup_b0_l7_15b963a9453a0c8c"
SEQUENCE = {
    "path": str(ROOT / "parent/takeover_20261024_execution_support/general_source_prepare/"
                "c2_general_pickup_l6_pt32_baseline_0001_01a16807/SEQUENCE_001.json"),
    "sha256": "215b858f7db70bf58651e2fd691e915e6c829415e9a93b621c231a6574eafa3b",
}


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(pin):
    path = Path(pin["path"])
    need(set(pin) == {"path", "sha256"} and path.is_relative_to(ROOT)
         and path.resolve() == path, "Foreign metadata")
    raw = path.read_bytes()
    need(len(raw) < 4 * 1024**2 and hashlib.sha256(raw).hexdigest() == pin["sha256"],
         "Changed or oversized metadata")
    return json.loads(raw)


def metadata_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode()).hexdigest()


def prefix_state(task):
    return {k: deepcopy(task.get(k)) for k in (
        "source_sequence", "source_sequence_disposition", "historical_l0_disposition")}


def validate_inputs(prepared, task, sources, sequence):
    source = prepared["source"]
    need(source["task"] == TASK and source["source_id"] == NEXT_SOURCE
         and source["layout_id"] == 7 and source["required_accounted_prefix"] == PREFIX
         and source["source_sequence"] == PREFIX + [7] and prepared["native_step_limit"] == 200,
         "Wrong next original General source")
    need(task["source_sequence"] == PREFIX
         and task["source_sequence_disposition"]["completed_initial_accounted_prefix"] == PREFIX,
         "Original prefix remains unaccounted")
    need(sequence["schema"] == "refate.general_pickup.accounted_sequence.v1"
         and sequence["task"] == TASK and sequence["base_split_manifest"] == ORIGINAL
         and sequence["source_sequence"] == PREFIX
         and sequence["accounted_sequence_prefix"] == PREFIX[:-1]
         and sequence["original_split_membership_edited"] is False,
         "Frozen prefix admission changed")
    indexed = {}
    for sid, row in sources.items():
        need(row["task"] == TASK and row["host"] == "perdon-hou"
             and row["source_id"] == sid, "Foreign historical source")
        matches = [i for i in PREFIX if sid.startswith(f"{TASK}_b0_l{i}_")]
        need(len(matches) == 1 and matches[0] not in indexed, "Ambiguous historical source")
        need(row.get("counted_in_quota") is False and row.get("counted_in_negative_quota") is False,
             "Original source quota classification changed")
        indexed[matches[0]] = row
    need(set(indexed) == {3, 4, 5, 6}, "Inspect changed legacy indexing before continuation")
    return indexed


def original_general_prefix_accounted(ledger, boundary, source, ordinal):
    if (source.get("source_id") != NEXT_SOURCE or source.get("task") != TASK
            or source.get("layout_id") != 7 or source.get("required_accounted_prefix") != PREFIX
            or type(ordinal) is not int or ordinal not in PREFIX):
        return False
    review = boundary.get("legacy_prefix_review", {})
    if (review.get("schema") != "refate.general.original_prefix.accounted.v1"
            or review.get("next_source_id") != NEXT_SOURCE
            or review.get("preparation_ref") != boundary["next_preparation"]["ref"]
            or review.get("old_source_qualification_changed") is not False
            or review.get("old_sources_replayed") is not False
            or review.get("sequence_ref") != SEQUENCE
            or review.get("live_referenced_processes") != []
            or review.get("prefix_state_sha256") != metadata_hash(prefix_state(ledger["tasks"][TASK]))):
        return False
    rows = [s for sid, s in ledger["source_index"].items()
            if sid.startswith(f"{TASK}_b0_l{ordinal}_") and s.get("host") == "perdon-hou"]
    entries = [e for e in review.get("entries", []) if e.get("layout") == ordinal]
    if (len(entries) != 1 or entries[0].get("source_consumed") is not True
            or entries[0].get("new_positive") != 0 or entries[0].get("new_negative") != 0):
        return False
    entry = entries[0]
    if ordinal in (0, 1, 2):
        return not rows and entry["source_metadata_sha256"] is None
    return (len(rows) == 1 and entry["source_id"] == rows[0]["source_id"]
            and entry["source_metadata_sha256"] == metadata_hash(rows[0]))


def observe(x):
    prepared, sequence = document(x["preparation_ref"]), document(SEQUENCE)
    indexed = validate_inputs(prepared, x["task"], x["sources"], sequence)
    l0_ref = x["task"]["historical_l0_disposition"]
    l0 = document(l0_ref)
    need(l0["task"] == TASK and l0["layout_id"] == 0
         and l0["disposition"] == "historical_used_no_rerun"
         and l0["qualification"] is False and l0["rerun_authorized"] is False
         and l0["positive_credit"] == l0["negative_credit"] == 0,
         "Protected historical L0 changed")
    entries, runs = [], {l0["historical_negative_review"]["run_id"]}
    for i in PREFIX:
        row = indexed.get(i)
        if row is None:
            pin = l0_ref if i == 0 else SEQUENCE
            receipt = l0 if i == 0 else sequence
            sid = l0["source_id"] if i == 0 else None
            disposition = "historical_used_no_rerun" if i == 0 else "previously_accounted_in_frozen_sequence"
        else:
            pin = row["final_disposition"] if i == 6 else row["settlement"]
            receipt = document(pin)
            sid = row["source_id"]
            need(receipt["source_id"] == sid and receipt["qualification"] is False,
                 "Historical settlement identity or qualification changed")
            if i == 3:
                need(receipt["operational_close_complete"] is True, "L3 closure incomplete")
            elif i == 4:
                need(receipt["resource_closed"] is True, "L4 closure incomplete")
            elif i == 5:
                need(receipt["reservations_already_released"] is True
                     and receipt["once_consumed"] is True, "L5 original disposition changed")
            else:
                need(receipt["original_owned_processes_absent"] is True
                     and receipt["native_success"] is False and receipt["native_steps"] == 200
                     and receipt["readback_complete"] is True, "L6 terminal settlement incomplete")
            disposition = receipt.get("status", receipt.get("disposition"))
            runs.add(receipt["run_id"])
        entries.append({
            "layout": i, "source_id": sid, "saved_disposition": pin,
            "source_metadata_sha256": metadata_hash(row) if row else None,
            "source_consumed": True, "disposition": disposition,
            "new_positive": 0, "new_negative": 0,
        })
    live = []
    for path in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            raw = path.read_bytes()
            matched = sorted(run for run in runs if run.encode() in raw)
            if matched:
                stat = (path.parent / "stat").read_text().rsplit(")", 1)[1].split()
                live.append({"pid": int(path.parent.name), "start_ticks": int(stat[19]), "runs": matched})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    need(not live, "Historical referenced processes remain; no launch authorization")
    result = {
        "schema": "refate.general.original_prefix.accounted.v1",
        "data_kind": "actual_existing_metadata_not_new_scientific_data",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": OWNER, "next_source_id": NEXT_SOURCE,
        "preparation_ref": x["preparation_ref"], "sequence_ref": SEQUENCE,
        "prefix_state_sha256": metadata_hash(prefix_state(x["task"])),
        "metadata_helper": ref(Path(__file__)), "entries": entries,
        "live_referenced_processes": [], "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "old_source_qualification_changed": False, "old_sources_replayed": False,
        "full_payload_decoded": False, "actual_launch": False,
        "new_positive": 0, "new_negative": 0,
    }
    path = ADAPTER / "task_sources/general_pickup/LEGACY_PREFIX_THROUGH_L6_ACCOUNTED_001.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    result["evidence_ref"] = ref(path)
    return result


def reserver():
    sys.path.insert(0, str(ADAPTER))
    import owner_reservation_handoff_v1 as original
    seam = "_inherited_prefix(ledger, b, source, i)"
    need(original.text.count(seam) == 1, "Original prefix reservation interface changed")
    namespace = dict(original.__dict__)
    namespace["original_general_prefix_accounted"] = original_general_prefix_accounted
    text = original.text.replace(seam, "(" + seam
                                 + " or original_general_prefix_accounted(ledger, b, source, i))", 1)
    exec(compile(text, str(ADAPTER / "common_owner_reservation.py") + "::general_legacy_prefix",
                 "exec"), namespace)
    return namespace["reserve"]


if __name__ == "__main__":
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    print(json.dumps(observe(x)))
