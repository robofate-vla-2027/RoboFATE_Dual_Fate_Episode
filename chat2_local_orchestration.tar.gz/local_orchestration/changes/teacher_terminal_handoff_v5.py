"""Original terminal observation with the exact matching General200 source hash."""
from pathlib import Path
import common_runtime as runtime


def source():
    path = Path(__file__).with_name("teacher_terminal_handoff_v4.py")
    text = runtime.read_pin({"path": str(path), "sha256":
        "5b03882c833c1824848f36fb2d201cdcd9047e5c22a81c42ed71ed1693390845"}).decode()
    text = runtime.edit(text, "import collect_teacher_content_v4 as collect",
                        "import collect_teacher_content_v5 as collect")
    return runtime.edit(text, "71895154e7be98b06078f37acc6d2b517601d9b387d5f94a377ce23f688bd001",
                        "c70b36872331116b7f5c92bed8b884c4cf8c3ea0d9171d7167375b6006591d61")


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general200_metadata", "exec"), globals())
