"""Original source metadata only; never launch models or simulations."""
import sys
def reject_live_effect(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event in ('os.system', 'os.kill', 'os.killpg', 'os.fork', 'os.posix_spawn'):
        if event != 'socket.gethostname':
            raise RuntimeError('SOURCE_METADATA_ONLY ' + event)
sys.addaudithook(reject_live_effect)
import sys,json,hashlib,datetime,copy
from pathlib import Path
A=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');T=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher');sys.path.insert(0,str(A));import task_source_binding as binding,task_family_binding as family,source_binding as original
def select_new_group_split(groups):
 labels=[g['split'] for g in groups.values()]
 assert labels and all(v in ('student_train','student_dev') for v in labels)
 count=len(labels)+1;target=min(count-1,max(1,count//5))
 return 'student_dev' if labels.count('student_dev')<target else 'student_train'

x=json.load(sys.stdin)
import execution_owner_binding_v1 as execution
execution.install()
assert x['execution_owner'] == execution.NEW
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def put(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
 return ref(p)
old=original.decode(binding.read_ref(x['prior_manifest']));task=old['task'];i=x['layout'];assert task=='organize_table' and old['campaign_id']=='refate-20261022-97baf70d5128' and old['owner_chat']=='01a16807-8085-7903-be07-66eb332ebf95'
assert type(i) is int and old['initial_source_sequence']==old['materialized_layouts']==list(range(i)) and i not in old['original_partition']['reserved_final'] and i<old['original_partition']['available_layout_count'];assert old['reserved_layouts_read']==[]
p=binding.NATIVE/f'Assets/Eval_Layout/RoboDojo/arx_x5/0/{task}_{i}.json';pr={'path':str(p),'sha256':x['raw_sha256']};raw=original.decode(binding.read_ref(pr,expected_path=p));fref=ref(Path(family.__file__));assert fref['sha256']=='924c471b10aa4488b7cb0f9bf9aec77c8a9411db71fc540b085c15d60cec3d30';f=family.family(raw);gid=task+'/task_content_family/'+f['content_sha256'];content=hashlib.sha256(original.canonical(raw).encode()).hexdigest();assert content not in {v['initialization_content_sha256'] for v in old['layouts'].values()}
at=datetime.datetime.now(datetime.timezone.utc).isoformat();new=gid not in old['families'];m=copy.deepcopy(old);review=x.get('new_family_review')
if new:
 assert isinstance(review,dict) and review['new_layout']==i and review['new_group']==gid and review['outcomes_read'] is False and review['next_original_ordinal'] and review['closest_existing']['different_nonpose_paths'];assert x['new_family_split']==select_new_group_split(old['families'])
 split=x['new_family_split'];m['families'][gid]=dict(group_id=gid,canonical_structure_sha256=f['content_sha256'],algorithm=f['algorithm'],only_removed_object_fields=f['only_removed_object_fields'],grouping_helper=fref,exposure='unknown_prior_exposure',independent_eval_eligible=False,clean_eval_claimed=False,independence_claimed=False,split=split,layouts=[])
else:
 split=old['families'][gid]['split'];assert split in ('student_train','student_dev')
root=A/'task_sources'/task;ext=dict(schema='refate.task.source_sequence_append.v1',data_kind='preparation_only',at=at,task=task,owner_chat='01a16807-8085-7903-be07-66eb332ebf95',prior_manifest=x['prior_manifest'],prior_sequence=list(range(i)),source_sequence=list(range(i+1)),added_layout=i,layout_ref=pr,initialization_content_sha256=content,group_id=gid,existing_family=not new,split=split,grouping_helper=fref,owner_metadata_review=review,split_append_reason='Previously used family assignments are immutable. This one new collection family fills the remaining20pct dev target only from new members, otherwise train. Existing used labels are never globally re-sorted; no prior exposure or clean evaluation claim is introduced.' if new else 'Retain original family assignment.',reserved_layouts_read=[],qualification=False,source_issued=False,launch_authority=False)
er=put(root/f'SEQUENCE_APPEND_L{i}_001.json',ext);m['initial_source_sequence']=m['materialized_layouts']=list(range(i+1));m['source_sequence_append']=er;m['appended_at']=at;m['previous_manifest']=x['prior_manifest'];m['families'][gid]['layouts'].append(dict(bank=0,layout_id=i,**pr));m['layouts'][str(i)]=dict(native_bank=0,layout_id=i,status='bound',layout_ref=pr,initialization_content_sha256=content,initialization_distinct_from_preceding=True,group_id=gid,split=split,data_split={'student_train':'train','student_dev':'development'}[split],original_layout_partition='appended_collection_family');m['layout_to_group'][str(i)]=gid
for k in old['layouts']:assert old['layouts'][k]==m['layouts'][k] and old['layout_to_group'][k]==m['layout_to_group'][k]
for k,v in old['families'].items():
 check=copy.deepcopy(m['families'][k])
 if k==gid:check['layouts']=check['layouts'][:-1]
 assert check==v
assert m['original_partition']==old['original_partition'] and set(m['layouts'])==set(m['layout_to_group'])==set(map(str,range(i+1)))
mr=put(root/f'SPLIT_MANIFEST_L{i}_APPEND_001.json',m);prepared,layout=binding.prepare_source(task=task,layout_id=i,split_ref=mr);assert prepared['native_step_limit']==1000 and binding.load_native_layout(prepared)==layout==raw;prep=put(T/f'preparations/ORGANIZE_L{i}_COMMON_PREPARATION_001.json',prepared)
import teacher_catalog_binding_v4 as teacher
assert teacher.load_native_layout(prepared)==raw and teacher.TASK_TOTALS[task]==1000
check=put(root/f'APPEND_L{i}_CHECK_001.json',dict(schema='refate.task.source_append.check.v1',data_kind='offline_metadata_check_not_scientific_result',at=at,manifest=mr,preparation=prep,normalizer=fref,unchanged_existing_rows=True,unchanged_existing_family_assignments=True,source_and_teacher_metadata_loaders_passed=True,native_budget=1000,actual_restore_verified=False,models_called=False,native_started=False,qualification=False))
result=dict(at=at,source_id=prepared['source']['source_id'],manifest_ref=mr,extension_ref=er,preparation_ref=prep,check_ref=check,budget=1000,group_id=gid,new_family=new,split=split)
record=dict(schema='refate.source_preparation.execution_handoff.v1',data_kind='preparation_only',at=at,prepared_by=execution.NEW,execution_owner=execution.NEW,source_owner=prepared['source']['source_owner'],canonical_descriptor_legacy_execution_owner=prepared['source']['execution_owner'],canonical_descriptor_identity_is_not_current_executor=True,source_id=prepared['source']['source_id'],layout=i,native_budget=1000,preparation=prep,split=mr,predecessor_split=x['prior_manifest'],handoff=execution.install(),fixed_source_order_preserved=True,original_split_owners_preserved=True,current_inflight_not_changed=True,source_reserved=False,actual_launch=False,positive_delta=0,negative_delta=0)
receipt=put(root/f'APPEND_L{i}_EXECUTION_HANDOFF_01a19072_001.json',record)
result.update(execution_owner=execution.NEW,execution_handoff=receipt,reservation_issued=False,actual_launch=False)
print(json.dumps(result))
