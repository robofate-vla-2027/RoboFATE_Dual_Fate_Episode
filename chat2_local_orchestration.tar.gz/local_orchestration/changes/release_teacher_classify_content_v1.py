"""Freeze only the Classify1100 extension of the existing content-aware teacher."""
import datetime
import hashlib
import json
from pathlib import Path

import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import teacher_catalog_binding_v8 as old_catalog
import teacher_catalog_binding_v9 as catalog
import collect_teacher_content_v1 as old_collect
import collect_teacher_content_v2 as collect
import prepare_teacher_content_v2 as prepare
import teacher_ledger_owner_handoff_v2 as accounting

HERE = Path(__file__).resolve().parent


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return ref(path)


def release():
    prior = ref(HERE / "TEACHER_CONTENT_RELEASE_20261031_01a19072.json")
    assert prior["sha256"] == "f782c1ba4815746c30d88049f39ecd8591a5a50d7f398001ffa151beeb515969"
    data = runtime.document(runtime.read_pin(prior))
    for item in data["runtime_files"]:
        runtime.read_pin(item)
    log = HERE / "TEACHER_CLASSIFY_CONTENT_CPU_002.log"
    assert "Ran 16 tests" in log.read_text() and log.read_text().rstrip().endswith("OK")
    assert catalog.TASK_TOTALS == dict(old_catalog.TASK_TOTALS, classify_objects=1100)
    assert collect.native.restore is catalog.restore and prepare.restore is catalog.restore
    assert collect.native.recording is old_collect.native.recording
    assert prepare.common_recording is collect.native.recording
    assert collect.dependency is old_collect.dependency
    assert prepare.shared_dependency_binding is collect.dependency
    assert collect.native.text.replace("teacher_catalog_binding_v9", "teacher_catalog_binding_v8") == old_collect.native.text
    assert accounting._TEXT == accounting.previous._TEXT
    assert data["actor_wall_seconds"] == 3600
    assert data["commit"] == "470278c478bdb5e4b6f17dde1ea0393761f230f0"
    assert data["model"] == "gt-6-as-a" and data["reasoning_effort"] == "xhigh"
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    additions = [ref(HERE / name) for name in (
        "teacher_catalog_binding_v9.py", "native_teacher_content_v2.py",
        "collect_teacher_content_v2.py", "prepare_teacher_content_v2.py",
        "teacher_ledger_owner_handoff_v2.py", "test_teacher_classify_content_v1.py",
        "release_teacher_classify_content_v1.py")]
    cpu = write(HERE / "TEACHER_CLASSIFY_CONTENT_CPU_002.json", {
        "schema": "refate.classify1100_content.synthetic_cpu.v1",
        "data_kind": "synthetic_not_scientific_data", "at": at,
        "tests": 16, "passed": 16, "exit_code": 0, "log": ref(log),
        "test": ref(HERE / "test_teacher_classify_content_v1.py"),
        "prior_failed_log": ref(HERE / "TEACHER_CLASSIFY_CONTENT_CPU_001.log"),
        "prior_failed_test": ref(HERE / "TEACHER_CLASSIFY_CPU_FAILED_TEST_001.py.txt"),
        "test_correction": "budget returns the original total; remaining steps are total minus t1",
        "runtime_changed_for_test_correction": False,
        "no_model_api_simulator_gpu_calls": True,
        "real_constant_frame_validation": False})
    data["runtime_files"] = list({item["path"]: item for item in data["runtime_files"] + additions}.values())
    data.update(
        created_at=at, inherits=prior, execution_owner=execution.NEW,
        foreground_entry=str(HERE / "collect_teacher_content_v2.py"),
        native_entry=str(HERE / "native_teacher_content_v2.py"),
        preparation_entry=str(HERE / "prepare_teacher_content_v2.py"),
        cpu_summary=cpu, actual_adoption=False, actual_teacher_takeover_verified=False,
        actual_positive_published=False, real_constant_frame_validation=False,
        catalog_extension={"task": "classify_objects", "native_limit": 1100,
                           "catalog": ref(HERE / "teacher_catalog_binding_v9.py")},
        accounting_parameter_extension=ref(HERE / "teacher_ledger_owner_handoff_v2.py"),
        native_effective_source_sha256=hashlib.sha256(collect.native.text.encode()).hexdigest(),
        change_scope="Classify1100 task metadata and matching entry references only; original controls, scoring, capture, readers, budgets and source ownership preserved",
        old_runtime_files_modified=False)
    return {"release": write(HERE / "TEACHER_CLASSIFY_CONTENT_RELEASE_20261101_01a19072.json", data),
            "cpu": cpu, "actual_native_started": False}


if __name__ == "__main__":
    print(json.dumps(release()))
