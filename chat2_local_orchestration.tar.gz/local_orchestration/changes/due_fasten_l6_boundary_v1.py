"""Existing resource/source predecessor separation for frozen Fasten L5 to L6."""
import hashlib
from pathlib import Path

SEQUENCE = list(range(7))


def validate_pair(previous, prepared):
    ps, ns = previous["source"], prepared["source"]
    if not (ps["task"] == ns["task"] == "fasten_screws"
            and ps["source_sequence"] == ns["source_sequence"] == SEQUENCE
            and ps["layout_id"] == 5 and ns["layout_id"] == 6
            and ps["required_accounted_prefix"] == SEQUENCE[:5]
            and ns["required_accounted_prefix"] == SEQUENCE[:6]
            and ns["required_accounted_prefix"] ==
            ps["required_accounted_prefix"] + [ps["layout_id"]]):
        raise ValueError("Not the next frozen Fasten source after settled L5")


def source():
    path = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"):
        raise ValueError("Frozen resource boundary changed")
    text = raw.decode().replace("put_bottles_into_dustbin", "fasten_screws")
    text = text.replace("sort_nesting_dolls_by_size", "classify_objects")
    for old, new in (
        ("prepared['native_step_limit']==700", "prepared['native_step_limit']==1900"),
        ("assert ns['required_accounted_prefix']==ps['source_sequence']=="
         "ps['required_accounted_prefix']+[ps['layout_id']]\n"
         "assert ns['source_sequence']==ps['source_sequence']+[ns['layout_id']]",
         "validate_pair(previous, prepared)"),
        (";bref=write(run/'MAIN_BOUNDARY_001.json',b)",
         ";b['inherited_prefix']={'source_id':sid,"
         "'preparation_ref':x['prior_preparation_ref'],'prepared_source':ps}"
         ";bref=write(run/'MAIN_BOUNDARY_001.json',b)"),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen boundary parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten_l6_metadata", "exec"),
         globals())
