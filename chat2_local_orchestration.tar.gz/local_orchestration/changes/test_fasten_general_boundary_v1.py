"""Synthetic CPU metadata only; no live ledger, network, model or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.insert(0, str(snapshot))

import due_general_l10_boundary_handoff_v1 as boundary
import switch_fasten_to_prepared_general_v1 as scheduling
from test_dolls_bottles_revisit_v1 import DueBottlesTests, reject_live
from test_general_append_reservation_v1 import general_fixture
from test_common_owner_reservation import AT, REF
import reserve_general_append_handoff_v1 as reservation

sys.addaudithook(reject_live)
OLD, NEXT = "fasten_screws", "general_pickup"
SEQUENCE = [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]


def rename(value):
    if isinstance(value, str):
        return value.replace("sort_nesting_dolls_by_size", OLD).replace(
            "put_bottles_into_dustbin", NEXT)
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class ClosedFastenTests(unittest.TestCase):
    def setUp(self):
        old = DueBottlesTests()
        old.setUp()
        self.f = old
        self.d, self.e, self.prep = rename(old.d), rename(old.e), rename(old.prep)
        self.e.update(
            schema="refate.common_baseline.main_settlement.v1", data_kind="actual",
            first_readback_passed=True, native_success=False,
            context={"synthetic": "context"},
            summary={"native_success": False, "qualified_negative": False},
            process_closure={"checks": [
                {"role": role, "original_process_absent": True,
                 "identity": {"pid": i + 9001, "start_ticks": 2**63 + i,
                              "boot_id": "synthetic-boot"}}
                for i, role in enumerate(("native", "policy"))]})
        self.d["source_index"]["old"] = {
            "task": OLD, "host": "perdon-hou", "run_id": self.e["run_id"],
            "context": deepcopy(self.e["context"]), "settlement": self.f.ref,
            "synthetic_ns": 1793496102759665601}
        self.d["reservations"]["old"] = {
            "status": "settled_native_failure_no_quota", "run_id": self.e["run_id"],
            "settlement": self.f.ref, "positive_slots": 0, "negative_slots": 0,
            "quota_reserved": False, "negative_quota_reserved": False}
        self.prep["native_step_limit"] = 200
        self.prep["source"].update(layout_id=10, source_sequence=SEQUENCE,
                                   required_accounted_prefix=SEQUENCE[:-1],
                                   split="student_dev")

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
            at or self.f.at, "Synthetic boundary, no scientific credit")

    def test_closed_failure_preserves_counts_history_and_nanoseconds(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))

    def test_closed_success_is_not_recounted(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        out = self.switch()
        self.assertEqual(out["receipt"]["negative_delta"], 0)

    def test_recent_positive_does_not_reset_negative_window(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_original_time_and_two_segment_rule_remain(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["tasks"][OLD].update(last_core_gain_at="2026-10-31T11:30:00+00:00",
                                   last_negative_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_or_unsettled_resource_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"), ("launch_inflight", True),
                           ("active_real_simulators", 1), ("user_stop", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.switch()

    def test_wrong_scope_settlement_and_context_rejected(self):
        for key, value in (("run_id", "different"), ("context", {}),
                           ("settlement", {}), ("host", "foreign")):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.d["reservations"]["old"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.switch()

    def test_source_order_budget_sealed_and_duplicates_rejected(self):
        for key, value in (("layout_id", 53), ("source_sequence", list(range(11))),
                           ("required_accounted_prefix", SEQUENCE[:-2])):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 700
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()


class ExistingBoundaryTests(unittest.TestCase):
    def test_resource_tail_unchanged_and_separate_from_source_predecessor(self):
        current = boundary.source()
        original = (Path(boundary.__file__).parent / "due_bottles_boundary_handoff_v1.py").read_text()
        start = "boot=Path('/proc/sys/kernel/random/boot_id')"
        end = "bref=write(run/'MAIN_BOUNDARY_001.json',b)"
        actual = current[current.index(start):current.index(end)]
        expected = original[original.index(start):original.index(end)]
        extra = "b['general_previous_preparation']={'ref':x['prior_preparation_ref'],'prepared':previous}\n"
        self.assertEqual(actual, expected + extra)
        for text in ("x['resource_settlement_ref']", "x['prior_source_run']",
                     "closed_baseline_resource_v1", "closed_teacher_resource_v1"):
            self.assertIn(text, current)
        ast.parse(current)

    def test_only_original_general9_to10_prefix_is_accepted(self):
        tree = ast.parse(boundary.source())
        nodes = [n for n in tree.body if isinstance(n, ast.Assert)
                 and ("ns[" in ast.unparse(n.test) or "ps[" in ast.unparse(n.test))]
        self.assertEqual(len(nodes), 4)
        code = compile(ast.Module(body=nodes, type_ignores=[]), "<synthetic-prefix>", "exec")
        ps = {"task": NEXT, "source_sequence": SEQUENCE[:-1],
              "required_accounted_prefix": SEQUENCE[:-2], "layout_id": 9,
              "source_id": "synthetic-prior"}
        ns = {"task": NEXT, "source_sequence": SEQUENCE,
              "required_accounted_prefix": SEQUENCE[:-1], "layout_id": 10}
        exec(code, {"ps": ps, "ns": ns, "sid": "synthetic-prior"})
        for key, value in (("required_accounted_prefix", list(range(10))),
                           ("source_sequence", SEQUENCE + [53]), ("layout_id", 11)):
            changed = dict(ns, **{key: value})
            with self.subTest(key=key), self.assertRaises(AssertionError):
                exec(code, {"ps": ps, "ns": changed, "sid": "synthetic-prior"})

    def test_pinned_helpers_reject_changes(self):
        with patch.object(Path, "read_bytes", return_value=b"changed"):
            for module in (boundary, scheduling):
                with self.subTest(module=module.__name__), self.assertRaises(ValueError):
                    module.source()

    def test_existing_general_append_reserver_supports_l10(self):
        d, b, previous, release = general_fixture()
        sid = b["settlement"]["source_id"]
        old = d["source_index"][sid]
        old.update(layout_id=9, source_sequence=SEQUENCE[:-1],
                   required_accounted_prefix=SEQUENCE[:-2])
        previous["prepared"]["source"] = deepcopy(old)
        d["tasks"][NEXT]["source_sequence"] = SEQUENCE[:-1]
        b["next_preparation"]["prepared"]["source"].update(
            layout_id=10, source_sequence=SEQUENCE, required_accounted_prefix=SEQUENCE[:-1])
        result = reservation.reserve_next(d, b, REF, previous, release, AT)
        self.assertEqual(result["ledger"]["tasks"][NEXT]["source_sequence"], SEQUENCE)
        self.assertEqual(result["ledger"]["source_index"][sid], old)
        self.assertEqual(result["receipt"]["positive_delta"], 0)

if __name__ == "__main__":
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (ClosedFastenTests, ExistingBoundaryTests))
    result = unittest.TextTestRunner().run(suite)
    raise SystemExit(not result.wasSuccessful())
