"""Offline synthetic metadata only; no model, network, simulator, or processes."""
import ast
import copy
from pathlib import Path
import unittest
import negative_only_boundary_handoff_v1 as negative
import owner_insert_reservation_handoff_v1 as owner
import common_owner_reservation_v3 as original

NEW = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
OLD = "01a16807-8085-7903-be07-66eb332ebf95"
AT = "2026-10-31T10:30:00+00:00"


def switch_function():
    path = Path(__file__).with_name("switch_play_to_insert_handoff_v1.py")
    node = next(n for n in ast.parse(path.read_bytes()).body
                if isinstance(n, ast.FunctionDef) and n.name == "switch_due")
    namespace = {}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
    return namespace["switch_due"]


class InsertMetadataTests(unittest.TestCase):
    def setUp(self):
        self.ref = {"path": "synthetic-only", "sha256": "synthetic-only"}
        self.context = {"path": "synthetic-context", "sha256": "synthetic-only"}
        self.checks = [dict(role=role, original_process_absent=True,
                            identity=dict(pid=i+100, start_ticks=i+200, boot_id="synthetic"))
                       for i, role in enumerate(("native", "policy"))]
        self.e = dict(schema="refate.common_baseline.main_settlement.v1", data_kind="actual",
                      execution_owner=OLD, source_owner=OLD, task="insert_tubes",
                      source_id="s", run_id="synthetic_run", context=self.context,
                      safe_for_next_simulator=True, native_budget=500, native_success=False,
                      first_readback_passed=True, new_positive=0, new_negative=0,
                      process_closure={"checks": self.checks}, summary={"run_id": "synthetic_run"},
                      summary_ref=self.ref)
        self.n = dict(active_chat_id=NEW, current_task="insert_tubes", fixed_tasks=["insert_tubes"],
                      user_pause_active=False, user_stop=False, owned_resource_launch_hold=False,
                      active_run_id=None, active_real_simulators=0, launch_inflight=False,
                      baseline_accounting={"baseline_attempts_running": 0},
                      completed_pending_sources=[], common_pending_readback_run_ids=[],
                      qualified_count=34, negative_count=18, last_owned_resource_settlement=self.ref,
                      task_segments=[dict(task="synthetic_other", ended_at="2026-10-30T10:00:00+00:00"),
                                     dict(task="synthetic_other2", ended_at="2026-10-30T12:00:00+00:00")])
        self.t = dict(assigned_host="perdon-hou", scheduling_state="deferred",
                      qualified_count=10, positive_quota=10, reserved_count=0,
                      negative_count=7, negative_quota=10, negative_reserved_count=0,
                      deferred_at="2026-10-29T00:00:00+00:00",
                      latest_segment_started_at="2026-10-29T00:00:00+00:00",
                      last_negative_gain_at="2026-10-29T00:00:00+00:00")
        self.s = dict(host="perdon-hou", task="insert_tubes", source_started=True,
                      complete_readback=True, native_success=False, native_budget=500,
                      run_id=self.e["run_id"], context=self.context, source_owner=OLD,
                      execution_owner=OLD, settlement=self.ref, reusable_DM_failure=True)
        self.r = dict(run_id=self.e["run_id"], settlement=self.ref,
                      status="settled_native_failure_no_quota", positive_slots=0,
                      negative_slots=0, quota_reserved=False, negative_quota_reserved=False)
        self.d = dict(campaign_id="refate-20261022-97baf70d5128", revision=1,
                      nodes={"perdon-hou": self.n, "h20_8": {"synthetic_peer": 1793437409455669682}},
                      tasks={"insert_tubes": self.t}, source_index={"s": self.s}, reservations={"s": self.r})

    def test_historical_executor_remains_bound(self):
        before = copy.deepcopy(self.d)
        self.assertEqual(negative.check(self.d, self.e, self.ref), self.checks)
        self.assertEqual(before, self.d)
        self.e["execution_owner"] = NEW
        with self.assertRaises(ValueError):
            negative.check(self.d, self.e, self.ref)
        self.s["execution_owner"] = NEW
        negative.check(self.d, self.e, self.ref)

    def test_active_work_quota_and_refusal_rejected(self):
        for target, key, value in ((self.n, "active_run_id", "synthetic_active"),
                                   (self.t, "qualified_count", 9),
                                   (self.s, "provider_safety_refusal", {"synthetic": True}),
                                   (self.r, "negative_quota_reserved", True)):
            present, old = key in target, target.get(key)
            target[key] = value
            with self.assertRaises(ValueError):
                negative.check(self.d, self.e, self.ref)
            if present:
                target[key] = old
            else:
                target.pop(key)

    def test_original_insert_algorithms_are_reused(self):
        self.assertEqual(owner.OWNER, NEW)
        self.assertEqual(original.OWNER, OLD)
        self.assertIs(owner._insert_checkpoint, original._insert_checkpoint)
        self.assertIs(owner._dispatch_split, original._dispatch_split)
        self.assertIs(owner.append_manifest, original.append_manifest)

    def play_fixture(self):
        self.n["current_task"] = "play_stacking_toy"
        self.e.update(task="play_stacking_toy", execution_owner=NEW, native_budget=1200)
        self.s.update(task="play_stacking_toy", execution_owner=NEW, native_budget=1200)
        self.d["tasks"]["play_stacking_toy"] = dict(
            qualified_count=1, positive_quota=10, negative_count=0, negative_quota=10,
            reserved_count=0, negative_reserved_count=0, latest_segment_started_at="2026-10-31T08:50:00+00:00",
            last_core_gain_at="2026-10-28T00:00:00+00:00")
        return self.d

    def test_safe_switch_preserves_counts_and_failure_source(self):
        d = self.play_fixture()
        source = copy.deepcopy(self.s)
        result = switch_function()(d, self.e, self.ref, AT)
        self.assertEqual(result["ledger"]["source_index"]["s"], source)
        self.assertEqual(self.n["current_task"], "insert_tubes")
        self.assertEqual(self.t["qualified_count"], 10)
        self.assertEqual(self.t["negative_count"], 7)
        self.assertEqual(self.t["last_negative_gain_at"], "2026-10-29T00:00:00+00:00")
        self.assertFalse(self.t["deferred_current"])
        retained = d["tasks"]["play_stacking_toy"]["retained_failed_source_revisit_records"][-1]
        self.assertFalse(retained["teacher_attempted"])
        self.assertFalse(retained["automatic_replay"])
        self.assertEqual(d["nodes"]["h20_8"]["synthetic_peer"], 1793437409455669682)

    def test_early_successful_or_active_boundary_rejected(self):
        self.play_fixture()
        cases = [("early", None), ("success", None), ("active", None)]
        for name, _ in cases:
            d, e = copy.deepcopy(self.d), copy.deepcopy(self.e)
            if name == "early":
                d["tasks"]["play_stacking_toy"]["latest_segment_started_at"] = "2026-10-31T10:00:00+00:00"
            elif name == "success":
                e["native_success"] = True
                e["new_negative"] = 1
            else:
                d["nodes"]["perdon-hou"]["active_run_id"] = "synthetic_live"
            with self.assertRaises(AssertionError):
                switch_function()(d, e, self.ref, AT)

    def test_boundary_reuses_existing_preparation_and_current_entry(self):
        path = Path(__file__).with_name("insert_negative_boundary_handoff_v1.py")
        text = path.read_text()
        self.assertNotIn("sequence.prepare_source(", text)
        self.assertIn("prepared=document(x['preparation_ref'])", text)
        self.assertIn("prepared['native_step_limit']==500", text)
        self.assertIn("collect_recording_content_v1", text)
        self.assertIn("RUNTIME_CONTENT_RELEASE_20261031_01a19072.json", text)


if __name__ == "__main__":
    unittest.main()
