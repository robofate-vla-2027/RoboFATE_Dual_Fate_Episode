"""Project one frozen legacy source into the existing configured-source interface."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import types

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
CATALOG_OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
LEGACY_OWNER = "01a16338-bd36-78e3-ac27-56c3e62e3333"
TASK = "classify_objects"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338")
ADAPTER = ROOT / "teacher/shared_teacher/perdon_adapter_20261026"
ORIGINAL = {
    "path": str(ROOT / "parent/classify_next142/split_manifest.candidate.v1.json"),
    "sha256": "6a4ca0b47e3ee6a9be797d794a59ea248402707cc068daa6b62d9b921568a42e",
}
LEGACY_HELPER_SHA = "357b3c77f9139909f59efecb7535f27be94bf082b4a4e4ca547a2f9e2c5c88fb"


def validate_projection(original, projected, layout):
    if original["task"] != TASK or original["owner_chat"] != LEGACY_OWNER:
        raise ValueError("Wrong historical source identity")
    if type(layout) is not int or layout not in original["initial_source_sequence"]:
        raise ValueError("Source is not in the frozen sequence")
    partition = original["previous_plan"]["partition"]
    if layout in partition["reserved_final"]:
        raise ValueError("Sealed source")
    for key, value in original.items():
        expected = CATALOG_OWNER if key == "owner_chat" else value
        if projected.get(key) != expected:
            raise ValueError("Historical field changed: " + key)
    if projected.get("historical_manifest_owner") != LEGACY_OWNER:
        raise ValueError("Missing historical manifest owner")
    if projected.get("original_partition") != partition:
        raise ValueError("Original partition changed")
    prefix = original["initial_source_sequence"]
    prefix = prefix[:prefix.index(layout) + 1]
    if set(projected["layouts"]) != {str(i) for i in prefix}:
        raise ValueError("Projection exceeds the required source prefix")
    for i in prefix:
        row = projected["layouts"][str(i)]
        group = original["layout_to_group"][str(i)]
        family = original["families"][group]
        members = [m for m in family["layouts"] if m["bank"] == 0 and m["layout_id"] == i]
        if len(members) != 1 or family["split"] not in ("student_train", "student_dev"):
            raise ValueError("Ambiguous or sealed member")
        member = members[0]
        if (row["layout_id"] != i or row["native_bank"] != 0
                or row["group_id"] != group or row["split"] != family["split"]
                or row["layout_ref"] != {k: member[k] for k in ("path", "sha256")}):
            raise ValueError("Source membership changed")
    if projected["layouts"][str(layout)]["initialization_distinct_from_preceding"] is not True:
        raise ValueError("Duplicate initialization")
    return True


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Existing metadata differs: " + str(path))
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path)


def next_prefix(original, previous, layout):
    source = previous["source"]
    sequence = original["initial_source_sequence"]
    if (type(layout) is not int or source["task"] != TASK
            or source["source_sequence"] != sequence
            or source["layout_id"] not in sequence):
        raise ValueError("Previous prepared source is not in this frozen sequence")
    index = sequence.index(source["layout_id"])
    if (index + 1 >= len(sequence) or sequence[index + 1] != layout
            or source["required_accounted_prefix"] != sequence[:index]
            or layout in original["previous_plan"]["partition"]["reserved_final"]):
        raise ValueError("Only the immediately following unsealed source is allowed")
    return sequence[:index + 2]


def main():
    def metadata_only(event, args):
        if event in ("socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                     "os.kill", "os.killpg"):
            raise RuntimeError("Source metadata only: " + event)

    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    if set(x) != {"execution_owner", "layout", "prior_preparation_ref"} or x["execution_owner"] != OWNER:
        raise ValueError("Explicit predecessor and current execution owner required")
    layout = x["layout"]
    sys.path.insert(0, str(ADAPTER))
    import task_configured_binding as configured

    helper_path = ADAPTER / "task_binding_v10.py"
    helper_raw = helper_path.read_bytes()
    if hashlib.sha256(helper_raw).hexdigest() != LEGACY_HELPER_SHA:
        raise ValueError("Frozen legacy projection helper changed")
    helper = types.ModuleType("_refate_classify_legacy_projection_only")
    helper.__file__ = str(helper_path)
    exec(compile(helper_raw, str(helper_path), "exec"), helper.__dict__)
    helper.TASK = TASK
    original = helper.base.original.decode(helper.base.read_ref(ORIGINAL))
    previous = helper.base.original.decode(helper.base.read_ref(x["prior_preparation_ref"]))
    configured.load_native_layout(previous)
    prefix = next_prefix(original, previous, layout)
    raw_by_layout = {}
    for i in prefix:
        _, _, row = helper.member(original, i)
        path = helper.base.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{TASK}_{i}.json"
        raw_by_layout[i] = helper.base.original.decode(helper.base.read_ref(
            {k: row[k] for k in ("path", "sha256")}, expected_path=path))
    if list(raw_by_layout) != prefix:
        raise ValueError("Frozen next-source prefix changed")
    projected = helper.legacy_view(original, layout, raw_by_layout)
    validate_projection(original, projected, layout)
    projected["metadata_projection"] = {
        "schema": "refate.legacy_split.configured_projection.v1",
        "original_manifest": deepcopy(ORIGINAL),
        "historical_manifest_owner": LEGACY_OWNER,
        "catalog_descriptor_owner": CATALOG_OWNER,
        "prepared_by": OWNER,
        "projection_is_not_execution_authority": True,
        "original_sequence_and_memberships_unchanged": True,
        "sealed_layout_content_read": False,
        "original_file_modified": False,
    }
    directory = ADAPTER / "task_sources" / TASK
    directory.mkdir(exist_ok=True)
    projection_ref = save(directory / f"SPLIT_LEGACY_VIEW_L{layout}_001.json", projected)
    task_ref = ref(helper.base.NATIVE / "task/RoboDojo/tasks/classify_objects.py")
    prepared, raw = configured.prepare_source(task=TASK, layout_id=layout,
        split_ref=projection_ref, native_total=1100, task_ref=task_ref)
    configured.load_native_layout(prepared)
    import teacher_catalog_binding_v9 as teacher
    if teacher.TASK_TOTALS[TASK] != 1100 or teacher.load_native_layout(prepared) != raw:
        raise ValueError("Matching teacher metadata loader disagrees")
    preparation_ref = save(directory / f"PREPARATION_L{layout}_CONFIGURED_001.json", prepared)
    if ref(Path(ORIGINAL["path"])) != ORIGINAL:
        raise ValueError("Original split changed during preparation")
    result = {
        "schema": "refate.classify.legacy_source_preparation.v1",
        "data_kind": "preparation_only",
        "execution_owner": OWNER,
        "source_id": prepared["source"]["source_id"],
        "source_owner": prepared["source"]["source_owner"],
        "preparation_ref": preparation_ref,
        "split_ref": projection_ref,
        "original_split": ORIGINAL,
        "prior_preparation_ref": x["prior_preparation_ref"],
        "metadata_helper": ref(Path(__file__)),
        "task_ref": task_ref,
        "native_budget": 1100,
        "required_accounted_prefix": prepared["source"]["required_accounted_prefix"],
        "original_source_sequence": prepared["source"]["source_sequence"],
        "fixed_group": prepared["source"]["group_id"],
        "split": prepared["source"]["split"],
        "sealed_content_read": False,
        "old_sources_replayed": False,
        "runtime_files_modified": False,
        "source_reserved": False,
        "actual_launch": False,
        "teacher_binding_verified": True,
        "positive_delta": 0,
        "negative_delta": 0,
    }
    result["evidence_ref"] = save(directory / f"PREPARATION_L{layout}_HANDOFF_01a19072_001.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
