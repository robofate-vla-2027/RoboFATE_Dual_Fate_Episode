"""Additive release for the paired Insert metadata-author adaptation."""
import datetime
import hashlib
import json
from pathlib import Path

import prepare_insert_sequence_handoff_v1 as preparation
import sys
sys.addaudithook(preparation.metadata_only)
import insert_sequence_handoff_v1 as handoff
handoff.install()
import common_runtime as runtime
import collection_insert_sequence_content_v1 as wiring
import collect_insert_sequence_content_v1 as collector
import bind_insert_sequence_content_v1 as binder

HERE = Path(__file__).resolve().parent
NAMES = (
    "insert_sequence_handoff_v1.py", "prepare_insert_sequence_handoff_v1.py",
    "collection_insert_sequence_content_v1.py", "baseline_insert_sequence_content_v1.py",
    "collect_insert_sequence_content_v1.py", "bind_insert_sequence_content_v1.py",
    "insert_negative_boundary_handoff_v2.py", "reserve_insert_content_handoff_v2.py",
    "test_insert_sequence_handoff_v1.py", "test_insert_sequence_entries_v1.py",
)


def main():
    log = HERE / "INSERT_SEQUENCE_CPU_20261103_001.log"
    text = log.read_text()
    assert "Ran 34 tests" in text and "Ran 4 tests" in text and text.rstrip().endswith("OK")
    assert binder.collection is collector
    assert collector.core.foreground.baseline is wiring.baseline_module
    assert wiring.source("baseline_native") == wiring.previous.source("baseline_native")
    assert collector.core.finish.reader_binding.__name__ == "reader_content_binding_v1"
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cpu = preparation.save(HERE / "INSERT_SEQUENCE_CPU_20261103_001.json", dict(
        data_kind="offline_cpu_not_scientific_data", at=at,
        synthetic_source_tests=34, entry_import_checks=4, all_passed=True,
        log=preparation.ref(log), no_model_api_simulator_calls=True,
        actual_source_launch=False, existing_source_documents_modified=False,
    ))
    previous = dict(
        path=str(HERE / "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"),
        sha256="b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131",
    )
    data = runtime.document(runtime.read_pin(previous))
    for item in data["runtime_files"]:
        runtime.read_pin(item)
    data["runtime_files"] = list({
        item["path"]: item
        for item in data["runtime_files"] + [preparation.ref(HERE / name) for name in NAMES]
    }.values())
    data.update(
        created_at=at, inherits=previous, cpu_summary=cpu,
        foreground_entry=str(HERE / "collect_insert_sequence_content_v1.py"),
        native_entry=str(HERE / "baseline_insert_sequence_content_v1.py"),
        context_builder=preparation.ref(HERE / "bind_insert_sequence_content_v1.py"),
        ownership_handoff=handoff.install(),
        sequence_author_adapter=preparation.ref(HERE / "insert_sequence_handoff_v1.py"),
        effective_source_sha256={
            name: hashlib.sha256(wiring.source(name).encode()).hexdigest()
            for name in ("baseline_native", "foreground_common")
        },
        actual_adoption=False, runtime_adopted=False,
        real_constant_frame_validation=False, old_runtime_files_modified=False,
        revision_scope="Sequence-author handoff only; source ownership, ordering, sealed "
                       "checks, recorder, readers, policy, renderer and budgets unchanged.",
    )
    assert data["native_wall_seconds"] == 2400 and data["teacher_wall_seconds"] == 3600
    result = preparation.save(
        HERE / "RUNTIME_INSERT_SEQUENCE_CONTENT_RELEASE_20261103_01a19072.json", data,
    )
    print(json.dumps(dict(release=result, cpu=cpu, actual_launch=False,
                          actual_adoption=False, positive_delta=0, negative_delta=0)))


if __name__ == "__main__":
    main()
