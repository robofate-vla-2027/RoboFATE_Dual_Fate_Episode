"""General200 metadata on the existing content-aware shared teacher catalog."""
from pathlib import Path
import common_runtime as runtime
import teacher_catalog_binding_v11 as previous
import task_configured_binding as configured

_TEXT = runtime.edit(previous._TEXT, "'pick_from_conveyor_by_image': 700}",
                     "'pick_from_conveyor_by_image': 700, 'general_pickup': 200}")
if _TEXT.count("teacher_catalog_binding_v11") != 6:
    raise ValueError("Frozen catalog import sites changed")
_TEXT = _TEXT.replace("teacher_catalog_binding_v11", "teacher_catalog_binding_v12")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_restore_v11'", "'_refate_shared_task_restore_v12'")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_persistence_v11'", "'_refate_shared_task_persistence_v12'")
exec(compile(_TEXT, str(Path(__file__).with_name("teacher_task_binding.py")) +
             "::general200_catalog_v12", "exec"), globals())


def load_native_layout(context):
    if context.get("binding_schema") == configured.SCHEMA and context["source"]["task"] == "general_pickup":
        need(type(context["native_step_limit"]) is int and context["native_step_limit"] == 200,
             "Original General200 budget required")
        return configured.load_native_layout(context)
    return previous.load_native_layout(context)
