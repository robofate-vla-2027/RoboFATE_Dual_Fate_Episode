"""Existing five-failure revisit, with Insert's original reviewer and Organize."""
import hashlib
from pathlib import Path

import negative_shortfall_deferral_handoff_v1 as negative
import switch_general_negative_to_retained_classify_v1 as previous

baseline_checks = previous.baseline_checks
review_negative_shortfall = negative.review


def source():
    for module, expected in (
        (previous, "775b79e3c739058eef2296d241f06fc4bba4a01e36cd1fa4dd3384f48f7afc21"),
        (negative, "8e9f9203c9f8d03ab444cf821d366ffed3c5b1e845ffdfd467f6a8981b1680b3"),
    ):
        if hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen scheduling dependency changed")
    text = previous.source()
    for old, new, count in (
        ("general_pickup", "insert_tubes", 6),
        ("classify_objects", "organize_table", 6),
        ('== s["native_budget"] == 1100', '== s["native_budget"] == 1000', 1),
    ):
        if text.count(old) != count:
            raise ValueError("Frozen scheduling parameter seam changed: " + old)
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::insert_retained_organize", "exec"),
     globals())
