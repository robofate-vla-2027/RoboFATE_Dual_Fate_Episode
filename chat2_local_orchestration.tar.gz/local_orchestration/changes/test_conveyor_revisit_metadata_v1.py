"""Synthetic in-memory transactions only; no model, network, process, or ledger writes."""
import base64
from copy import deepcopy
import datetime
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata tests prohibit live effects")


sys.addaudithook(reject_live)
HERE = Path(__file__).parent
if (HERE.parent / "snapshot").exists():
    STAGED = tempfile.TemporaryDirectory(prefix="refate-synthetic-conveyor-")
    for name in ("common_owner_reservation.py", "common_owner_reservation_v2.py"):
        shutil.copyfile(HERE.parent / "snapshot" / name, Path(STAGED.name) / name)
    shutil.copyfile(HERE / "owner_reservation_handoff_v1.py",
                    Path(STAGED.name) / "owner_reservation_handoff_v1.py")
    sys.path.insert(0, STAGED.name)
else:
    sys.path.insert(0, str(HERE))
import owner_reservation_handoff_v1 as original_reservation

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
TASK = "pick_from_conveyor_by_image"
TEXT = (HERE / "conveyor_revisit_handoff_v1.py").read_text()


def ref(name):
    return {"path": "/synthetic/" + name, "sha256": "a" * 64}


def fixture():
    now = datetime.datetime.now(datetime.timezone.utc)
    stamp = lambda hours: (now - datetime.timedelta(hours=hours)).isoformat()
    current_id = "synthetic-classify-source"
    run_id = "c2_classify_objects_synthetic_teacher_01a16807"
    current = dict(schema="closed_teacher_resource_v1", source_id=current_id, run_id=run_id,
                   ref=ref("terminal"), summary_ref=ref("summary"),
                   settlement_ref=ref("terminal"), safe_for_next_simulator=True)
    source = dict(task=TASK, source_id=TASK + "_b0_l5_synthetic", layout_id=5,
                  execution_owner="01a16807-8085-7903-be07-66eb332ebf95",
                  source_owner="01a16807-8085-7903-be07-66eb332ebf95",
                  initialization_content_sha256="new-synthetic-initialization",
                  group_id="synthetic-group", split="student_dev", layout_sha256="b" * 64,
                  source_sequence=list(range(7)), required_accounted_prefix=list(range(5)))
    prepared = dict(binding_schema="refate.common_collector.task_source_binding.v1",
                    source=source, native_step_limit=700, mode="independent_baseline",
                    requested_initial_native_count=0, renderer_profile="synthetic-rtx",
                    prospective_teacher_renderer_profile="synthetic-rtx",
                    provenance={"split": ref("split")})
    rows, reservations = {}, {}
    for ordinal in range(5):
        sid = f"{TASK}_b0_l{ordinal}_synthetic"
        rows[sid] = dict(source_id=sid, task=TASK, host="perdon-hou",
                         settlement=ref(f"baseline{ordinal}"),
                         initialization_content_sha256=f"old-synthetic-{ordinal}")
        reservations[sid] = dict(status="settled_native_failure")
    prior_id = f"{TASK}_b0_l4_synthetic"
    rows[current_id] = dict(source_id=current_id, task="classify_objects",
                           host="perdon-hou", complete_readback=True, native_budget=1100,
                           run_id="synthetic-classify-baseline",
                           active_teacher_attempt=dict(run_id=run_id, status="settled",
                                                       terminal_observation=current["ref"]))
    reservations[current_id] = dict(status="shared_Evo_teacher_settled",
        current_attempt_settlement=current["summary_ref"], positive_slots=0, negative_slots=0,
        quota_reserved=False, negative_quota_reserved=False)
    node = dict(active_chat_id=OWNER, current_task="classify_objects",
        active_run_id=None, active_real_simulators=0, launch_inflight=False,
        baseline_accounting={"baseline_attempts_running": 0}, fixed_tasks=[TASK, "classify_objects"],
        user_pause_active=False, user_stop=False, owned_resource_launch_hold=False,
        completed_pending_sources=[], common_pending_readback_run_ids=[],
        last_owned_resource_settlement=current["ref"], qualified_count=35, negative_count=18,
        negative_quota=210, negative_reserved_count=0,
        task_segments=[dict(task="synthetic-other", ended_at=stamp(3))],
        current_runtime_adoption={}, current_dispatch={}, current_common_foreground={})
    old = dict(task="classify_objects", quota=10, qualified_count=1,
               negative_count=1, negative_quota=10, latest_segment_started_at=stamp(2),
               last_core_gain_at=stamp(0.001), last_negative_gain_at=stamp(24))
    target = dict(task=TASK, quota=10, qualified_count=0, negative_count=0, negative_quota=10,
                  negative_reserved_count=0, scheduling_state="deferred",
                  assigned_host="perdon-hou", deferred_at=stamp(4),
                  latest_segment_started_at=stamp(5))
    ledger = dict(campaign_id="refate-20261022-97baf70d5128", revision=100,
                  started_at="synthetic-original-start", updated_at=stamp(1),
                  nodes={"perdon-hou": node, "h20_8": {"foreign_ns": 1793470102279866547}},
                  tasks={"classify_objects": old, TASK: target},
                  source_index=rows, reservations=reservations, synthetic_test_fixture=True)
    boundary = dict(at=now.isoformat(), next_preparation={"prepared": prepared, "ref": ref("prepared")},
        resource_precheck={"summary": {"run_id": f"c2_{TASK}_l5_synthetic_01a16807"},
                           "ref": ref("resource")},
        settlement={"source_id": prior_id, "settlement_ref": rows[prior_id]["settlement"],
                    "safe_for_next_simulator": True},
        resource_predecessor=current, runtime_release=ref("release"), metadata_adapter=ref("helper"),
        native_kit_extensions=["isaacsim.asset.gen.conveyor"],
        native_extension_pins={"path": "/synthetic/extension",
          "sha256": "ccfab74f1ab422235587a174f72ff19ffe460349daa15a037a41228b0007d80a"},
        teacher_supplement_present=True)
    return ledger, boundary


def invoke(ledger, boundary):
    release = dict(native_wall_seconds=2400, teacher_wall_seconds=3600,
        foreground_entry="/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
        "20261022_collection_chat2_01a16338/teacher/shared_teacher/"
        "perdon_adapter_20261026/collect_recording_content_v1.py")
    runtime = types.ModuleType("common_runtime")
    runtime.read_pin = lambda value: value
    runtime.document = lambda value: release if value == boundary["runtime_release"] else boundary
    binding = types.ModuleType("task_configured_binding")
    binding.load_native_layout = lambda value: None
    request = dict(from_task="classify_objects", boundary_ref=ref("boundary"),
                   ledger_b64=base64.b64encode(json.dumps(ledger).encode()).decode(),
                   reason="Synthetic due revisit", outline_sha256="c" * 64, directive_sha256="d" * 64)
    output = io.StringIO()
    with patch.dict(sys.modules, {"common_runtime": runtime,
                                  "task_configured_binding": binding,
                                  "owner_reservation_handoff_v1": original_reservation}), \
            patch("sys.stdin", io.StringIO(json.dumps(request))), patch("sys.stdout", output):
        exec(compile(TEXT, "<synthetic-conveyor-metadata>", "exec"), {"__name__": "__main__"})
    return json.loads(output.getvalue())


class ConveyorMetadataTests(unittest.TestCase):
    def test_full_transaction_uses_original_reservation_and_preserves_history(self):
        ledger, boundary = fixture()
        before = deepcopy(ledger)
        out = invoke(ledger, boundary)
        self.assertEqual(ledger, before)
        self.assertEqual(out["ledger"]["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for sid, row in before["source_index"].items():
            self.assertEqual(out["ledger"]["source_index"][sid], row)
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        dispatch = out["receipt"]["dispatch"]
        self.assertEqual(dispatch["native_total_steps"], 700)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["teacher_wall_seconds"], 3600)
        self.assertEqual(dispatch["native_kit_extensions"], ["isaacsim.asset.gen.conveyor"])
        self.assertEqual(dispatch["execution_owner"], OWNER)
        self.assertNotEqual(dispatch["source_owner"], OWNER)
        self.assertEqual(out["ledger"]["tasks"]["classify_objects"]["negative_count"], 1)
        self.assertGreater(out["receipt"]["scheduling_event"]["seconds_since_last_negative_gain"], 5400)

    def test_reject_live_run_wrong_owner_and_unsettled_attempt(self):
        for key in ("live", "owner", "settlement"):
            ledger, boundary = fixture()
            if key == "live":
                ledger["nodes"]["perdon-hou"]["active_run_id"] = "synthetic-live"
            elif key == "owner":
                ledger["nodes"]["perdon-hou"]["active_chat_id"] = "synthetic-other-owner"
            else:
                ledger["reservations"]["synthetic-classify-source"]["positive_slots"] = 1
            with self.assertRaises((AssertionError, ValueError)):
                invoke(ledger, boundary)

    def test_unknown_negative_origin_does_not_invent_window(self):
        ledger, boundary = fixture()
        ledger["tasks"]["classify_objects"].pop("last_negative_gain_at")
        with self.assertRaises(AssertionError):
            invoke(ledger, boundary)

    def test_reject_used_source_unsettled_prefix_and_wrong_extension(self):
        for key in ("used", "prefix", "extension", "budget"):
            ledger, boundary = fixture()
            if key == "used":
                sid = boundary["next_preparation"]["prepared"]["source"]["source_id"]
                ledger["source_index"][sid] = {"task": TASK}
            elif key == "prefix":
                ledger["source_index"][f"{TASK}_b0_l2_synthetic"]["settlement"] = None
            elif key == "extension":
                boundary["native_kit_extensions"] = []
            else:
                boundary["next_preparation"]["prepared"]["native_step_limit"] = 701
            with self.assertRaises((AssertionError, ValueError)):
                invoke(ledger, boundary)

    def test_boundary_retains_native_extension_and_owned_process_checks(self):
        text = (HERE / "conveyor_boundary_handoff_v1.py").read_text()
        self.assertIn("extensions.verify(extension_context)", text)
        self.assertLess(text.index("extensions.verify(extension_context)"), text.index("run.mkdir()"))
        self.assertIn("ident['start_ticks']", text)
        self.assertIn("latest['safe_for_next_simulator']", text)
        self.assertIn("memory_headroom(120)", text)
        self.assertIn("prepared['native_step_limit']==700", text)


if __name__ == "__main__":
    unittest.main()
