"""Offline synthetic metadata checks, not actual approvals or scientific receipts."""
import ast
import hashlib
from pathlib import Path
import sys
import unittest


def offline(event, args):
    if (event.startswith("socket.") and event != "socket.gethostname") or event.startswith("subprocess.") or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata test cannot execute peers or subprocesses")


sys.addaudithook(offline)
import teacher_prepare_metadata_handoff_v4 as prepare
import teacher_reserve_handoff_v5 as reserve
import teacher_bind_handoff_v4 as bind
import teacher_terminal_handoff_v5 as terminal
import teacher_settle_handoff_v5 as settle
import native_teacher_content_v5 as native

HERE = Path(__file__).resolve().parent


class GeneralMetadataTests(unittest.TestCase):
    def test_preparation_changes_only_matching_catalog_release_and_tag(self):
        text = prepare.source()
        ast.parse(text)
        for old, new in (
            ("teacher_catalog_binding_v12", "teacher_catalog_binding_v11"),
            ("collect_teacher_content_v5", "collect_teacher_content_v4"),
            ("'pick_from_conveyor_by_image':'CONVEYOR','general_pickup':'GENERAL'}",
             "'pick_from_conveyor_by_image':'CONVEYOR'}"),
            ("TEACHER_GENERAL_CONTENT_RELEASE_20261101_01a19072.json",
             "TEACHER_CONVEYOR_CONTENT_RELEASE_V2_20261101_01a19072.json"),
            ("d1aa841ebeee87001dcfa2239fc0809ff212b8855469563eeed5f5ce749d35e5",
             "74d2cdf5bb0ad1b688c002d792ae67f2b2af168a7314435e32abc5911dbb1ffd"),
        ):
            text = text.replace(old, new)
        self.assertEqual(text, (HERE / "teacher_prepare_metadata_handoff_v3.py").read_text())

    def test_reservation_only_catalog_and_tag_change(self):
        text = reserve.source().replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v11")
        text = text.replace("'pick_from_conveyor_by_image':'conveyor','general_pickup':'general'}",
                            "'pick_from_conveyor_by_image':'conveyor'}")
        self.assertEqual(text, (HERE / "teacher_reserve_handoff_v4.py").read_text())

    def test_binding_only_actual_entry_reference_changes(self):
        text = bind.source().replace("prepare_teacher_content_v5", "prepare_teacher_content_v4")
        self.assertEqual(text, (HERE / "teacher_bind_handoff_v3.py").read_text())

    def test_terminal_only_entry_and_effective_source_hash_change(self):
        text = terminal.source()
        self.assertIn(hashlib.sha256(native.text.encode()).hexdigest(), text)
        text = text.replace("collect_teacher_content_v5", "collect_teacher_content_v4").replace(
            "c70b36872331116b7f5c92bed8b884c4cf8c3ea0d9171d7167375b6006591d61",
            "71895154e7be98b06078f37acc6d2b517601d9b387d5f94a377ce23f688bd001")
        self.assertEqual(text, (HERE / "teacher_terminal_handoff_v4.py").read_text())

    def test_accounting_only_parameter_binding_changes(self):
        text = settle.source().replace("teacher_ledger_owner_handoff_v4", "teacher_ledger_owner_handoff_v3")
        self.assertEqual(text, (HERE / "teacher_settle_handoff_v4.py").read_text())

    def test_synthetic_pre_actor_failure_stays_failure_and_exact_source_bound(self):
        tree = ast.parse(terminal.source())
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == "verified_pre_actor_failure")
        namespace = {}
        exec(compile(ast.Module(body=[node], type_ignores=[]), "<synthetic-pre-actor-check>", "exec"), namespace)
        check = namespace[node.name]
        context = {"source_id": "synthetic_source", "run_id": "synthetic_run",
                   "t1": 25, "native_limit": 200, "remaining_steps": 175}
        failure = {"source_id": "synthetic_source", "run_id": "synthetic_run",
                   "stage": "initial_boundary_saved", "type": "RuntimeError",
                   "message": "Restored physical/discrete state mismatch",
                   "native_used": 25, "actual_control_steps": 250,
                   "native_done": False, "native_success": False}
        comparison = {"all_compared_fields_within_candidate_rules": False,
                      "context_budget": {"total": 200, "t1": 25, "remaining": 175}}
        sha = hashlib.sha256(native.text.encode()).hexdigest()
        self.assertTrue(check(context, failure, comparison, {"synthetic_actor": False}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": True}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": False}, "0" * 64))
        failure["native_success"] = True
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": False}, sha))


if __name__ == "__main__":
    unittest.main()
