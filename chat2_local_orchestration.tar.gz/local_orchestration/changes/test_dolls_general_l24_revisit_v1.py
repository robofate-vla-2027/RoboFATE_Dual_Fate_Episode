"""Synthetic CPU bookkeeping; no live ledger, peers, model or simulator."""
import ast
from pathlib import Path
import unittest
from unittest.mock import patch

import test_dolls_general_l23_revisit_v1 as previous_tests
import switch_dolls_teacher_to_general_l24_v1 as scheduling
import due_general_l24_from_dolls_boundary_v1 as boundary

previous_tests.legacy.switch_due = scheduling.switch_due


class DueGeneralL24Tests(previous_tests.DueGeneralTests):
    def setUp(self):
        super().setUp()
        self.prep["source"].update(
            layout_id=24, source_sequence=[1, 2, 3, 4, 0] + list(range(5, 25)),
            required_accounted_prefix=[1, 2, 3, 4, 0] + list(range(5, 24)))

    def test_only_declared_source_parameters_change(self):
        expected = scheduling.previous.source()
        for old, new in scheduling.CHANGES:
            expected = expected.replace(old, new, 1)
        self.assertEqual(scheduling.source(), expected)
        expected_boundary = boundary.previous.source().replace(boundary.OLD, boundary.NEW, 1)
        self.assertEqual(boundary.source(), expected_boundary)
        ast.parse(expected_boundary)
        start = "boot=Path('/proc/sys/kernel/random/boot_id')"
        self.assertEqual(expected_boundary[expected_boundary.index(start):],
                         boundary.previous.source()[boundary.previous.source().index(start):])

    def test_old_layout_and_changed_pins_rejected(self):
        self.prep["source"]["layout_id"] = 23
        with self.assertRaises(AssertionError):
            self.run_switch()
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed pin"):
            with self.assertRaises(ValueError):
                scheduling.source()
            with self.assertRaises(ValueError):
                boundary.source()


if __name__ == "__main__":
    unittest.main()
