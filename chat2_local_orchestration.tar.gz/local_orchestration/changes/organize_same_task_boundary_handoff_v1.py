import sys,json,hashlib,datetime,fcntl,os
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import collect_recording_content_v1 as collection;import task_source_binding as binding
x=json.load(sys.stdin);fg=collection.core.foreground;fg.host();T=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher');run=T/'runs'/x['run_id']
def ref(p):return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def doc(r):
 p=Path(r['path']);assert ref(p)==r;return json.loads(p.read_bytes())
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
 return ref(p)
prepared=doc(x['preparation_ref']);binding.load_native_layout(prepared);s=prepared['source'];assert s['task']=='organize_table' and prepared['native_step_limit']==1000 and prepared['requested_initial_native_count']==0 and s['execution_owner']=='01a16807-8085-7903-be07-66eb332ebf95'
assert x['run_id'].startswith('c2_organize_table_l'+str(s['layout_id'])+'_common_baseline_') and x['run_id'].endswith('_01a16807') and not run.exists()
te=doc(x['terminal_ref']);be=doc(x['baseline_settlement_ref']);assert te['source_id']==be['source_id'] and te['safe_for_next_simulator'] and be['safe_for_next_simulator'] and be['first_readback_passed'] and not be['native_success']
checks=te['own_process_checks']+be['process_closure']['checks'];boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for row in checks:
 ident=row['identity'];p=Path('/proc')/str(ident['pid'])/'stat';assert not(p.exists() and boot==ident['boot_id'] and int(p.read_text().rsplit(')',1)[1].split()[19])==ident['start_ticks'])
allocation=fg.allocation();memory=fg.helpers().memory_headroom(120)
with fg.LOCK.open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(f,fcntl.LOCK_UN)
peers=[]
for line in allocation['existing_processes'].splitlines():
 pid=int(line.split(',')[0]);p=Path('/proc')/str(pid);peers.append(dict(identity=fg.identity(pid),uid=p.stat().st_uid,executable=os.readlink(p/'exe')))
disks={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/',str(T)]};assert disks['/']>256*1024**2 and disks[str(T)]>30*1024**3
run.mkdir();at=datetime.datetime.now(datetime.timezone.utc).isoformat();resource=dict(schema='refate.actual_resource_precheck.v1',data_kind='actual',at=at,host='perdon-hou',hostname='nb-5pl2apckdj-0',ssh_endpoint='root@116.198.70.4:1122',run_id=x['run_id'],source_id=s['source_id'],allocation=allocation,memory_precheck=memory,existing_processes=peers,disk_free_bytes=disks,exclusive_native_lock_available=True,estimated_native_gpu1_mib=18000,policy_gpu0_reserve_mib=15000,safety_headroom_mib=12000,temporary_logs_cache_root=str(run/'runtime'),actual_launch=False,existing_peers_untouched=True)
rr=write(run/'RESOURCE_PRECHECK_001.json',resource);runtime=ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/RUNTIME_CONTENT_RELEASE_20261031_01a19072.json'));assert runtime['sha256']=='b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131'
b=dict(schema='refate.actual_boundary_preparation.v1',at=at,next_preparation=dict(prepared=prepared,ref=x['preparation_ref']),resource_precheck=dict(summary=resource,ref=rr),settlement=dict(source_id=be['source_id'],settlement_ref=x['baseline_settlement_ref'],safe_for_next_simulator=True),last_teacher_settlement=te['summary_ref'],resource_predecessor=dict(source_id=te['source_id'],run_id=te['run_id'],summary_ref=te['summary_ref'],safe_for_next_simulator=True,ref=x['terminal_ref']),runtime_release=runtime,metadata_adapter=ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/owner_reservation_handoff_v1.py')),native_kit_extensions=[],teacher_supplement_present=True)
br=write(run/'MAIN_BOUNDARY_001.json',b);print(json.dumps(dict(boundary_ref=br,source_id=s['source_id'],run_id=x['run_id'],budget=prepared['native_step_limit'],resource=resource)))