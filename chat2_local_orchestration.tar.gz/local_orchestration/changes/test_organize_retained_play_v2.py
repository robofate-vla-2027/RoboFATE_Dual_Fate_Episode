"""Offline synthetic scheduling only; no real ledger, network, model or Native."""
import copy
import unittest

import test_switch_retained_play_v1 as fixture
import switch_organize_to_retained_play_v2 as current


class OrganizePlayTests(unittest.TestCase):
    def setUp(self):
        fixture.RetainedPlayTests.setUp(self)
        self.d["source_index"]["old"].update(task="organize_table", host="perdon-hou")
        self.d["source_index"]["retained"]["synthetic_ns"] = 1793707548215597247

    def run_switch(self):
        return current.switch_due(self.d, self.e, self.ref, self.retained,
                                  self.at, "Synthetic fixture, not scientific data")

    def test_only_existing_task_and_budget_bindings_change(self):
        text = current.source().replace("organize_table", "general_pickup").replace(
            "play_stacking_toy", "classify_objects").replace(
                '== s["native_budget"] == 1200', '== s["native_budget"] == 1100')
        self.assertEqual(text, current.parent.source())

    def test_preserves_sources_peers_quota_and_ns(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "play_stacking_toy")
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)

    def test_teacher_positive_does_not_reset_negative_window(self):
        self.e["summary"]["qualified_positive"] = True
        self.d["tasks"]["organize_table"].update(
            qualified_count=1, last_core_gain_at="2026-10-31T11:30:00+00:00")
        self.run_switch()
        event = self.d["nodes"]["perdon-hou"]["task_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_or_recent_negative_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["tasks"]["organize_table"].update(
            negative_count=1, last_negative_gain_at="2026-10-31T11:30:00+00:00",
            last_core_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_unsettled_and_not_due_rejected(self):
        self.d["nodes"]["perdon-hou"]["active_real_simulators"] = 1
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_retained_attempt_refusal_or_bad_budget_rejected(self):
        for key, value in (
            ("teacher_attempt_history", [{"synthetic": True}]),
            ("provider_safety_refusal", {"synthetic": True}),
            ("teacher_replay_prohibited", True), ("counted_in_quota", True),
            ("complete_readback", False), ("native_budget", 1100),
        ):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()


if __name__ == "__main__":
    unittest.main()
