import json,itertools,sys
from pathlib import Path
x=json.load(sys.stdin);p=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];a=[json.loads(l) for l in itertools.islice((p/'native_actions.jsonl').open(),70)];hits=[]
for arm in ('left','right'):
 key=arm+'_ee_joint_state'
 for i in range(3,len(a)-2):
  if all(a[k]['action'][key][0]>.99 for k in range(i-3,i)) and a[i]['action'][key][0]<.99 and a[i+2]['action'][key][0]<a[i]['action'][key][0]:hits.append({'closing_arm':arm,'t1':i,'grippers_near_candidate':[{'i':z['index'],'native_after':z['native_count_after'],'left':z['action']['left_ee_joint_state'],'right':z['action']['right_ee_joint_state']} for z in a[i-3:i+3]]})
print(json.dumps({'closure_candidates':sorted(hits,key=lambda h:(h['t1'],h['closing_arm'])),'automatic_selection':False}))
