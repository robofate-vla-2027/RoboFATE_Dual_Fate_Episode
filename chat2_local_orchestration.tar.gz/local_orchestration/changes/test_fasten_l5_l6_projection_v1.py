"""Synthetic CPU metadata tests; no real sources, model, ledger or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import prepare_fasten_legacy_handoff_v2 as previous
import prepare_fasten_legacy_handoff_v3 as current
from test_fasten_legacy_projection_v1 import fixture


class LastOriginalLayoutsTests(unittest.TestCase):
    def test_preserves_frozen_groups_sequence_and_all_old_fields(self):
        for layout in (5, 6):
            original, projected = fixture(layout)
            before = deepcopy((original, projected))
            current.validate_projection(original, projected, layout)
            self.assertEqual((original, projected), before)
            self.assertEqual(original["initial_source_sequence"], list(range(7)))
            self.assertEqual(original["historical_ns"], 1800000000000000001)
            self.assertNotIn("campaign_id", original)
            self.assertEqual(projected["original_partition"], original["previous_plan"]["partition"])
        self.assertEqual(projected["layouts"]["6"]["group_id"],
                         projected["layouts"]["3"]["group_id"])

    def test_previous_scope_unchanged(self):
        for layout in (2, 3, 4):
            original, projected = fixture(layout)
            previous.validate_projection(original, projected, layout)
            current.validate_projection(original, projected, layout)
        for layout in (5, 6):
            original, projected = fixture(layout)
            with self.assertRaises(ValueError):
                previous.validate_projection(original, projected, layout)

    def test_unadmitted_sealed_and_wrong_types_rejected(self):
        original, _ = fixture(6)
        for layout in (True, 0, 1, 5.0, 7, 52, 53, 54):
            with self.subTest(layout=layout), self.assertRaises(ValueError):
                current.validate_original(original, layout)

    def test_duplicates_and_membership_changes_rejected(self):
        for layout in (5, 6):
            for key, value in (("initialization_distinct_from_preceding", False),
                               ("group_id", "different"), ("native_bank", 1),
                               ("layout_ref", {})):
                original, projected = fixture(layout)
                projected["layouts"][str(layout)][key] = value
                with self.subTest(layout=layout, key=key), self.assertRaises(ValueError):
                    current.validate_projection(original, projected, layout)

    def test_extra_layout_or_changed_original_rejected(self):
        for case in ("sequence", "sealed", "extra", "precision"):
            original, projected = fixture(6)
            if case == "sequence":
                original["initial_source_sequence"] = list(reversed(range(7)))
            elif case == "sealed":
                original["reserved_content_read"] = True
            elif case == "extra":
                projected["layouts"]["7"] = deepcopy(projected["layouts"]["6"])
            else:
                projected["historical_ns"] += 1
            with self.subTest(case=case), self.assertRaises(ValueError):
                current.validate_projection(original, projected, 6)

    def test_pinned_entry_keeps_original_budget_loader_and_prefix_only_reads(self):
        text = current.source()
        ast.parse(text)
        self.assertIn("native_total=1900", text)
        self.assertIn("for index in range(layout + 1):", text)
        self.assertIn("configured.load_native_layout(prepared)", text)
        self.assertIn('"teacher_binding_verified": False', text)
        with patch.object(Path, "read_bytes", return_value=b"changed"):
            with self.assertRaises(ValueError):
                current.source()


def deny_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.", "os.system", "os.posix_spawn")) or event in ("os.kill", "os.killpg"):
        raise RuntimeError("Synthetic CPU projection cannot contact or launch a peer")


if __name__ == "__main__":
    sys.addaudithook(deny_live_effects)
    unittest.main()
