"""Reuse the existing resource boundary with Plug closed and Dolls L13 next."""
import hashlib
from pathlib import Path

import due_dolls_l11_boundary_v1 as previous

PARENT_SHA = "c35f8d9ebd50bf69de4f3390c0b26c0b9d667a2704e82fa52cea5222eff68556"


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Pinned Dolls resource-boundary helper changed")
    text = previous.source()
    for old, new in (
        ("x['from_task']=='pick_from_conveyor_by_image'",
         "x['from_task']=='plug_in_charger'"),
        ("prepared['source']['layout_id']==11 and prepared['source']['source_sequence']==list(range(12))",
         "prepared['source']['layout_id']==13 and prepared['source']['source_sequence']==list(range(14))"),
    ):
        if text.count(old) != 1:
            raise ValueError("Existing resource-boundary parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::dolls_l13_boundary", "exec"), globals())
