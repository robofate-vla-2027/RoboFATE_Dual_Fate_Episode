"""Original due-revisit bookkeeping for an existing, unstarted Bottles source."""
import base64
import copy
import datetime
import hashlib
import json
from pathlib import Path
import sys

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")


def document(ref):
    path = Path(ref["path"])
    assert path.is_relative_to(ROOT) and path.resolve() == path
    raw = path.read_bytes()
    assert len(raw) < 4 * 1024**2
    assert hashlib.sha256(raw).hexdigest() == ref["sha256"]
    return json.loads(raw)


def switch_due(d, terminal, terminal_ref, prepared, preparation_ref, at, reason):
    n = d["nodes"]["perdon-hou"]
    old, target = d["tasks"]["sort_nesting_dolls_by_size"], d["tasks"]["put_bottles_into_dustbin"]
    now = datetime.datetime.fromisoformat(at)
    assert d["campaign_id"] == "refate-20261022-97baf70d5128"
    assert n["active_chat_id"] == OWNER and n["current_task"] == "sort_nesting_dolls_by_size"
    assert not any(n.get(k) for k in ("user_pause_active", "user_stop",
                                    "owned_resource_launch_hold", "launch_inflight"))
    assert n["active_run_id"] is None and n["active_real_simulators"] == 0
    assert n["baseline_accounting"]["baseline_attempts_running"] == 0
    assert len(n["completed_pending_sources"]) <= 2
    assert len(n["common_pending_readback_run_ids"]) <= 2
    assert terminal["task"] == "sort_nesting_dolls_by_size" and terminal["execution_owner"] == OWNER
    assert terminal["safe_for_next_simulator"] is True
    assert n["last_owned_resource_settlement"] == terminal_ref
    source = d["source_index"][terminal["source_id"]]
    reservation = d["reservations"][terminal["source_id"]]
    assert source["task"] == terminal["task"] and source["host"] == "perdon-hou"
    assert source["active_teacher_attempt"]["status"] == "settled"
    assert source["active_teacher_attempt"]["terminal_observation"] == terminal_ref
    assert source["active_teacher_attempt"]["run_id"] == terminal["run_id"]
    assert reservation["status"] == "shared_Evo_teacher_settled"
    assert reservation["current_attempt_settlement"] == terminal["summary_ref"]
    assert reservation["current_attempt_run_id"] == terminal["run_id"]
    assert reservation["positive_slots"] == reservation["negative_slots"] == 0
    assert not reservation["quota_reserved"] and not reservation["negative_quota_reserved"]
    assert type(terminal["summary"]["qualified_positive"]) is bool
    start = datetime.datetime.fromisoformat(old["latest_segment_started_at"])
    gain = datetime.datetime.fromisoformat(old["last_core_gain_at"]) if old.get("last_core_gain_at") else start
    elapsed = (now - max(start, gain)).total_seconds()
    negative_gain = old.get("last_negative_gain_at")
    negative_elapsed = None
    if old["negative_count"] < old["negative_quota"]:
        if negative_gain:
            negative_elapsed = (now - max(start, datetime.datetime.fromisoformat(negative_gain))).total_seconds()
        elif old["negative_count"] == 0:
            negative_elapsed = (now - start).total_seconds()
    assert elapsed >= 5400 or (negative_elapsed is not None and negative_elapsed >= 5400), "Original low-yield window not reached"
    for task in (old, target):
        assert task["assigned_host"] == "perdon-hou" and task["assigned_role"] == "chat2"
        assert task["reserved_count"] == task["negative_reserved_count"] == 0
    assert "put_bottles_into_dustbin" in n["fixed_tasks"]
    assert target["scheduling_state"] == "deferred" and target.get("active_run_id") is None
    assert target["positive_quota"] == target["negative_quota"] == 10
    assert target["qualified_count"] < 10 or target["negative_count"] < 10
    deferred = datetime.datetime.fromisoformat(target["deferred_at"])
    segments = [row for row in n["task_segments"]
                if row["task"] not in ("put_bottles_into_dustbin", "sort_nesting_dolls_by_size")
                and deferred < datetime.datetime.fromisoformat(row["ended_at"]) <= start]
    assert segments, "Two-other-segment revisit is not yet due"
    s = prepared["source"]
    sid = s["source_id"]
    assert s["task"] == "put_bottles_into_dustbin"
    assert prepared["binding_schema"] == "refate.common_collector.configured_task_binding.v1"
    assert prepared["native_step_limit"] == 700 and prepared["mode"] == "independent_baseline"
    assert s["layout_id"] == 12 and s["source_sequence"] == list(range(13))
    assert s["required_accounted_prefix"] == list(range(12))
    assert s["split"] == "student_train" and s["native_bank"] == 0
    assert sid not in d["source_index"] and sid not in d["reservations"], "Inspect existing registration before switching"
    event = dict(
        at=at, task="sort_nesting_dolls_by_size", started_at=old["latest_segment_started_at"],
        ended_at=at, duration_minutes=(now-start).total_seconds()/60,
        outcome="deferred_after_low_yield_review", seconds_since_last_core_gain=elapsed,
        seconds_since_last_negative_gain=negative_elapsed,
        last_core_gain_at=old.get("last_core_gain_at"),
        last_negative_gain_at=old.get("last_negative_gain_at"),
        negative_shortfall_clock_reset=False,
        counts_at_end=dict(positive=old["qualified_count"], negative=old["negative_count"]),
        deficits=dict(positive=old["positive_quota"]-old["qualified_count"],
                      negative=old["negative_quota"]-old["negative_count"]),
        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason)
    review = dict(at=at, event="activate_due_prepared_independent_source",
                  from_task="sort_nesting_dolls_by_size", task="put_bottles_into_dustbin",
                  prior_deferred_at=target["deferred_at"],
                  prior_segment_started_at=target["latest_segment_started_at"],
                  completed_other_segments=[segments[-1], event],
                  source_id=sid, preparation=copy.deepcopy(preparation_ref), baseline_replay=False,
                  source_registered=False,
                  source_started=False, reserved=False, reason=reason)
    n["task_segments"].append(event)
    old.setdefault("scheduling_history", []).append(copy.deepcopy(event))
    old.update(status="pending", phase="deferred_after_settled_no_gain",
               scheduling_state="deferred", deferred_current=True, deferred_at=at,
               deferred_reason=reason, active_run_id=None, updated_at=at)
    target.setdefault("scheduling_history", []).append(copy.deepcopy(review))
    target.update(status="pending", phase="due_configured_source_registration",
                  scheduling_state="active", deferred_current=False,
                  latest_segment_started_at=at, last_revisit_at=at,
                  last_revisit=review, updated_at=at)
    n.setdefault("scheduling_history", []).append(copy.deepcopy(review))
    n.update(current_task="put_bottles_into_dustbin", phase=target["phase"], updated_at=at)
    d["revision"] += 1
    d["updated_at"] = at
    return dict(ledger=d, receipt=dict(
        schema="refate.due_prepared_source_revisit.v1", at=at, revision=d["revision"],
        transition=review, positive_delta=0, negative_delta=0,
        node_positive=n["qualified_count"], node_negative=n["negative_count"],
        lock_inode=27555308))


if __name__ == "__main__":
    x = json.load(sys.stdin)
    d = json.loads(base64.b64decode(x["ledger_b64"]))
    terminal = document(x["terminal_ref"])
    prepared = document(x["preparation_ref"])
    import task_configured_binding as binding
    binding.load_native_layout(prepared)
    print(json.dumps(switch_due(d, terminal, x["terminal_ref"], prepared, x["preparation_ref"],
                               datetime.datetime.now(datetime.timezone.utc).isoformat(),
                               x["reason"])))
