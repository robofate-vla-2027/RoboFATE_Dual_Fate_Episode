"""Existing reservation CLI with the capacity-aware pure metadata helper."""
from pathlib import Path
import hashlib
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
path = Path(__file__).with_name("reserve_content_handoff_v1.py")
text = gap.pinned_text(path, "1a5b5b27560cb29b839cf2f527bfe2912625a966de83f2cf5e8893bef16ca585")
text = gap.change(text, "import owner_reservation_handoff_v1 as helper",
                  "import owner_positive_gap_reservation_v1 as helper")
text = gap.change(text, "print(json.dumps({'ledger':out,'receipt':receipt},ensure_ascii=False))",
                  "receipt['actual_capacity_adapter']=capacity_adapter;"
                  "node['current_capacity_metadata_adapter']=capacity_adapter;"
                  "print(json.dumps({'ledger':out,'receipt':receipt},ensure_ascii=False))")
capacity_adapter = dict(path=str(Path(__file__)), sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
if __name__ == "__main__":
    exec(compile(text, str(path) + "::positive_gap", "exec"), globals())
