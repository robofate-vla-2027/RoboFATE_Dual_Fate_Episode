"""Original teacher reservation with the General200 task and session tag."""
from pathlib import Path
import common_runtime as runtime


def source():
    path = Path(__file__).with_name("teacher_reserve_handoff_v4.py")
    text = runtime.read_pin({"path": str(path), "sha256":
        "d208e3ff32e08e2e50975db605175ebb1e753e5234118e19dd266593ab523820"}).decode()
    text = runtime.edit(text, "from teacher_catalog_binding_v11 import",
                        "from teacher_catalog_binding_v12 import")
    return runtime.edit(text, "'pick_from_conveyor_by_image':'conveyor'}",
                        "'pick_from_conveyor_by_image':'conveyor','general_pickup':'general'}")


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general200_metadata", "exec"), globals())
