"""Offline synthetic scheduling tests; no actual ledger or external effects."""
import ast
import unittest

import test_dolls_bottles_revisit_v1 as original
import switch_organize_teacher_to_play_l14_v1 as scheduling

original.OLD = "organize_table"
original.NEXT = "play_stacking_toy"


class OrganizeTeacherPlayTests(original.DueBottlesTests):
    def setUp(self):
        super().setUp()
        self.prep.update(native_step_limit=1200,
                         binding_schema="refate.common_collector.collection_group_binding.v1")
        self.prep["source"].update(layout_id=14, source_sequence=list(range(15)),
                                   required_accounted_prefix=list(range(14)))

    def run_switch(self):
        return scheduling.switch_due(
            self.d, self.e, self.ref, self.prep, self.prep_ref,
            self.at, "Synthetic teacher settlement; no scientific credit")

    def test_boundary_reuses_original_resource_checks_and_release(self):
        text = scheduling.source()
        ast.parse(text)
        for marker in ('active_teacher_attempt"]["status"] == "settled"',
                       'reservation["current_attempt_settlement"] == terminal["summary_ref"]',
                       'n["last_owned_resource_settlement"] == terminal_ref',
                       'negative_elapsed >= 5400',
                       'import collection_group_binding as binding'):
            self.assertIn(marker, text)
        self.assertNotIn("baseline_checks(", text)

    def test_wrong_schema_budget_and_prefix_rejected(self):
        for key, value in (("binding_schema", "wrong_synthetic_schema"),
                           ("native_step_limit", 700)):
            self.setUp()
            self.prep[key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.run_switch()
        self.setUp()
        self.prep["source"]["required_accounted_prefix"] = [13]
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
