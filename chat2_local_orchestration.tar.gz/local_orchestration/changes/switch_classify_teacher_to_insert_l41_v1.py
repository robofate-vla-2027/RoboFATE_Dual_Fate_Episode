"""Existing closed-teacher revisit transaction, bound to the prepared Insert L41."""
import hashlib
from pathlib import Path

CHANGES = (
    ("sort_nesting_dolls_by_size", "classify_objects"),
    ("put_bottles_into_dustbin", "insert_tubes"),
    ("refate.common_collector.configured_task_binding.v1",
     "refate.common_collector.source_sequence_binding.v1"),
    ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 500'),
    ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
     's["layout_id"] == 41 and s["source_sequence"] == list(range(42))'),
    ('s["required_accounted_prefix"] == list(range(12))',
     's["required_accounted_prefix"] == list(range(41))'),
    ('assert target["qualified_count"] < 10 or target["negative_count"] < 10',
     'assert target["qualified_count"] == 10 and target["negative_count"] < 10'),
    ('import task_configured_binding as binding', 'import source_sequence_binding as binding'),
    ('phase="deferred_after_settled_no_gain"', 'phase="deferred_after_settled_negative_shortfall"'),
    ('status="pending", phase="due_configured_source_registration"',
     'status="collecting", phase="independent_negative_revisit_preparation"'),
)


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
        "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"
    ):
        raise ValueError("Original scheduling helper changed")
    text = raw.decode()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Original scheduling interface changed: " + old)
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    import insert_sequence_handoff_v1 as handoff
    handoff.install()

exec(compile(source(), str(Path(__file__)) + "::insert_l41_metadata", "exec"), globals())
