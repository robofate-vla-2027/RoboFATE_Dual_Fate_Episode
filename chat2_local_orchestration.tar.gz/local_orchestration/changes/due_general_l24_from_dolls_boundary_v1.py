"""Existing separate source/resource boundary with General L24 parameters."""
import hashlib
from pathlib import Path

import due_general_l23_from_dolls_boundary_v1 as previous

PARENT_SHA = "923c7c6dd986666bc56c9fa2d07d1bf4068850c5089ca621bbf2360179901ef5"
OLD = "prepared['source']['layout_id']==23 and prepared['source']['source_sequence']==[1,2,3,4,0]+list(range(5,24))"
NEW = "prepared['source']['layout_id']==24 and prepared['source']['source_sequence']==[1,2,3,4,0]+list(range(5,25))"


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Pinned General resource-boundary helper changed")
    text = previous.source()
    if text.count(OLD) != 1:
        raise ValueError("Existing General layout seam changed")
    return text.replace(OLD, NEW, 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general_l24_boundary", "exec"), globals())
