"""Existing resource-boundary checks with the prepared General L7 references."""
import hashlib
from pathlib import Path

path = Path(__file__).with_name("classify_boundary_handoff_v1.py")
raw = path.read_bytes()
if hashlib.sha256(raw).hexdigest() != "14fa894388b6d5fff10d199488547cc5a6876f05c8475aaa45a44456c97a1621":
    raise ValueError("Frozen resource-boundary helper changed")
text = raw.decode()
for old, new in (
    ("from classify_prefix_handoff_v1 import", "from general_prefix_handoff_v1 import"),
    ('prepared["native_step_limit"] != 1100', 'prepared["native_step_limit"] != 200'),
    ('terminal["task"] == "plug_in_charger"', 'terminal["task"] == "put_bottles_into_dustbin"'),
    ("c2_plug_in_charger_l17_common_baseline_0018_01a16807",
     "c2_put_bottles_into_dustbin_l14_common_baseline_0015_01a16807"),
    ("c2_classify_objects_l6_common_baseline_0001_01a16807",
     "c2_general_pickup_l7_common_baseline_0001_01a16807"),
    ("prospective_classify_teacher_binding_verified", "prospective_general_teacher_binding_verified"),
):
    if text.count(old) != 1:
        raise ValueError("Frozen boundary interface changed: " + old)
    text = text.replace(old, new, 1)
text = text.replace("Classify", "General")
exec(compile(text, str(path) + "::general200_resource_boundary", "exec"), globals())
