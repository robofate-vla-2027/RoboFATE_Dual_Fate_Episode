import execution_owner_binding_v1 as execution
execution.install()
from collection_recording_content_v1 import source
exec(compile(source("baseline_native"), __file__, "exec"), globals())
