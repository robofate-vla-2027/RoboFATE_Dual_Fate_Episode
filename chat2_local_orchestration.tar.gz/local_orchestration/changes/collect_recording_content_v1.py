"""Same one-source foreground with the paired content-aware Native and reader."""
import argparse
import json
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()

import collect_transport_rng as previous
import collection_recording_content_v1 as wiring
import finish_common_content_v1 as finish

previous.core.foreground = wiring.load("foreground_common")
previous.core.finish = finish
core = previous.core
extensions = previous.extensions
collect = previous.collect

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--context", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--settle-only", action="store_true")
    args = parser.parse_args()
    result = collect(args.context, args.sha256, settle_only=args.settle_only)
    print(json.dumps(result, indent=2), flush=True)
    if result["bridge_status"] == "failed" or result["readback_error"] is not None:
        raise SystemExit(1)
