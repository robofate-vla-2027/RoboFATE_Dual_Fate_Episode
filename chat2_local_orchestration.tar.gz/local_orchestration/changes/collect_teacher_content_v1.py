"""Original v12 teacher foreground and publication with consistent readers."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import collect_shared_teacher_v12 as previous

text = previous._source
for old, new in (
    ("import native_shared_teacher_v12 as native", "import native_teacher_content_v1 as native"),
    ("stage.HERE/'native_shared_teacher_v12.py'", "stage.HERE/'native_teacher_content_v1.py'"),
    ("import shared_dependency_binding as dependency\n", "import shared_dependency_content_v1 as dependency\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("collect_shared_teacher.py")) +
             "::content_recording", "exec"), globals())
