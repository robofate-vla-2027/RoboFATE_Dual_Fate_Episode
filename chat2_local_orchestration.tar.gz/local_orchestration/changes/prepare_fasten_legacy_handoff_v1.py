"""Project frozen Fasten metadata into the existing configured baseline interface."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import types

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
SOURCE_OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
CAMPAIGN = "refate-20261022-97baf70d5128"
TASK = "fasten_screws"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338")
ADAPTER = ROOT / "teacher/shared_teacher/perdon_adapter_20261026"
ORIGINAL = {
    "path": str(ROOT / "parent/takeover_01a16807_fasten_source_prepare/SPLIT_MANIFEST_001.json"),
    "sha256": "26e60fc4129aab79900cf7ea9a8a7f225a9cc6193e379231cbfa13cea78ade29",
}
HELPER_SHA = "357b3c77f9139909f59efecb7535f27be94bf082b4a4e4ca547a2f9e2c5c88fb"
TASK_SHA = "2e187a28e33e44efb87baae6463b3ec35264ccd41e35c21a1be44f6361675185"


def validate_original(original, layout):
    if (original["task"] != TASK or original["owner_chat"] != SOURCE_OWNER
            or original["initial_source_sequence"] != list(range(7))
            or original["opaque_reserved_layouts"] != [53, 54]
            or original["previous_plan"]["partition"]["reserved_final"] != [53, 54]
            or original["reserved_content_read"] or "campaign_id" in original
            or type(layout) is not int or layout not in (2, 3)
            or layout in original["unadmitted_layouts"]):
        raise ValueError("Only frozen Fasten L2 descriptor and next L3 are in scope")


def validate_projection(original, projected, layout):
    validate_original(original, layout)
    for key, value in original.items():
        if projected.get(key) != value:
            raise ValueError("Historical metadata changed: " + key)
    if (projected["campaign_id"] != CAMPAIGN
            or projected["historical_manifest_owner"] != SOURCE_OWNER
            or projected["original_partition"] != original["previous_plan"]["partition"]
            or set(projected["layouts"]) != set(map(str, range(layout + 1)))):
        raise ValueError("Wrong configured projection scope")
    for index in range(layout + 1):
        row = projected["layouts"][str(index)]
        group = original["layout_to_group"][str(index)]
        family = original["families"][group]
        members = [m for m in family["layouts"]
                   if m["bank"] == 0 and m["layout_id"] == index]
        if len(members) != 1 or family["split"] not in ("student_train", "student_dev"):
            raise ValueError("Ambiguous or sealed family")
        if (row["layout_id"] != index or row["native_bank"] != 0
                or row["group_id"] != group or row["split"] != family["split"]
                or row["layout_ref"] != {k: members[0][k] for k in ("path", "sha256")}):
            raise ValueError("Original source membership changed")
    if projected["layouts"][str(layout)]["initialization_distinct_from_preceding"] is not True:
        raise ValueError("Duplicate initialization")


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Existing metadata differs: " + str(path))
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path)


def main():
    def metadata_only(event, args):
        if event in ("socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                     "os.kill", "os.killpg"):
            raise RuntimeError("Source metadata only: " + event)

    sys.addaudithook(metadata_only)
    args = json.load(sys.stdin)
    if set(args) != {"execution_owner", "layout"} or args["execution_owner"] != OWNER:
        raise ValueError("Explicit current executor required")
    layout = args["layout"]
    sys.path.insert(0, str(ADAPTER))
    import task_configured_binding as configured

    path = ADAPTER / "task_binding_v10.py"
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != HELPER_SHA:
        raise ValueError("Frozen projection helper changed")
    helper = types.ModuleType("_refate_fasten_projection_only")
    helper.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), helper.__dict__)
    helper.TASK = TASK
    helper.LEGACY_OWNER = SOURCE_OWNER
    original = helper.base.original.decode(helper.base.read_ref(ORIGINAL))
    validate_original(original, layout)
    raw_by_layout = {}
    for index in range(layout + 1):
        _, _, member = helper.member(original, index)
        source_path = helper.base.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{TASK}_{index}.json"
        raw_by_layout[index] = helper.base.original.decode(helper.base.read_ref(
            {k: member[k] for k in ("path", "sha256")}, expected_path=source_path))
    # The old manifest has no campaign field; only the private configured view gains it.
    view_input = deepcopy(original)
    view_input["campaign_id"] = CAMPAIGN
    projected = helper.legacy_view(view_input, layout, raw_by_layout)
    validate_projection(original, projected, layout)
    projected["metadata_projection"] = {
        "original_manifest": ORIGINAL, "prepared_by": OWNER,
        "original_campaign_field_absent": True, "configured_campaign": CAMPAIGN,
        "original_file_modified": False, "source_or_family_membership_changed": False,
        "sealed_content_read": False, "execution_authority": False,
    }
    directory = ADAPTER / "task_sources" / TASK
    directory.mkdir(exist_ok=True)
    split_ref = save(directory / f"SPLIT_LEGACY_VIEW_L{layout}_001.json", projected)
    task_ref = {"path": str(helper.base.NATIVE / f"task/RoboDojo/tasks/{TASK}.py"),
                "sha256": TASK_SHA}
    prepared, layout_raw = configured.prepare_source(
        task=TASK, layout_id=layout, split_ref=split_ref, native_total=1900, task_ref=task_ref)
    if configured.load_native_layout(prepared) != layout_raw:
        raise ValueError("Configured baseline loader disagrees")
    prep_ref = save(directory / f"PREPARATION_L{layout}_CONFIGURED_001.json", prepared)
    if ref(Path(ORIGINAL["path"])) != ORIGINAL:
        raise ValueError("Original split changed during preparation")
    result = {
        "schema": "refate.fasten.legacy_source_preparation.v1",
        "data_kind": "historical_descriptor_only" if layout == 2 else "preparation_only",
        "execution_owner": OWNER, "source_owner": prepared["source"]["source_owner"],
        "source_id": prepared["source"]["source_id"], "preparation_ref": prep_ref,
        "split_ref": split_ref, "original_split": ORIGINAL, "native_budget": 1900,
        "required_accounted_prefix": prepared["source"]["required_accounted_prefix"],
        "original_source_sequence": prepared["source"]["source_sequence"],
        "metadata_helper": ref(Path(__file__)), "task_ref": task_ref,
        "old_sources_replayed": False, "runtime_files_modified": False,
        "teacher_binding_verified": False, "source_reserved": False, "actual_launch": False,
        "positive_delta": 0, "negative_delta": 0,
    }
    result["evidence_ref"] = save(directory / f"PREPARATION_L{layout}_HANDOFF_01a19072_001.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
