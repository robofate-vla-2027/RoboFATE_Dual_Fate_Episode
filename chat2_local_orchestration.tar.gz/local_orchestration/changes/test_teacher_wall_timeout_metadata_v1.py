"""Synthetic offline metadata tests: no model, API, simulator, or subprocess."""
import copy
from pathlib import Path
import unittest
import teacher_wall_timeout_metadata_v1 as m


class TimeoutMetadataTests(unittest.TestCase):
    def setUp(self):
        self.c = dict(execution_owner=m.OWNER, native_wall_seconds=3600,
                      t1=2, native_limit=6, remaining_steps=4)
        self.error = dict(type="TimeoutExpired", message="synthetic command timed out after 3600 seconds")
        self.t1 = dict(stage="actual_t1_verified", wall_ns=1793437409455669682)
        self.actions = [dict(index=i, native_count_after=i+1,
                             role="synthetic_prefix" if i < 2 else "synthetic_teacher",
                             wall_before_ns=self.t1["wall_ns"]+i+1,
                             native_success=False, terminated=False, truncated=False)
                        for i in range(4)]
        self.flags = dict(has_result=False, has_refusal=False, safe=True)

    def check(self):
        return m.validate(self.c, self.error, self.actions, self.t1, **self.flags)

    def test_actual_action_count_and_no_qualification(self):
        self.assertEqual(self.check()["actual_teacher_actions"], 2)
        self.assertEqual(self.check()["actual_native_steps"], 4)
        self.assertFalse(self.check()["native_terminal_observed"])

    def test_other_outcomes_and_unclosed_resources_rejected(self):
        for key, value in (("has_result", True), ("has_refusal", True), ("safe", False)):
            with self.subTest(key=key):
                self.flags[key] = value
                with self.assertRaises(AssertionError):
                    self.check()
                self.flags = dict(has_result=False, has_refusal=False, safe=True)

    def test_wrong_budget_and_non_timeout_rejected(self):
        for error in (dict(type="RuntimeError", message=self.error["message"]),
                      dict(type="TimeoutExpired", message="timed out after 7200 seconds")):
            self.error = error
            with self.assertRaises(AssertionError):
                self.check()

    def test_no_teacher_action_and_terminal_action_rejected(self):
        original = copy.deepcopy(self.actions)
        self.actions = self.actions[:2]
        with self.assertRaises(AssertionError):
            self.check()
        for key in ("native_success", "terminated", "truncated"):
            self.actions = copy.deepcopy(original)
            self.actions[-1][key] = True
            with self.assertRaises(AssertionError):
                self.check()

    def test_sequence_and_t1_correspondence_rejected(self):
        self.actions[-1]["native_count_after"] = 5
        with self.assertRaises(AssertionError):
            self.check()
        self.actions[-1]["native_count_after"] = 4
        self.actions[2]["wall_before_ns"] = self.t1["wall_ns"]
        with self.assertRaises(AssertionError):
            self.check()

    def test_cost_only_preserves_current_run_and_is_idempotent(self):
        run = "synthetic_evo_common_teacher_0001"
        attempt = dict(run_id=run, source_id="s", at="2026-10-31T00:00:00+00:00",
                       native_result=None, teacher_effective_failure=False,
                       positive_delta=0, negative_delta=0)
        d = dict(revision=1, nodes={"perdon-hou": {
            "active_chat_id": m.OWNER, "active_run_id": "synthetic_baseline",
            "current_task": "task", "current_dispatch": {"source_id": "next"}},
            "h20_8": {"nanoseconds": self.t1["wall_ns"]}},
            tasks={"task": {"teacher_statistics": {"EmbodiedEvo": {}}}},
            source_index={"s": {"source_owner": "historical", "host": "perdon-hou",
                               "task": "task", "teacher_attempt_history": [attempt]}})
        e = dict(execution_owner=m.OWNER, source_owner="historical", source_id="s",
                 run_id=run, task="task", data_kind="actual", qualified_sample=False,
                 evidence_ref={"synthetic": True}, **self.check())
        stats = m.statistics(Path(__file__).with_name("teacher_settle_handoff_v2.py"))
        out = m.apply_metadata(d, e, "2026-10-31T01:00:00+00:00", stats)
        self.assertEqual(out["ledger"]["nodes"], d["nodes"])
        updated = out["ledger"]["tasks"]["task"]["teacher_statistics"]["EmbodiedEvo"]
        self.assertEqual(updated["attempts_closed"], 1)
        self.assertEqual(updated["unknown_or_cancelled"], 1)
        self.assertEqual(updated["pre_takeover_failures"], 0)
        self.assertEqual(updated["native_failures"], 0)
        again = m.apply_metadata(out["ledger"], e, "later", stats)
        self.assertEqual(again["ledger"], out["ledger"])
        self.assertTrue(again["receipt"]["idempotent_reuse"])


if __name__ == "__main__":
    unittest.main()
