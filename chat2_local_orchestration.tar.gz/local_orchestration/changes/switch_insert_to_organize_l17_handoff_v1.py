"""Keep the original five-failure review, naming the already prepared L17."""
import hashlib
from pathlib import Path

PARENT_SHA = "9bfa0e904bf5ef4ed60b2160e865fb673936bc807cebd051f10cc4ea74d0cd0c"


def source():
    path = Path(__file__).with_name("switch_insert_to_organize_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PARENT_SHA:
        raise ValueError("Original Insert closed-boundary scheduling helper changed")
    text = raw.decode()
    old = "next unused prepared L13, budget1000"
    if text.count(old) != 1:
        raise ValueError("Original prepared-source description seam changed")
    return text.replace(old, "next unused prepared L17, budget1000", 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::prepared_l17", "exec"), globals())
