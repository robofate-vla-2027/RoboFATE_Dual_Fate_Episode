"""Reuse the closed-baseline revisit for the prepared Insert L42 successor."""
import hashlib
from pathlib import Path

import switch_fasten_to_prepared_general_v1 as previous
from closed_baseline_resource_v1 import baseline_checks

PARENT_SHA = "273196f3e43cda557a096ef708e7894f740b6180292362217aff1399361cde5b"
CHANGES = (
    ("fasten_screws", "put_bottles_into_dustbin"),
    ("general_pickup", "insert_tubes"),
    ("refate.common_collector.configured_task_binding.v1",
     "refate.common_collector.source_sequence_binding.v1"),
    ('prepared["native_step_limit"] == 200', 'prepared["native_step_limit"] == 500'),
    ('s["layout_id"] == 10 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]',
     's["layout_id"] == 42 and s["source_sequence"] == list(range(43))'),
    ('s["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]',
     's["required_accounted_prefix"] == list(range(42))'),
    ('s["split"] in ("student_train", "student_dev")', 's["split"] == "student_train"'),
    ('assert target["qualified_count"] < 10 or target["negative_count"] < 10',
     'assert target["qualified_count"] == 10 and target["negative_count"] < 10'),
    ('import task_configured_binding as binding', 'import source_sequence_binding as binding'),
    ('phase="deferred_after_settled_negative_shortfall"',
     'phase="deferred_after_settled_no_gain"'),
    ('status="pending", phase="due_configured_source_registration"',
     'status="collecting", phase="independent_negative_revisit_preparation"'),
)


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Pinned closed-baseline scheduling helper changed")
    text = previous.source()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Existing scheduling parameter seam changed: " + old)
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    import insert_sequence_handoff_v1 as handoff
    handoff.install()

exec(compile(source(), str(Path(__file__)) + "::bottles_insert_l42", "exec"), globals())
