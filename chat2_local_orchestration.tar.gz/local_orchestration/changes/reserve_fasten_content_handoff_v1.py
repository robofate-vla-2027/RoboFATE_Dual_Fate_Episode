"""Existing metadata CAS result with the verified Fasten prefix adapter."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("reserve_content_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "1a5b5b27560cb29b839cf2f527bfe2912625a966de83f2cf5e8893bef16ca585"):
        raise ValueError("Original reservation entry changed")
    text = raw.decode()
    for old, new in (
        ("import owner_reservation_handoff_v1 as helper",
         "import fasten_owner_reservation_handoff_v1 as helper"),
        ("out,dispatch=helper.reserve(d,b,at);",
         "runtime.read_pin(b['legacy_prefix_adapter']);"
         "assert b['legacy_prefix_adapter']['path']==str(Path(__file__).with_name('fasten_prefix_handoff_v1.py'));"
         "assert b['legacy_prefix_review']==runtime.document(runtime.read_pin(b['legacy_prefix_ref']));"
         "out,dispatch=helper.reserve(d,b,at);"),
        (";print(json.dumps({'ledger':out,'receipt':receipt},ensure_ascii=False))",
         ";receipt['legacy_prefix_ref']=b['legacy_prefix_ref']"
         ";receipt['legacy_prefix_adapter']=b['legacy_prefix_adapter']"
         ";receipt['actual_reservation_adapter']={'path':str(Path(helper.__file__)),"
         "'sha256':hashlib.sha256(Path(helper.__file__).read_bytes()).hexdigest()}"
         ";print(json.dumps({'ledger':out,'receipt':receipt},ensure_ascii=False))"),
    ):
        if text.count(old) != 1:
            raise ValueError("Original reservation interface changed")
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten_metadata", "exec"), globals())
