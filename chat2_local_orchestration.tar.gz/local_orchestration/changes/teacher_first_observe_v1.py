import sys,json,datetime,hashlib
from pathlib import Path
x=json.load(sys.stdin);run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];c=json.loads((run/'CONTEXT_001.json').read_text());p=run/'native_actions.jsonl';a=[]
if p.exists():
 with p.open() as f:
  for line in f:
   e=json.loads(line)
   if e.get('index',-1)>=c['t1'] and 'prefix' not in e.get('role',''):a.append(e)
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
if not a:print(json.dumps({'at':at,'teacher_first_seen':False,'run_id':x['run_id']}));raise SystemExit(0)
t1=json.loads((run/'actual_t1_verified.json').read_text());first=a[0];last=a[-1];assert first['index']==c['t1'] and first['native_count_after']==c['t1']+1 and first['wall_before_ns']>t1['wall_ns'];out=run/'MAIN_FIRST_TEACHER_OBSERVATION_001.json'
if out.exists():d=json.loads(out.read_text())
else:
 d=dict(schema='refate.actual_first_teacher_observation.v1',data_kind='actual',at=at,run_id=x['run_id'],source_id=c['source_id'],task=c['task'],context=ref(run/'CONTEXT_001.json'),stage='actual_t1_verified_teacher_actions_observed',actual_t1=ref(run/'actual_t1_verified.json'),t1=c['t1'],native_limit=c['native_limit'],remaining_steps=c['remaining_steps'],first_teacher_action=first,latest_native_action=last,teacher_actions=len(a),latest_native_steps=last['native_count_after'],t1_ready_to_first_teacher_action_seconds=(first['wall_before_ns']-t1['wall_ns'])/1e9,native_success=last['native_success'],qualified_sample=False)
 with out.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
d['evidence_ref']=ref(out);d['teacher_first_seen']=True;print(json.dumps(d))
