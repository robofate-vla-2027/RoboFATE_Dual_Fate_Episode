"""Reuse the existing closed-teacher negative-only revisit for General L24."""
import hashlib
from pathlib import Path

import switch_dolls_teacher_to_general_l23_v1 as previous

PARENT_SHA = "a088b238e1b36aaa1a1b0b9ffb7b43cdd5c5365a4782e7f50eefab47aaf53ddb"
CHANGES = (
    ('s["layout_id"] == 23 and s["source_sequence"] == [1, 2, 3, 4, 0] + list(range(5, 24))',
     's["layout_id"] == 24 and s["source_sequence"] == [1, 2, 3, 4, 0] + list(range(5, 25))'),
    ('s["required_accounted_prefix"] == [1, 2, 3, 4, 0] + list(range(5, 23))',
     's["required_accounted_prefix"] == [1, 2, 3, 4, 0] + list(range(5, 24))'),
)


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Pinned General negative-only revisit changed")
    text = previous.source()
    for old, new in CHANGES:
        if text.count(old) != 1:
            raise ValueError("Existing General source-sequence seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::general_l24", "exec"), globals())
