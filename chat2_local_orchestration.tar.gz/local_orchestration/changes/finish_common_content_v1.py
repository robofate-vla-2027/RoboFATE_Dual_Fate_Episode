"""Original postwait and once semantics, now bound to the content-aware reader."""
from pathlib import Path
import common_runtime as runtime

path = Path(__file__).with_name("finish_common_identity.py")
text = runtime.read_pin({"path": str(path), "sha256":
    "a5a6450161bb13df3f2a64f67e27bae31c7f3e413eefff06bae3785518419a5e"}).decode()
text = runtime.edit(text, "import reader_identity_binding as reader_binding",
                    "import reader_content_binding_v1 as reader_binding", count=2)
exec(compile(text, str(path) + "::content_reader_postwait", "exec"), globals())
