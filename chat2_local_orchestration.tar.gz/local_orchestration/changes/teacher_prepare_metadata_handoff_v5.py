"""Same metadata operation, with matching Fasten1900 entry references."""
from pathlib import Path
import common_runtime as runtime
import teacher_prepare_metadata_handoff_v4 as previous

CHANGES = (('teacher_catalog_binding_v12', 'teacher_catalog_binding_v13'), ('collect_teacher_content_v5', 'collect_teacher_content_v6'), ("'general_pickup':'GENERAL'}", "'general_pickup':'GENERAL','fasten_screws':'FASTEN'}"), ('TEACHER_GENERAL_CONTENT_RELEASE_20261101_01a19072.json', 'TEACHER_FASTEN_CONTENT_RELEASE_20261101_01a19072.json'), ('d1aa841ebeee87001dcfa2239fc0809ff212b8855469563eeed5f5ce749d35e5', '7d3a95a691030d7d3dc5707c619ab9da9e11c61fd1bab49af2bec4b491e73e46'))


def source():
    runtime.read_pin({"path": str(Path(__file__).with_name('teacher_prepare_metadata_handoff_v4.py')),
                      "sha256": '09d209209bffb3b67af82ebe1ba3bddee847cc0a5211732841519c40505e1425'})
    text = previous.source()
    for old, new in CHANGES:
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten1900_metadata", "exec"), globals())
