"""Synthetic append/reservation fixtures; no live data, network, model, or simulator."""
import ast
import base64
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import test_conveyor_revisit_metadata_v1 as fixtures

HERE = Path(__file__).parent
TASK = fixtures.TASK
TEXT = (HERE / "reserve_conveyor_append_content_handoff_v1.py").read_text()


def fixture():
    ledger, boundary = fixtures.fixture()
    source = boundary["next_preparation"]["prepared"]["source"]
    source.update(source_id=f"{TASK}_b0_l7_synthetic", layout_id=7,
                  source_sequence=list(range(8)), required_accounted_prefix=list(range(7)))
    for ordinal in (5, 6):
        sid = f"{TASK}_b0_l{ordinal}_synthetic"
        ledger["source_index"][sid] = dict(source_id=sid, task=TASK, host="perdon-hou",
            initialization_content_sha256=f"synthetic-old-{ordinal}",
            settlement=fixtures.ref(f"baseline{ordinal}"))
        ledger["reservations"][sid] = dict(status="settled_native_failure")
    prior = f"{TASK}_b0_l6_synthetic"
    prior_ref = ledger["source_index"][prior]["settlement"]
    boundary["settlement"] = dict(source_id=prior, settlement_ref=prior_ref,
                                  safe_for_next_simulator=True)
    boundary["resource_predecessor"] = dict(source_id=prior, ref=prior_ref,
                                           safe_for_next_simulator=True)
    boundary["resource_precheck"]["summary"]["run_id"] = f"c2_{TASK}_l7_synthetic_01a16807"
    root = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/" \
           "20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026"
    boundary["runtime_release"] = dict(path=root + "/RUNTIME_CONTENT_RELEASE_20261031_01a19072.json",
        sha256="b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131")
    node = ledger["nodes"]["perdon-hou"]
    node.update(current_task=TASK, last_owned_resource_settlement=prior_ref)
    manifest = dict(task=TASK, previous_manifest=fixtures.ref("original-manifest"),
                    initial_source_sequence=list(range(8)), materialized_layouts=list(range(8)),
                    original_partition={"reserved_final": [53, 54]},
                    source_sequence_append=fixtures.ref("append-event"))
    ledger["split_manifests"] = {TASK: dict(manifest=manifest["previous_manifest"],
        sequence=list(range(7)), owner_chat="synthetic-frozen-owner",
        preserved_ns=1793470102279866547)}
    return ledger, boundary, manifest


def invoke(ledger, boundary, manifest):
    manifest_raw = json.dumps(manifest).encode()
    manifest_ref = dict(path="/synthetic/conveyor-append.json",
                        sha256=hashlib.sha256(manifest_raw).hexdigest())
    boundary["next_preparation"]["prepared"]["provenance"]["split"] = manifest_ref
    boundary_raw = json.dumps(boundary).encode()
    boundary_ref = dict(path="/synthetic/conveyor-boundary.json",
                        sha256=hashlib.sha256(boundary_raw).hexdigest())
    documents = {manifest_ref["path"]: manifest_raw, boundary_ref["path"]: boundary_raw}
    actual_read = Path.read_bytes
    read = lambda path: documents[str(path)] if str(path) in documents else actual_read(path)
    request = dict(ledger_b64=base64.b64encode(json.dumps(ledger).encode()).decode(),
                   boundary_ref=boundary_ref, outline_sha="c" * 64, directive_sha="d" * 64)
    output = io.StringIO()
    with patch.object(Path, "read_bytes", read), \
            patch("sys.stdin", io.StringIO(json.dumps(request))), patch("sys.stdout", output):
        exec(compile(TEXT, "<synthetic-conveyor-append-reservation>", "exec"),
             {"__name__": "__main__"})
    return json.loads(output.getvalue())


class ConveyorAppendTests(unittest.TestCase):
    def test_original_transaction_preserves_rows_counts_clock_and_foreign_data(self):
        ledger, boundary, manifest = fixture()
        before = deepcopy(ledger)
        out = invoke(ledger, boundary, manifest)
        self.assertEqual(ledger, before)
        for sid, row in before["source_index"].items():
            self.assertEqual(out["ledger"]["source_index"][sid], row)
        self.assertEqual(out["ledger"]["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["ledger"]["tasks"][TASK]["latest_segment_started_at"],
                         before["tasks"][TASK]["latest_segment_started_at"])
        self.assertEqual(out["ledger"]["split_manifests"][TASK]["sequence"], list(range(8)))
        self.assertEqual(out["ledger"]["split_manifests"][TASK]["preserved_ns"], 1793470102279866547)
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        dispatch = out["receipt"]["dispatch"]
        self.assertEqual((dispatch["native_total_steps"], dispatch["native_wall_seconds"],
                          dispatch["teacher_wall_seconds"]), (700, 2400, 3600))
        self.assertEqual(dispatch["native_kit_extensions"], ["isaacsim.asset.gen.conveyor"])

    def test_reject_live_source_wrong_budget_missing_extension_and_skipped_source(self):
        for mode in ("live", "budget", "extension", "skip", "sealed"):
            ledger, boundary, manifest = fixture()
            if mode == "live":
                ledger["nodes"]["perdon-hou"]["active_run_id"] = "synthetic-live"
            elif mode == "budget":
                boundary["next_preparation"]["prepared"]["native_step_limit"] = 701
            elif mode == "extension":
                boundary["native_kit_extensions"] = []
            elif mode == "skip":
                boundary["next_preparation"]["prepared"]["source"]["layout_id"] = 8
            else:
                boundary["next_preparation"]["prepared"]["source"]["layout_id"] = 53
            with self.assertRaises((AssertionError, ValueError)):
                invoke(ledger, boundary, manifest)

    def test_reject_changed_registry_and_unsettled_prefix(self):
        for mode in ("registry", "prefix"):
            ledger, boundary, manifest = fixture()
            if mode == "registry":
                ledger["split_manifests"][TASK]["manifest"] = fixtures.ref("wrong-original")
            else:
                ledger["source_index"][f"{TASK}_b0_l2_synthetic"]["settlement"] = None
            with self.assertRaises((AssertionError, ValueError)):
                invoke(ledger, boundary, manifest)

    def test_original_new_family_rule_and_no_teacher_admission_claim(self):
        text = (HERE / "prepare_next_conveyor_handoff_v1.py").read_text()
        tree = ast.parse(text)
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                        and n.name == "select_new_group_split")
        namespace = {}
        exec(compile(ast.Module(body=[function], type_ignores=[]), "<synthetic-group>", "exec"),
             namespace)
        self.assertEqual(namespace["select_new_group_split"](
            {"a": {"split": "student_train"}, "b": {"split": "student_dev"}}), "student_train")
        self.assertIn("teacher_metadata_loader_checked=False", text)
        self.assertNotIn("source_and_teacher_metadata_loaders_passed=True", text)
        self.assertIn("m['original_partition']==old['original_partition']", text)
        self.assertIn("old['layouts'][k]==m['layouts'][k]", text)
        self.assertIn("canonical_descriptor_identity_is_not_current_executor=True", text)
        for name in ("review_next_conveyor_handoff_v1.py", "prepare_next_conveyor_handoff_v1.py"):
            self.assertIn("sys.addaudithook(reject_live_effect)", (HERE / name).read_text())


if __name__ == "__main__":
    unittest.main()
