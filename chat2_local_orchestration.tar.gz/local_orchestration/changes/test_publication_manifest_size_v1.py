"""Synthetic CPU metadata tests; no real ledger, models, peers or simulation."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


def offline(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic publication metadata only")


sys.addaudithook(offline)
import publication_manifest_size_v1 as module


def document(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            module.need(key not in result, "Duplicate metadata key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: module.need(False, "Nonfinite metadata"))


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="refate_synthetic_manifest_")
        self.root = Path(self.tmp.name).resolve()
        self.context = {"task": "SYNTHETIC_TASK", "source_id": "SYNTHETIC_SOURCE"}
        self.path = self.root / "published/SYNTHETIC_TASK/SYNTHETIC_SOURCE/manifest.json"
        self.path.parent.mkdir(parents=True)
        self.scope = patch.object(module, "SHARED", self.root)
        self.scope.start()
        self.runtime = patch.dict(sys.modules, {
            "common_runtime": types.SimpleNamespace(document=document)})
        self.runtime.start()

    def tearDown(self):
        self.runtime.stop()
        self.scope.stop()
        self.tmp.cleanup()

    def save(self, size=32, raw=None):
        if raw is None:
            raw = json.dumps({"synthetic_ns": 2**63 + 17, "padding": " " * size}).encode()
        self.path.write_bytes(raw)
        return {"path": str(self.path), "sha256": hashlib.sha256(raw).hexdigest()}

    def test_long_manifest_preserves_original_document_and_nanoseconds(self):
        ref = self.save(12 * 1024**2)
        self.assertEqual(module.read_manifest(ref, self.context), document(self.path.read_bytes()))
        self.assertEqual(module.read_manifest(ref, self.context)["synthetic_ns"], 2**63 + 17)

    def test_small_document_unchanged(self):
        ref = self.save()
        self.assertEqual(module.read_manifest(ref, self.context), document(self.path.read_bytes()))

    def test_oversize_wrong_hash_and_missing_rejected(self):
        ref = self.save(module.LIMIT)
        with self.assertRaises(ValueError):
            module.read_manifest(ref, self.context)
        ref = self.save()
        with self.assertRaises(ValueError):
            module.read_manifest(dict(ref, sha256="0"*64), self.context)
        self.path.unlink()
        with self.assertRaises(FileNotFoundError):
            module.read_manifest(ref, self.context)

    def test_wrong_scope_report_and_nonexact_reference_rejected(self):
        ref = self.save()
        for changed in (dict(self.context, source_id="OTHER"),
                        dict(self.context, task="../OTHER")):
            with self.assertRaises(ValueError):
                module.read_manifest(ref, changed)
        for changed in (dict(ref, extra=True),
                        dict(ref, path=str(self.path.with_name("REPORT.json")))):
            with self.assertRaises(ValueError):
                module.read_manifest(changed, self.context)

    def test_corrupt_duplicate_and_nonfinite_metadata_rejected(self):
        for raw in (b"broken", b'{"a":1,"a":2}', b'{"a":NaN}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                module.read_manifest(self.save(raw=raw), self.context)

    def test_mutation_and_symlink_rejected(self):
        ref = self.save()
        before = module.signature(self.path)
        after = (*before[:-1], before[-1] + 1)
        with patch.object(module, "signature", side_effect=[before, after]):
            with self.assertRaises(ValueError):
                module.read_manifest(ref, self.context)
        target = self.path.with_name("original.json")
        self.path.rename(target)
        self.path.symlink_to(target)
        with self.assertRaises(ValueError):
            module.read_manifest(ref, self.context)

    def test_actual_compute_seam_only_manifest_reader_changes(self):
        text = ("r=original_r\nledger_core=original_core\n"
                "def compute(ledger, context):\n"
                "    c=context;published=ledger['publication']\n"
                "    manifest=r.document(published['manifest'])\n"
                "    return manifest\n")
        transaction = types.ModuleType("synthetic_transaction")
        original_reader = types.SimpleNamespace(document=lambda _: self.fail("Old reader called"))
        transaction.original_r = original_reader
        transaction.original_core = object()
        cli = types.SimpleNamespace(_text=text, _transaction=transaction, r=original_reader)
        ref = self.save(9 * 1024**2)
        ledger = {"publication": {"manifest": ref}, "peer_ns": 2**63 + 17}
        before = deepcopy(ledger)
        with patch.object(module, "TRANSACTION_SHA", hashlib.sha256(text.encode()).hexdigest()):
            module.bind_cli(cli)
        self.assertEqual(transaction.compute(ledger, self.context)["synthetic_ns"], 2**63 + 17)
        self.assertEqual(ledger, before)
        self.assertIs(cli.r, original_reader)
        self.assertIs(cli.ledger_core, transaction.original_core)
        self.assertEqual(text.replace(module.OLD, module.NEW, 1).replace(module.NEW, module.OLD, 1), text)

    def test_changed_transaction_fails_closed(self):
        cli = types.SimpleNamespace(_text="changed")
        with self.assertRaises(ValueError):
            module.bind_cli(cli)


if __name__ == "__main__":
    unittest.main()
