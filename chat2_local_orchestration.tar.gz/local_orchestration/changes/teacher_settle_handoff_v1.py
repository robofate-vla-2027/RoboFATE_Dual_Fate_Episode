import json,sys,base64,datetime,copy
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import execution_owner_binding_v1 as execution;execution.install();import shared_teacher_ledger_cli_v12 as cli
cli.r.document({"path":"/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/ACCOUNTING_DOLLS1050_RELEASE_001.json","sha256":"b682410443739cdfc74388032fa8c62180a3073c95acdcc29e023410d37cc1a9"})
def current_stats(d,task,inflight=None):
 events={};infra={};refusals={};qualified=[]
 for row in d['source_index'].values():
  if row.get('task')!=task or row.get('host')!='perdon-hou':continue
  for a in row.get('teacher_attempt_history',[]):
   run=a.get('run_id','');native=a.get('native_result') or {}
   if '_evo_common_teacher_' not in run:continue
   observed=a.get('actual_teacher_actions',0);started=(native.get('mode')=='EmbodiedEvo_teacher_suffix' and native.get('teacher_actions',0)>0) or (type(observed) is int and observed>0)
   refused=bool(a.get('provider_safety_refusal'))
   if refused:refusals[run]=a
   if started:events[run]=a
   elif a.get('teacher_effective_failure') is False and not refused:infra[run]=a
  for a in row.get('teacher_preparation_failures',[]):
   if '_evo_common_teacher_' in a.get('run_id','') and not a.get('native_started'):infra[a['run_id']]=a
  if row.get('counted_in_quota') is True and row.get('positive_publication') and row.get('teacher')=='EmbodiedEvo public-recipe primitive baseline' and row.get('core_episode_id'):
   run=row['core_episode_id'];events.setdefault(run,dict(run_id=run,source_id=row['source_id'],at=row.get('qualified_at',''),native_result={'native_success':True},positive_delta=1));qualified.append({'run_id':run,'source_id':row['source_id'],'publication':row['positive_publication']})
 ns=sum((a.get('native_result') or {}).get('native_success') is True for a in events.values());nf=sum((a.get('native_result') or {}).get('native_success') is False and bool((a.get('native_result') or {}).get('terminated') or (a.get('native_result') or {}).get('truncated')) for a in events.values());consecutive=0
 for a in sorted(events.values(),key=lambda a:a.get('at',''),reverse=True):
  native=a.get('native_result') or {}
  if native.get('native_success'):break
  if native.get('terminated') or native.get('truncated'):consecutive+=1
 pre_refusals=sum(run not in events for run in refusals)
 return dict(attempts_closed=len(events),attempts_started=len(events)+int(inflight is not None),attempts_in_flight=int(inflight is not None),independent_sources=len({a['source_id'] for a in events.values()}|({inflight} if inflight else set())),native_failures=nf,native_successes=ns,unknown_or_cancelled=len(events)-ns-nf,sr_denominator=ns+nf,sr_numerator=ns,takeover_sr_pct=100*ns/(ns+nf) if ns+nf else None,infrastructure_errors=len(infra),pre_takeover_failures=len(infra)+pre_refusals,provider_safety_refusals=len(refusals),pre_takeover_provider_refusals=pre_refusals,consecutive_valid_failures=consecutive,accepted_unique_sources=len(qualified),core_positive_count=len(qualified),reviewed_run_ids=sorted(events),infra_failure_run_ids=sorted(infra),provider_refusal_run_ids=sorted(refusals),success_publication_verified=bool(qualified),actual_qualified_publications=qualified)

def apply_resource_observation(node,task,evidence):
 safe=evidence['safe_for_next_simulator']
 node['current_runtime_adoption'].update(resource_closed=safe,terminal_observation=evidence['evidence_ref'])
 if not safe:
  native=[x for x in evidence.get('own_process_checks',[]) if x.get('role')=='native']
  node.update(active_run_id=evidence['run_id'],active_real_simulators=0 if native and all(x['original_process_absent'] for x in native) else node['active_real_simulators'],launch_inflight=False,phase='data_settled_resource_cleanup_pending')
  task.update(active_run_id=evidence['run_id'],phase='data_settled_resource_cleanup_pending')
 node['owned_resource_launch_hold']=not safe

x=json.load(sys.stdin);d=json.loads(base64.b64decode(x['ledger_b64']));e=json.loads(base64.b64decode(x['evidence_b64']));assert type(e.get('safe_for_next_simulator')) is bool;result=cli.compute(d,e['context'])
if result['receipt'].get('idempotent_reuse'):print(json.dumps(result));raise SystemExit(0)
out=result['ledger'];receipt=result['receipt'];n=out['nodes']['perdon-hou'];t=out['tasks'][e['task']];s=out['source_index'][e['source_id']];at=out['updated_at'];n['last_owned_resource_settlement']=e['evidence_ref'];n['current_runtime_adoption'].update(terminal_observation=e['evidence_ref'],resource_closed=e['safe_for_next_simulator']);s.setdefault('history',[]).append(dict(at=at,event='teacher_terminal_resource_observed',run_id=e['run_id'],evidence=e['evidence_ref'],actual_tool_returncode=e['actual_foreground_tool_returncode'],safe_for_next_simulator=e['safe_for_next_simulator'],positive_delta=0,negative_delta=0));s['active_teacher_attempt'].update(status='settled' if e['safe_for_next_simulator'] else 'data_settled_resource_cleanup_pending',terminal_observation=e['evidence_ref']);s.setdefault('active_teacher_milestone',{}).update(stage='terminal_settled',native_success=(e['summary'].get('native_result') or {}).get('native_success'),qualified_sample=e['summary']['qualified_positive'])
if x.get('interruption_ref'):
 ir=x['interruption_ref'];ip=Path(ir['path']);assert ip.parent==Path(e['context']['path']).parent and ip.name=='MAIN_INTERRUPTION_OBSERVATION_001.json'
 import hashlib
 assert hashlib.sha256(ip.read_bytes()).hexdigest()==ir['sha256'];o=json.loads(ip.read_bytes());assert o['context']==e['context'] and o['run_id']==e['run_id'] and o['source_id']==e['source_id']
 assert o['interruption_category']=='provider_safety_refusal' and o['provider_retry_allowed'] is False and o['source_replay_prohibited'] is True and s['provider_safety_refusal']==o['provider_safety_ref']
 rows=[a for a in s['teacher_attempt_history'] if a['run_id']==e['run_id']];assert len(rows)==1 and rows[0]['native_result'] is None and rows[0]['teacher_effective_failure'] is False
 rows[0].update(actual_teacher_actions=o['actual_teacher_actions'],actual_native_steps=o['actual_native_steps'],provider_safety_refusal=o['provider_safety_ref'],interruption_observation=ir,interruption_category=o['interruption_category'],native_terminal_observed=False)
 s.update(teacher_replay_prohibited=True,provider_retry_allowed=False);s.setdefault('history',[]).append(dict(at=at,event='actual_post_takeover_provider_refusal_classified',run_id=e['run_id'],evidence=ir,positive_delta=0,negative_delta=0))
 n['current_runtime_adoption'].update(actual_teacher_verified=o['teacher_started']);n['shared_teacher_integration_latest'].update(actual_teacher_verified=o['teacher_started'],latest_native_steps=o['actual_native_steps'],latest_teacher_steps=o['actual_teacher_actions'],interruption_category=o['interruption_category'],provider_safety_refusal=o['provider_safety_ref'],provider_retry_allowed=False)
 s['active_teacher_milestone'].update(stage='provider_safety_refusal_settled',last_observed_native_success=False,interruption_observation=ir)
 receipt.update(interruption_category=o['interruption_category'],provider_safety_refusal=o['provider_safety_ref'],actual_teacher_actions=o['actual_teacher_actions'],actual_native_steps=o['actual_native_steps'],provider_retry_allowed=False)
updated=current_stats(out,e['task']);st=t['teacher_statistics']['EmbodiedEvo'];t.setdefault('teacher_statistics_history',[]).append(dict(at=at,reason='Current fixed primitive terminal results; original values preserved',changed_fields_before={k:copy.deepcopy(st.get(k)) for k in updated}));st.update(updated);st.update(last_settlement=e['summary_ref'],last_attempt_timing=dict(foreground_to_saved_summary_seconds=e['foreground_to_saved_summary_seconds']),native_episode_status=e['summary']['data_status'],test_status='actual_success_publication_and_failure_paths_verified' if updated['success_publication_verified'] else 'actual_teacher_executed_success_publication_unverified')
apply_resource_observation(n,t,e)
receipt.update(terminal_observation=e['evidence_ref'],foreground_to_saved_summary_seconds=e['foreground_to_saved_summary_seconds'],safe_for_next_simulator=e['safe_for_next_simulator'],actual_tool_returncode=e['actual_foreground_tool_returncode'],task_native_failures=st['native_failures'],task_native_successes=st['native_successes'],task_unknown_outcomes=st['unknown_or_cancelled']);adoption=dict(release={"path":"/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/ACCOUNTING_DOLLS1050_RELEASE_001.json","sha256":"b682410443739cdfc74388032fa8c62180a3073c95acdcc29e023410d37cc1a9"},at=at,run_id=e['run_id'],source_id=e['source_id'],actual_settlement_used=True,changed_scope='metadata accounting only; runtime/reader unchanged')
n['current_accounting_adoption']=adoption
s.setdefault('history',[]).append(dict(at=at,event='pinned_accounting_name_compatibility_adopted',adoption=adoption,positive_delta=0,negative_delta=0))
receipt['accounting_release']=adoption['release']
print(json.dumps(result))