"""Synthetic original-prefix and closed-boundary tests; no real execution."""
from copy import deepcopy
import unittest

import general_prefix_handoff_v1 as prefix
from prepare_general_l7_handoff_v1 import metadata_only
from switch_bottles_to_prepared_general_v1 import switch_due
from test_dolls_bottles_revisit_v1 import DueBottlesTests


def rename(value):
    if isinstance(value, str):
        return value.replace("put_bottles_into_dustbin", "general_pickup").replace(
            "sort_nesting_dolls_by_size", "put_bottles_into_dustbin")
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class GeneralSwitchTests(unittest.TestCase):
    def setUp(self):
        f = DueBottlesTests()
        f.setUp()
        self.f = f
        self.d, self.e, self.prep = rename(f.d), rename(f.e), rename(f.prep)
        self.prep["native_step_limit"] = 200
        self.prep["source"].update(layout_id=7, source_sequence=prefix.PREFIX + [7],
                                   required_accounted_prefix=prefix.PREFIX, split="student_dev")
        self.old = "put_bottles_into_dustbin"

    def switch(self, at=None):
        return switch_due(self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
                          at or self.f.at, "Synthetic scheduling fixture, zero scientific credit")

    def test_preserves_history_nanoseconds_and_counts(self):
        before = deepcopy(self.d)
        out = self.switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], prefix.TASK)
        for k in ("source_index", "reservations"):
            self.assertEqual(self.d[k], before[k])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)

    def test_teacher_positive_does_not_reset_negative_window(self):
        self.d["tasks"][self.old]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        self.e["summary"]["qualified_positive"] = True
        out = self.switch()
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_window_and_live_source_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["nodes"]["perdon-hou"]["active_real_simulators"] = 1
        with self.assertRaises(AssertionError):
            self.switch()

    def test_wrong_order_budget_and_duplicate_rejected(self):
        for name, value in (("layout_id", 53), ("source_sequence", list(range(8))),
                            ("required_accounted_prefix", list(range(7)))):
            self.setUp()
            self.prep["source"][name] = value
            with self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 700
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_no_previous_segment_timestamp_required(self):
        del self.d["tasks"][prefix.TASK]["latest_segment_started_at"]
        self.switch()
        self.assertEqual(self.d["tasks"][prefix.TASK]["latest_segment_started_at"], self.f.at)


class GeneralPrefixTests(unittest.TestCase):
    def setUp(self):
        self.task = {"source_sequence": prefix.PREFIX,
                     "source_sequence_disposition": {"completed_initial_accounted_prefix": prefix.PREFIX},
                     "historical_l0_disposition": {"synthetic": True}}
        self.source = {"task": prefix.TASK, "source_id": prefix.NEXT_SOURCE, "layout_id": 7,
                       "required_accounted_prefix": prefix.PREFIX,
                       "source_sequence": prefix.PREFIX + [7]}
        self.rows = {f"{prefix.TASK}_b0_l{i}_synthetic": {
            "source_id": f"{prefix.TASK}_b0_l{i}_synthetic", "task": prefix.TASK,
            "host": "perdon-hou", "counted_in_quota": False, "counted_in_negative_quota": False,
            "synthetic_ns": 2**63 + i} for i in (3, 4, 5, 6)}
        self.ledger = {"tasks": {prefix.TASK: self.task}, "source_index": self.rows}
        self.review = {
            "schema": "refate.general.original_prefix.accounted.v1",
            "next_source_id": prefix.NEXT_SOURCE, "preparation_ref": {"synthetic": "preparation"},
            "sequence_ref": prefix.SEQUENCE, "old_source_qualification_changed": False,
            "old_sources_replayed": False, "live_referenced_processes": [],
            "prefix_state_sha256": prefix.metadata_hash(prefix.prefix_state(self.task)), "entries": [],
        }
        for i in prefix.PREFIX:
            sid = f"{prefix.TASK}_b0_l{i}_synthetic"
            row = self.rows.get(sid)
            self.review["entries"].append({
                "layout": i, "source_id": sid if row else None, "source_consumed": True,
                "source_metadata_sha256": prefix.metadata_hash(row) if row else None,
                "new_positive": 0, "new_negative": 0,
            })
        self.boundary = {"legacy_prefix_review": self.review,
                         "next_preparation": {"ref": self.review["preparation_ref"]}}

    def accepted(self, ordinal):
        return prefix.original_general_prefix_accounted(self.ledger, self.boundary, self.source, ordinal)

    def test_original_prefix_accepted_without_fabricating_missing_rows(self):
        for i in prefix.PREFIX:
            self.assertTrue(self.accepted(i))
        self.assertEqual(len(self.rows), 4)

    def test_changed_settled_row_and_nanoseconds_rejected(self):
        sid = f"{prefix.TASK}_b0_l3_synthetic"
        self.rows[sid]["synthetic_ns"] += 1
        self.assertFalse(self.accepted(3))

    def test_missing_accounting_or_changed_source_rejected(self):
        self.task["source_sequence"] = list(range(7))
        self.assertFalse(self.accepted(1))
        self.setUp()
        self.source["layout_id"] = 8
        self.assertFalse(self.accepted(1))

    def test_replay_live_process_and_credit_rejected(self):
        self.review["old_sources_replayed"] = True
        self.assertFalse(self.accepted(0))
        self.setUp()
        self.review["live_referenced_processes"] = [{"pid": 999, "synthetic": True}]
        self.assertFalse(self.accepted(0))
        self.setUp()
        self.review["entries"][0]["new_positive"] = 1
        self.assertFalse(self.accepted(1))


if __name__ == "__main__":
    import sys
    sys.addaudithook(metadata_only)
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (GeneralSwitchTests, GeneralPrefixTests))
    result = unittest.TextTestRunner().run(suite)
    raise SystemExit(not result.wasSuccessful())
