"""Existing closed-teacher revisit rules for the prepared General L23."""
import hashlib
from pathlib import Path

PARENT_SHA = "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"
CHANGES = (
    ("put_bottles_into_dustbin", "general_pickup"),
    ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 200'),
    ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
     's["layout_id"] == 23 and s["source_sequence"] == [1, 2, 3, 4, 0] + list(range(5, 24))'),
    ('s["required_accounted_prefix"] == list(range(12))',
     's["required_accounted_prefix"] == [1, 2, 3, 4, 0] + list(range(5, 23))'),
    ('assert target["qualified_count"] < 10 or target["negative_count"] < 10',
     'assert target["qualified_count"] == 10 and target["negative_count"] < 10'),
)


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PARENT_SHA:
        raise ValueError("Frozen teacher-boundary scheduling helper changed")
    text = raw.decode()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Frozen scheduling parameter seam changed: " + old)
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::general_l23", "exec"), globals())
