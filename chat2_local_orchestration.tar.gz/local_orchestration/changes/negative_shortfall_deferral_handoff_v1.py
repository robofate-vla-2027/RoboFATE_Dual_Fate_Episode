"""Original five-source evidence review with current execution ownership."""
from pathlib import Path
import hashlib
import negative_shortfall_deferral_v1 as previous

raw = Path(previous.__file__).read_bytes()
assert hashlib.sha256(raw).hexdigest() == "01f89d4aad4dfe2d8d6edd9ae334243a65d5f37d68850e1480ad393eb910aefc"
text = raw.decode()
before = "n['active_chat_id'] == '01a16807-8085-7903-be07-66eb332ebf95'"
after = "n['active_chat_id'] == '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'"
assert text.count(before) == 1
exec(compile(text.replace(before, after, 1), str(Path(__file__)) + "::current_owner", "exec"), globals())
