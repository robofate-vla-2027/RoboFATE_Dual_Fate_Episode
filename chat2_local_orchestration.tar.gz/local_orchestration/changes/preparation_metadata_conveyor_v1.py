"""Lossless Conveyor700 legacy failure view; no restore or qualification changes."""
import hashlib
from pathlib import Path
import preparation_metadata_compat_v3 as previous

parent = Path(previous.__file__)
if hashlib.sha256(parent.read_bytes()).hexdigest() != "267e23636c1f3e6dc69d1bd8fcdbc2d3e10e4b440519c98b905ed4abae61906b":
    raise ValueError("Frozen legacy metadata parent changed")

text = previous._TEXT
for before, after in (
    ("task in ('organize_table', 'play_stacking_toy') and document.get('schema')",
     "task in ('organize_table', 'play_stacking_toy', 'pick_from_conveyor_by_image') and document.get('schema')"),
    ("{'organize_table':1000,'play_stacking_toy':1200}[task]",
     "{'organize_table':1000,'play_stacking_toy':1200,'pick_from_conveyor_by_image':700}[task]"),
):
    if text.count(before) != 1:
        raise ValueError("Legacy source scope seam changed")
    text = text.replace(before, after, 1)
exec(compile(text, str(parent) + "::conveyor700_legacy_view", "exec"), globals())
