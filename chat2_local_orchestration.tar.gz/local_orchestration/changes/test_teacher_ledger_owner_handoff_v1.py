"""Synthetic CPU transactions only; no model, network, launch or ledger writes."""
import copy
import sys
import unittest


def no_effect(event, args):
    if event in ("socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                 "os.kill", "os.killpg"):
        raise RuntimeError("SYNTHETIC_HANDOFF_ACCOUNTING_ONLY " + event)


sys.addaudithook(no_effect)
import teacher_ledger_owner_handoff_v1 as core
import test_teacher_bottles_accounting as original
import shared_teacher_ledger_cli_v12 as cli
core.bind_cli(cli)

OLD = "01a16807-8085-7903-be07-66eb332ebf95"
NEW = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
NOW = "2026-10-31T06:00:00+00:00"


def fixture():
    ledger, request = original.fixture()
    sid = request["source_id"]
    request.update(owner=NEW, execution_owner=NEW, source_owner=OLD)
    ledger["nodes"]["perdon-hou"]["active_chat_id"] = NEW
    ledger["tasks"][request["task"]]["active_chat_id"] = NEW
    ledger["source_index"][sid].update(owner_chat=NEW, source_owner=OLD, execution_owner=NEW)
    ledger["reservations"][sid].update(active_attempt_owner=NEW, execution_owner=NEW,
                                       source_owner=OLD)
    return ledger, request


def apply(ledger, request):
    return core.apply_commit(ledger, request, now=NOW, lock_inode=27555308, synthetic=True)


class HandoffAccountingTests(unittest.TestCase):
    def test_new_executor_preserves_lineage_peers_precision_and_idempotence(self):
        ledger, request = fixture()
        ledger["source_index"]["peer"]["timestamp_ns"] = 1793427195043098319
        before = copy.deepcopy(ledger)
        out, receipt = apply(ledger, request)
        self.assertEqual(ledger, before)
        self.assertEqual(receipt["positive_delta"], 1)
        self.assertEqual(out["source_index"]["peer"], before["source_index"]["peer"])
        self.assertEqual(out["nodes"]["h20_10"], before["nodes"]["h20_10"])
        source = out["source_index"][request["source_id"]]
        self.assertEqual((source["owner_chat"], source["source_owner"], source["execution_owner"]),
                         (NEW, OLD, NEW))
        twice, receipt = apply(out, request)
        self.assertEqual(twice, out)
        self.assertTrue(receipt["idempotent_reuse"])

    def test_historical_source_owner_chat_remains_unchanged(self):
        ledger, request = fixture()
        ledger["source_index"][request["source_id"]]["owner_chat"] = OLD
        out, _ = apply(ledger, request)
        self.assertEqual(out["source_index"][request["source_id"]]["owner_chat"], OLD)

    def test_wrong_current_or_source_owner_rejected(self):
        for key in ("owner", "source_owner"):
            ledger, request = fixture()
            request[key] = "SYNTHETIC_WRONG_OWNER"
            with self.subTest(key=key), self.assertRaises(ValueError):
                apply(ledger, request)
        ledger, request = fixture()
        ledger["nodes"]["perdon-hou"]["active_chat_id"] = OLD
        with self.assertRaises(ValueError):
            apply(ledger, request)

    def test_conditions_budget_and_native_failure_still_rejected(self):
        for key, value in (
            ("remaining_steps", 700), ("native_teacher_success", False),
            ("conditions", {"1.1": True, "1.2": False, "1.3": True}),
        ):
            ledger, request = fixture()
            request[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                apply(ledger, request)

    def test_refusal_and_independent_success_still_rejected(self):
        for field, value in (("provider_safety_refusal", {"synthetic": True}),
                             ("negative_count", 1)):
            ledger, request = fixture()
            ledger["source_index"][request["source_id"]][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                apply(ledger, request)

    def test_actual_cli_uses_handoff_core_and_reuses_small_verdict(self):
        namespace = dict(original.__dict__, fixture=fixture, core=core, cli=cli)
        code = original._code.replace("shared_teacher_ledger_v9",
                                      "teacher_ledger_owner_handoff_v1")
        exec(compile(code, __file__ + "::original_actual_cli_fixture", "exec"), namespace)
        namespace["test_actual_entry_uses_new_core_no_full_report_read"](self)


if __name__ == "__main__":
    unittest.main()
