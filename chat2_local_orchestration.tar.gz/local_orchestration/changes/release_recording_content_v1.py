"""Freeze additive release manifests after the targeted offline tests."""
import datetime
import hashlib
import json
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import collection_recording_content_v1 as wiring
import collect_recording_content_v1 as baseline
import collect_teacher_content_v1 as teacher
import prepare_teacher_content_v1 as prepare_teacher
import bind_recording_content_v1 as binder

HERE = Path(__file__).resolve().parent


def ref(path):
    path = Path(path)
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return ref(path)


def release():
    log = HERE / "CONTENT_DIAGNOSTIC_CPU_20261031_01a19072_002.log"
    text = log.read_text()
    assert "Ran 10 tests" in text and text.rstrip().endswith("OK")
    assert baseline.core.finish.reader_binding.__name__ == "reader_content_binding_v1"
    assert teacher.native.recording is baseline.core.foreground.baseline.recording
    assert teacher.dependency.__name__ == "shared_dependency_content_v1"
    assert prepare_teacher.common_recording is teacher.native.recording
    assert prepare_teacher.shared_dependency_binding.__name__ == "shared_dependency_content_v1"
    assert binder.collection is baseline
    assert not binder.historical_preparer_allowed({"execution_owner": "FOREIGN", "source_owner": execution.NEW})
    additions = [ref(HERE / name) for name in (
        "execution_owner_binding_v1.py", "EXECUTION_HANDOFF_20261031_01a19072.json",
        "common_recording_content_v2.py", "reader_content_binding_v1.py",
        "shared_dependency_content_v1.py", "collection_recording_content_v1.py",
        "baseline_recording_content_v1.py", "finish_common_content_v1.py",
        "collect_recording_content_v1.py", "native_teacher_content_v1.py",
        "collect_teacher_content_v1.py", "prepare_teacher_content_v1.py",
        "bind_recording_content_v1.py", "owner_reservation_handoff_v1.py")]
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cpu = write(HERE / "CONTENT_DIAGNOSTIC_CPU_20261031_01a19072_002.json", {
        "schema": "refate.recording_content.synthetic_cpu.v1", "data_kind": "synthetic_not_scientific_data",
        "at": at, "tests": 10, "passed": 10, "exit_code": 0, "log": ref(log),
        "test": ref(HERE / "test_recording_content_v2.py"),
        "previous_failed_log": ref(HERE / "CONTENT_DIAGNOSTIC_CPU_20261031_01a19072_001.log"),
        "previous_failure": "Three numpy.testing import attempts rejected by unchanged subprocess guard.",
        "no_model_api_simulator_gpu_calls": True,
        "real_constant_frame_validation": False, "additional_entry_and_preparation_imports_checked": True})
    results = {}
    for kind, old, new in (
        ("baseline", "RUNTIME_TRANSPORT_RNG_RELEASE_001.json", "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"),
        ("teacher", "TEACHER_DOLLS1050_RELEASE_001.json", "TEACHER_CONTENT_RELEASE_20261031_01a19072.json"),
    ):
        previous = ref(HERE / old)
        data = runtime.document(runtime.read_pin(previous))
        for item in data["runtime_files"]:
            runtime.read_pin(item)
        data["runtime_files"] = list({item["path"]: item for item in data["runtime_files"] + additions}.values())
        data.update(created_at=at, execution_owner=execution.NEW, inherits=previous,
                    content_policy=ref(HERE / "common_recording_content_v2.py"),
                    ownership_handoff=execution.install(), cpu_summary=cpu,
                    actual_adoption=False, real_constant_frame_validation=False,
                    old_runtime_files_modified=False,
                    content_revision_scope="Variance diagnostic only; original capture, data integrity, controls, budgets and native scoring retained.")
        if kind == "baseline":
            data.update(owner_chat=execution.NEW,
                foreground_entry=str(HERE / "collect_recording_content_v1.py"),
                native_entry=str(HERE / "baseline_recording_content_v1.py"),
                context_builder=ref(HERE / "bind_recording_content_v1.py"),
                reader=ref(HERE / "reader_content_binding_v1.py"),
                postwait=ref(HERE / "finish_common_content_v1.py"),
                effective_source_sha256={name: hashlib.sha256(wiring.source(name).encode()).hexdigest()
                                         for name in ("baseline_native", "foreground_common")},
                runtime_adopted=False)
            assert data["native_wall_seconds"] == 2400 and data["teacher_wall_seconds"] == 3600
        else:
            data.update(foreground_entry=str(HERE / "collect_teacher_content_v1.py"),
                native_entry=str(HERE / "native_teacher_content_v1.py"),
                preparation_entry=str(HERE / "prepare_teacher_content_v1.py"),
                actual_teacher_takeover_verified=False, actual_positive_published=False)
            assert data["actor_wall_seconds"] == 3600
        results[kind] = write(HERE / new, data)
    return {"releases": results, "cpu": cpu, "actual_native_started": False}


if __name__ == "__main__":
    print(json.dumps(release()))
