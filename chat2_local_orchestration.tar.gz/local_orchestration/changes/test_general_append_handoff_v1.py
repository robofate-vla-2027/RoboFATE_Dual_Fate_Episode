"""Offline synthetic metadata; no model, simulator, network, or real ledger."""
from copy import deepcopy
import unittest

import prepare_general_append_handoff_v1 as append
import test_general_l7_metadata_v1 as old


def fixture():
    original, prior = old.fixture()
    for i in (8, 9):
        group = f"synthetic-family-{i}"
        original["families"][group] = {
            "group_id": group, "split": "student_dev",
            "layouts": [{"bank": 0, "layout_id": i, "path": f"/synthetic/{i}.json",
                         "sha256": f"{i:064x}"}],
        }
        original["layout_to_group"][str(i)] = group
    prior["families"] = deepcopy(original["families"])
    prior["layout_to_group"] = deepcopy(original["layout_to_group"])
    return original, prior


class GeneralAppendTests(unittest.TestCase):
    def test_only_next_original_source_appended_without_mutating_inputs(self):
        original, prior = fixture()
        before = deepcopy((original, prior))
        extended = append.extend(original, prior, 8)
        self.assertEqual(extended["initial_source_sequence"], [1, 2, 3, 4, 0, 5, 6, 7, 8])
        self.assertEqual((original, prior), before)
        self.assertEqual(extended["families"], original["families"])

    def test_skipped_predecessor_rejected(self):
        with self.assertRaises(ValueError):
            append.extend(*fixture(), 9)

    def test_old_source_reorder_rejected(self):
        original, prior = fixture()
        prior["initial_source_sequence"] = list(range(8))
        with self.assertRaises(ValueError):
            append.extend(original, prior, 8)

    def test_family_reassignment_rejected(self):
        original, prior = fixture()
        prior["families"]["synthetic-family-7"]["split"] = "student_dev"
        with self.assertRaises(ValueError):
            append.extend(original, prior, 8)

    def test_old_source_identity_change_rejected(self):
        original, prior = fixture()
        prior["layouts"]["7"]["layout_ref"]["sha256"] = "f" * 64
        with self.assertRaises(ValueError):
            append.extend(original, prior, 8)

    def test_sealed_boundary_and_invalid_ordinals_rejected(self):
        for i in (True, 7, 53, 54, 55, -1):
            with self.subTest(layout=i), self.assertRaises(ValueError):
                append.extend(*fixture(), i)

    def test_sealed_family_rejected(self):
        original, prior = fixture()
        original["families"]["synthetic-family-7"]["split"] = "sealed_eval"
        prior["families"]["synthetic-family-7"]["split"] = "sealed_eval"
        with self.assertRaises(ValueError):
            append.extend(original, prior, 8)

    def test_duplicate_prior_initialization_rejected(self):
        original, prior = fixture()
        prior["layouts"]["7"]["initialization_distinct_from_preceding"] = False
        with self.assertRaises(ValueError):
            append.extend(original, prior, 8)


if __name__ == "__main__":
    unittest.main()
