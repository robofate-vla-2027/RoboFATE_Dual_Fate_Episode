import sys,json,hashlib,datetime,fcntl,os
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026')
import collect_recording_content_v1 as collection
import task_configured_binding as binding
import common_runtime as runtime
import preparation_metadata_compat_v4 as legacy
x=json.load(sys.stdin);fg=collection.core.foreground;fg.host();root=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher');prior=root/'runs'/x['prior_source_run'];run=root/'runs'/x['run_id'];assert not run.exists()
def ref(p):p=Path(p);return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def doc(v):return runtime.document(runtime.read_pin(v))
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
 return ref(p)
prepared=doc(x['preparation_ref']);binding.load_native_layout(prepared);assert prepared['source']['task']==x['task'] and prepared['native_step_limit']==x['native_budget'] and prepared['mode']=='independent_baseline'
settlement_ref=ref(prior/x.get('predecessor_settlement_name','MAIN_SETTLEMENT_001.json'));old=doc(settlement_ref)
if 'native_success' not in old:old=legacy.failed_baseline_view(old,doc(old['summary_ref']),doc(old['cleanup_ref']),old['source_id'],x['prior_task'])
interrupted=(old.get('schema')=='refate.actual_interrupted_baseline.v1' and old.get('full_readback_passed') is False and old.get('native_terminal') is False and old.get('new_positive')==old.get('new_negative')==0)
assert old['task']==x['prior_task'] and old['safe_for_next_simulator'] and (old.get('first_readback_passed') is True or interrupted);sid=old['source_id'];checks=list(old['process_closure']['checks']);teacher=None
if x.get('prior_teacher_run'):
 teacher_ref=ref(root/'runs'/x['prior_teacher_run']/'MAIN_TERMINAL_OBSERVATION_001.json');teacher=doc(teacher_ref);assert teacher['source_id']==sid and teacher['safe_for_next_simulator'];checks+=teacher['own_process_checks'];resource_predecessor={'source_id':sid,'run_id':teacher['run_id'],'summary_ref':teacher['summary_ref'],'safe_for_next_simulator':True,'ref':teacher_ref}
else:resource_predecessor={'source_id':sid,'run_id':old['run_id'],'summary_ref':old.get('summary_ref'),'safe_for_next_simulator':True,'ref':settlement_ref}
previous=doc(x['prior_preparation_ref']);binding.load_native_layout(previous);ps=previous['source'];ns=prepared['source']
assert ps['source_id']==sid and ps['task']==ns['task']==x['task'] and ps['source_sequence']==ns['source_sequence']
assert ns['required_accounted_prefix']==ps['required_accounted_prefix']+[ps['layout_id']]
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for row in checks:
 ident=row['identity'];p=Path('/proc')/str(ident['pid'])/'stat';assert not(p.exists() and boot==ident['boot_id'] and int(p.read_text().rsplit(')',1)[1].split()[19])==ident['start_ticks'])
allocation=fg.allocation();memory=fg.helpers().memory_headroom(120)
with fg.LOCK.open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
run.mkdir();at=datetime.datetime.now(datetime.timezone.utc).isoformat();peers=[]
for line in allocation['existing_processes'].splitlines():
 pid=int(line.split(',')[0]);p=Path('/proc')/str(pid);peers.append({'identity':fg.identity(pid),'uid':p.stat().st_uid,'executable':os.readlink(p/'exe')})
disks={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/',str(run)]};assert disks['/']>256*1024**2 and disks[str(run)]>30*1024**3
resource={'schema':'refate.actual_resource_precheck.v1','data_kind':'actual','at':at,'host':'perdon-hou','hostname':'nb-5pl2apckdj-0','ssh_endpoint':'root@116.198.70.4:1122','run_id':x['run_id'],'source_id':prepared['source']['source_id'],'allocation':allocation,'memory_precheck':memory,'existing_processes':peers,'disk_free_bytes':disks,'exclusive_native_lock_available':True,'estimated_native_gpu1_mib':18000,'policy_gpu0_reserve_mib':15000,'safety_headroom_mib':12000,'temporary_logs_cache_root':str(run/'runtime'),'actual_launch':False,'existing_peers_untouched':True};resource_ref=write(run/'RESOURCE_PRECHECK_001.json',resource)
release=ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026')/'RUNTIME_CONTENT_RELEASE_20261031_01a19072.json');assert release['sha256']=='b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131';metadata=ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026')/'owner_reservation_handoff_v1.py');assert metadata in doc(release)['runtime_files']
b={'schema':'refate.actual_boundary_preparation.v1','at':at,'next_preparation':{'prepared':prepared,'ref':x['preparation_ref']},'resource_precheck':{'summary':resource,'ref':resource_ref},'settlement':{'source_id':sid,'settlement_ref':settlement_ref,'safe_for_next_simulator':True},'last_teacher_settlement':teacher['summary_ref'] if teacher else None,'resource_predecessor':resource_predecessor,'runtime_release':release,'metadata_adapter':metadata,'native_kit_extensions':[],'teacher_supplement_present':True}
b['inherited_prefix']={'source_id':sid,'preparation_ref':x['prior_preparation_ref'],'prepared_source':ps}
bref=write(run/'MAIN_BOUNDARY_001.json',b)
print(json.dumps({'boundary_ref':bref,'source_id':prepared['source']['source_id'],'preparation_ref':x['preparation_ref'],'resource':resource}))
