"""Task binding only: the existing closed-teacher retained-source revisit."""
import hashlib
from pathlib import Path

import switch_general_to_retained_classify_v1 as parent


def bind_general(text):
    text = parent.replace_exact(text, "general_pickup", "fasten_screws", 6)
    text = parent.replace_exact(text, "classify_objects", "general_pickup", 6)
    return parent.replace_exact(
        text, '== s["native_budget"] == 1100', '== s["native_budget"] == 200')


def source():
    expected = "c548e0f262f4de991c20367c3dd8b9296f0f164815b73086d54d50232883aebc"
    if hashlib.sha256(Path(parent.__file__).read_bytes()).hexdigest() != expected:
        raise ValueError("Frozen retained-source scheduling dependency changed")
    return bind_general(parent.source())


exec(compile(source(), str(Path(__file__)) + "::fasten_general_revisit", "exec"),
     globals())
