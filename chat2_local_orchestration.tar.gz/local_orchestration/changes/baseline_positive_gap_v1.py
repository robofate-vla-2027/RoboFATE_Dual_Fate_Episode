"""Pure bookkeeping compatibility for a positive deficit after negative quota."""
from copy import deepcopy
import hashlib

MODE = "positive_failure_source_after_negative_quota"


def need(value, message):
    if not value:
        raise ValueError(message)


def change(text, old, new, count=1):
    need(text.count(old) == count, "Pinned metadata seam changed: " + old[:72])
    return text.replace(old, new)


def pinned_text(path, digest):
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == digest, "Pinned metadata file changed")
    return raw.decode()


def positive_gap(node, task):
    for scope in (node, task):
        for key in ("negative_count", "negative_quota", "negative_reserved_count",
                    "qualified_count", "positive_quota", "reserved_count"):
            need(type(scope.get(key)) is int and scope[key] >= 0,
                 "Exact nonnegative quota counters required")
        need(scope["qualified_count"] + scope["reserved_count"] < scope["positive_quota"],
             "No remaining positive capacity")
        need(scope["negative_count"] <= scope["negative_quota"]
             and scope["negative_reserved_count"] == 0, "Negative capacity conflict")
    need(task["negative_count"] == task["negative_quota"], "Task negative quota not full")
    return True


def reservation_slots(node, task):
    if (task["negative_count"] + task["negative_reserved_count"] < task["negative_quota"]
            and node["negative_count"] + node["negative_reserved_count"] < node["negative_quota"]):
        return 1
    positive_gap(node, task)
    return 0


def mark_positive_dispatch(dispatch, task):
    dispatch.update(collection_goal=MODE, quota_at_issue={
        "negative_count": task["negative_count"], "negative_quota": task["negative_quota"],
        "positive_count": task["qualified_count"], "positive_quota": task["positive_quota"],
    })


def dispatch_slots_valid(dispatch):
    slots = dispatch.get("negative_slots")
    if type(slots) is not int:
        return False
    if slots == 1:
        return dispatch.get("collection_goal") != MODE
    proof = dispatch.get("quota_at_issue", {})
    return (slots == 0 and dispatch.get("collection_goal") == MODE
            and isinstance(proof, dict)
            and set(proof) == {"negative_count", "negative_quota", "positive_count", "positive_quota"}
            and all(type(v) is int and v >= 0 for v in proof.values())
            and proof["negative_count"] == proof["negative_quota"]
            and proof["positive_count"] < proof["positive_quota"])


def original_slots(reservation):
    dispatch = reservation.get("dispatch")
    if dispatch is None:
        return 1
    need(dispatch_slots_valid(dispatch), "Invalid original baseline capacity")
    return dispatch["negative_slots"]


def local_reservation_valid(ledger, reservation, source, node, task):
    slots = original_slots(reservation)
    need(reservation["negative_slots"] == slots, "Reservation capacity changed")
    if slots == 0:
        positive_gap(node, task)
        need(source.get("collection_goal") == MODE
             and reservation.get("negative_quota_reserved") is False,
             "Missing zero-slot source authorization")
    return True


def reservation_source(text):
    old = """need(t['negative_count'] + t['negative_reserved_count'] < t['negative_quota']
         and n['negative_count'] + n['negative_reserved_count'] < n['negative_quota'],
         'No independent-negative quota')"""
    text = change(text, old, "slots = reservation_slots(n, t)")
    text = change(text, "negative_slots=1, positive_slots=0", "negative_slots=slots, positive_slots=0", 2)
    text = change(text, "    row = dict(source_id=sid", "    if slots == 0:\n        mark_positive_dispatch(dispatch, t)\n    row = dict(source_id=sid")
    for scope in ("n", "t"):
        text = change(text, f"{scope}['negative_reserved_count'] += 1",
                      f"{scope}['negative_reserved_count'] += slots")
    text = change(text, "    previous_adoption = deepcopy(n['current_runtime_adoption'])",
                  "    if slots == 0:\n"
                  "        row['collection_goal'] = MODE\n"
                  "        d['reservations'][sid].update(quota_reserved=False, negative_quota_reserved=False)\n"
                  "    previous_adoption = deepcopy(n['current_runtime_adoption'])")
    return text


def settlement_source(text):
    text = change(text, "    negative = int(q['native_success'])",
                  "    native_negative = int(q['native_success'])\n"
                  "    slots = original_slots(ledger['reservations'][sid])\n"
                  "    negative = native_negative * slots")
    text = change(text, "e['new_negative'] == negative", "e['new_negative'] == native_negative")
    text = change(text, "    need(n['active_run_id'] == run",
                  "    if slots == 0:\n        local_reservation_valid(ledger, r, s, n, t)\n"
                  "    need(n['active_run_id'] == run")
    text = change(text, "r['negative_slots'] == 1", "r['negative_slots'] == slots")
    text = change(text, "t['negative_reserved_count'] >= 1", "t['negative_reserved_count'] >= slots")
    text = change(text, "n['negative_reserved_count'] >= 1", "n['negative_reserved_count'] >= slots")
    text = change(text, "if negative else 'complete_native_failure_readback_passed'",
                  "if native_negative else 'complete_native_failure_readback_passed'")
    text = change(text, "reusable_DM_failure=not bool(negative)", "reusable_DM_failure=not bool(native_negative)")
    text = change(text, '"qualified" if negative else "not_negative_native_failure"',
                  '"qualified" if native_negative else "not_negative_native_failure"')
    text = change(text, '    if negative:\n        s.update(negative_manifest=',
                  '    if native_negative:\n        s.update(negative_manifest=')
    text = change(text, "    s.setdefault('history', []).append(",
                  "    if native_negative and not negative:\n"
                  "        refs = t.setdefault('negative_reserve_manifest_refs', [])\n"
                  "        need(not any(v.get('source_id') == sid for v in refs), 'Duplicate reserve source')\n"
                  "        refs.append(dict(e['manifest'], source_id=sid, settlement=e['settlement_ref']))\n"
                  "        s.update(reserve_qualified_negative=True, core_negative_excluded_reason='negative_quota_already_full')\n"
                  "    s.setdefault('history', []).append(")
    text = change(text, "negative_slot_released=1", "negative_slot_released=slots")
    text = change(text, "status='settled_qualified_negative' if negative",
                  "status='settled_qualified_negative' if native_negative")
    for scope in ("t", "n"):
        text = change(text, f"{scope}['negative_reserved_count'] -= 1",
                      f"{scope}['negative_reserved_count'] -= slots")
    text = change(text, "'baseline_attempts_native_success' if negative",
                  "'baseline_attempts_native_success' if native_negative")
    text = change(text, "dict(native_success=negative,\n        native_failure=1-negative,",
                  "dict(native_success=native_negative,\n        native_failure=1-native_negative,")
    text = change(text, "native_success_negative_publication_verified=bool(negative)",
                  "native_success_negative_publication_verified=bool(native_negative)")
    text = change(text, "    return d, commit",
                  "    d['reservations'][sid].update(quota_reserved=False, negative_quota_reserved=False)\n"
                  "    if slots == 0:\n        commit['backup_negative_delta'] = native_negative\n"
                  "    return d, commit")
    return text


def binding_source(text):
    return change(text, "type(dispatch.get('negative_slots')) is int and dispatch['negative_slots'] == 1",
                  "dispatch_slots_valid(dispatch)")


def local_source(text):
    return change(text, "r['negative_slots']==1",
                  "local_reservation_valid(d,r,s,n,t)")


def namespace():
    return dict(MODE=MODE, reservation_slots=reservation_slots,
                mark_positive_dispatch=mark_positive_dispatch, original_slots=original_slots,
                local_reservation_valid=local_reservation_valid, dispatch_slots_valid=dispatch_slots_valid)
