"""Same Fasten preparation with the bounded long-report projection adapter."""
from pathlib import Path
import hashlib
import teacher_prepare_metadata_handoff_v5 as previous

EXPECTED_PREVIOUS_SHA = "8af20cad354d0091e6f4e2b839dc579cef2ed6ed5f0f709b2657d395d841fc99"


def source():
    raw = Path(previous.__file__).read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_PREVIOUS_SHA:
        raise ValueError("Frozen Fasten preparation changed")
    text = previous.source()
    old = "import failure_summary_binding as failure"
    if text.count(old) != 1:
        raise ValueError("Failure projection import seam changed")
    return text.replace(old, "import failure_summary_report_size_v1 as failure", 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::bounded_report_preparation", "exec"), globals())
