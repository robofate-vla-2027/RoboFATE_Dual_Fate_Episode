import json,sys,hashlib,datetime,fcntl
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import collect_teacher_content_v2 as collect
def verified_pre_actor_failure(context,failure,comparison,artifact_presence,native_source_sha256):
    if native_source_sha256!='461b383cef47a116e7e6620816f1da4da4dd8e3ce29afc93226c607b426632cc':return False
    if not isinstance(failure,dict) or not isinstance(comparison,dict):return False
    if not artifact_presence or any(artifact_presence.values()):return False
    if failure.get('source_id')!=context.get('source_id') or failure.get('run_id')!=context.get('run_id'):return False
    return (failure.get('stage')=='initial_boundary_saved'
        and failure.get('type')=='RuntimeError'
        and failure.get('message')=='Restored physical/discrete state mismatch'
        and failure.get('native_used')==context.get('t1')
        and type(context.get('t1')) is int and 0<context['t1']<context['native_limit']
        and context.get('remaining_steps')==context['native_limit']-context['t1']
        and failure.get('actual_control_steps')==10*context['t1']
        and failure.get('native_done') is False and failure.get('native_success') is False
        and comparison.get('all_compared_fields_within_candidate_rules') is False
        and comparison.get('context_budget')==dict(total=context['native_limit'],t1=context['t1'],remaining=context['remaining_steps']))

x=json.load(sys.stdin);fg=collect.base;fg.host();run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];c=json.loads((run/'CONTEXT_001.json').read_text());session=Path(c['runtime_binding']['run_dir'])
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def doc(p):return json.loads(p.read_text())
fgs=doc(run/'foreground_started.json');own=doc(run/'owned_native.json');checks=[];boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for role,ident in [('foreground',fgs['identity']),('native',own['identity'])]:
 p=Path('/proc')/str(ident['pid'])/'stat';same=p.exists() and boot==ident['boot_id'] and int(p.read_text().rsplit(')',1)[1].split()[19])==ident['start_ticks'];checks.append(dict(role=role,identity=ident,original_process_absent=not same))
wait=doc(run/'native_wait.json') if (run/'native_wait.json').exists() else None;cleanup=doc(run/'process_cleanup.json') if (run/'process_cleanup.json').exists() else None;writer=doc(run/'writer_close.json') if (run/'writer_close.json').exists() else None;life=doc(session/'oci/LIFECYCLE.json') if (session/'oci/LIFECYCLE.json').exists() else None
try:remaining=json.loads(life['remaining']) if life else None
except (ValueError,KeyError,TypeError):remaining='unparseable'
cn=cleanup.get('native',{}) if isinstance(cleanup,dict) else {}
failure=doc(run/'failure.json') if (run/'failure.json').exists() else None
comparison=doc(run/'restore_state_comparison.json') if (run/'restore_state_comparison.json').exists() else None
artifacts={str(p):p.exists() for p in [session/'agent',session/'oci',session/'runtime',run/'actual_t1_verified.json',run/'teacher_ready.json',run/'teacher_first_native_action.json',run/'result.json']}
native_source_sha=hashlib.sha256(collect.native.text.encode()).hexdigest()
pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha)
actor_safe=bool(isinstance(life,dict) and life.get('run_root')==str(session) and life.get('owned_cleanup_complete') is True and life.get('cleanup_raw_exit')==0 and life.get('list_raw_exit')==0 and remaining in [None,[]]) or pre_actor
safe=all(v['original_process_absent'] for v in checks) and cn.get('original_process_absent') is True and actor_safe
resource_errors=[]
if wait is not None and wait.get('pid')!=own['identity']['pid']:resource_errors.append('wait_pid_mismatch')
if cleanup is not None and cn.get('identity')!=own['identity']:resource_errors.append('cleanup_identity_mismatch')
if wait is not None and cleanup is not None and wait.get('returncode')!=cn.get('returncode'):resource_errors.append('wait_cleanup_returncode_mismatch')
safe=bool(safe and not resource_errors)
if safe:
 with fg.LOCK.open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
summary=doc(run/'teacher_readback_001/SUMMARY.json') if (run/'teacher_readback_001/SUMMARY.json').exists() else None;at=datetime.datetime.now(datetime.timezone.utc).isoformat();d=dict(schema='refate.actual_terminal_observation.v1',data_kind='actual',at=at,execution_owner=c['execution_owner'],run_id=x['run_id'],source_id=c['source_id'],task=c['task'],context=ref(run/'CONTEXT_001.json'),actual_foreground_tool_returncode=x['tool_returncode'],own_process_checks=checks,native_wait=wait,process_cleanup=cleanup,writer_close=writer,gvisor_lifecycle=life,gvisor_lifecycle_ref=ref(session/'oci/LIFECYCLE.json') if life else None,safe_for_next_simulator=safe,summary=summary,summary_ref=ref(run/'teacher_readback_001/SUMMARY.json') if summary else None,foreground_started_at=fgs['at'],foreground_to_saved_summary_seconds=(datetime.datetime.fromisoformat(summary['at'])-datetime.datetime.fromisoformat(fgs['at'])).total_seconds() if summary else None,data_qualification_not_inferred_from_exit=True,resource_consistency_errors=resource_errors)
d['actor_role_observation']=dict(teacher_started=False if pre_actor else None,pre_actor_failure_verified=pre_actor,lifecycle_required=not pre_actor,launch_artifact_presence=artifacts,native_effective_source_sha256=native_source_sha,failure_ref=ref(run/'failure.json') if failure else None,restore_comparison_ref=ref(run/'restore_state_comparison.json') if comparison else None)
p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json');assert p.parent==run and p.name.startswith('MAIN_TERMINAL_OBSERVATION_') and p.suffix=='.json'
if p.exists():assert doc(p)['run_id']==x['run_id'];d=doc(p)
else:
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
d['evidence_ref']=ref(p);print(json.dumps(d))