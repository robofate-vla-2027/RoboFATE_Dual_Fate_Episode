"""Freeze only Fasten task parameters and matching existing teacher entries."""
import datetime
import hashlib
import json
from pathlib import Path

import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import teacher_catalog_binding_v12 as previous_catalog
import teacher_catalog_binding_v13 as catalog
import collect_teacher_content_v5 as previous_collect
import collect_teacher_content_v6 as collect
import prepare_teacher_content_v6 as prepare
import teacher_ledger_owner_handoff_v5 as accounting

HERE = Path(__file__).resolve().parent


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def release():
    prior = ref(HERE / "TEACHER_GENERAL_CONTENT_RELEASE_20261101_01a19072.json")
    assert prior["sha256"] == "d1aa841ebeee87001dcfa2239fc0809ff212b8855469563eeed5f5ce749d35e5"
    data = runtime.document(runtime.read_pin(prior))
    for item in data["runtime_files"]:
        runtime.read_pin(item)
    log = HERE / "TEACHER_FASTEN_CONTENT_CPU_002.log"
    assert "Ran 6 tests" in log.read_text() and log.read_text().rstrip().endswith("OK")
    assert catalog.TASK_TOTALS == dict(previous_catalog.TASK_TOTALS, fasten_screws=1900)
    assert collect.native.restore is prepare.restore is catalog.restore
    assert collect.native.recording is prepare.common_recording is previous_collect.native.recording
    assert collect.dependency is prepare.shared_dependency_binding is previous_collect.dependency
    assert collect.native.text.replace("teacher_catalog_binding_v13", "teacher_catalog_binding_v12") == previous_collect.native.text
    assert accounting._TEXT == accounting.previous._TEXT
    assert data["actor_wall_seconds"] == 3600
    assert data["commit"] == "470278c478bdb5e4b6f17dde1ea0393761f230f0"
    assert data["model"] == "gt-6-as-a" and data["reasoning_effort"] == "xhigh"
    additions = [ref(HERE / name) for name in (
        "teacher_catalog_binding_v13.py", "native_teacher_content_v6.py",
        "collect_teacher_content_v6.py", "prepare_teacher_content_v6.py",
        "teacher_ledger_owner_handoff_v5.py", "test_teacher_fasten_content_v1.py",
        "release_teacher_fasten_content_v1.py")]
    data["runtime_files"] = list({v["path"]: v for v in data["runtime_files"] + additions}.values())
    data.update(
        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        inherits=prior, execution_owner=execution.NEW,
        foreground_entry=str(HERE / "collect_teacher_content_v6.py"),
        native_entry=str(HERE / "native_teacher_content_v6.py"),
        preparation_entry=str(HERE / "prepare_teacher_content_v6.py"),
        cpu_summary={"tests": 6, "passed": 6, "log": ref(log),
                     "data_kind": "synthetic_not_scientific_data",
                     "prior_invocation_failure": ref(HERE / "TEACHER_FASTEN_CONTENT_CPU_001.log"),
                     "invocation_correction": "Set verified exact SSH alias and current executor environment; identity checks unchanged",
                     "model_api_simulator_gpu_calls": False},
        actual_adoption=False, actual_teacher_takeover_verified=False,
        actual_positive_published=False, real_constant_frame_validation=False,
        catalog_extension={"task": "fasten_screws", "native_limit": 1900,
                           "catalog": ref(HERE / "teacher_catalog_binding_v13.py")},
        accounting_parameter_extension=ref(HERE / "teacher_ledger_owner_handoff_v5.py"),
        native_effective_source_sha256=hashlib.sha256(collect.native.text.encode()).hexdigest(),
        change_scope="Fasten1900 task parameters and matching entry references only; actual t1 restoration remains unverified",
        old_runtime_files_modified=False)
    path = HERE / "TEACHER_FASTEN_CONTENT_RELEASE_20261101_01a19072.json"
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return {"release": ref(path), "actual_native_started": False,
            "actual_teacher_takeover_verified": False}


if __name__ == "__main__":
    print(json.dumps(release()))
