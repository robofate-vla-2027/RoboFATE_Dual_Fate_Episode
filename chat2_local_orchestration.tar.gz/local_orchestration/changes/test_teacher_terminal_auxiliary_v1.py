"""Synthetic CPU metadata tests; no actual ledger, model, robot or process control."""
import ast
import copy
import json
import os
from pathlib import Path
import sys
import unittest
import teacher_terminal_handoff_v7 as observer


def deny_external(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.fork", "os.posix_spawn", "os.kill", "os.killpg"):
        raise AssertionError("Synthetic test forbids external effects: " + event)


sys.addaudithook(deny_external)


class AuxiliaryTests(unittest.TestCase):
    def setUp(self):
        self.context = dict(source_id="SYNTHETIC_SOURCE", run_id="SYNTHETIC_RUN",
                            t1=10, native_limit=700, remaining_steps=690)
        self.failure = dict(source_id="SYNTHETIC_SOURCE", run_id="SYNTHETIC_RUN",
                            stage="initial_boundary_saved", type="RuntimeError",
                            message="Task auxiliary state mismatch", native_used=10,
                            actual_control_steps=100, native_done=False, native_success=False,
                            qualified=False, provider_retry_allowed=False)
        self.artifacts = {str(i): False for i in range(7)}
        self.names = ["initial_task_auxiliary.json", "task_auxiliary_000010.json"]
        self.pairs = {n: dict(sha256=["a"*64, "b"*64], typed_json_exact=False)
                      for n in self.names}
        self.comparison = dict(
            task_auxiliary=[dict(file=n, **p) for n, p in self.pairs.items()],
            qualified=False, old_suffix_reuse_allowed=False,
            rtx_profile_exact=True, requested_rtx_profile_exact=True)

    def check(self, sha=observer.NATIVE_SHA):
        return observer.verified_pre_actor_auxiliary_failure(
            self.context, self.failure, self.comparison, self.artifacts, sha, self.pairs)

    def test_exact_failed_restore_is_not_mutated_or_qualified(self):
        values = (self.context, self.failure, self.comparison, self.artifacts, self.pairs)
        before = copy.deepcopy(values)
        self.assertTrue(self.check())
        self.assertEqual(values, before)
        self.assertFalse(self.failure["qualified"])
        self.assertFalse(self.failure["native_done"])

    def test_changed_native_hash_rejected(self):
        self.assertFalse(self.check("0"*64))

    def test_each_actor_artifact_rejected(self):
        for key in self.artifacts:
            self.artifacts[key] = True
            self.assertFalse(self.check())
            self.artifacts[key] = False

    def test_missing_artifact_inventory_rejected(self):
        self.artifacts.pop("0")
        self.assertFalse(self.check())

    def test_wrong_source_or_stage_or_failure_rejected(self):
        for key, value in (("source_id", "OTHER"), ("run_id", "OTHER"),
                           ("stage", "teacher_ready"), ("message", "content_filter"),
                           ("native_done", True), ("native_success", True),
                           ("native_used", 11), ("actual_control_steps", 110),
                           ("qualified", True), ("provider_retry_allowed", True)):
            with self.subTest(key=key):
                old = self.failure[key]
                self.failure[key] = value
                self.assertFalse(self.check())
                self.failure[key] = old

    def test_reset_or_invalid_budget_rejected(self):
        for key, value in (("remaining_steps", 700), ("t1", True), ("native_limit", 10)):
            old = self.context[key]
            self.context[key] = value
            self.assertFalse(self.check())
            self.context[key] = old

    def test_missing_comparison_rejected(self):
        self.comparison = None
        self.assertFalse(self.check())

    def test_changed_saved_hash_rejected(self):
        self.comparison = copy.deepcopy(self.comparison)
        self.comparison["task_auxiliary"][0]["sha256"][0] = "c"*64
        self.assertFalse(self.check())

    def test_no_actual_auxiliary_difference_rejected(self):
        for pair in self.pairs.values():
            pair["typed_json_exact"] = True
        for row in self.comparison["task_auxiliary"]:
            row["typed_json_exact"] = True
        self.assertFalse(self.check())

    def test_failed_render_or_false_comparison_rejected(self):
        self.comparison["rtx_profile_exact"] = False
        self.assertFalse(self.check())

    def test_original_physical_check_and_resource_checks_retained(self):
        parent = Path(os.environ.get("REFATE_CPU_PARENT_SOURCE",
                      str(Path(__file__).parent.parent / "preactor_auxiliary_source_review_001.txt")))
        text = parent.read_text().split("\n", 1)[1]
        revised = observer.source(text)
        ast.parse(revised)
        old = ast.parse(text)
        new = ast.parse(revised)
        get = lambda t: ast.dump(next(n for n in t.body if isinstance(n, ast.FunctionDef)
                                      and n.name == "verified_pre_actor_failure"))
        self.assertEqual(get(old), get(new))
        for line in text.splitlines():
            if line.startswith(("safe=", "if wait", "if cleanup", "actor_safe=")):
                self.assertIn(line, revised)
        self.assertIn("comparison is None and verified_pre_actor_auxiliary_failure", revised)

    def test_changed_entry_seam_rejected(self):
        with self.assertRaises(ValueError):
            observer.source("SYNTHETIC_BAD_ENTRY")


if __name__ == "__main__":
    unittest.main()
