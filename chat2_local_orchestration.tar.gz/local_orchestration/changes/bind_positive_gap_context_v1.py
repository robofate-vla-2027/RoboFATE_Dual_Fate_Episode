"""Only dispatch capacity changes; the Native/recording/reader release is reused."""
from pathlib import Path
import hashlib
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
gap.pinned_text(Path(__file__).with_name("bind_recording_content_v1.py"),
                "a0472625dfa7f9df017541729ca78f0624edf5280ca0736e7894c2dac155befc")
import bind_recording_content_v1 as previous

text = gap.binding_source(previous.text)
text = gap.change(text, "actual_imports_checked=True, actual_native_started=False, teacher_started=False",
                  "actual_imports_checked=True, actual_native_started=False, teacher_started=False,"
                  " actual_capacity_adapter=capacity_adapter")
capacity_adapter = dict(path=str(Path(__file__)), sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
dispatch_slots_valid = gap.dispatch_slots_valid
historical_preparer_allowed = previous.historical_preparer_allowed
if __name__ == "__main__":
    exec(compile(text, str(Path(previous.__file__)) + "::positive_gap", "exec"), globals())
