"""Read-only legacy prefix evidence for the next original Fasten baseline."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

from prepare_fasten_legacy_handoff_v1 import ADAPTER, ORIGINAL, ROOT, SOURCE_OWNER, TASK

SOURCE_IDS = {
    "1": "fasten_screws_b0_l1_fb65645ae483f85a",
    "2": "fasten_screws_b0_l2_ada71ec39d343ecd",
}
NEXT_SOURCE = "fasten_screws_b0_l3_5d48211720e3285f"
SCHEMA = "refate.fasten.original_prefix.accounted.v1"


def metadata_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode()).hexdigest()


def document(pin):
    path = Path(pin["path"])
    if set(pin) != {"path", "sha256"} or not path.is_relative_to(ROOT) or path.resolve() != path:
        raise ValueError("Foreign metadata reference")
    raw = path.read_bytes()
    if len(raw) > 4 * 1024**2 or hashlib.sha256(raw).hexdigest() != pin["sha256"]:
        raise ValueError("Changed or oversized metadata")
    return json.loads(raw)


def validate_review(review, preparation_ref, source):
    if (source.get("task") != TASK or source.get("source_id") != NEXT_SOURCE
            or type(source.get("layout_id")) is not int or source["layout_id"] != 3
            or source.get("source_sequence") != list(range(7))
            or source.get("required_accounted_prefix") != [0, 1, 2]):
        raise ValueError("Wrong original Fasten next source")
    if (review.get("schema") != SCHEMA or review.get("next_source_id") != NEXT_SOURCE
            or review.get("preparation_ref") != preparation_ref
            or review.get("original_manifest") != ORIGINAL
            or review.get("expected_used_prefix") != [0, 1, 2]
            or review.get("parent_reported_used_prefix") != [0, 1]
            or review.get("original_zero_source_quality_claimed") is not False
            or review.get("old_source_qualification_changed") is not False
            or review.get("old_sources_replayed") is not False
            or review.get("live_referenced_processes") != []
            or review.get("positive_delta") != 0 or review.get("negative_delta") != 0
            or set(review.get("entries", {})) != set(SOURCE_IDS)):
        raise ValueError("Incomplete or changed original Fasten prefix review")
    for index, sid in SOURCE_IDS.items():
        entry = review["entries"][index]
        if (entry.get("source_id") != sid or entry.get("positive_delta") != 0
                or entry.get("negative_delta") != 0
                or entry.get("disposition") != "indexed_consumed_source_no_quality_change"):
            raise ValueError("Historical prefix quality or identity changed")


def fasten_original_prefix_accounted(ledger, boundary, source, ordinal):
    if type(ordinal) is not int or ordinal not in (0, 1, 2):
        return False
    review = boundary.get("legacy_prefix_review", {})
    try:
        validate_review(review, boundary["next_preparation"]["ref"], source)
    except (KeyError, TypeError, ValueError):
        return False
    expected = sorted(SOURCE_IDS.values())
    for field, hash_key in (("source_index", "source_metadata_sha256"),
                            ("reservations", "reservation_metadata_sha256")):
        rows = {sid: row for sid, row in ledger[field].items()
                if row.get("task") == TASK and row.get("host") == "perdon-hou"}
        if sorted(rows) != expected:
            return False
        for index, sid in SOURCE_IDS.items():
            entry = review.get("entries", {}).get(index, {})
            if (entry.get("source_id") != sid
                    or entry.get(hash_key) != metadata_hash(rows[sid])
                    or entry.get("positive_delta") != 0 or entry.get("negative_delta") != 0):
                return False
    return True


def observe(args):
    prepared = document(args["preparation_ref"])
    previous = document(args["prior_preparation_ref"])
    source, prior = prepared["source"], previous["source"]
    if (source["source_id"] != NEXT_SOURCE or source["layout_id"] != 3
            or source["required_accounted_prefix"] != [0, 1, 2]
            or source["source_sequence"] != list(range(7))
            or prior["source_id"] != SOURCE_IDS["2"]
            or prior["required_accounted_prefix"] != [0, 1]):
        raise ValueError("Wrong original Fasten descriptor pair")
    if not (prepared["native_step_limit"] == previous["native_step_limit"] == 1900):
        raise ValueError("Original native budget changed")
    split = document(prepared["provenance"]["split"])
    if split["metadata_projection"]["original_manifest"] != ORIGINAL:
        raise ValueError("Original split is not the frozen Fasten manifest")
    entries = {}
    for field in ("sources", "reservations"):
        if set(args[field]) != set(SOURCE_IDS):
            raise ValueError("Complete indexed historical prefix required")
    for index, sid in SOURCE_IDS.items():
        row, reservation = args["sources"][index], args["reservations"][index]
        if (row["source_id"] != sid or row["task"] != TASK or row["host"] != "perdon-hou"
                or row["owner_chat"] != SOURCE_OWNER or reservation["task"] != TASK
                or reservation["host"] != "perdon-hou" or reservation["source_id"] != sid
                or reservation["quota_reserved"] or reservation["negative_quota_reserved"]
                or row["source_layout_sha256"] != split["layouts"][index]["layout_ref"]["sha256"]
                or row["group_id"] != split["layouts"][index]["group_id"]):
            raise ValueError("Historical source changed or remains reserved")
        expected_status = ("settled_native_failure_no_active_teacher_reservation"
                           if index == "1" else "closed_native_failure")
        if reservation["status"] != expected_status:
            raise ValueError("Historical source not closed")
        entries[index] = {
            "source_id": sid, "source_metadata_sha256": metadata_hash(row),
            "reservation_metadata_sha256": metadata_hash(reservation),
            "disposition": "indexed_consumed_source_no_quality_change",
            "positive_delta": 0, "negative_delta": 0,
        }
    row = args["sources"]["2"]
    context = document(row["context"])
    final = document(row["baseline_final_settlement"])
    summary = document(row["readback_summary"])
    closure = document(row["closure"])
    if (context["source_id"] != SOURCE_IDS["2"] or context["task"] != TASK
            or context["source_owner"] != SOURCE_OWNER or final["source_owner"] != SOURCE_OWNER
            or not (context["run_id"] == final["run_id"] == summary["run_id"]
                    == closure["run_id"] == args["reservations"]["2"]["run_id"])
            or context["used_sequence_prefix_parent_report"] != [0, 1]
            or context["native_total_steps"] != 1900
            or context["layout_id"] != 2 or context["native_bank"] != 0
            or final["source_id"] != SOURCE_IDS["2"] or final["native_success"] is not False
            or final["native_actions"] != 1900 or final["observations"] != 1901
            or final["low_level_controls"] != 19000 or final["readback_complete"] is not True
            or final["positive_delta"] != 0 or final["negative_delta"] != 0
            or final["context"] != row["context"] or final["reader_summary"] != row["readback_summary"]
            or final["closure"] != row["closure"]
            or summary["readback_complete"] is not True or summary["source_context"] != row["context"]
            or closure["source_context"] != row["context"] or closure["closed"] is not True
            or closure["original_owned_processes_absent"] is not True):
        raise ValueError("Saved L2 terminal/prefix evidence disagrees")
    runs = [row["run_id"] for row in args["reservations"].values()]
    live = []
    for path in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            raw = path.read_bytes()
            if any(run.encode() in raw for run in runs):
                live.append(int(path.parent.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    if live:
        raise ValueError("A referenced historical Fasten run is live")
    return {
        "schema": SCHEMA, "data_kind": "actual_saved_metadata_only",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "next_source_id": NEXT_SOURCE, "preparation_ref": args["preparation_ref"],
        "prior_preparation_ref": args["prior_preparation_ref"], "original_manifest": ORIGINAL,
        "expected_used_prefix": [0, 1, 2], "parent_reported_used_prefix": [0, 1],
        "parent_report_ref": row["context"], "last_consumed_source": row["baseline_final_settlement"],
        "entries": entries, "live_referenced_processes": [],
        "ordinal_zero_basis": "historical_parent_report_only_not_new_lifecycle_or_quality_evidence",
        "original_zero_source_quality_claimed": False,
        "old_source_qualification_changed": False, "old_sources_replayed": False,
        "positive_delta": 0, "negative_delta": 0,
    }


if __name__ == "__main__":
    args = json.load(sys.stdin)
    result = observe(args)
    path = ADAPTER / "task_sources/fasten_screws/PREFIX_BEFORE_L3_001.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    result["evidence_ref"] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    print(json.dumps(result))
