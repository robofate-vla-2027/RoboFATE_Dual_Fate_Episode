"""Offline synthetic metadata only; no model, API, simulator, or ledger writes."""
import copy
import sys
import unittest
from switch_organize_to_retained_play_v1 import OWNER, switch_due


def deny_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.", "os.system", "os.posix_spawn")):
        raise RuntimeError("Synthetic fixture cannot launch a peer or use a network")


sys.addaudithook(deny_live_effects)


class RetainedPlayTests(unittest.TestCase):
    def setUp(self):
        ref = lambda tag: {"path": "synthetic/" + tag, "sha256": tag}
        self.ref = ref("terminal")
        self.e = dict(task="organize_table", execution_owner=OWNER,
                      safe_for_next_simulator=True, source_id="old", run_id="teacher",
                      summary_ref=ref("summary"), summary={"qualified_positive": False})
        zero = dict(positive_slots=0, negative_slots=0, quota_reserved=False,
                    negative_quota_reserved=False)
        s = dict(source_id="retained", task="play_stacking_toy", host="perdon-hou",
                 native_success=False, native_steps=1200, native_budget=1200,
                 complete_readback=True, reusable_DM_failure=True, run_id="baseline",
                 **{k: ref(k) for k in ("context", "manifest", "settlement", "readback")})
        self.retained = {k:s[k] for k in ("source_id", "context", "manifest", "settlement", "readback")}
        task = dict(assigned_host="perdon-hou", assigned_role="chat2",
                    reserved_count=0, negative_reserved_count=0, active_run_id=None,
                    positive_quota=10, negative_quota=10, qualified_count=0, negative_count=0)
        old = dict(task, latest_segment_started_at="2026-10-31T10:00:00+00:00")
        target = dict(task, scheduling_state="deferred",
                      deferred_at="2026-10-31T08:00:00+00:00",
                      latest_segment_started_at="2026-10-31T06:00:00+00:00")
        node = dict(active_chat_id=OWNER, current_task="organize_table",
                    active_run_id=None, active_real_simulators=0,
                    baseline_accounting={"baseline_attempts_running": 0},
                    completed_pending_sources=[], common_pending_readback_run_ids=[],
                    last_owned_resource_settlement=self.ref,
                    fixed_tasks=["organize_table", "play_stacking_toy"],
                    qualified_count=34, negative_count=18,
                    task_segments=[dict(task="insert_tubes", ended_at="2026-10-31T10:00:00+00:00")])
        self.d = dict(campaign_id="refate-20261022-97baf70d5128", revision=7,
                      nodes={"perdon-hou":node, "h20_8":{"untouched":2**63+111}},
                      tasks={"organize_table":old, "play_stacking_toy":target},
                      source_index={"retained":s, "old":{"active_teacher_attempt":dict(
                          status="settled", terminal_observation=self.ref, run_id="teacher")}},
                      reservations={
                          "retained":dict(zero, status="settled_native_failure_no_quota",
                                          settlement=s["settlement"], run_id="baseline"),
                          "old":dict(zero, status="shared_Evo_teacher_settled",
                                     current_attempt_settlement=self.e["summary_ref"],
                                     current_attempt_run_id="teacher")})
        self.at = "2026-10-31T11:31:00+00:00"

    def run_switch(self):
        return switch_due(self.d, self.e, self.ref, self.retained, self.at, "synthetic fixture")

    def test_due_switch_preserves_sources_peers_and_counts(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "play_stacking_toy")
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertFalse(out["receipt"]["transition"]["baseline_replay"])

    def test_live_or_resource_pending_rejected(self):
        for key,value in (("active_run_id","live"), ("active_real_simulators",1),
                          ("owned_resource_launch_hold",True), ("launch_inflight",True)):
            with self.subTest(key=key):
                self.setUp()
                self.d["nodes"]["perdon-hou"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_early_window_recent_gain_or_not_due_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["tasks"]["organize_table"]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_repeat_refused_or_unread_source_rejected(self):
        for key,value in (("active_teacher_attempt",{"status":"settled"}),
                          ("teacher_attempt_history",[{"synthetic":True}]),
                          ("provider_safety_refusal",{"synthetic":True}),
                          ("complete_readback",False)):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_unsettled_or_qualifying_current_teacher_rejected(self):
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_positive"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()


if __name__ == "__main__":
    unittest.main()
