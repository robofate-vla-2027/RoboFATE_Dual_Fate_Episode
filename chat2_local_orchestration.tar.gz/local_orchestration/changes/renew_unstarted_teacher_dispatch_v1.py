"""Metadata-only renewal of an expired, bound teacher that never started."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
RUN = "c2_organize_table_l16_evo_common_teacher_0001_01a16807"
SID = "organize_table_b0_l16_ddfa6bb480299656"
OLD_SHA = "b3dc25947a77e79a52eee25a8dcbfae6e264c790e95ee55a66ef5cf51784fee4"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")
CONTEXT_NAME = "CONTEXT_UNSTARTED_RENEWAL_001.json"
DISPATCH_NAME = "DISPATCH_UNSTARTED_RENEWAL_001.json"
RECEIPT_NAME = "UNSTARTED_DISPATCH_RENEWAL_001.json"
MARKERS = (
    "foreground_started.json", "native_started.json", "owned_native.json",
    "teacher_ready.json", "actual_t1_verified.json", "native_actions.jsonl",
    "result.json", "failure.json", "foreground_error.json", "resource_selection.json",
    "memory_before.json", "native_wait.json", "process_cleanup.json", "dense",
    "runtime", "initial", "teacher_ipc", "teacher_readback_001",
)


def need(value, message):
    if not value:
        raise ValueError(message)


def ref(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "Regular original file required")
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(reference):
    path = Path(reference["path"])
    need(ref(path) == reference, "Pinned metadata changed")
    return json.loads(path.read_bytes())


def exclusive(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return ref(path)


def renew_documents(context, dispatch, evidence, at):
    now = datetime.datetime.fromisoformat(at)
    need(now.tzinfo is not None, "Timezone required")
    need(context["run_id"] == dispatch["run_id"] == RUN
         and context["source_id"] == dispatch["source_id"] == SID
         and context["execution_owner"] == dispatch["execution_owner"] == OWNER,
         "Different run/source/owner")
    need(context["native_limit"] == dispatch["native_total_steps"] == 1000
         and context["t1"] == dispatch["t1"] == 48
         and context["remaining_steps"] == dispatch["remaining_steps"] == 952
         and context["actor_wall_s"] == context["native_wall_seconds"]
         == dispatch["native_wall_seconds"] == dispatch["teacher_wall_seconds"] == 3600,
         "Original budget changed")
    need(dispatch["positive_slots"] == 1 and dispatch["negative_slots"] == 0
         and dispatch["source_reserved"] is True, "Reservation changed")
    need(datetime.datetime.fromisoformat(dispatch["valid_until"]) <= now,
         "Existing dispatch is not expired")
    need(set(evidence["markers"]) == set(MARKERS)
         and all(v is False for v in evidence["markers"].values()),
         "Actual or unknown execution markers")
    need(set(evidence["session_execution_dirs"]) == {"agent", "runtime", "oci"}
         and all(v is False for v in evidence["session_execution_dirs"].values())
         and evidence["inputs_present"] is True, "Session started or inputs missing")
    need(evidence["matching_processes"] == []
         and evidence["exclusive_native_lock_available"] is True,
         "Live or uncertain project execution")
    need(evidence["memory"]["available_bytes"] >= 120 * 1024**3
         and evidence["memory"]["minimum_free_gib"] == 120,
         "Original memory admission failed")
    fresh = copy.deepcopy(dispatch)
    fresh["valid_until"] = (now + datetime.timedelta(hours=2)).isoformat()
    fresh["unstarted_renewal"] = dict(
        at=at, original_dispatch_ref=copy.deepcopy(context["dispatch_ref"]),
        reason="Bound teacher never invoked; resource hold outlasted dispatch validity",
        actual_attempt_started=False, wall_origin_started=False)
    updated = copy.deepcopy(context)
    return updated, fresh


def verify_renewal(old, new, dispatch, evidence):
    need(evidence["run_id"] == old["run_id"] == new["run_id"] == RUN,
         "Renewal run mismatch")
    need(evidence["actual_launch_issued"] is False
         and evidence["scientific_attempt_started"] is False, "Not unstarted renewal")
    need({k: v for k, v in old.items() if k != "dispatch_ref"} ==
         {k: v for k, v in new.items() if k != "dispatch_ref"},
         "Renewal changed context beyond dispatch")
    previous = read(old["dispatch_ref"])
    need({k: v for k, v in dispatch.items() if k not in ("valid_until", "unstarted_renewal")}
         == {k: v for k, v in previous.items() if k != "valid_until"},
         "Renewal changed original dispatch fields")
    need(dispatch["unstarted_renewal"]["original_dispatch_ref"] == old["dispatch_ref"],
         "Old dispatch link changed")


def main():
    import fcntl
    import collect_teacher_content_v6 as collect

    collect.base.host()
    run = ROOT / "runs" / RUN
    old_ref = dict(path=str(run / "CONTEXT_001.json"), sha256=OLD_SHA)
    old = read(old_ref)
    dispatch = read(old["dispatch_ref"])
    session = Path(old["runtime_binding"]["run_dir"])
    need(session.parent == ROOT / "sessions", "Wrong session root")
    with collect.base.LOCK.open("r+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        evidence = dict(
            markers={name: (run / name).exists() for name in MARKERS},
            session_execution_dirs={name: (session / name).exists()
                                    for name in ("agent", "runtime", "oci")},
            inputs_present=(session / "inputs").is_dir(),
            matching_processes=[], exclusive_native_lock_available=True,
            memory=collect.base.helpers().memory_headroom(120),
            gpu_allocation=collect.base.allocation())
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        for proc in Path("/proc").iterdir():
            if not proc.name.isdigit() or int(proc.name) == os.getpid():
                continue
            try:
                args = (proc / "cmdline").read_bytes().split(b"\0")
                matched = any(str(run).encode() in arg or str(session).encode() in arg
                              or b"collect_teacher_content" in arg
                              or b"native_teacher_content" in arg for arg in args)
                if matched:
                    stat = (proc / "stat").read_text().rsplit(")", 1)[1].split()
                    evidence["matching_processes"].append(dict(
                        pid=int(proc.name), start_ticks=int(stat[19]), boot_id=boot))
            except FileNotFoundError:
                continue
        at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        updated, fresh = renew_documents(old, dispatch, evidence, at)
        need(not any((run / name).exists() for name in (
            CONTEXT_NAME, DISPATCH_NAME, RECEIPT_NAME)), "Existing renewal; inspect, do not repeat")
        updated["dispatch_ref"] = exclusive(run / DISPATCH_NAME, fresh)
        new_ref = exclusive(run / CONTEXT_NAME, updated)
        actual, material = collect.native.load_context(Path(new_ref["path"]), new_ref["sha256"])
        need(actual == updated and material["source_id"] == SID,
             "Actual unchanged loader rejected renewed metadata")
        value = dict(
            schema="refate.bound_unstarted_dispatch_renewal.v1", data_kind="actual",
            at=at, execution_owner=OWNER, source_id=SID, run_id=RUN,
            original_context=old_ref, original_dispatch=old["dispatch_ref"],
            context=new_ref, dispatch=updated["dispatch_ref"], dispatch_document=fresh,
            zero_start_evidence=evidence, actual_original_loader_passed=True,
            actual_launch_issued=False, scientific_attempt_started=False,
            original_wall_origin_not_started=True, original_budget_unchanged=True,
            original_session_inputs_reused=True, actual_restore_verified=False,
            positive_delta=0, negative_delta=0, helper=ref(Path(__file__).resolve()))
        value["evidence_ref"] = exclusive(run / RECEIPT_NAME, value)
        print(json.dumps(value))


if __name__ == "__main__":
    main()
