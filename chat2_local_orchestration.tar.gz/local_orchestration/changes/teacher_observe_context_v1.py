"""Use a pinned renewed context with existing metadata observers, unchanged otherwise."""
import importlib
import io
import json
from pathlib import Path
import sys

import renew_unstarted_teacher_dispatch_v1 as renewal

HELPERS = {
    "teacher_start_observe_v1": ("991f9908d0ba4e92b5c0f6a5c53402f8b80e72e8ecdc011449578135a23a60de", 1),
    "teacher_first_observe_v1": ("c86c8b359857d4aa47f7727afd8c3b5a6813085b0251ce92928ea662960e4f26", 2),
    "teacher_health_observe_v1": ("37792aa9da9384e5095bd12d175e28c0e10d65e917b6a69a0b63bca5537494ca", 1),
    "teacher_terminal_handoff_v7": ("5f410e668477ea54364c991ef1804fbd7afa31d9e355f497e257f6b4500e5bb3", 2),
    "observe_content_entry_v1": ("d7a9e2dd3756118468316296b0fcefc3253253d6e75a69abed0256ab0dafd0b1", 2),
    "observe_teacher_request_devices_v1": ("ac37d770e85f3ac9ce175a513d882fc0fc9260f54e1af5802d61f2ffe92b6f6f", 1),
}


def adapt(text, count):
    renewal.need(text.count("CONTEXT_001.json") == count, "Original context seams changed")
    return text.replace("CONTEXT_001.json", renewal.CONTEXT_NAME)


def main():
    name = sys.argv[1]
    digest, count = HELPERS[name]
    x = json.load(sys.stdin)
    renewal.need(x["run_id"] == renewal.RUN, "Different run")
    path = Path(__file__).with_name(name + ".py")
    renewal.need(renewal.ref(path)["sha256"] == digest, "Original observer changed")
    evidence = renewal.read(x["renewal_ref"])
    old = renewal.read(evidence["original_context"])
    new = renewal.read(evidence["context"])
    renewal.verify_renewal(old, new, renewal.read(new["dispatch_ref"]), evidence)
    run = Path(new["run_dir"])
    if (run / "foreground_started.json").exists():
        foreground = json.loads((run / "foreground_started.json").read_bytes())
        renewal.need(foreground["context_ref"] == evidence["context"],
                     "Actual foreground used another context")
    text = importlib.import_module(name).source() if name == "teacher_terminal_handoff_v7" else path.read_text()
    text = adapt(text, count)
    sys.stdin = io.StringIO(json.dumps(x))
    exec(compile(text, str(path) + "::renewed_context_only", "exec"),
         dict(__name__="__main__", __file__=str(path)))


if __name__ == "__main__":
    main()
