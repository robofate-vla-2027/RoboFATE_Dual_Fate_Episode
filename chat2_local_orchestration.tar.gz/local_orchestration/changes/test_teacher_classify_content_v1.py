"""Offline entry and budget tests; no model, simulator, robot, or real data verdict."""
import re
import unittest

import teacher_catalog_binding_v8 as old_catalog
import teacher_catalog_binding_v9 as catalog
import native_teacher_content_v1 as old_native
import native_teacher_content_v2 as native
import collect_teacher_content_v1 as old_collect
import collect_teacher_content_v2 as collect
import prepare_teacher_content_v1 as old_prepare
import prepare_teacher_content_v2 as prepare
import teacher_ledger_owner_handoff_v1 as old_accounting
import teacher_ledger_owner_handoff_v2 as accounting


class ClassifyContentTests(unittest.TestCase):
    def test_only_classify_budget_added(self):
        self.assertNotIn("classify_objects", old_catalog.TASK_TOTALS)
        self.assertEqual(catalog.TASK_TOTALS, dict(old_catalog.TASK_TOTALS, classify_objects=1100))
        total = catalog.budget("classify_objects", 1100, 37)
        self.assertEqual(total, 1100)
        self.assertEqual(total - 37, 1063)
        for total, t1 in ((500, 37), (1100, 0), (1100, 1100), (1100, True)):
            with self.assertRaises((ValueError, AssertionError)):
                catalog.budget("classify_objects", total, t1)

    def test_actual_entry_set_uses_same_catalog_and_recording(self):
        self.assertIs(collect.native, native)
        self.assertIs(native.restore, catalog.restore)
        self.assertIs(collect.restore, catalog.restore)
        self.assertIs(prepare.restore, catalog.restore)
        self.assertIs(native.recording, old_native.recording)
        self.assertIs(prepare.common_recording, native.recording)
        self.assertEqual(collect.dependency.__name__, "shared_dependency_content_v1")
        self.assertEqual(prepare.shared_dependency_binding.__name__, "shared_dependency_content_v1")

    def test_native_only_catalog_imports_change(self):
        self.assertEqual(native.text.replace("teacher_catalog_binding_v9", "teacher_catalog_binding_v8"),
                         old_native.text)

    def test_foreground_only_matching_entry_references_change(self):
        restored = collect.text.replace("native_teacher_content_v2", "native_teacher_content_v1")
        restored = restored.replace("teacher_catalog_binding_v9", "teacher_catalog_binding_v8")
        self.assertEqual(restored, old_collect.text)

    def test_preparation_only_matching_entry_references_change(self):
        restored = prepare.text.replace("native_teacher_content_v2", "native_teacher_content_v1")
        restored = restored.replace("teacher_catalog_binding_v9", "teacher_catalog_binding_v8")
        self.assertEqual(restored, old_prepare.text)

    def test_accounting_adds_only_task_tuple(self):
        self.assertNotIn("classify_objects", old_accounting._BINDINGS)
        new = dict(accounting._BINDINGS)
        total, pattern = new.pop("classify_objects")
        self.assertEqual(new, old_accounting._BINDINGS)
        self.assertEqual(total, 1100)
        self.assertTrue(re.fullmatch(pattern, "c2_classify_objects_l6_evo_common_teacher_0001_01a16807"))
        self.assertEqual(accounting._TEXT, old_accounting._TEXT)


if __name__ == "__main__":
    unittest.main()
