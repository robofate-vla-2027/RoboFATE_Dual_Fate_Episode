"""Offline General200 entry tests; no model/API/simulation or data qualification."""
import json
from pathlib import Path
import re
import sys
import unittest


def no_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic CPU checks cannot call peers or launch processes")


sys.addaudithook(no_live_effects)
import teacher_catalog_binding_v11 as old_catalog
import teacher_catalog_binding_v12 as catalog
import native_teacher_content_v4 as old_native
import native_teacher_content_v5 as native
import collect_teacher_content_v4 as old_collect
import collect_teacher_content_v5 as collect
import prepare_teacher_content_v4 as old_prepare
import prepare_teacher_content_v5 as prepare
import teacher_ledger_owner_handoff_v3 as old_accounting
import teacher_ledger_owner_handoff_v4 as accounting


class GeneralContentTests(unittest.TestCase):
    def test_only_general_budget_added(self):
        self.assertNotIn("general_pickup", old_catalog.TASK_TOTALS)
        self.assertEqual(catalog.TASK_TOTALS, dict(old_catalog.TASK_TOTALS, general_pickup=200))
        self.assertEqual(catalog.budget("general_pickup", 200, 25), 200)
        for total, t1 in ((700, 25), (200, 0), (200, 200), (200, True)):
            with self.assertRaises((ValueError, AssertionError)):
                catalog.budget("general_pickup", total, t1)

    def test_actual_entry_set_keeps_content_recorder_and_reader(self):
        self.assertIs(collect.native, native)
        self.assertIs(native.restore, catalog.restore)
        self.assertIs(collect.restore, catalog.restore)
        self.assertIs(prepare.restore, catalog.restore)
        self.assertIs(native.recording, old_native.recording)
        self.assertIs(prepare.common_recording, native.recording)
        self.assertEqual(collect.dependency.__name__, "shared_dependency_content_v1")
        self.assertEqual(prepare.shared_dependency_binding.__name__, "shared_dependency_content_v1")

    def test_native_only_catalog_imports_change(self):
        self.assertEqual(native.text.replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v11"),
                         old_native.text)

    def test_foreground_only_matching_entry_references_change(self):
        restored = collect.text.replace("native_teacher_content_v5", "native_teacher_content_v4")
        restored = restored.replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v11")
        self.assertEqual(restored, old_collect.text)

    def test_preparation_only_matching_entry_references_change(self):
        restored = prepare.text.replace("native_teacher_content_v5", "native_teacher_content_v4")
        restored = restored.replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v11")
        self.assertEqual(restored, old_prepare.text)

    def test_accounting_adds_only_general_tuple(self):
        self.assertNotIn("general_pickup", old_accounting._BINDINGS)
        bindings = dict(accounting._BINDINGS)
        total, pattern = bindings.pop("general_pickup")
        self.assertEqual(bindings, old_accounting._BINDINGS)
        self.assertEqual(total, 200)
        self.assertTrue(re.fullmatch(pattern, "c2_general_pickup_l7_evo_common_teacher_0001_01a16807"))
        self.assertEqual(accounting._TEXT, old_accounting._TEXT)


if __name__ == "__main__":
    unittest.main()
