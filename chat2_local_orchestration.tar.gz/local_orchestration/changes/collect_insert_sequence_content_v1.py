"""Same foreground and reader; install the sequence-author handoff in both processes."""
from pathlib import Path
import insert_sequence_handoff_v1 as handoff
handoff.install()
import common_runtime as runtime

path = Path(__file__).with_name("collect_recording_content_v1.py")
text = runtime.read_pin({
    "path": str(path),
    "sha256": "94018747106873d6994aae5c04b4f89928c3a71e2f2439aa154b49e927cb1ea5",
}).decode()
text = runtime.edit(
    text, "import collection_recording_content_v1 as wiring\n",
    "import collection_insert_sequence_content_v1 as wiring\n",
)
exec(compile(text, str(path) + "::sequence_handoff", "exec"), globals())
