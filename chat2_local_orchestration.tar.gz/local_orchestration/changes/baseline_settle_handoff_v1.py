import sys,json,base64,datetime
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import owner_settlement_handoff_v1 as helper
x=json.load(sys.stdin);ledger=json.loads(base64.b64decode(x['ledger_b64']));e=json.loads(base64.b64decode(x['evidence_b64']));at=datetime.datetime.now(datetime.timezone.utc).isoformat();d,receipt=helper.settle(ledger,e,at)
if not receipt.get('already_settled'):
 d['source_index'][e['source_id']]['complete_readback']=True
 if e['new_negative']:
  t=d['tasks'][e['task']];t.update(last_core_gain_at=at,last_negative_gain_at=at,last_core_gain_category='negative');d['nodes']['perdon-hou']['latest_negative_ledger_commit']=dict(receipt)
import closed_baseline_resource_v1 as closed
def adopt_closed_baseline(d,e,at):
 n=d['nodes']['perdon-hou'];sid=e['source_id'];s=d['source_index'][sid];row=d['reservations'][sid];eref=e['settlement_ref']
 assert n['active_chat_id']=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0' and e['execution_owner']==n['active_chat_id']
 assert n['active_run_id'] is None and n['active_real_simulators']==0 and not n['launch_inflight'] and n['baseline_accounting']['baseline_attempts_running']==0
 assert n['current_dispatch']['run_id']==e['run_id'] and s['host']=='perdon-hou' and s['task']==e['task'] and e['task'] in n['fixed_tasks']
 assert s['run_id']==row['run_id']==e['run_id'] and s['context']==e['context'] and s['settlement']==row['settlement']==eref
 assert row['status'] in ('settled_qualified_negative','settled_native_failure_no_quota') and not row.get('quota_reserved') and not row.get('negative_quota_reserved')
 closed.baseline_checks(e)
 if n.get('last_owned_resource_settlement')==eref:return False
 old=n.get('last_owned_resource_settlement')
 if old:n.setdefault('owned_resource_settlement_history',[]).append(dict(at=at,prior=old,replaced_by=eref,reason='Actually closed baseline predecessor; data outcome unchanged'))
 n['last_owned_resource_settlement']=eref
 n['latest_baseline_resource_adoption']=dict(at=at,run_id=e['run_id'],source_id=sid,settlement=eref,source_result_unchanged=True)
 return True

if e.get('safe_for_next_simulator') is True:receipt['closed_baseline_resource_pointer_updated']=adopt_closed_baseline(d,e,at)
print(json.dumps({'ledger':d,'receipt':receipt}))