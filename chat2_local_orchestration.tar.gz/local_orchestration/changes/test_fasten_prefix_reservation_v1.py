"""Offline synthetic metadata only; never access the production ledger."""
import ast
from copy import deepcopy
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.append(str(snapshot))

import fasten_prefix_handoff_v1 as prefix
import fasten_owner_reservation_handoff_v1 as owner
import fasten_boundary_handoff_v1 as boundary
import reserve_fasten_content_handoff_v1 as reserve_entry
import switch_classify_to_fasten_l3_v1 as scheduler
from test_common_owner_reservation import fixture as original_fixture, AT

REF = {"path": "/synthetic/preparation.json", "sha256": "a" * 64}


def fixture():
    d, b = original_fixture()
    n = d["nodes"]["perdon-hou"]
    n.update(active_chat_id=owner.OWNER, current_task=prefix.TASK, fixed_tasks=[prefix.TASK])
    d["nodes"]["h20_8"]["nanoseconds"] = 1800000000000000001
    d["tasks"][prefix.TASK] = d["tasks"].pop("plug_in_charger")
    p = b["next_preparation"]["prepared"]
    p["native_step_limit"] = 1900
    p["source"].update(task=prefix.TASK, source_id=prefix.NEXT_SOURCE, layout_id=3,
                       source_owner=prefix.SOURCE_OWNER, execution_owner=prefix.SOURCE_OWNER,
                       source_sequence=list(range(7)), required_accounted_prefix=[0, 1, 2])
    b["next_preparation"]["ref"] = deepcopy(REF)
    b["resource_precheck"]["summary"]["run_id"] = "c2_fasten_screws_l3_synthetic_01a16807"
    entries = {}
    for index, sid in prefix.SOURCE_IDS.items():
        row = dict(source_id=sid, task=prefix.TASK, host="perdon-hou",
                   native_success=False, synthetic_ns=1800000000000000001,
                   original_quality="failed_readback" if index == "1" else "complete_failure")
        reservation = dict(source_id=sid, task=prefix.TASK, host="perdon-hou",
                           quota_reserved=False, negative_quota_reserved=False)
        d["source_index"][sid] = row
        d["reservations"][sid] = reservation
        entries[index] = dict(source_id=sid, source_metadata_sha256=prefix.metadata_hash(row),
                              reservation_metadata_sha256=prefix.metadata_hash(reservation),
                              positive_delta=0, negative_delta=0,
                              disposition="indexed_consumed_source_no_quality_change")
    b["legacy_prefix_review"] = dict(
        schema=prefix.SCHEMA, next_source_id=prefix.NEXT_SOURCE, preparation_ref=deepcopy(REF),
        original_manifest=deepcopy(prefix.ORIGINAL), entries=entries,
        expected_used_prefix=[0, 1, 2], parent_reported_used_prefix=[0, 1],
        original_zero_source_quality_claimed=False, old_source_qualification_changed=False,
        old_sources_replayed=False, live_referenced_processes=[], positive_delta=0, negative_delta=0)
    return d, b


class PrefixReservationTests(unittest.TestCase):
    def test_original_core_preserves_old_rows_peers_and_budgets(self):
        d, b = fixture()
        before = deepcopy(d)
        out, dispatch = owner.reserve(d, b, AT)
        self.assertEqual(d, before)
        self.assertEqual(out["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for field in ("source_index", "reservations"):
            for sid, row in before[field].items():
                self.assertEqual(out[field][sid], row)
        self.assertEqual(dispatch["native_total_steps"], 1900)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["teacher_wall_seconds"], 3600)
        self.assertEqual(dispatch["source_owner"], prefix.SOURCE_OWNER)
        self.assertEqual(dispatch["execution_owner"], owner.OWNER)
        self.assertFalse(dispatch["source_started"])
        self.assertFalse(any(s.startswith("fasten_screws_b0_l0_") for s in out["source_index"]))

    def test_each_original_ordinal_only_accounts_consumption(self):
        d, b = fixture()
        for ordinal in (0, 1, 2):
            self.assertTrue(prefix.fasten_original_prefix_accounted(
                d, b, b["next_preparation"]["prepared"]["source"], ordinal))
        for ordinal in (True, -1, 3, 53):
            self.assertFalse(prefix.fasten_original_prefix_accounted(
                d, b, b["next_preparation"]["prepared"]["source"], ordinal))

    def test_old_row_or_reservation_change_rejected_at_nanosecond_precision(self):
        for field in ("source_index", "reservations"):
            d, b = fixture()
            d[field][prefix.SOURCE_IDS["1"]]["synthetic_ns"] = 1800000000000000002
            with self.assertRaises(ValueError):
                owner.reserve(d, b, AT)

    def test_missing_extra_and_live_prefix_rejected(self):
        for case in ("missing", "extra", "live"):
            d, b = fixture()
            if case == "missing":
                del b["legacy_prefix_review"]["entries"]["1"]
            elif case == "extra":
                d["source_index"]["extra"] = dict(task=prefix.TASK, host="perdon-hou",
                                                 source_id="extra")
            else:
                b["legacy_prefix_review"]["live_referenced_processes"] = [999]
            with self.subTest(case=case), self.assertRaises(ValueError):
                owner.reserve(d, b, AT)

    def test_no_quality_upgrade_replay_or_new_credit(self):
        for key in ("original_zero_source_quality_claimed", "old_source_qualification_changed",
                    "old_sources_replayed", "positive_delta", "negative_delta"):
            d, b = fixture()
            b["legacy_prefix_review"][key] = True if key.endswith(("claimed", "changed", "replayed")) else 1
            with self.subTest(key=key), self.assertRaises(ValueError):
                owner.reserve(d, b, AT)

    def test_wrong_source_sequence_or_preparation_rejected(self):
        for key, value in (("layout_id", 4), ("source_sequence", [0, 1, 3, 2, 4, 5, 6]),
                           ("source_id", "fasten_screws_b0_l4_synthetic"),
                           ("required_accounted_prefix", [0, 1, 2, 3])):
            d, b = fixture()
            b["next_preparation"]["prepared"]["source"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                owner.reserve(d, b, AT)
        d, b = fixture()
        b["legacy_prefix_review"]["preparation_ref"]["sha256"] = "b" * 64
        with self.assertRaises(ValueError):
            owner.reserve(d, b, AT)

    def test_original_active_quota_and_wall_guards(self):
        for key, value in (("active_run_id", "live"), ("active_real_simulators", 1),
                           ("user_pause_active", True), ("launch_inflight", True)):
            d, b = fixture()
            d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                owner.reserve(d, b, AT)
        d, b = fixture()
        d["tasks"][prefix.TASK]["negative_count"] = 10
        with self.assertRaises(ValueError):
            owner.reserve(d, b, AT)
        d, b = fixture()
        d["nodes"]["perdon-hou"]["current_dispatch"]["teacher_wall_seconds"] = 7200
        with self.assertRaises(ValueError):
            owner.reserve(d, b, AT)

    def test_changed_original_seam_fails_closed(self):
        for module in (boundary, reserve_entry, scheduler):
            with self.subTest(module=module.__name__), patch.object(Path, "read_bytes", return_value=b"changed"):
                with self.assertRaises(ValueError):
                    module.source()

    def test_bound_entries_compile_and_preserve_resource_checks(self):
        text = boundary.source()
        ast.parse(text)
        ast.parse(reserve_entry.source())
        ast.parse(scheduler.source())
        for guard in ("fg.host()", "fg.allocation()", "fg.helpers().memory_headroom(120)",
                      "fcntl.LOCK_EX|fcntl.LOCK_NB", "ident['start_ticks']",
                      "disks[str(run)]>30*1024**3", "'native_kit_extensions':[]"):
            self.assertIn(guard, text)
        self.assertLess(text.index("validate_review(review"), text.index("run.mkdir()"))
        self.assertLess(text.index("validate_review(review"), text.index("allocation=fg.allocation()"))
        self.assertIn("import fasten_owner_reservation_handoff_v1 as helper", reserve_entry.source())

    def test_bad_review_actual_boundary_rejects_before_directory_or_resources(self):
        _, b = fixture()
        review = b["legacy_prefix_review"]
        review["parent_reported_used_prefix"] = [0]
        prepared = b["next_preparation"]["prepared"]
        args = dict(prior_source_run="synthetic_prior", run_id="synthetic_new",
                    task=prefix.TASK, native_budget=1900,
                    preparation_ref=REF, legacy_prefix_ref={"synthetic": "review"})
        resource_calls = []
        fg = types.SimpleNamespace(host=lambda: None,
                                   allocation=lambda: resource_calls.append("allocation"))
        modules = {
            "collect_recording_content_v1": types.SimpleNamespace(core=types.SimpleNamespace(foreground=fg)),
            "task_configured_binding": types.SimpleNamespace(load_native_layout=lambda p: None),
            "common_runtime": types.SimpleNamespace(
                read_pin=lambda ref: ref,
                document=lambda ref: prepared if ref == REF else review),
            "preparation_metadata_compat_v4": types.SimpleNamespace(),
        }
        with tempfile.TemporaryDirectory(prefix="refate_synthetic_") as directory:
            text = boundary.source().replace(str(scheduler.ROOT), directory)
            with patch.dict(sys.modules, modules), patch.object(sys, "stdin", io.StringIO(json.dumps(args))):
                with self.assertRaises(ValueError):
                    exec(compile(text, "<synthetic_boundary>", "exec"), {"__file__": boundary.__file__})
            self.assertEqual(list(Path(directory).iterdir()), [])
        self.assertEqual(resource_calls, [])


def scheduling_fixture():
    zero = dict(positive_slots=0, negative_slots=0, quota_reserved=False, negative_quota_reserved=False)
    terminal = dict(task="classify_objects", execution_owner=owner.OWNER,
                    safe_for_next_simulator=True, source_id="synthetic_classify", run_id="teacher",
                    summary_ref=REF, summary={"qualified_positive": True})
    task = dict(assigned_host="perdon-hou", assigned_role="chat2",
                reserved_count=0, negative_reserved_count=0, active_run_id=None,
                positive_quota=10, negative_quota=10, qualified_count=2, negative_count=1)
    old = dict(task, latest_segment_started_at="2026-11-01T07:00:00+00:00",
               last_core_gain_at="2026-11-01T08:30:00+00:00",
               last_negative_gain_at="2026-10-29T07:00:00+00:00")
    target = dict(task, scheduling_state="deferred", deferred_at="2026-10-30T08:00:00+00:00",
                  segment_started_at="2026-10-25T06:00:00+00:00")
    n = dict(active_chat_id=owner.OWNER, current_task="classify_objects", active_run_id=None,
             active_real_simulators=0, baseline_accounting={"baseline_attempts_running": 0},
             completed_pending_sources=[], common_pending_readback_run_ids=[],
             last_owned_resource_settlement=REF, fixed_tasks=["classify_objects", prefix.TASK],
             qualified_count=40, negative_count=19,
             task_segments=[dict(task="synthetic_other", ended_at="2026-11-01T06:00:00+00:00")])
    d = dict(campaign_id="refate-20261022-97baf70d5128", revision=1,
             started_at="synthetic_original_campaign", nodes={"perdon-hou": n, "h20_8": {"ns": 2**63+1}},
             tasks={"classify_objects": old, prefix.TASK: target},
             source_index={"synthetic_classify": dict(task="classify_objects", host="perdon-hou",
                 active_teacher_attempt=dict(status="settled", terminal_observation=REF, run_id="teacher"))},
             reservations={"synthetic_classify": dict(zero, status="shared_Evo_teacher_settled",
                 current_attempt_settlement=REF, current_attempt_run_id="teacher")})
    _, b = fixture()
    prepared = b["next_preparation"]["prepared"]
    prepared["binding_schema"] = "refate.common_collector.configured_task_binding.v1"
    prepared["source"]["native_bank"] = 0
    return d, terminal, prepared


class SchedulingTests(unittest.TestCase):
    def test_teacher_gain_does_not_reset_negative_clock_or_campaign(self):
        d, terminal, prepared = scheduling_fixture()
        before = deepcopy(d)
        result = scheduler.switch_due(d, terminal, REF, prepared, REF,
                                      "2026-11-01T08:31:00+00:00", "synthetic_only")
        self.assertEqual(d["started_at"], before["started_at"])
        self.assertEqual(d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for field in ("source_index", "reservations"):
            self.assertEqual(d[field], before[field])
        old = d["tasks"]["classify_objects"]
        self.assertEqual(old["last_negative_gain_at"], before["tasks"]["classify_objects"]["last_negative_gain_at"])
        event = d["nodes"]["perdon-hou"]["task_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertFalse(event["negative_shortfall_clock_reset"])
        self.assertEqual(event["deficits"], {"positive": 8, "negative": 9})
        self.assertFalse(result["receipt"]["transition"]["source_started"])

    def test_early_or_live_run_cannot_switch(self):
        for case in ("early", "active", "unsettled", "no_other_segment"):
            d, terminal, prepared = scheduling_fixture()
            at = "2026-11-01T08:31:00+00:00"
            if case == "early":
                at = "2026-11-01T08:29:00+00:00"
            elif case == "active":
                d["nodes"]["perdon-hou"]["active_run_id"] = "live"
            elif case == "unsettled":
                terminal["safe_for_next_simulator"] = False
            else:
                d["nodes"]["perdon-hou"]["task_segments"] = []
            with self.subTest(case=case), self.assertRaises(AssertionError):
                scheduler.switch_due(d, terminal, REF, prepared, REF, at, "synthetic_only")


def deny_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.", "os.system", "os.posix_spawn")) or event in ("os.kill", "os.killpg"):
        raise RuntimeError("Synthetic CPU metadata test cannot contact or start a peer")


if __name__ == "__main__":
    sys.addaudithook(deny_live_effects)
    unittest.main()
