"""Synthetic CPU bookkeeping only; no live ledger, peers, model or simulator."""
import ast
import hashlib
from pathlib import Path
import unittest

import switch_dolls_teacher_to_general_l23_v1 as switch
import due_general_l23_from_dolls_boundary_v1 as boundary
import test_dolls_bottles_revisit_v1 as legacy

legacy.NEXT = "general_pickup"
legacy.switch_due = switch.switch_due


class DueGeneralTests(legacy.DueBottlesTests):
    def setUp(self):
        super().setUp()
        self.d["tasks"]["general_pickup"]["qualified_count"] = 10
        self.prep["native_step_limit"] = 200
        self.prep["source"].update(
            layout_id=23, source_sequence=[1, 2, 3, 4, 0] + list(range(5, 24)),
            required_accounted_prefix=[1, 2, 3, 4, 0] + list(range(5, 23)))

    def test_boundary_reuses_original_resource_checks_and_release(self):
        expected = boundary.previous.source().replace(boundary.OLD, boundary.NEW, 1)
        expected = expected.replace("fasten_screws", "sort_nesting_dolls_by_size", 1)
        self.assertEqual(boundary.source(), expected)
        ast.parse(expected)
        for seam in ("checks+=latest['own_process_checks']", "memory_headroom(120)",
                     "b['general_previous_preparation']", "teacher['summary_ref'] if teacher else None",
                     "ns['required_accounted_prefix']==ps['source_sequence']",
                     "'b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131'"):
            self.assertIn(seam, expected)

    def test_only_missing_independent_negative_branch_selected(self):
        self.d["tasks"]["general_pickup"]["qualified_count"] = 9
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["tasks"]["general_pickup"]["negative_count"] = 10
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_exact_original_switch_except_declared_parameters(self):
        path = Path(switch.__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
        raw = path.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), switch.PARENT_SHA)
        expected = raw.decode()
        for old, new in switch.CHANGES:
            expected = expected.replace(old, new)
        self.assertEqual(switch.source(), expected)


if __name__ == "__main__":
    unittest.main()
