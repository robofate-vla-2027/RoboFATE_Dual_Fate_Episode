"""Original Insert prefix and split checks, with an explicit new executor."""
from pathlib import Path
import hashlib
import common_owner_reservation_v3 as previous
from common_owner_reservation_v3 import (
    _settled_predecessor, _inherited_prefix, _insert_checkpoint,
    _conditional_prefix, _dispatch_split, append_manifest,
)
from owner_reservation_handoff_v1 import historical_preparer_allowed

assert hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() == "c01ea84ad0b6de9f27f53bd3ba22fedad514552a67aeec884af1776ee795d588"
text = previous._text
for before, after in (
    ("OWNER = '01a16807-8085-7903-be07-66eb332ebf95'",
     "OWNER = '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'"),
    ("and source['execution_owner'] == OWNER", "and historical_preparer_allowed(source)"),
):
    assert text.count(before) == 1
    text = text.replace(before, after, 1)
exec(compile(text, str(Path(__file__)) + "::original_insert_reservation", "exec"), globals())
