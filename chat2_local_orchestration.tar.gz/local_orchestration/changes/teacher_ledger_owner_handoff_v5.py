"""Same owner-safe accounting transaction, adding only the Fasten1900 tuple."""
from pathlib import Path
import sys
import teacher_ledger_owner_handoff_v4 as previous

collection_groups = previous.collection_groups
_BINDINGS = dict(previous._BINDINGS)
_BINDINGS["fasten_screws"] = (
    1900, r"c2_fasten_screws_l[0-9]+_evo_common_teacher_[0-9]{4}_01a16807")
_TEXT = previous._TEXT
exec(compile(_TEXT, str(Path(__file__)) + "::fasten1900_executor_transaction", "exec"), globals())


def bind_cli(cli):
    current = sys.modules[__name__]
    previous.bind_cli(cli)
    assert cli.ledger_core is previous and cli._transaction.ledger_core is previous
    cli.ledger_core = current
    cli._transaction.ledger_core = current
    assert cli._transaction.compute.__globals__["ledger_core"] is current
