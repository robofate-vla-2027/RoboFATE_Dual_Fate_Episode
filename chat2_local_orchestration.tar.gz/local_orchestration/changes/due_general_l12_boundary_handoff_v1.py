"""Keep the source/resource predecessor checks, with General L12 parameters."""
import hashlib
from pathlib import Path
import due_general_l10_boundary_handoff_v1 as previous

PARENT_SHA = "6e1a6f7c43b7f338175048cc65e585548dfa24f11a30470d2d1b65421521a3a8"
OLD = "prepared['source']['layout_id']==10 and prepared['source']['source_sequence']==[1,2,3,4,0,5,6,7,8,9,10]"
NEW = "prepared['source']['layout_id']==12 and prepared['source']['source_sequence']==[1,2,3,4,0,5,6,7,8,9,10,11,12]"


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Frozen General resource-boundary helper changed")
    text = previous.source()
    if text.count(OLD) != 1:
        raise ValueError("Original General boundary parameter seam changed")
    return text.replace(OLD, NEW, 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general_l12_boundary", "exec"), globals())
