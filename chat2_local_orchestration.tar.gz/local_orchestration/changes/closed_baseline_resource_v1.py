"""Owner metadata only: verify a closed independent-baseline predecessor."""
from pathlib import Path
import hashlib
import json


def need(ok, message):
    if not ok:
        raise ValueError(message)


def document(ref):
    need(set(ref) == {'path', 'sha256'}, 'Invalid reference')
    p = Path(ref['path'])
    need(p.is_file() and p.stat().st_size < 4 * 1024**2, 'Invalid bounded document')
    raw = p.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == ref['sha256'], 'Reference changed')
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'Duplicate key')
            out[key] = value
        return out
    value = json.loads(raw, object_pairs_hook=pairs)
    need(isinstance(value, dict), 'Invalid document type')
    return value


def baseline_checks(evidence):
    need(evidence.get('schema') == 'refate.common_baseline.main_settlement.v1'
         and evidence.get('data_kind') == 'actual'
         and evidence.get('safe_for_next_simulator') is True, 'Not a closed baseline')
    checks = evidence['process_closure']['checks']
    need(len(checks) == 2 and {v['role'] for v in checks} == {'native', 'policy'}, 'Wrong launched roles')
    for row in checks:
        identity = row['identity']
        need(row.get('original_process_absent') is True, 'Owned process remains')
        need(all(type(identity.get(k)) is int and identity[k] > 0 for k in ('pid', 'start_ticks'))
             and isinstance(identity.get('boot_id'), str) and bool(identity['boot_id']), 'Missing stable identity')
    return checks


def verify_ledger_predecessor(ledger, boundary, read_document=document):
    current = boundary['resource_predecessor']
    e = read_document(current['ref'])
    baseline_checks(e)
    need(e['execution_owner'] == '01a16807-8085-7903-be07-66eb332ebf95', 'Owner mismatch')
    need(e['source_id'] == current['source_id'] and e['run_id'] == current['run_id']
         and e['summary_ref'] == current['summary_ref'], 'Resource evidence mismatch')
    source = ledger['source_index'][e['source_id']]
    row = ledger['reservations'][e['source_id']]
    need(source['host'] == 'perdon-hou' and source['task'] == e['task'] == 'arrange_largest_number'
         and source['run_id'] == e['run_id'] and source['context'] == e['context']
         and source['settlement'] == current['ref'] and row['settlement'] == current['ref'], 'Source scope mismatch')
    need(row['status'] in ('settled_native_failure_no_quota', 'settled_qualified_negative')
         and row['run_id'] == e['run_id'] and row['positive_slots'] == row['negative_slots'] == 0,
         'Baseline reservation remains')
    return True
