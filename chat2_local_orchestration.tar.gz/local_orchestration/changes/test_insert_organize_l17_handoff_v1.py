"""Synthetic CPU scheduling tests; no real ledger, model, network or Native."""
import ast
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import switch_insert_to_organize_l17_handoff_v1 as binding
import test_organize_revisit_handoff_v1 as original_tests


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.", "os.spawn")) or event in (
            "os.system", "os.fork", "os.posix_spawn", "os.kill", "os.killpg"):
        raise AssertionError("Offline synthetic test forbids live effects")


sys.addaudithook(reject_live)


def switch_function():
    node = next(n for n in ast.parse(binding.source()).body
                if isinstance(n, ast.FunctionDef) and n.name == "switch_due")
    namespace = {}
    exec(compile(ast.Module(body=[node], type_ignores=[]), "synthetic_l17", "exec"),
         namespace)
    return namespace["switch_due"]


class OriginalBehavior(original_tests.OrganizeMetadataTests):
    def setUp(self):
        self.replacement = patch.object(original_tests, "switch_function", switch_function)
        self.replacement.start()
        self.addCleanup(self.replacement.stop)

    def test_only_prepared_source_description_changed(self):
        old = Path(binding.__file__).with_name(
            "switch_insert_to_organize_handoff_v1.py").read_text()
        self.assertEqual(binding.source(), old.replace(
            "next unused prepared L13, budget1000",
            "next unused prepared L17, budget1000", 1))

    def test_runtime_pin_change_rejected(self):
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed pin"):
            with self.assertRaises(ValueError):
                binding.source()

    def test_l17_description_and_existing_clocks(self):
        b = self.fixture()
        original_clock = b.t["last_core_gain_at"]
        trigger = dict(trigger="negative_only_five_consecutive_independent_DM_failures",
                       negative_shortfall_clock_reset=False)
        result = switch_function()(b.d, b.e, b.ref, original_tests.AT,
                                   lambda d, sid: trigger)
        self.assertIn("prepared L17, budget1000", result["receipt"]["transition"]["reason"])
        self.assertEqual(b.t["last_core_gain_at"], original_clock)
        self.assertFalse(result["receipt"]["transition"]["negative_lowyield_counters_reset"])


if __name__ == "__main__":
    unittest.main()
