"""Offline Fasten metadata checks with synthetic failures and no live peers."""
import ast
import hashlib
import sys
import unittest


def offline(event, args):
    if (event.startswith("socket.") and event != "socket.gethostname") or event.startswith("subprocess.") or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata cannot execute peers or processes")


sys.addaudithook(offline)
import teacher_prepare_metadata_handoff_v5 as prepare
import teacher_reserve_handoff_v6 as reserve
import teacher_bind_handoff_v5 as bind
import teacher_terminal_handoff_v6 as terminal
import teacher_settle_handoff_v6 as settle
import native_teacher_content_v6 as native


class FastenMetadataTests(unittest.TestCase):
    def test_only_explicit_matching_entry_references_changed(self):
        for module in (prepare, reserve, bind, terminal, settle):
            with self.subTest(module=module.__name__):
                text = module.source()
                ast.parse(text)
                for old, new in reversed(module.CHANGES):
                    self.assertEqual(text.count(new), 1)
                    text = text.replace(new, old, 1)
                self.assertEqual(text, module.previous.source())

    def test_original_budget_and_refusal_guards_remain(self):
        text = reserve.source()
        for guard in ("remaining==total-t1", "native_wall_seconds=3600",
                      "teacher_wall_seconds=3600", "not s.get('provider_safety_refusal')",
                      "original_segment_started_at=t['latest_segment_started_at']"):
            self.assertIn(guard, text)
        self.assertIn("'fasten_screws':'fasten'", text)
        self.assertIn("import prepare_teacher_content_v6 as prep", bind.source())

    def test_pre_actor_mismatch_is_still_failure_with_exact_native_identity(self):
        text = terminal.source()
        sha = hashlib.sha256(native.text.encode()).hexdigest()
        self.assertIn(sha, text)
        node = next(n for n in ast.parse(text).body
                    if isinstance(n, ast.FunctionDef) and n.name == "verified_pre_actor_failure")
        namespace = {}
        exec(compile(ast.Module(body=[node], type_ignores=[]), "<synthetic-Fasten-failure>", "exec"), namespace)
        check = namespace[node.name]
        context = {"source_id": "synthetic", "run_id": "synthetic-run",
                   "t1": 27, "native_limit": 1900, "remaining_steps": 1873}
        failure = {"source_id": "synthetic", "run_id": "synthetic-run",
                   "stage": "initial_boundary_saved", "type": "RuntimeError",
                   "message": "Restored physical/discrete state mismatch",
                   "native_used": 27, "actual_control_steps": 270,
                   "native_done": False, "native_success": False}
        comparison = {"all_compared_fields_within_candidate_rules": False,
                      "context_budget": {"total": 1900, "t1": 27, "remaining": 1873}}
        self.assertTrue(check(context, failure, comparison, {"synthetic_actor": False}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": True}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": False}, "0" * 64))
        failure["native_success"] = True
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": False}, sha))


if __name__ == "__main__":
    unittest.main()
