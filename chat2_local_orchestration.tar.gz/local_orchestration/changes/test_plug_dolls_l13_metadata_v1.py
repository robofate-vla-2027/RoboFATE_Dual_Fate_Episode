"""Synthetic CPU metadata only; no real ledger, network, model or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import unittest
from unittest.mock import patch

import test_fasten_general_boundary_v1 as fixtures
import switch_plug_baseline_to_dolls_l13_v1 as scheduling
import due_dolls_l13_boundary_v1 as boundary

OLD, NEXT = "plug_in_charger", "sort_nesting_dolls_by_size"


def rename(value):
    if isinstance(value, str):
        return value.replace("fasten_screws", OLD).replace("general_pickup", NEXT)
    if isinstance(value, list):
        return [rename(item) for item in value]
    if isinstance(value, dict):
        return {rename(key): rename(item) for key, item in value.items()}
    return value


class MetadataTests(unittest.TestCase):
    def setUp(self):
        f = fixtures.ClosedFastenTests()
        f.setUp()
        self.f = f
        self.d, self.e, self.prep = rename(f.d), rename(f.e), rename(f.prep)
        self.prep["native_step_limit"] = 1050
        self.prep["source"].update(layout_id=13, source_sequence=list(range(14)),
                                   required_accounted_prefix=list(range(13)),
                                   split="student_train")

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.f.ref, self.prep, self.f.f.prep_ref,
            at or self.f.f.at, "Synthetic metadata; zero scientific credit")

    def test_counts_peers_history_and_nanoseconds_preserved(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))

    def test_teacher_gain_does_not_reset_negative_window(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_recent_negative_and_missing_segments_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["tasks"][OLD].update(last_core_gain_at="2026-10-31T11:30:00+00:00",
                                    last_negative_gain_at="2026-10-31T11:30:00+00:00")
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_resources_or_unsettled_source_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"),
                           ("active_real_simulators", 1), ("launch_inflight", True),
                           ("user_stop", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.switch()

    def test_wrong_source_budget_scope_and_duplicates_rejected(self):
        for key, value in (("layout_id", 28), ("source_sequence", list(range(13))),
                           ("required_accounted_prefix", list(range(12)))):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        for key, value in (("host", "foreign"), ("context", {}), ("settlement", {})):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 700
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_qualified_negative_not_recounted(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        self.assertEqual(self.switch()["receipt"]["negative_delta"], 0)

    def test_resource_tail_and_clocks_unchanged(self):
        text = boundary.source()
        old = boundary.previous.source()
        start = "boot=Path('/proc/sys/kernel/random/boot_id')"
        self.assertEqual(text[text.index(start):], old[old.index(start):])
        ast.parse(text)
        expected = scheduling.previous.source()
        for before, after in scheduling.CHANGES:
            expected = expected.replace(before, after)
        self.assertEqual(scheduling.source(), expected)

    def test_changed_dependency_pins_rejected(self):
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed pin"):
            with self.assertRaises(ValueError):
                scheduling.source()
            with self.assertRaises(ValueError):
                boundary.source()


if __name__ == "__main__":
    unittest.main()
