"""Same Native logic and content recorder, with the Fasten1900 task catalog."""
from pathlib import Path
import native_teacher_content_v5 as previous

text = previous.text
if text.count("teacher_catalog_binding_v12") != 3:
    raise ValueError("Frozen Native catalog sites changed")
text = text.replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v13")
exec(compile(text, str(Path(__file__).with_name("native_shared_teacher.py")) +
             "::fasten1900_content", "exec"), globals())
