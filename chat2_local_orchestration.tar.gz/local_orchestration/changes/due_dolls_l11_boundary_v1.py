"""Reuse the existing separate source/resource boundary for prepared Dolls L11."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"):
        raise ValueError("Frozen resource-boundary helper changed")
    text = raw.decode().replace("sort_nesting_dolls_by_size", "pick_from_conveyor_by_image")
    text = text.replace("put_bottles_into_dustbin", "sort_nesting_dolls_by_size")
    for old, new in (
        ("prepared['native_step_limit']==700", "prepared['native_step_limit']==1050"),
        ("assert x['from_task']=='pick_from_conveyor_by_image'",
         "assert x['from_task']=='pick_from_conveyor_by_image'\n"
         "assert prepared['source']['layout_id']==11 and prepared['source']['source_sequence']==list(range(12))"),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen resource-boundary parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::dolls_l11_boundary", "exec"),
         globals())
