"""Synthetic shape of the current ledger, not the real ledger itself."""
from copy import deepcopy
import unittest

import positive_gap_node_schema_v2 as schema

schema.install()
import test_baseline_positive_gap_v1 as shared


class NodeSchemaTests(unittest.TestCase):
    def test_node_without_task_reservation_field_can_reserve(self):
        ledger, boundary = shared.positive_reservation()
        node = ledger["nodes"]["perdon-hou"]
        del node["reserved_count"]
        before = deepcopy(ledger)
        out, dispatch = shared.reserve_new(ledger, boundary, "2026-10-26T12:00:01+00:00")
        self.assertEqual(dispatch["negative_slots"], 0)
        self.assertNotIn("reserved_count", out["nodes"]["perdon-hou"])
        self.assertEqual(ledger, before)

    def test_node_without_task_reservation_field_can_settle_backup(self):
        ledger, evidence = shared.positive_settlement(True)
        del ledger["nodes"]["perdon-hou"]["reserved_count"]
        out, receipt = shared.settle_new(ledger, evidence, "synthetic-time")
        self.assertEqual(receipt["negative_delta"], 0)
        self.assertEqual(receipt["backup_negative_delta"], 1)
        self.assertNotIn("reserved_count", out["nodes"]["perdon-hou"])
        self.assertEqual(out["tasks"][evidence["task"]]["negative_count"], 10)

    def test_missing_task_reservation_field_is_not_assumed_zero(self):
        ledger, boundary = shared.positive_reservation()
        del ledger["tasks"]["plug_in_charger"]["reserved_count"]
        with self.assertRaises(ValueError):
            shared.reserve_new(ledger, boundary, "2026-10-26T12:00:01+00:00")

    def test_full_node_positive_quota_still_rejected(self):
        ledger, boundary = shared.positive_reservation()
        node = ledger["nodes"]["perdon-hou"]
        del node["reserved_count"]
        node["qualified_count"] = node["positive_quota"]
        with self.assertRaises(ValueError):
            shared.reserve_new(ledger, boundary, "2026-10-26T12:00:01+00:00")

    def test_installer_idempotent_and_original_source_is_unchanged(self):
        schema.install()
        schema.install()
        self.assertIs(schema.base.positive_gap, schema.positive_gap)
        self.assertIn('scope["qualified_count"] + scope["reserved_count"]',
                      schema.base.pinned_text(schema.Path(schema.base.__file__), schema.BASE_SHA))


if __name__ == "__main__":
    unittest.main()
