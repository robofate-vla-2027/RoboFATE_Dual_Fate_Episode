"""Reuse the frozen due-revisit checks for Plug and prepared Bottles L15."""
import hashlib
from pathlib import Path

PARENT = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
PARENT_SHA256 = "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"


def source():
    raw = PARENT.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PARENT_SHA256
    text = raw.decode()
    edits = (
        ("sort_nesting_dolls_by_size", "plug_in_charger", 6),
        ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
         's["layout_id"] == 15 and s["source_sequence"] == list(range(16))', 1),
        ('s["required_accounted_prefix"] == list(range(12))',
         's["required_accounted_prefix"] == list(range(15))', 1),
    )
    for old, new, count in edits:
        assert text.count(old) == count, "Frozen scheduling seam changed"
        text = text.replace(old, new)
    return text


exec(compile(source(), str(PARENT) + "::plug_to_bottles_l15", "exec"), globals())
