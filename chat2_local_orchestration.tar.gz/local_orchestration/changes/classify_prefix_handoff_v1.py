"""Existing Classify prefix evidence; no replay, relabeling, or runtime changes."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
TASK = "classify_objects"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338")
ADAPTER = ROOT / "teacher/shared_teacher/perdon_adapter_20261026"
NEXT_SOURCE = "classify_objects_b0_l6_7858cf068d1aa9d3"
LEGACY_RUNS = {
    3: ("c2_classify_l3_hexa_t1_attempt_0001_01a16807",
        "3f253ff4ee98848ef4d89311e206689abed5bbc54870294ba37e7ffcbb87a94c"),
    4: ("c2_classify_l4_hexa_t200_attempt_0002_01a16807",
        "de93a6ed7b9d246fae989a11bdb86e60ed1a4bee43e53d21b51cff1c59d2a9a5"),
    5: ("c2_classify_l5_hexa_t100_attempt_0001_01a16807",
        "cb38f821d4662ea09c1badd8640f212101d0e29eed3484ee3c613780ca3b637f"),
}


def metadata_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":")).encode()).hexdigest()


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(pin):
    path = Path(pin["path"])
    if set(pin) != {"path", "sha256"} or not path.is_relative_to(ROOT):
        raise ValueError("Foreign metadata reference")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != pin["sha256"]:
        raise ValueError("Changed referenced metadata")
    return json.loads(raw)


def original_classify_prefix_accounted(ledger, boundary, source, ordinal):
    if (source.get("task") != TASK or source.get("source_id") != NEXT_SOURCE
            or source.get("layout_id") != 6
            or source.get("required_accounted_prefix") != [1, 2, 3, 4, 5]
            or type(ordinal) is not int or ordinal not in (1, 2, 3, 4, 5)):
        return False
    review = boundary.get("legacy_prefix_review", {})
    if (review.get("schema") != "refate.classify.original_prefix.accounted.v1"
            or review.get("next_source_id") != NEXT_SOURCE
            or review.get("preparation_ref") != boundary["next_preparation"]["ref"]
            or review.get("old_source_qualification_changed") is not False
            or review.get("old_sources_replayed") is not False
            or review.get("live_referenced_processes") != []):
        return False
    matches = [s for sid, s in ledger["source_index"].items()
               if sid.startswith(f"{TASK}_b0_l{ordinal}_") and s.get("host") == "perdon-hou"]
    entries = [e for e in review.get("entries", []) if e.get("layout") == ordinal]
    return (len(matches) == len(entries) == 1
            and entries[0]["source_id"] == matches[0]["source_id"]
            and entries[0]["source_metadata_sha256"] == metadata_hash(matches[0])
            and entries[0].get("source_consumed") is True
            and entries[0].get("new_positive") == entries[0].get("new_negative") == 0)


def observe(x):
    prepared = document(x["preparation_ref"])
    if (prepared["source"]["source_id"] != NEXT_SOURCE
            or prepared["source"]["required_accounted_prefix"] != [1, 2, 3, 4, 5]):
        raise ValueError("Wrong next frozen source")
    sources = x["sources"]
    if set(sources) != {str(i) for i in range(1, 6)}:
        raise ValueError("Complete original prefix required")
    entries, referenced_runs = [], set()
    for i in range(1, 6):
        row = sources[str(i)]
        sid = row["source_id"]
        if row["task"] != TASK or row["host"] != "perdon-hou" or not sid.startswith(f"{TASK}_b0_l{i}_"):
            raise ValueError("Wrong prefix identity")
        if i == 1:
            pin = row["negative_receipt"]
            receipt = document(pin)
            if not (row["counted_in_negative_quota"] is True
                    and row["counted_in_quota"] is False
                    and receipt["source_id"] == sid
                    and receipt["negative_qualification_status"] == "qualified"
                    and receipt["data_type"] == "dm_native_success"):
                raise ValueError("Original accepted negative not established")
            disposition = "previously_counted_independent_negative_no_new_credit"
        elif i == 2:
            attempt = row["teacher_attempt_history"][-1]
            pin = attempt["settlement"]
            receipt = document(pin)
            if not (receipt["source_id"] == sid and receipt["run_id"] == attempt["run_id"]
                    and receipt["status"] == "closed_reader_complete_nonterminal_teacher_infrastructure_abort"
                    and receipt["once_consumed"] is True
                    and receipt["original_owned_processes_absent"] is True
                    and receipt["qualification"] is False
                    and receipt["positive_delta"] == receipt["negative_delta"] == 0):
                raise ValueError("Original protected interruption not established")
            disposition = "protected_consumed_infrastructure_abort_zero_credit"
            referenced_runs.add(attempt["run_id"])
        else:
            run_id, digest = LEGACY_RUNS[i]
            path = ROOT / "parent/takeover_20261024_execution_support/teacher_takeover_repair_20261025/production/runs" / run_id / "RESULT.json"
            pin = {"path": str(path), "sha256": digest}
            receipt = document(pin)
            attempt = row["teacher_attempt_history"][-1]
            if not (attempt["run_id"] == receipt["run_id"] == run_id
                    and receipt["source_id"] == sid
                    and receipt["status"] == attempt["status"] == "teacher_wall_timeout"
                    and receipt["actor_rc"] == 124 and receipt["qualified"] is False
                    and receipt["native_terminal"] is False
                    and receipt["native_success"] is None and receipt["positive_delta"] == 0
                    and row["native_success"] is False):
                raise ValueError("Original nonterminal timeout not established")
            disposition = "consumed_teacher_wall_timeout_not_native_failure"
            referenced_runs.add(run_id)
        referenced_runs.add(row["remote_run"])
        entries.append({"layout": i, "source_id": sid,
                        "source_metadata_sha256": metadata_hash(row), "disposition": disposition,
                        "saved_disposition": pin, "source_consumed": True,
                        "new_positive": 0, "new_negative": 0})
    live = []
    for path in Path("/proc").glob("[0-9]*/cmdline"):
        try:
            cmdline = path.read_bytes()
            matches = sorted(run for run in referenced_runs if run.encode() in cmdline)
            if matches:
                stat = (path.parent / "stat").read_text().rsplit(")", 1)[1].split()
                live.append({"pid": int(path.parent.name), "start_ticks": int(stat[19]),
                             "referenced_runs": matches})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    if live:
        raise ValueError("Referenced legacy processes remain; no launch authority: " + json.dumps(live))
    result = {
        "schema": "refate.classify.original_prefix.accounted.v1",
        "data_kind": "actual_existing_metadata_not_new_scientific_data",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": OWNER, "next_source_id": NEXT_SOURCE,
        "preparation_ref": x["preparation_ref"], "metadata_helper": ref(Path(__file__)),
        "entries": entries, "live_referenced_processes": live,
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "old_source_qualification_changed": False, "old_sources_replayed": False,
        "source_reserved": False, "actual_launch": False, "new_positive": 0, "new_negative": 0,
    }
    path = ADAPTER / "task_sources/classify_objects/LEGACY_PREFIX_L1_L5_ACCOUNTED_001.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    result["evidence_ref"] = ref(path)
    return result


def reserver():
    sys.path.insert(0, str(ADAPTER))
    import owner_reservation_handoff_v1 as original
    seam = "_inherited_prefix(ledger, b, source, i)"
    if original.text.count(seam) != 1:
        raise ValueError("Original prefix reservation seam changed")
    namespace = dict(original.__dict__)
    namespace["original_classify_prefix_accounted"] = original_classify_prefix_accounted
    text = original.text.replace(seam, "(" + seam + " or original_classify_prefix_accounted(ledger, b, source, i))", 1)
    exec(compile(text, str(ADAPTER / "common_owner_reservation.py") + "::classify_legacy_prefix", "exec"), namespace)
    return namespace["reserve"]


def main():
    def metadata_only(event, args):
        if event in ("socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                     "os.kill", "os.killpg"):
            raise RuntimeError("Metadata only: " + event)
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    if x.pop("mode") != "observe":
        raise ValueError("Observation only; reservation is called at a later closed boundary")
    print(json.dumps(observe(x)))


if __name__ == "__main__":
    main()
