"""Synthetic metadata tests; no simulator, model, API, or subprocess execution."""
import ast
from pathlib import Path
import unittest


ROOT = Path(__file__).parent


class OrganizeAppendTests(unittest.TestCase):
    def test_original_group_split(self):
        p = ROOT / "prepare_next_organize_handoff_v1.py"
        tree = ast.parse(p.read_bytes())
        function = next(n for n in tree.body
                        if isinstance(n, ast.FunctionDef)
                        and n.name == "select_new_group_split")
        namespace = {}
        exec(compile(ast.Module(body=[function], type_ignores=[]), str(p), "exec"),
             namespace)
        select = namespace["select_new_group_split"]
        self.assertEqual(select({"a": {"split": "student_train"}}), "student_dev")
        self.assertEqual(select({"a": {"split": "student_train"},
                                 "b": {"split": "student_dev"}}), "student_train")
        with self.assertRaises(AssertionError):
            select({"sealed": {"split": "sealed_eval"}})

    def test_native_budget_source_order_and_identity_separation(self):
        text = (ROOT / "prepare_next_organize_handoff_v1.py").read_text()
        self.assertIn("prepared['native_step_limit']==1000", text)
        self.assertIn("old['initial_source_sequence']==old['materialized_layouts']==list(range(i))", text)
        self.assertIn("i not in old['original_partition']['reserved_final']", text)
        self.assertIn("m['original_partition']==old['original_partition']", text)
        self.assertIn("canonical_descriptor_identity_is_not_current_executor=True", text)
        self.assertIn("execution_owner=execution.NEW", text)
        self.assertIn("with p.open('x')", text)

    def test_both_helpers_preserve_metadata_only_guard(self):
        for name in ("review_next_organize_handoff_v1.py",
                     "prepare_next_organize_handoff_v1.py"):
            text = (ROOT / name).read_text()
            ast.parse(text)
            self.assertIn("sys.addaudithook(reject_live_effect)", text)
            self.assertIn("'subprocess.'", text)
            self.assertIn("'os.kill'", text)
            self.assertIn("assert x['execution_owner'] == execution.NEW", text)


if __name__ == "__main__":
    unittest.main()
