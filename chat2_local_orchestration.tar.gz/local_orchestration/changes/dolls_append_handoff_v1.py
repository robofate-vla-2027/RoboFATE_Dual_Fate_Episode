"""Reuse the saved Dolls metadata scripts with an explicit current executor."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher")
ADAPTER = ROOT / "perdon_adapter_20261026"
ARCHIVE = ROOT / "preparations/MAIN_DOLLS_APPEND_METADATA_HELPERS_20261030_2113_002.json"
ARCHIVE_SHA = "ffe9ce5c7e523ae7bd054aec4de4e8f36541acb757a8053e3007d119b258ea4b"
EXECUTOR = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def script(mode, archive):
    if mode not in ("prepare", "register"):
        raise ValueError("Unknown metadata operation")
    text = archive[mode]
    if mode == "register":
        old = "n['active_chat_id']==m.OWNER"
        if text.count(old) != 1:
            raise ValueError("Archived executor interface changed")
        text = text.replace(old, "n['active_chat_id']==EXECUTOR", 1)
    return text


def evaluate(text, arguments):
    output = io.StringIO()
    old_input = sys.stdin
    try:
        sys.stdin = io.StringIO(json.dumps(arguments))
        with contextlib.redirect_stdout(output):
            exec(compile(text, str(ARCHIVE) + "::metadata_handoff", "exec"),
                 {"__name__": "__main__", "EXECUTOR": EXECUTOR})
    finally:
        sys.stdin = old_input
    return json.loads(output.getvalue())


def put(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


def reject_live_effect(event, args):
    if (event.startswith("socket.") and event != "socket.gethostname") or event in (
        "subprocess.Popen", "os.system", "os.fork", "os.posix_spawn"):
        raise RuntimeError("METADATA_ONLY " + event)


def main():
    sys.addaudithook(reject_live_effect)
    sys.path.insert(0, str(ADAPTER))
    import execution_owner_binding_v1 as execution
    handoff = execution.install()
    args = json.load(sys.stdin)
    assert args["execution_owner"] == EXECUTOR
    raw = ARCHIVE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ARCHIVE_SHA
    mode = args["operation"]
    text = script(mode, json.loads(raw))
    if mode == "prepare":
        i = args["layout"]
        assert type(i) is int and 7 <= i < 28
        task_root = ADAPTER / "task_sources/sort_nesting_dolls_by_size"
        paths = [task_root / f"SPLIT_APPEND_L{i}_001.json",
                 task_root / f"PREPARATION_L{i}_CONFIGURED_001.json",
                 ROOT / f"preparations/DOLLS_L{i}_SOURCE_REGISTRATION_PREPARATION_001.json"]
        assert not any(p.exists() for p in paths), "Inspect existing preparation; do not recreate"
        result = evaluate(text, args)
        prepared = json.loads(Path(result["preparation_ref"]["path"]).read_bytes())
        record = {
            "schema": "refate.source_preparation.execution_handoff.v1",
            "data_kind": "actual_source_metadata_not_execution",
            "execution_owner": EXECUTOR,
            "source_owner": prepared["source"]["source_owner"],
            "canonical_descriptor_legacy_execution_owner": prepared["source"]["execution_owner"],
            "canonical_descriptor_identity_is_not_current_executor": True,
            "source_id": result["source_id"],
            "layout": i,
            "native_budget": 1050,
            "preparation": result["preparation_ref"],
            "split": result["append_manifest"],
            "predecessor_split": args["prior_manifest"],
            "handoff": handoff,
            "archived_metadata_helpers": ref(ARCHIVE),
            "actual_metadata_check": result["actual_metadata_check"],
            "original_split_owners_preserved": True,
            "source_reserved": False,
            "actual_launch": False,
            "positive_delta": 0,
            "negative_delta": 0,
        }
        evidence = put(task_root / f"APPEND_L{i}_EXECUTION_HANDOFF_01a19072_001.json", record)
        result.update(execution_owner=EXECUTOR, execution_handoff=evidence)
    elif mode == "register":
        pin = args["execution_handoff"]
        path = Path(pin["path"])
        assert ref(path) == pin
        record = json.loads(path.read_bytes())
        assert record["execution_owner"] == EXECUTOR and record["handoff"] == handoff
        assert record["actual_metadata_check"] == args["preparation_check"]
        result = evaluate(text, args)
        assert result["receipt"]["source_id"] == record["source_id"]
        result["receipt"].update(execution_owner=EXECUTOR, execution_handoff=pin)
        if not result["receipt"]["idempotent_reuse"]:
            event = result["ledger"]["tasks"]["sort_nesting_dolls_by_size"]["source_registration_history"][-1]
            event.update(execution_owner=EXECUTOR, execution_handoff=pin)
    else:
        raise ValueError("Unknown metadata operation")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
