"""Reuse the frozen Bottles boundary with a settled Plug resource predecessor."""
import hashlib
from pathlib import Path

PARENT = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
PARENT_SHA256 = "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"


def source():
    raw = PARENT.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PARENT_SHA256
    text = raw.decode()
    old = "assert x['from_task']=='sort_nesting_dolls_by_size'"
    assert text.count(old) == 1, "Frozen boundary source-task seam changed"
    return text.replace(old, "assert x['from_task']=='plug_in_charger'", 1)


if __name__ == "__main__":
    exec(compile(source(), str(PARENT) + "::settled_plug_predecessor", "exec"), globals())
