"""Same terminal accounting, with the owner-safe General200 parameter tuple."""
from pathlib import Path
import common_runtime as runtime


def source():
    path = Path(__file__).with_name("teacher_settle_handoff_v4.py")
    text = runtime.read_pin({"path": str(path), "sha256":
        "47fe8f07444e1e55881393c0ffae48ff2a8ba108b1d3e41ca5fdd49517e8393b"}).decode()
    return runtime.edit(text, "import teacher_ledger_owner_handoff_v3 as owner_core",
                        "import teacher_ledger_owner_handoff_v4 as owner_core")


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general200_metadata", "exec"), globals())
