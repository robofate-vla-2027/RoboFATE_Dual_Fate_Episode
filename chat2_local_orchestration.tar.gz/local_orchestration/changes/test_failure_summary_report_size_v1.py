"""Synthetic file metadata CPU tests; no real reports, model or simulator."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


def offline(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata only")


sys.addaudithook(offline)
HERE = Path(__file__).resolve().parent
FROZEN = HERE / "failure_summary_binding.py"
if not FROZEN.exists():
    FROZEN = HERE.parent / "snapshot/failure_summary_binding.py"


class MetadataSizeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="refate_synthetic_report_")
        self.root = Path(self.tmp.name).resolve()
        for name, raw in (
                ("failure_summary_binding.py", FROZEN.read_bytes()),
                ("failure_summary_report_size_v1.py", (HERE / "failure_summary_report_size_v1.py").read_bytes())):
            (self.root / name).write_bytes(raw)
        runtime = types.ModuleType("common_runtime")
        runtime.document = json.loads
        stage = types.ModuleType("isolation_stage")
        stage.SHARED = self.root
        spec = importlib.util.spec_from_file_location("_synthetic_failure_size", self.root / "failure_summary_report_size_v1.py")
        self.module = importlib.util.module_from_spec(spec)
        with patch.dict(sys.modules, {"common_runtime": runtime, "isolation_stage": stage}):
            spec.loader.exec_module(self.module)
        self.report = self.root / "runs/SYNTHETIC/readback_once_001/REPORT.json"
        self.report.parent.mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def save(self, path, size=32):
        raw = json.dumps({"synthetic_ns": 1793496102759665601, "padding": " " * size}).encode()
        path.write_bytes(raw)
        return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}

    def test_long_report_is_read_without_precision_loss(self):
        ref = self.save(self.report, 9 * 1024**2)
        result = self.module.read_ref(ref)
        self.assertEqual(result["synthetic_ns"], 1793496102759665601)
        self.assertEqual(len(result["padding"]), 9 * 1024**2)

    def test_ordinary_small_document_unchanged(self):
        path = self.report.with_name("SUMMARY.json")
        ref = self.save(path)
        self.assertEqual(self.module.read_ref(ref), json.loads(path.read_bytes()))
        self.assertEqual(self.module.source().replace(self.module.NEW, self.module.OLD, 1),
                         FROZEN.read_text())

    def test_nonreport_and_oversize_report_rejected(self):
        for path, size in ((self.report.with_name("SUMMARY.json"), 9 * 1024**2),
                           (self.report, 16 * 1024**2)):
            ref = self.save(path, size)
            with self.subTest(path=path.name), self.assertRaises(ValueError):
                self.module.read_ref(ref)

    def test_wrong_hash_damaged_or_missing_metadata_rejected(self):
        ref = self.save(self.report)
        ref["sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            self.module.read_ref(ref)
        self.report.write_bytes(b"invalid-json")
        ref["sha256"] = hashlib.sha256(self.report.read_bytes()).hexdigest()
        with self.assertRaises(json.JSONDecodeError):
            self.module.read_ref(ref)
        self.report.unlink()
        with self.assertRaises(FileNotFoundError):
            self.module.read_ref(ref)

    def test_mutation_and_linked_metadata_rejected(self):
        ref = self.save(self.report)
        before = self.module.signature(self.report)
        after = list(before)
        after[-1] += 1
        with patch.object(self.module, "signature", side_effect=[before, after]):
            with self.assertRaises(ValueError):
                self.module.read_ref(ref)
        link = self.report.with_name("LINK.json")
        link.symlink_to(self.report)
        with self.assertRaises(ValueError):
            self.module.read_ref(dict(ref, path=str(link)))

    def test_pinned_parent_and_scope_remain_bounded(self):
        (self.root / "failure_summary_binding.py").write_bytes(b"changed")
        with self.assertRaises(ValueError):
            self.module.source()
        self.assertEqual(self.module._metadata_limit(self.root / "REPORT.json"), 8 * 1024**2)


if __name__ == "__main__":
    unittest.main()
