"""Same canonical bookkeeping with the explicitly handed-off execution owner."""
import hashlib
from pathlib import Path

path = Path(__file__).with_name("common_owner_settlement_v3.py")
raw = path.read_bytes()
if hashlib.sha256(raw).hexdigest() != "efc733478e834fc06f06bc4fb9901fb772d71fc1cc5e3a70963e167a0f9d2e55":
    raise ValueError("Pinned baseline bookkeeping changed")
exec(compile(raw, str(path) + "::execution_handoff", "exec"), globals())
_NAMESPACE["OWNER"] = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
