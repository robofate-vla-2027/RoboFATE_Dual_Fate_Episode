"""Separate the sequence author's handoff from immutable Insert source ownership."""
from pathlib import Path
import hashlib
import json

SOURCE_OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
EXECUTOR = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
FROZEN_SHA = "1724f8f8c46bca22c48ecf7c706a7cd26d6cda9eea05f8dc4aed7f723ad12fad"


def wrapped_prior(original, receipt):
    if not (
        receipt.get("from_chat_id") == SOURCE_OWNER
        and receipt.get("to_chat_id") == EXECUTOR
        and receipt.get("lock_inode") == 27555308
        and receipt.get("chat1_unchanged") is True
        and receipt.get("source_index_and_reservations_unchanged") is True
    ):
        raise ValueError("Original explicit execution handoff required")

    def prior(history, anchor, base, split, sequence, sequence_ref):
        class History:
            def __getattr__(self, name):
                return getattr(history, name)

            def same(self, value, **expected):
                # Only this exact sequence document can have the new author.
                if value is sequence and expected.get("owner_chat") == SOURCE_OWNER:
                    if sequence.get("owner_chat") == EXECUTOR:
                        expected = dict(expected, owner_chat=EXECUTOR)
                return history.same(value, **expected)

        return original(History(), anchor, base, split, sequence, sequence_ref)

    prior._refate_insert_original_prior = original
    return prior


def install():
    import execution_owner_binding_v1 as execution
    import source_sequence_binding as sequence

    handoff = execution.install()
    if hashlib.sha256(Path(sequence.__file__).read_bytes()).hexdigest() != FROZEN_SHA:
        raise ValueError("Frozen Insert sequence validator changed")
    receipt = json.loads(Path(handoff["path"]).read_bytes())
    current = sequence._prior
    if not hasattr(current, "_refate_insert_original_prior"):
        sequence._prior = wrapped_prior(current, receipt)
    return handoff
