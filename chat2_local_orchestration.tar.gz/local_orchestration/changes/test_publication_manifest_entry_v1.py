"""Offline actual-entry regression with only synthetic ledger/publication peers."""
import ast
import unittest
from unittest.mock import patch
import test_teacher_fasten_accounting_v1 as original
import publication_manifest_size_v1 as manifest_metadata
import teacher_settle_handoff_v7 as entry

cli = original.cli
manifest_metadata.bind_cli(cli)
original.core.bind_cli(cli)


class ActualEntryTests(original.FastenAccountingTests):
    def test_real_cli_interface_reuses_mocked_small_verdict_without_decode(self):
        # File validation is covered separately; these peers are synthetic documents.
        with patch.object(cli._transaction, "_read_publication_manifest",
                          side_effect=lambda ref, context: cli.r.document(ref)):
            super().test_real_cli_interface_reuses_mocked_small_verdict_without_decode()

    def test_actual_settlement_source_changes_only_manifest_binding(self):
        text = entry.source()
        ast.parse(text)
        self.assertEqual(text.replace(entry.NEW, entry.OLD, 1), entry.previous.source())
        self.assertIn("_read_publication_manifest", cli._transaction.compute.__code__.co_names)
        self.assertIn("_publication_verdict", cli._transaction.compute.__code__.co_names)
        self.assertIs(cli._transaction.compute.__globals__["ledger_core"], original.core)

    def test_global_reader_still_has_original_eight_mib_limit(self):
        import inspect
        import common_runtime
        self.assertIn("8*1024*1024", inspect.getsource(common_runtime.read_pin))
        self.assertNotIn("read_manifest", inspect.getsource(common_runtime.read_pin))


if __name__ == "__main__":
    unittest.main()
