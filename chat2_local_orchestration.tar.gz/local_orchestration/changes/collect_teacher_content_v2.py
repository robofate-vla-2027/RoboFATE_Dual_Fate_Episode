"""Existing foreground, reader, and publisher with the matching Classify Native entry."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import collect_teacher_content_v1 as previous

text = previous.text
for old, new in (
    ("import native_teacher_content_v1 as native", "import native_teacher_content_v2 as native"),
    ("stage.HERE/'native_teacher_content_v1.py'", "stage.HERE/'native_teacher_content_v2.py'"),
    ("from teacher_catalog_binding_v8 import restore\n", "from teacher_catalog_binding_v9 import restore\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("collect_shared_teacher.py")) +
             "::classify1100_content", "exec"), globals())
