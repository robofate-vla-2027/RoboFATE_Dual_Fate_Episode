"""Synthetic CPU metadata only; no real ledger, network, model or simulator."""
import ast
from pathlib import Path
import unittest

import test_plug_dolls_l13_metadata_v1 as original
import switch_classify_baseline_to_bottles_l26_v1 as scheduling
import due_bottles_from_classify_boundary_v1 as boundary

original.OLD, original.NEXT = "classify_objects", "put_bottles_into_dustbin"
original.scheduling, original.boundary = scheduling, boundary


class ClassifyBottlesTests(original.MetadataTests):
    def setUp(self):
        super().setUp()
        self.d["tasks"][original.OLD].update(qualified_count=6, negative_count=4)
        self.d["tasks"][original.NEXT].update(qualified_count=3, negative_count=10)
        self.prep["native_step_limit"] = 700
        self.prep["source"].update(layout_id=26, source_sequence=list(range(27)),
                                   required_accounted_prefix=list(range(26)))

    def test_wrong_source_budget_scope_and_duplicates_rejected(self):
        for key, value in (("layout_id", 28), ("source_sequence", list(range(13))),
                           ("required_accounted_prefix", list(range(12)))):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        for key, value in (("host", "foreign"), ("context", {}), ("settlement", {})):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 1050
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_resource_tail_and_clocks_unchanged(self):
        text = boundary.source()
        old = Path(boundary.__file__).with_name(
            "due_bottles_boundary_handoff_v1.py").read_text()
        start = "boot=Path('/proc/sys/kernel/random/boot_id')"
        self.assertEqual(text[text.index(start):], old[old.index(start):])
        ast.parse(text)
        self.assertIn("latest['run_id']==x['resource_run_id']", text)
        self.assertIn("assert sid==ps['source_id']", text)
        expected = scheduling.previous.source()
        for before, after in scheduling.CHANGES:
            expected = expected.replace(before, after)
        self.assertEqual(scheduling.source(), expected)

    def test_positive_gap_and_closed_source_are_not_registered_by_switch(self):
        before = dict(self.d["tasks"][original.NEXT])
        receipt = self.switch()["receipt"]
        task = self.d["tasks"][original.NEXT]
        self.assertEqual((task["qualified_count"], task["negative_count"]), (3, 10))
        self.assertEqual(task["negative_quota"], before["negative_quota"])
        self.assertFalse(receipt["transition"]["source_registered"])
        self.assertFalse(receipt["transition"]["reserved"])
        self.assertFalse(receipt["transition"]["source_started"])


if __name__ == "__main__":
    unittest.main()
