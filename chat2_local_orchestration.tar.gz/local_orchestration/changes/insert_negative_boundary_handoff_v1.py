import sys,json,hashlib,datetime,fcntl,os,base64
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import collect_recording_content_v1 as collection;import owner_insert_reservation_handoff_v1 as reservation;import source_sequence_binding as sequence
import negative_only_boundary_handoff_v1 as negative_only
assert hashlib.sha256(Path(negative_only.__file__).read_bytes()).hexdigest()=='da192d16654e22a0e8f84bd76d58fa180f4f72527d689dff0215eac9ea6f72ed'
x=json.load(sys.stdin);fg=collection.core.foreground;fg.host();prior=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['prior_source_run'];run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];assert not run.exists()
def ref(p):p=Path(p);return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def document(r):p=Path(r['path']);assert ref(p)==r;return json.loads(p.read_text())
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
 return ref(p)
old_dispatch=json.loads((prior/'DISPATCH_001.json').read_text());split_ref=old_dispatch['split_manifest'];seq_ref=ref(prior/'SEQUENCE_EXTENSION_001.json');prep_path=Path(x['preparation_ref']['path']);prepared=document(x['preparation_ref']);sequence.load_native_layout(prepared)
assert prep_path==Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/preparations')/('INSERT_L'+str(x['layout'])+'_COMMON_PREPARATION_001.json')
assert prepared['source']['task']=='insert_tubes' and prepared['source']['layout_id']==x['layout'] and prepared['native_step_limit']==500
assert prepared['provenance']['prior_split']==split_ref and prepared['provenance']['prior_sequence']==seq_ref

def resource_checks(e):
 assert e.get('execution_owner')=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0' and e.get('safe_for_next_simulator') is True
 if e.get('schema')=='refate.common_baseline.main_settlement.v1':return negative_only.closed.baseline_checks(e)
 assert e.get('schema')=='refate.actual_terminal_observation.v1'
 checks=e['own_process_checks'];assert checks and all(v['original_process_absent'] is True for v in checks)
 return checks

def predecessor_checks(base,teacher=None):
 assert base['safe_for_next_simulator'] and base['first_readback_passed']
 checks=list(base['process_closure']['checks'])
 if teacher is None:
  if base['native_success'] is False:
   assert x.get('negative_only') is True,'A failed baseline with positive deficit still needs its teacher/defer disposition'
   checks=negative_only.check(json.loads(base64.b64decode(x['ledger_b64'])),base,ref(prior/'MAIN_SETTLEMENT_001.json'))
  else:assert base['native_success'] is True,'Unknown baseline outcome'
 else:
  assert base['native_success'] is False and teacher['source_id']==base['source_id'] and teacher['safe_for_next_simulator']
  checks.extend(teacher['own_process_checks'])
 return checks
sid=old_dispatch['source_id'];base_term=document(ref(prior/'MAIN_SETTLEMENT_001.json'));assert base_term['source_id']==sid;term=None
if x.get('prior_teacher_run'):term=document(ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['prior_teacher_run']/'MAIN_TERMINAL_OBSERVATION_001.json'))
checks=predecessor_checks(base_term,term);current_resource=document(x['current_resource_ref']);ledger=json.loads(base64.b64decode(x['ledger_b64']));assert current_resource['safe_for_next_simulator'] and current_resource['execution_owner']=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0' and ledger['nodes']['perdon-hou']['last_owned_resource_settlement']==x['current_resource_ref'];checks.extend(resource_checks(current_resource));boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for row in checks:
 ident=row['identity'];p=Path('/proc')/str(ident['pid'])/'stat';assert not(p.exists() and boot==ident['boot_id'] and int(p.read_text().rsplit(')',1)[1].split()[19])==ident['start_ticks'])
allocation=fg.allocation();memory=fg.helpers().memory_headroom(120)
with fg.LOCK.open('r+') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(lock,fcntl.LOCK_UN)
run.mkdir();at=datetime.datetime.now(datetime.timezone.utc).isoformat();peers=[]
for line in allocation['existing_processes'].splitlines():
 pid=int(line.split(',')[0]);p=Path('/proc')/str(pid);peers.append({'identity':fg.identity(pid),'uid':p.stat().st_uid,'executable':os.readlink(p/'exe')})
disks={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/',str(run)]};assert disks['/']>256*1024**2 and disks[str(run)]>30*1024**3
resource={'schema':'refate.actual_resource_precheck.v1','data_kind':'actual','at':at,'host':'perdon-hou','hostname':'nb-5pl2apckdj-0','ssh_endpoint':'root@116.198.70.4:1122','run_id':x['run_id'],'source_id':prepared['source']['source_id'],'allocation':allocation,'memory_precheck':memory,'existing_processes':peers,'disk_free_bytes':disks,'exclusive_native_lock_available':True,'estimated_native_gpu1_mib':18000,'policy_gpu0_reserve_mib':15000,'safety_headroom_mib':12000,'temporary_logs_cache_root':str(run/'runtime'),'actual_launch':False,'existing_peers_untouched':True};resource_ref=write(run/'RESOURCE_PRECHECK_001.json',resource)
oldprep_ref=old_dispatch['source_preparation'];oldprep=document(oldprep_ref);oldsplit=document(split_ref);settlement_ref=ref(prior/'MAIN_SETTLEMENT_001.json');cp={'source_id':sid,'prepared':oldprep,'preparation_ref':oldprep_ref,'settlement_ref':settlement_ref,'split_ref':split_ref,'split':oldsplit,'sequence_ref':seq_ref}
ext={'schema':'refate.insert.source_sequence_extension.v1','data_kind':'preparation_only','owner_chat':'01a19072-9e5e-7e02-b77a-8f115cfc9bd0',**prepared['sequence_extension_proposal'],'qualification':False,'source_issued':False,'launch_authority':False,'predecessor_disposition':settlement_ref};extension_ref=write(run/'SEQUENCE_EXTENSION_001.json',ext);manifest=reservation.append_manifest(prepared,oldsplit,extension_ref,at);manifest_ref=write(run/('SPLIT_MANIFEST_L'+str(x['layout'])+'_001.json'),manifest)
b={'schema':'refate.actual_boundary_preparation.v1','at':at,'next_preparation':{'prepared':prepared,'ref':ref(prep_path)},'resource_precheck':{'summary':resource,'ref':resource_ref},'settlement':{'source_id':sid,'settlement_ref':settlement_ref,'safe_for_next_simulator':True},'last_teacher_settlement':term['summary_ref'] if term else None,'runtime_release':ref('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/RUNTIME_CONTENT_RELEASE_20261031_01a19072.json'),'teacher_supplement_present':True,'insert_prefix_checkpoint':cp,'insert_sequence_publication':{'at':at,'manifest':manifest,'manifest_ref':manifest_ref,'extension_ref':extension_ref},'metadata_adapter':ref('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/owner_insert_reservation_handoff_v1.py'),'preparation_validation':ref('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/INSERT_L10_RESERVATION_PREPARATION_001.json')}
if x.get('negative_only'):
 assert base_term['native_success'] is False and term is None
 b['negative_only_boundary']=dict(checker=ref(Path(negative_only.__file__)),source_settlement=settlement_ref,positive_quota_full=True,negative_deficit_preserved=True,teacher_required=False,qualification_unchanged=True)
b['current_owned_resource_predecessor']=x['current_resource_ref'];bref=write(run/'MAIN_BOUNDARY_001.json',b)
print(json.dumps({'boundary_ref':bref,'source_id':prepared['source']['source_id'],'preparation_ref':ref(prep_path),'resource':resource}))