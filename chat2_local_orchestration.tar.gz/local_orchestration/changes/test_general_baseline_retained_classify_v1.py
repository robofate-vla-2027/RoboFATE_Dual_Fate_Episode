"""Offline synthetic bookkeeping; no real peers, models, simulation or ledger."""
import copy
import unittest

import test_general_retained_classify_v1 as fixture
import switch_general_baseline_to_retained_classify_v1 as current


class ClosedGeneralRetainedTests(unittest.TestCase):
    def setUp(self):
        fixture.RetainedClassifyTests.setUp(self)
        self.e.update(
            schema="refate.common_baseline.main_settlement.v1", data_kind="actual",
            run_id="synthetic-general-baseline", first_readback_passed=True,
            native_success=False, context={"synthetic": "current-context"},
            summary={"native_success": False, "qualified_negative": False},
            process_closure={"checks": [
                {"role": role, "original_process_absent": True,
                 "identity": {"pid": 1001 + i, "start_ticks": 2**63 + i,
                              "boot_id": "synthetic-boot"}}
                for i, role in enumerate(("native", "policy"))]})
        self.d["source_index"]["old"] = dict(
            task="general_pickup", host="perdon-hou", run_id=self.e["run_id"],
            context=copy.deepcopy(self.e["context"]), settlement=self.ref,
            original_wall_ns=1793607858783181414)
        self.d["reservations"]["old"] = dict(
            status="settled_native_failure_no_quota", run_id=self.e["run_id"],
            settlement=self.ref, positive_slots=0, negative_slots=0,
            quota_reserved=False, negative_quota_reserved=False)

    def run_switch(self):
        return current.switch_due(self.d, self.e, self.ref, self.retained,
                                  self.at, "synthetic fixture, not scientific data")

    def test_preserves_sources_peers_counts_and_nanoseconds(self):
        fixture.RetainedClassifyTests.test_due_preserves_sources_peers_counts_and_nanoseconds(self)

    def test_recent_teacher_positive_does_not_reset_negative_window(self):
        self.d["tasks"]["general_pickup"].update(
            last_core_gain_at="2026-10-31T11:30:00+00:00", qualified_count=8)
        out = self.run_switch()
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_window_rejected(self):
        fixture.RetainedClassifyTests.test_early_window_rejected(self)

    def test_recent_negative_or_unknown_nonzero_origin_rejected(self):
        fixture.RetainedClassifyTests.test_recent_negative_or_unknown_nonzero_origin_rejected(self)

    def test_two_other_segments_required(self):
        fixture.RetainedClassifyTests.test_two_other_segments_still_required(self)

    def test_live_resources_and_user_holds_rejected(self):
        fixture.RetainedClassifyTests.test_live_resources_and_user_holds_rejected(self)
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.run_switch()

    def test_retained_attempts_refusals_and_unread_data_rejected(self):
        fixture.RetainedClassifyTests.test_retained_attempts_refusals_and_unread_data_rejected(self)

    def test_scope_context_and_unsettled_baseline_rejected(self):
        for key, value in (("task", "foreign"), ("host", "foreign"),
                           ("context", {}), ("run_id", "different"), ("settlement", {})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["old"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.d["reservations"]["old"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_incomplete_or_mismatched_native_outcome_rejected(self):
        self.e["first_readback_passed"] = False
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_negative"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_settled_negative_not_recounted(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        out = self.run_switch()
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        self.assertEqual(out["receipt"]["positive_delta"], 0)

    def test_retained_source_bindings_still_required(self):
        fixture.RetainedClassifyTests.test_owner_source_and_budget_binding_rejected(self)
        self.setUp()
        fixture.RetainedClassifyTests.test_full_positive_target_or_outstanding_reservation_rejected(self)

    def test_existing_baseline_validation_reused(self):
        text, original = current.source(), current.baseline.source()
        start = "    baseline_checks(terminal)"
        end = '    assert reservation["positive_slots"]'
        self.assertEqual(text[text.index(start):text.index(end)],
                         original[original.index(start):original.index(end)])
        self.assertNotIn('terminal["summary"]["qualified_positive"]', text)


if __name__ == "__main__":
    unittest.main()
