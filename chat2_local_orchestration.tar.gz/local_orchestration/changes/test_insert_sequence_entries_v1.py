"""Offline entry imports and exact source equality; no rollout or ledger calls."""
from pathlib import Path
import hashlib
import unittest


class EntryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import collection_insert_sequence_content_v1 as wiring
        import collect_insert_sequence_content_v1 as collector
        import bind_insert_sequence_content_v1 as binder
        cls.wiring = wiring
        cls.collector = collector
        cls.binder = binder

    def test_actual_collector_and_binder_use_matching_entry(self):
        self.assertIs(self.binder.collection, self.collector)
        self.assertIn("collect_insert_sequence_content_v1.py", self.binder.text)
        self.assertIs(self.collector.core.foreground.baseline, self.wiring.baseline_module)

    def test_native_algorithm_and_content_policy_unchanged(self):
        self.assertEqual(self.wiring.source("baseline_native"),
                         self.wiring.previous.source("baseline_native"))
        policy = Path(self.collector.core.foreground.baseline.recording.__file__)
        self.assertEqual(hashlib.sha256(policy.read_bytes()).hexdigest(),
                         "0c0f8c218e52bd62b0142b3eae8f75d6176d6b1aa8cc3097d8f38a090633b2da")
        self.assertEqual(self.collector.core.finish.reader_binding.__name__,
                         "reader_content_binding_v1")

    def test_foreground_has_only_two_entry_binding_changes(self):
        original = self.wiring.previous.source("foreground_common")
        expected = original.replace(
            "from collection_recording_content_v1 import baseline_module as baseline\n",
            "from collection_insert_sequence_content_v1 import baseline_module as baseline\n",
        ).replace("node.stage.HERE/'baseline_recording_content_v1.py'",
                  "node.stage.HERE/'baseline_insert_sequence_content_v1.py'")
        self.assertEqual(self.wiring.source("foreground_common"), expected)

    def test_child_installs_handoff_before_original_native_source(self):
        text = Path(self.wiring.__file__).with_name(
            "baseline_insert_sequence_content_v1.py").read_text()
        self.assertLess(text.index("handoff.install()"), text.index('source("baseline_native")'))
        compile(text, "<offline-child-syntax-only>", "exec")


if __name__ == "__main__":
    unittest.main()
