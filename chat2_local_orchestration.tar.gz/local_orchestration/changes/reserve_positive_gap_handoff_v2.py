"""Original capacity CLI plus the exact current node/task counter schema."""
from pathlib import Path
import positive_gap_node_schema_v2 as schema

schema.base.pinned_text(Path(schema.__file__), "d1ddfb4fed65efda35ea6a335200f57a34bddec5ea71cdfed7ca12d9f5b21e11")
schema.install()
path = Path(__file__).with_name("reserve_positive_gap_handoff_v1.py")
text = schema.base.pinned_text(path, "a9e90707572d9d96d0326b176ec753fd01e3f696e983007eaa1cdfc4231d0b2a")
if __name__ == "__main__":
    exec(compile(text, str(path) + "::node_schema_v2", "exec"), globals())
