"""Fasten1900 metadata on the existing content-aware shared teacher catalog."""
from pathlib import Path
import common_runtime as runtime
import teacher_catalog_binding_v12 as previous
import task_configured_binding as configured

_TEXT = runtime.edit(previous._TEXT, "'general_pickup': 200}",
                     "'general_pickup': 200, 'fasten_screws': 1900}")
if _TEXT.count("teacher_catalog_binding_v12") != 6:
    raise ValueError("Frozen catalog import sites changed")
_TEXT = _TEXT.replace("teacher_catalog_binding_v12", "teacher_catalog_binding_v13")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_restore_v12'", "'_refate_shared_task_restore_v13'")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_persistence_v12'", "'_refate_shared_task_persistence_v13'")
exec(compile(_TEXT, str(Path(__file__).with_name("teacher_task_binding.py")) +
             "::fasten1900_catalog_v13", "exec"), globals())


def load_native_layout(context):
    if context.get("binding_schema") == configured.SCHEMA and context["source"]["task"] == "fasten_screws":
        need(type(context["native_step_limit"]) is int and context["native_step_limit"] == 1900,
             "Original Fasten1900 budget required")
        return configured.load_native_layout(context)
    return previous.load_native_layout(context)
