"""Synthetic CPU metadata only; no live ledger, model, simulation or peer calls."""
import unittest

import test_general_negative_classify_l47_v1 as old_switch
import test_classify_l47_boundary_v1 as old_boundary
import switch_general_negative_to_classify_l37_v1 as current
import due_classify_l37_boundary_v1 as boundary

old_switch.current = current
old_switch.REAL_REVIEW = current.review_negative_shortfall
old_boundary.boundary = boundary


class GeneralNegativeL37Tests(old_switch.GeneralNegativeMetadataTests):
    def setUp(self):
        super().setUp()
        self.prep["source"].update(
            layout_id=37, required_accounted_prefix=current.SEQUENCE[:20])

    def test_previous_layout_and_short_prefix_are_rejected(self):
        for key, value in (("layout_id", 47),
                           ("required_accounted_prefix", current.SEQUENCE[:15])):
            self.setUp()
            self.prep["source"][key] = value
            with self.assertRaises(AssertionError):
                self.run_switch()


class ClassifyL37BoundaryTests(old_boundary.ClassifyL47BoundaryTests):
    def setUp(self):
        super().setUp()
        self.previous["source"].update(
            layout_id=27, required_accounted_prefix=boundary.SEQUENCE[:19])
        self.prepared["source"].update(
            layout_id=37, required_accounted_prefix=boundary.SEQUENCE[:20])

    def test_cross_task_resource_predecessor_is_not_source_predecessor(self):
        text = boundary.source()
        for marker in ("assert x['from_task']=='general_pickup'",
                       "latest=doc(x['resource_settlement_ref'])",
                       "latest['run_id']==x['resource_run_id']",
                       "assert sid==ps['source_id']"):
            self.assertIn(marker, text)


if __name__ == "__main__":
    unittest.main()
