"""Bind the original dispatch to the matching General200 preparation entry."""
from pathlib import Path
import common_runtime as runtime


def source():
    path = Path(__file__).with_name("teacher_bind_handoff_v3.py")
    text = runtime.read_pin({"path": str(path), "sha256":
        "42c10b399ae568ba096d383bf984f1c1a366e7da89ae00fd5f8ef1190635a74b"}).decode()
    return runtime.edit(text, "import prepare_teacher_content_v4 as prep",
                        "import prepare_teacher_content_v5 as prep")


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general200_metadata", "exec"), globals())
