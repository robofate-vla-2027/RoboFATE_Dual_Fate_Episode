"""Closed-boundary scheduling and existing baseline reservation for Classify L6."""
from copy import deepcopy
import datetime
import json
from pathlib import Path
import sys

from classify_prefix_handoff_v1 import (
    ADAPTER, NEXT_SOURCE, OWNER, TASK, document, original_classify_prefix_accounted,
    ref, reserver,
)


def switch_due(ledger, terminal, terminal_ref, prepared, preparation_ref, review, at):
    d = deepcopy(ledger)
    n = d["nodes"]["perdon-hou"]
    prior, target = d["tasks"]["plug_in_charger"], d["tasks"][TASK]
    now = datetime.datetime.fromisoformat(at)
    if not (d["campaign_id"] == "refate-20261022-97baf70d5128"
            and n["active_chat_id"] == OWNER and n["current_task"] == "plug_in_charger"
            and not n["user_pause_active"] and not n["user_stop"]
            and not n.get("owned_resource_launch_hold", False)
            and n["active_run_id"] is None and n["active_real_simulators"] == 0
            and not n["launch_inflight"] and n["baseline_accounting"]["baseline_attempts_running"] == 0):
        raise ValueError("Current source still active or execution authority changed")
    if not (terminal["task"] == "plug_in_charger" and terminal["execution_owner"] == OWNER
            and terminal["safe_for_next_simulator"] is True
            and n["last_owned_resource_settlement"] == terminal_ref
            and len(n["completed_pending_sources"]) <= 2
            and len(n["common_pending_readback_run_ids"]) <= 2):
        raise ValueError("Actual closed boundary or backlog check failed")
    reservation = d["reservations"][terminal["source_id"]]
    if not (reservation["status"] == "shared_Evo_teacher_settled"
            and reservation["current_attempt_run_id"] == terminal["run_id"]
            and reservation["current_attempt_settlement"] == terminal["summary_ref"]
            and reservation["positive_slots"] == reservation["negative_slots"] == 0
            and reservation["quota_reserved"] is False
            and reservation["negative_quota_reserved"] is False):
        raise ValueError("Current teacher attempt is not settled")
    start = datetime.datetime.fromisoformat(prior["latest_segment_started_at"])
    last_gain = datetime.datetime.fromisoformat(prior["last_core_gain_at"]) if prior.get("last_core_gain_at") else start
    no_gain = (now - max(start, last_gain)).total_seconds()
    segment_seconds = (now - start).total_seconds()
    # Plug has never yielded an independent negative. Teacher gains cannot reset this window.
    if not (prior["negative_count"] == 0 and segment_seconds >= 5400):
        raise ValueError("Original independent-negative shortage boundary is not due")
    if not (TASK in n["fixed_tasks"] and target["assigned_host"] == "perdon-hou"
            and target["scheduling_state"] == "deferred"
            and target["negative_count"] < target["negative_quota"] == 10
            and prior["reserved_count"] == prior["negative_reserved_count"] == 0
            and target["reserved_count"] == target["negative_reserved_count"] == 0):
        raise ValueError("Target task is not an available own deficit")
    source = prepared["source"]
    if source["source_id"] != NEXT_SOURCE or prepared["native_step_limit"] != 1100:
        raise ValueError("Wrong frozen next-source preparation")
    boundary = {"next_preparation": {"ref": preparation_ref}, "legacy_prefix_review": review}
    if not all(original_classify_prefix_accounted(d, boundary, source, i) for i in range(1, 6)):
        raise ValueError("Original Classify prefix changed or remains unaccounted")
    deferred = datetime.datetime.fromisoformat(target["deferred_at"])
    intervening = [s for s in n["task_segments"] if s["task"] != TASK
                   and datetime.datetime.fromisoformat(s["ended_at"]) > deferred]
    if len(intervening) < 2:
        raise ValueError("Original deferred-task revisit is not due")
    reason = ("Plug's settled source boundary has >=90min without an independent negative; "
              "preserve teacher gains and both remaining deficits. Revisit deferred Classify "
              "using the next frozen unused L6 and the existing configured baseline, native1100. "
              "L1's old negative and L2-L5's failed/interrupted attempts remain unchanged and "
              "are not replayed. Shared Evo Classify teacher binding is not yet verified.")
    transition = {
        "at": at, "from_task": "plug_in_charger", "to_task": TASK, "reason": reason,
        "terminal": terminal_ref, "preparation": preparation_ref,
        "seconds_since_last_core_gain": no_gain,
        "seconds_since_last_negative_gain": segment_seconds,
        "last_negative_gain_at": None, "negative_shortfall_clock_reset": False,
        "prior_deficits": {"positive": prior["positive_quota"] - prior["qualified_count"],
                          "negative": prior["negative_quota"] - prior["negative_count"]},
        "target_deficits": {"positive": target["positive_quota"] - target["qualified_count"],
                           "negative": target["negative_quota"] - target["negative_count"]},
    }
    n["task_segments"].append({
        "at": at, "task": "plug_in_charger", "started_at": prior["latest_segment_started_at"],
        "ended_at": at, "duration_minutes": segment_seconds / 60,
        "outcome": "deferred_after_low_yield_review", "reason": reason,
        "seconds_since_last_core_gain": no_gain,
        "seconds_since_last_negative_gain": segment_seconds,
        "negative_shortfall_clock_reset": False, "last_core_gain_at": prior.get("last_core_gain_at"),
        "counts_at_end": {"positive": prior["qualified_count"], "negative": prior["negative_count"]},
        "deficits": deepcopy(transition["prior_deficits"]), "last_settlement": terminal["summary_ref"],
        "resource_terminal": terminal_ref,
    })
    for task in (prior, target):
        task.setdefault("scheduling_history", []).append({
            k: deepcopy(task.get(k)) for k in
            ("status", "scheduling_state", "latest_segment_started_at", "last_core_gain_at", "deferred_at")})
    prior.update(status="pending", scheduling_state="deferred", deferred_current=True,
                 deferred_at=at, deferred_reason=reason, latest_deferral=transition,
                 active_run_id=None, phase="low_yield_deferred_after_settlement", updated_at=at)
    target.update(status="collecting", scheduling_state="active", deferred_current=False,
                  latest_segment_started_at=at, last_revisit_at=at, revisit_reason=reason,
                  phase="due_revisit_preparation", updated_at=at)
    n.setdefault("scheduling_history", []).append(transition)
    n.update(current_task=TASK, phase="due_revisit_preparation", updated_at=at)
    d.update(revision=d["revision"] + 1, updated_at=at)
    return {"ledger": d, "receipt": {
        "schema": "refate.due_task_revisit.v1", "at": at, "revision": d["revision"],
        "transition": transition, "positive_delta": 0, "negative_delta": 0,
        "node_positive": n["qualified_count"], "node_negative": n["negative_count"],
        "lock_inode": 27555308,
    }}


def reserve_next(d, boundary, boundary_ref, at):
    n = d["nodes"]["perdon-hou"]
    if not (n["active_chat_id"] == OWNER and n["current_task"] == TASK
            and n["active_run_id"] is None and n["active_real_simulators"] == 0
            and not n.get("owned_resource_launch_hold", False)
            and n["last_owned_resource_settlement"] == boundary["resource_predecessor"]["ref"]):
        raise ValueError("Classify reservation is not at the current closed boundary")
    release = document(boundary["runtime_release"])
    if not (release["native_wall_seconds"] == 2400 and release["teacher_wall_seconds"] == 3600):
        raise ValueError("Original wall budgets changed")
    review = document(boundary["legacy_prefix_ref"])
    if review != boundary["legacy_prefix_review"]:
        raise ValueError("Prefix observation does not match saved evidence")
    prefix_before = {sid: deepcopy(s) for sid, s in d["source_index"].items()
                     if s.get("host") == "perdon-hou" and s.get("task") == TASK}
    n.setdefault("runtime_adoption_history", []).append(deepcopy(n["current_runtime_adoption"]))
    n["current_runtime_adoption"] = {"at": at, "runtime_release": boundary["runtime_release"],
        "stage": "baseline_prelaunch_adoption", "actual_native_started": False,
        "actual_teacher_verified": False, "actual_full_readback_verified": False}
    n.setdefault("dispatch_history", []).append(deepcopy(n["current_dispatch"]))
    n["current_dispatch"] = {"data_kind": "baseline_wall_defaults_not_dispatch",
                            "native_wall_seconds": 2400, "teacher_wall_seconds": 3600}
    n["current_common_foreground"]["actual_entry"] = release["foreground_entry"]
    out, dispatch = reserver()(d, boundary, at)
    for sid, row in prefix_before.items():
        if out["source_index"][sid] != row:
            raise ValueError("Historical source was modified")
    prepared = boundary["next_preparation"]["prepared"]
    source = prepared["source"]
    row = out["source_index"][dispatch["source_id"]]
    row.update(group_id=source["group_id"], layout_id=6,
               source_sequence=deepcopy(source["source_sequence"]),
               required_accounted_prefix=deepcopy(source["required_accounted_prefix"]),
               preparation=boundary["next_preparation"]["ref"],
               legacy_prefix_accounting=boundary["legacy_prefix_ref"])
    node = out["nodes"]["perdon-hou"]
    node["current_reservation_helper"] = boundary["metadata_adapter"]
    node["last_ledger_update_note"] = "Next frozen Classify L6; old source rows unchanged; no scientific relabeling."
    return {"ledger": out, "receipt": {
        "revision": out["revision"], "at": at, "run_id": dispatch["run_id"],
        "source_id": dispatch["source_id"], "dispatch": dispatch,
        "boundary_ref": boundary_ref, "legacy_prefix": boundary["legacy_prefix_ref"],
        "metadata_helper": ref(Path(__file__)), "positive_delta": 0, "negative_delta": 0,
        "node_positive": node["qualified_count"], "node_negative": node["negative_count"],
    }}


def main():
    import base64
    x = json.load(sys.stdin)
    d = json.loads(base64.b64decode(x["ledger_b64"]))
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if x["mode"] == "switch":
        terminal = document(x["terminal_ref"])
        prepared = document(x["preparation_ref"])
        review = document(x["prefix_ref"])
        out = switch_due(d, terminal, x["terminal_ref"], prepared, x["preparation_ref"], review, at)
    elif x["mode"] == "reserve":
        out = reserve_next(d, document(x["boundary_ref"]), x["boundary_ref"], at)
    else:
        raise ValueError("Unknown metadata operation")
    print(json.dumps(out))


if __name__ == "__main__":
    main()
