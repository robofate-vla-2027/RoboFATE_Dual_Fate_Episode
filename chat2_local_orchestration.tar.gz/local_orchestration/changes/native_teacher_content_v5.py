"""Same Native logic and content recorder, with the General200 task catalog."""
from pathlib import Path
import native_teacher_content_v4 as previous

text = previous.text
if text.count("teacher_catalog_binding_v11") != 3:
    raise ValueError("Frozen Native catalog sites changed")
text = text.replace("teacher_catalog_binding_v11", "teacher_catalog_binding_v12")
exec(compile(text, str(Path(__file__).with_name("native_shared_teacher.py")) +
             "::general200_content", "exec"), globals())
