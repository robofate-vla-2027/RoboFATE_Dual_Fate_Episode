"""Original dispatch-file wrapper, invoking the paired Insert context binder."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("baseline_bind_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
        "a8fe6225189a8e12c41db7159291a66513b77c13aad5ae491fa53adf80119caf"
    ):
        raise ValueError("Original dispatch wrapper changed")
    text = raw.decode()
    old = "bind_recording_content_v1.py"
    if text.count(old) != 1:
        raise ValueError("Original binder invocation changed")
    return text.replace(old, "bind_insert_sequence_content_v1.py", 1)


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::insert_binder", "exec"), globals())
