"""Keep the existing baseline transport/RNG and switch only recording imports."""
from pathlib import Path
import types
import common_runtime as runtime
import collection_rng_runtime as previous

HERE = Path(__file__).resolve().parent


def source(name):
    text = previous.source(name)
    if name == "baseline_native":
        return runtime.edit(text, "import common_recording as recording\n",
                            "import common_recording_content_v2 as recording\n")
    text = runtime.edit(text, "from collection_rng_runtime import baseline_module as baseline\n",
                        "from collection_recording_content_v1 import baseline_module as baseline\n")
    return runtime.edit(text, "node.stage.HERE/'baseline_transport_rng.py'",
                        "node.stage.HERE/'baseline_recording_content_v1.py'")


def load(name):
    module = types.ModuleType("_refate_content_" + name)
    module.__file__ = str(HERE / (name + ".py"))
    exec(compile(source(name), module.__file__ + "::content_binding", "exec"), module.__dict__)
    return module


baseline_module = load("baseline_native")
