"""Synthetic metadata only: no real ledger, API, model, Native or GPU calls."""
import ast
import copy
import sys
import unittest
from unittest.mock import patch

import boundary_configured_handoff_v2 as boundary


def reject_live_effect(event, args):
    if event.startswith("socket.") or event in {
        "subprocess.Popen", "os.system", "os.fork", "os.posix_spawn",
    }:
        raise AssertionError("Synthetic test forbids network/process effects")


sys.addaudithook(reject_live_effect)


def sources():
    return (
        dict(source_sequence=list(range(16)), layout_id=15,
             required_accounted_prefix=list(range(15))),
        dict(source_sequence=list(range(17)), layout_id=16,
             required_accounted_prefix=list(range(16))),
    )


class ConfiguredAppendBoundaryTest(unittest.TestCase):
    def test_next_contiguous_append(self):
        self.assertTrue(boundary.configured_sequence_follows(*sources()))

    def test_existing_frozen_sequence(self):
        old, new = sources()
        old["source_sequence"] = copy.deepcopy(new["source_sequence"])
        self.assertTrue(boundary.configured_sequence_follows(old, new))

    def test_inputs_preserved(self):
        pair = sources()
        before = copy.deepcopy(pair)
        boundary.configured_sequence_follows(*pair)
        self.assertEqual(pair, before)

    def test_skip_rejected(self):
        old, new = sources()
        new.update(layout_id=17, source_sequence=list(range(18)))
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_reordered_prefix_rejected(self):
        old, new = sources()
        new["source_sequence"][0:2] = [1, 0]
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_missing_old_prefix_rejected(self):
        old, new = sources()
        old["required_accounted_prefix"].pop()
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_missing_new_prefix_rejected(self):
        old, new = sources()
        new["required_accounted_prefix"].pop()
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_duplicate_sequence_rejected(self):
        old, new = sources()
        new["source_sequence"].append(16)
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_non_integer_layout_rejected(self):
        old, new = sources()
        new["layout_id"] = 16.0
        self.assertFalse(boundary.configured_sequence_follows(old, new))

    def test_exact_single_seam(self):
        original = boundary.PREVIOUS.read_text()
        effective = boundary.source()
        self.assertEqual(effective.replace(boundary.NEW, boundary.OLD, 1), original)
        ast.parse(effective)

    def test_source_drift_rejected(self):
        with patch.object(type(boundary.PREVIOUS), "read_bytes", return_value=b"changed"):
            with self.assertRaisesRegex(ValueError, "Pinned configured"):
                boundary.source()

    def test_guards_preserved(self):
        text = boundary.source()
        for fragment in (
            "binding.load_native_layout(prepared)",
            "binding.load_native_layout(previous)",
            "ps['source_id']==sid",
            "ps['task']==ns['task']==x['task']",
            "assert ns['required_accounted_prefix']==ps['required_accounted_prefix']+[ps['layout_id']]",
            "memory_headroom(120)",
            "allocation=fg.allocation()",
            "fcntl.LOCK_EX|fcntl.LOCK_NB",
            "ident['start_ticks']",
            "old['safe_for_next_simulator']",
            "'RUNTIME_CONTENT_RELEASE_20261031_01a19072.json'",
        ):
            with self.subTest(fragment=fragment):
                self.assertIn(fragment, text)


if __name__ == "__main__":
    unittest.main()
