"""Read-only baseline process/GPU evidence; not a data-qualification gate."""
import datetime
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher/runs")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def active_gpu_ids(table):
    active = []
    for line in table:
        fields = [field.strip() for field in line.split("|")]
        # GPU identity is column 1, not a zero in the LUID or Active columns.
        if len(fields) > 3 and fields[1].isdigit() and fields[3].startswith("Yes:"):
            active.append(int(fields[1]))
    return active


def main():
    assert socket.gethostname() == "nb-5pl2apckdj-0"
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert os.environ["REFATE_EXECUTION_OWNER"] == OWNER
    x = json.load(sys.stdin)
    run = ROOT / x["run_id"]
    assert run.parent == ROOT and run.name.startswith("c2_")
    context = json.loads((run / "CONTEXT_001.json").read_bytes())
    assert context["execution_owner"] == OWNER
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    query = lambda fields, kind: subprocess.check_output(
        ["nvidia-smi", "--query-" + kind + "=" + fields,
         "--format=csv,noheader,nounits"], text=True).splitlines()
    gpus = query("index,uuid,memory.free", "gpu")
    apps = query("pid,gpu_uuid,used_memory", "compute-apps")
    uuids = {int(row.split(",")[0]): row.split(",")[1].strip() for row in gpus}
    owned = []
    for role in ("native", "policy"):
        identity = json.loads((run / f"owned_{role}.json").read_bytes())["identity"]
        process = Path("/proc") / str(identity["pid"])
        stat = (process / "stat").read_text().rsplit(")", 1)[1].split()
        assert int(stat[19]) == identity["start_ticks"] and boot == identity["boot_id"]
        environment = dict(row.split(b"=", 1) for row in
                           (process / "environ").read_bytes().split(b"\0") if b"=" in row)
        selected = {key: environment[key.encode()].decode()
                    for key in ("CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER")}
        assert selected["CUDA_VISIBLE_DEVICES"] == ("0,1" if role == "native" else "0")
        actual = [row for row in apps if row.split(",")[0].strip() == str(identity["pid"])]
        assert actual, "GPU allocation not observable yet; do not relaunch"
        if role == "policy":
            assert all(row.split(",")[1].strip() == uuids[0] for row in actual)
        else:
            assert any(row.split(",")[1].strip() == uuids[1] for row in actual)
        owned.append(dict(role=role, identity=identity, selected_environment=selected,
                          actual_gpu_rows=actual))
    with (run / "stdout.log").open("rb") as stream:
        lines = stream.read(512 * 1024).decode(errors="replace").splitlines()
    index = next(i for i, line in enumerate(lines) if "| GPU | Name" in line)
    table = lines[index:index + 12]
    assert len(table) == 12 and active_gpu_ids(table) == [1]
    started = json.loads((run / "native_started.json").read_bytes())
    assert context["native_wall_seconds"] == 2400
    print(json.dumps(dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(), run_id=run.name,
        data_kind="actual_readonly_device_observation", gpu_free_snapshot=gpus,
        owned_processes=owned, renderer_active_gpu_table=table, native_started=started,
        original_baseline_deadline_wall_ns=started["wall_ns"] + 2400 * 1000000000,
        native_budget=context["native_total_steps"], wall_budget_seconds=2400,
        other_processes_managed=False, RGB_decoded=False)))


if __name__ == "__main__":
    main()
