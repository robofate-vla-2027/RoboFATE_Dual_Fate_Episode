"""Use the original five-DM-failure review for an unattempted retained source."""
import hashlib
from pathlib import Path

import switch_general_baseline_to_retained_classify_v1 as previous
import switch_general_negative_to_classify_l47_v1 as five

baseline_checks = previous.baseline_checks
review_negative_shortfall = five.review_negative_shortfall
OLD = '    assert elapsed >= 5400 or (negative_elapsed is not None and negative_elapsed >= 5400), "Original low-yield window not reached"'
NEW = '    shortfall = review_negative_shortfall(d, terminal["source_id"])'
EVENT = '        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason)'
NEW_EVENT = (
    '        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason,\n'
    '        negative_shortfall_review=shortfall, scheduling_trigger=shortfall["trigger"])'
)


def source():
    for module, expected in (
        (previous, "32bf3a0d032c804f73d11e0ac92903ea98e306e09ecc481748ea49b1630ccc2b"),
        (five, "d0d665229c4083ac6f24e462d1f65e86e28f4ec8227851760bc74d6acd1ff01d"),
    ):
        if hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen retained-source or five-failure helper changed")
    text = previous.source()
    for old, new in ((OLD, NEW), (EVENT, NEW_EVENT)):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::original_five_failure_review", "exec"),
     globals())
