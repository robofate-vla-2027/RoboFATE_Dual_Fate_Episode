"""Original source metadata only; never launch models or simulations."""
import sys
def reject_live_effect(event, args):
    if event.startswith(('socket.', 'subprocess.')) or event in ('os.system', 'os.kill', 'os.killpg', 'os.fork', 'os.posix_spawn'):
        if event != 'socket.gethostname':
            raise RuntimeError('SOURCE_METADATA_ONLY ' + event)
sys.addaudithook(reject_live_effect)
import json,sys,hashlib
from pathlib import Path
A=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');sys.path.insert(0,str(A));import task_source_binding as binding,task_family_binding as family,source_binding as original
x=json.load(sys.stdin)
import execution_owner_binding_v1 as execution
execution.install()
assert x['execution_owner'] == execution.NEW
old=original.decode(binding.read_ref(x['prior_manifest']));i=x['layout'];assert old['task']=='organize_table' and old['initial_source_sequence']==list(range(i)) and i not in old['original_partition']['reserved_final']
p=binding.NATIVE/f'Assets/Eval_Layout/RoboDojo/arx_x5/0/organize_table_{i}.json';raw=original.decode(p.read_bytes());current=family.family(raw);gid='organize_table/task_content_family/'+current['content_sha256'];review=None
def diffs(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   q=path+'/'+k;out+=([q] if k not in a or k not in b else diffs(a[k],b[k],q))
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [path+'/length']
  return [q for j,(u,v) in enumerate(zip(a,b)) for q in diffs(u,v,path+'/'+str(j))]
 return [] if a==b else [path]
if gid not in old['families']:
 candidates=[]
 for group,row in old['families'].items():
  ref=row['layouts'][0];data=original.decode(binding.read_ref(dict(path=ref['path'],sha256=ref['sha256']),expected_path=binding.NATIVE/f"Assets/Eval_Layout/RoboDojo/arx_x5/0/organize_table_{ref['layout_id']}.json"));other=family.family(data);delta=diffs(other['normalized_layout'],current['normalized_layout']);assert delta
  candidates.append(dict(group_id=group,layout=ref['layout_id'],different_nonpose_paths=delta))
 closest=min(candidates,key=lambda a:(len(a['different_nonpose_paths']),a['layout']));review=dict(new_layout=i,new_group=gid,outcomes_read=False,next_original_ordinal=True,closest_existing=closest)
labels=[r['split'] for r in old['families'].values()];count=len(labels)+1;target=min(count-1,max(1,count//5));split=('student_dev' if labels.count('student_dev')<target else 'student_train') if review else old['families'][gid]['split']
print(json.dumps(dict(layout=i,raw_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),group_id=gid,new_family_review=review,new_family_split=split,prior_manifest=x['prior_manifest'],outcomes_read=False,reserved_layouts_read=[])))