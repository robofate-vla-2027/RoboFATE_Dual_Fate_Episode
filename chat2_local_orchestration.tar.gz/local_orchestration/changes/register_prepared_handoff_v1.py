import sys,json,base64,datetime,copy
from pathlib import Path
x=json.load(sys.stdin);d=json.loads(base64.b64decode(x['ledger_b64']));root=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher');sys.path.insert(0,str(root/'preparations'));import configured_source_registration_v2_20261031 as m
check=m.document(x['preparation_check']);task=check['task'];profile=m.profile(task);assert check['schema']=='refate.actual_metadata_preparation.v1' and check['data_kind']=='actual_source_metadata_not_execution'
assert check['task']==task and check['native_budget']==profile['native_budget'] and check['metadata_helper']==m.ref(m.__file__) and check['actual_configuration_roundtrip_passed'] is True and check['runtime_files_modified'] is False
manifest=m.lineage(check['append_manifest'],task);append=manifest['collection_append'];assert append['prior_split']==check['prior_manifest'] and append['metadata_helper']==check['metadata_helper'];tests=m.document(check['cpu_tests']);assert tests['data_kind']=='synthetic_not_actual_admission' and tests['actual_test_exit']==0
n=d['nodes']['perdon-hou'];t=d['tasks'][task];reg=d['split_manifests'][task];old_ref={k:reg[k] for k in ('path','sha256')};at=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert d['campaign_id']==m.CAMPAIGN and n['active_chat_id']=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0' and n['current_task']==task and t['assigned_host']=='perdon-hou'
if old_ref==check['append_manifest']:
 receipt=dict(idempotent_reuse=True,revision=d['revision'],source_id=check['source_id'],append_manifest=check['append_manifest'],positive_delta=0,negative_delta=0)
else:
 assert n['active_run_id'] is None and n['active_real_simulators']==0 and not n.get('launch_inflight',False) and not n.get('user_pause_active',False) and not n.get('user_stop',False)
 assert old_ref==check['prior_manifest'] and check['source_id'] not in d['source_index']
 event=dict(at=at,event='append_original_source_before_execution',source_id=check['source_id'],added_layout=append['added_layout'],prior_registry=copy.deepcopy(reg),new_manifest=check['append_manifest'],actual_metadata_check=x['preparation_check'],metadata_helper=check['metadata_helper'],cpu_tests=check['cpu_tests'],old_memberships_changed=False,source_started=False,positive_delta=0,negative_delta=0)
 t.setdefault('source_registration_history',[]).append(event)
 reg.update(check['append_manifest']);reg.update(scope='original_initial_scope_plus_monotonic_nonsealed_collection_append',prior_assignments_preserved=True,unread_sealed_layout_ids=profile['reserved_final'],prior_manifest=check['prior_manifest'],latest_append=append['added_layout'])
 n.setdefault('split_registry_projection_history',[]).append(copy.deepcopy(n.get('latest_split_registry_projection')))
 n['latest_split_registry_projection']=dict(at=at,task=task,source_id=check['source_id'],split_manifest=check['append_manifest'],reason='Before next original-source execution, append its distinct initialization/family without changing historical membership or frozen evaluation layouts; runtime and reader unchanged.',actual_metadata_check=x['preparation_check'])
 d['revision']+=1;d['updated_at']=at
 receipt=dict(idempotent_reuse=False,at=at,revision=d['revision'],source_id=check['source_id'],task=task,prior_manifest=check['prior_manifest'],append_manifest=check['append_manifest'],metadata_helper=check['metadata_helper'],actual_metadata_check=x['preparation_check'],new_source_started=False,positive_delta=0,negative_delta=0)
print(json.dumps(dict(ledger=d,receipt=receipt)))
