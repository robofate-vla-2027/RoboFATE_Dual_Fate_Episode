"""Reuse source/resource predecessor separation for the prepared General L10."""
import hashlib
from pathlib import Path


def source():
    path = Path(__file__).with_name("due_bottles_boundary_handoff_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "6a97e07f01e2e7e61872b1ccd2453225852e6be3676b3d27878440d8f6d2b56e"):
        raise ValueError("Frozen resource-boundary helper changed")
    text = raw.decode().replace("put_bottles_into_dustbin", "general_pickup")
    text = text.replace("sort_nesting_dolls_by_size", "fasten_screws")
    for old, new in (
        ("prepared['native_step_limit']==700", "prepared['native_step_limit']==200"),
        ("assert x['from_task']=='fasten_screws'",
         "assert x['from_task']=='fasten_screws'\n"
         "assert prepared['source']['layout_id']==10 and prepared['source']['source_sequence']==[1,2,3,4,0,5,6,7,8,9,10]"),
        ("bref=write(run/'MAIN_BOUNDARY_001.json',b)",
         "b['general_previous_preparation']={'ref':x['prior_preparation_ref'],'prepared':previous}\n"
         "bref=write(run/'MAIN_BOUNDARY_001.json',b)"),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen resource-boundary interface changed: " + old)
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::general_l10_resource_boundary", "exec"), globals())
