"""Prepare the next frozen General source through the existing metadata loader."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import types

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
CATALOG_OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
LEGACY_OWNER = "01a16338-bd36-78e3-ac27-56c3e62e3333"
TASK = "general_pickup"
PREFIX = [1, 2, 3, 4, 0, 5, 6]
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338")
ADAPTER = ROOT / "teacher/shared_teacher/perdon_adapter_20261026"
ORIGINAL = {
    "path": str(ROOT / "splits/general_pickup_v1.json"),
    "sha256": "9b7e857e246fe610e9b8b61afc3a62588752557ee7779e5b28b3e0927efa1d84",
}
HELPER_SHA = "357b3c77f9139909f59efecb7535f27be94bf082b4a4e4ca547a2f9e2c5c88fb"


def need(value, message):
    if not value:
        raise ValueError(message)


def extended_manifest(original):
    need(original["task"] == TASK and original["owner_chat"] == LEGACY_OWNER,
         "Wrong frozen task identity")
    need(original["initial_source_sequence"] == PREFIX, "Original source order changed")
    need(original["previous_plan"]["partition"]["reserved_final"] == [53, 54],
         "Original sealed collection boundary changed")
    out = deepcopy(original)
    out["initial_source_sequence"] = PREFIX + [7]
    return out


def validate_projection(original, projected):
    extended = extended_manifest(original)
    for key, value in extended.items():
        expected = CATALOG_OWNER if key == "owner_chat" else value
        need(projected.get(key) == expected, "Historical field changed: " + key)
    need(projected["historical_manifest_owner"] == LEGACY_OWNER,
         "Historical manifest owner missing")
    need(projected["original_partition"] == original["previous_plan"]["partition"],
         "Partition changed")
    need(set(projected["layouts"]) == {str(i) for i in PREFIX + [7]},
         "Unexpected source projection")
    for i in PREFIX + [7]:
        group = original["layout_to_group"][str(i)]
        family = original["families"][group]
        members = [m for m in family["layouts"] if m["bank"] == 0 and m["layout_id"] == i]
        need(len(members) == 1 and family["split"] in ("student_train", "student_dev"),
             "Ambiguous or sealed family")
        row = projected["layouts"][str(i)]
        need(row["layout_id"] == i and row["native_bank"] == 0
             and row["group_id"] == group and row["split"] == family["split"]
             and row["layout_ref"] == {k: members[0][k] for k in ("path", "sha256")},
             "Frozen source membership changed")
    need(projected["layouts"]["7"]["initialization_distinct_from_preceding"] is True,
         "Duplicate full initialization")
    return True


def metadata_only(event, args):
    if event in ("socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                 "os.kill", "os.killpg"):
        raise RuntimeError("Offline source metadata only: " + event)


def main():
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    need(x == {"execution_owner": OWNER, "layout": 7}, "Only the next original L7 is supported")
    sys.path.insert(0, str(ADAPTER))
    import task_configured_binding as configured
    from prepare_classify_legacy_handoff_v2 import ref, save

    path = ADAPTER / "task_binding_v10.py"
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == HELPER_SHA, "Frozen projection core changed")
    helper = types.ModuleType("_refate_general_projection_only")
    helper.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), helper.__dict__)
    helper.TASK = TASK
    original = helper.base.original.decode(helper.base.read_ref(ORIGINAL))
    extended = extended_manifest(original)
    raw_by_layout = {}
    for i in PREFIX + [7]:
        _, family, member = helper.member(original, i)
        need(family["split"] in ("student_train", "student_dev"), "Sealed family")
        expected = helper.base.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{TASK}_{i}.json"
        raw_by_layout[i] = helper.base.original.decode(helper.base.read_ref(
            {k: member[k] for k in ("path", "sha256")}, expected_path=expected))
    projected = helper.legacy_view(extended, 7, raw_by_layout)
    validate_projection(original, projected)
    projected["metadata_projection"] = {
        "schema": "refate.legacy_split.configured_sequence_append.v1",
        "original_manifest": deepcopy(ORIGINAL),
        "original_accounted_prefix": PREFIX,
        "appended_original_layout": 7,
        "existing_family_assignments_unchanged": True,
        "historical_manifest_owner": LEGACY_OWNER,
        "catalog_descriptor_owner": CATALOG_OWNER,
        "prepared_by": OWNER,
        "new_family_registered": False,
        "sealed_layout_content_read": False,
        "original_file_modified": False,
        "projection_is_not_execution_authority": True,
    }
    directory = ADAPTER / "task_sources" / TASK
    directory.mkdir(exist_ok=True)
    split_ref = save(directory / "SPLIT_LEGACY_APPEND_L7_001.json", projected)
    task_ref = ref(helper.base.NATIVE / f"task/RoboDojo/tasks/{TASK}.py")
    prepared, native_layout = configured.prepare_source(
        task=TASK, layout_id=7, split_ref=split_ref, native_total=200, task_ref=task_ref)
    need(configured.load_native_layout(prepared) == native_layout, "Configured loader disagrees")
    preparation_ref = save(directory / "PREPARATION_L7_CONFIGURED_001.json", prepared)
    need(ref(Path(ORIGINAL["path"])) == ORIGINAL, "Original split changed during preparation")
    result = {
        "schema": "refate.general.legacy_source_preparation.v1",
        "data_kind": "preparation_only",
        "execution_owner": OWNER,
        "source_id": prepared["source"]["source_id"],
        "source_owner": prepared["source"]["source_owner"],
        "preparation_ref": preparation_ref,
        "split_ref": split_ref,
        "original_split": ORIGINAL,
        "metadata_helper": ref(Path(__file__)),
        "task_ref": task_ref,
        "native_budget": 200,
        "required_accounted_prefix": PREFIX,
        "source_sequence": PREFIX + [7],
        "group_id": prepared["source"]["group_id"],
        "split": prepared["source"]["split"],
        "sealed_content_read": False,
        "old_sources_replayed": False,
        "old_raw32_source_repaired_to_pt4": False,
        "runtime_files_modified": False,
        "source_registered": False,
        "source_reserved": False,
        "actual_launch": False,
        "teacher_binding_verified": False,
        "positive_delta": 0,
        "negative_delta": 0,
    }
    result["evidence_ref"] = save(directory / "PREPARATION_L7_HANDOFF_01a19072_001.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
