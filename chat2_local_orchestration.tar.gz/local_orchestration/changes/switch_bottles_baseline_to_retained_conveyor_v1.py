"""Task binding only, retaining the pinned closed-source revisit checks."""
import hashlib
from pathlib import Path

import switch_general_baseline_to_retained_classify_v1 as parent

baseline_checks = parent.baseline_checks
PARENT_SHA = "32bf3a0d032c804f73d11e0ac92903ea98e306e09ecc481748ea49b1630ccc2b"


def source():
    if hashlib.sha256(Path(parent.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Frozen retained-source scheduling dependency changed")
    text = parent.source()
    for old, new, count in (
        ("classify_objects", "pick_from_conveyor_by_image", 6),
        ("general_pickup", "put_bottles_into_dustbin", 6),
        ('== s["native_budget"] == 1100', '== s["native_budget"] == 700', 1),
        ('phase="deferred_after_settled_negative_shortfall"',
         'phase="deferred_after_settled_no_gain"', 1),
    ):
        if text.count(old) != count:
            raise ValueError("Frozen scheduling task-binding seam changed")
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::bottles_retained_conveyor", "exec"),
     globals())
