"""Offline synthetic bookkeeping, with no real ledger, network or execution."""
import copy
import sys
import unittest

import test_general_retained_classify_v1 as fixture
import switch_fasten_to_retained_general_v1 as current


def deny_real_ledger(event, args):
    if event == "open" and args and isinstance(args[0], (str, bytes)):
        if "ReFATE_collection_progress" in str(args[0]):
            raise RuntimeError("Synthetic fixtures cannot open the real ledger")


sys.addaudithook(deny_real_ledger)


class RetainedGeneralTests(unittest.TestCase):
    def setUp(self):
        fixture.RetainedClassifyTests.setUp(self)
        tasks = self.d["tasks"]
        tasks["fasten_screws"] = tasks.pop("general_pickup")
        tasks["general_pickup"] = tasks.pop("classify_objects")
        node = self.d["nodes"]["perdon-hou"]
        node["current_task"] = "fasten_screws"
        node["fixed_tasks"] = ["fasten_screws", "general_pickup"]
        self.e["task"] = "fasten_screws"
        self.d["source_index"]["old"]["task"] = "fasten_screws"
        self.d["source_index"]["retained"].update(
            task="general_pickup", native_steps=200, native_budget=200)

    def run_switch(self):
        return current.switch_due(
            self.d, self.e, self.ref, self.retained, self.at,
            "Offline synthetic fixture, not a collection decision")

    def test_preserves_sources_peers_counts_and_nanoseconds(self):
        before = copy.deepcopy(self.d)
        result = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"],
                         "general_pickup")
        for key in ("source_index", "reservations", "campaign_id"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(result["receipt"]["positive_delta"], 0)
        self.assertEqual(result["receipt"]["negative_delta"], 0)
        transition = result["receipt"]["transition"]
        self.assertEqual(len(transition["completed_other_segments"]), 2)
        for key in ("baseline_replay", "source_started", "reserved"):
            self.assertFalse(transition[key])

    def test_teacher_positive_does_not_reset_negative_window(self):
        self.e["summary"]["qualified_positive"] = True
        self.d["tasks"]["fasten_screws"].update(
            last_core_gain_at="2026-10-31T11:30:00+00:00", qualified_count=2)
        result = self.run_switch()
        event = result["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 60)
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_original_early_window_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_recent_negative_or_unknown_nonzero_origin_rejected(self):
        for gain in ("2026-10-31T11:30:00+00:00", None):
            with self.subTest(gain=gain):
                self.setUp()
                self.d["tasks"]["fasten_screws"].update(
                    last_core_gain_at="2026-10-31T11:30:00+00:00",
                    negative_count=2, last_negative_gain_at=gain)
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_two_other_segments_required(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_resources_and_user_holds_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"),
                           ("active_real_simulators", 1),
                           ("owned_resource_launch_hold", True),
                           ("launch_inflight", True),
                           ("user_pause_active", True), ("user_stop", True)):
            with self.subTest(key=key):
                self.setUp()
                self.d["nodes"]["perdon-hou"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_attempted_refused_counted_or_incomplete_source_rejected(self):
        for key, value in (("active_teacher_attempt", {"status": "settled"}),
                           ("teacher_attempt_history", [{"synthetic": True}]),
                           ("provider_safety_refusal", {"synthetic": True}),
                           ("teacher_replay_prohibited", True),
                           ("counted_in_quota", True),
                           ("counted_in_negative_quota", True),
                           ("complete_readback", False),
                           ("reusable_DM_failure", False),
                           ("native_success", True), ("native_budget", 1900),
                           ("native_steps", 199)):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_unsettled_or_unknown_outcome_rejected(self):
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_positive"] = None
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_owner_task_host_and_source_binding_rejected(self):
        for key, value in (("task", "fasten_screws"), ("host", "synthetic-other"),
                           ("context", {"path": "synthetic/wrong", "sha256": "wrong"})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["active_chat_id"] = "synthetic-other-owner"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_full_target_or_outstanding_reservation_rejected(self):
        self.d["tasks"]["general_pickup"]["qualified_count"] = 10
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["reservations"]["retained"]["negative_quota_reserved"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_only_task_names_and_native_budget_change(self):
        text = current.parent.source()
        expected = text.replace("general_pickup", "fasten_screws")
        expected = expected.replace("classify_objects", "general_pickup")
        expected = expected.replace('== s["native_budget"] == 1100',
                                    '== s["native_budget"] == 200')
        self.assertEqual(current.source(), expected)
        with self.assertRaises(ValueError):
            current.bind_general(text + " general_pickup")


if __name__ == "__main__":
    unittest.main()
