"""Same task binding with the existing closed-baseline predecessor checks."""
import hashlib
from pathlib import Path

import switch_general_baseline_to_retained_classify_v1 as parent
from switch_classify_to_retained_fasten_v1 import bind_fasten

baseline_checks = parent.baseline_checks


def source():
    expected = "32bf3a0d032c804f73d11e0ac92903ea98e306e09ecc481748ea49b1630ccc2b"
    if hashlib.sha256(Path(parent.__file__).read_bytes()).hexdigest() != expected:
        raise ValueError("Frozen closed-baseline scheduling dependency changed")
    return bind_fasten(parent.source())


exec(compile(source(), str(Path(__file__)) + "::closed_classify_fasten_revisit", "exec"),
     globals())
