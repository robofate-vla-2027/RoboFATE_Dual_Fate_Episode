"""Synthetic metadata only; no real ledger, network, model, or simulation."""
import base64
import contextlib
import copy
import datetime
import io
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

from test_common_owner_reservation import fixture, OLD, NEW

HERE = Path(__file__).resolve().parent
TEXT = (HERE / "reserve_plug_append_content_handoff_v1.py").read_text()
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
HISTORICAL = "01a16807-8085-7903-be07-66eb332ebf95"


def prohibit_side_effects(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in {
        "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn",
        "os.remove", "os.rename", "os.mkdir",
    }:
        raise RuntimeError("Synthetic test prohibited side effect: " + event)
    if event == "open" and isinstance(args[1], str):
        if any(mode in args[1] for mode in "wax+"):
            raise RuntimeError("Synthetic test prohibited file write")


sys.addaudithook(prohibit_side_effects)


def case():
    data, boundary = fixture()
    node = data["nodes"]["perdon-hou"]
    node.update(active_chat_id=OWNER, qualified_count=5)
    source = boundary["next_preparation"]["prepared"]["source"]
    source.update(execution_owner=HISTORICAL, source_owner=HISTORICAL,
                  source_sequence=[0, 1], layout_id=1)
    prepared = boundary["next_preparation"]["prepared"]
    prepared.update(binding_schema="synthetic_append_schema",
                    collection_append_provenance={"synthetic": True})
    boundary["at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    boundary["resource_predecessor"] = {
        "ref": copy.deepcopy(boundary["settlement"]["settlement_ref"]),
        "safe_for_next_simulator": True,
    }
    node["last_owned_resource_settlement"] = copy.deepcopy(
        boundary["resource_predecessor"]["ref"])
    boundary["metadata_adapter"] = {"path": "/synthetic/owner.py", "sha256": "d" * 64}
    data["source_index"][OLD]["wall_ns"] = 1793430000123456789
    return data, boundary


def invoke(data, boundary):
    release = {
        "native_wall_seconds": 2400,
        "teacher_wall_seconds": 3600,
        "foreground_entry": str(HERE / "collect_recording_content_v1.py"),
    }
    runtime = types.ModuleType("common_runtime")
    pins = iter([boundary, release])
    runtime.read_pin = lambda value: value
    runtime.document = lambda value: next(pins)
    binding = types.ModuleType("collection_append_binding_v1")
    binding.SCHEMA = "synthetic_append_schema"
    binding.load_native_layout = lambda value: None
    request = {
        "ledger_b64": base64.b64encode(json.dumps(data).encode()).decode(),
        "boundary_ref": {"path": "/synthetic/boundary.json", "sha256": "e" * 64},
    }
    output = io.StringIO()
    with patch.dict(sys.modules, {"common_runtime": runtime,
                                "collection_append_binding_v1": binding}):
        with patch.object(sys, "stdin", io.StringIO(json.dumps(request))):
            with contextlib.redirect_stdout(output):
                exec(compile(TEXT, str(HERE / "reserve_plug_append_content_handoff_v1.py"),
                             "exec"), {"__name__": "__synthetic_metadata_test__"})
    return json.loads(output.getvalue())


class Tests(unittest.TestCase):
    def test_actual_entry_preserves_lineage_peers_clocks_and_integer(self):
        data, boundary = case()
        before = copy.deepcopy(data)
        result = invoke(data, boundary)
        out, dispatch = result["ledger"], result["receipt"]["dispatch"]
        self.assertEqual(data, before)
        self.assertEqual(out["nodes"]["h20_8"], data["nodes"]["h20_8"])
        self.assertEqual(out["source_index"][OLD], data["source_index"][OLD])
        self.assertEqual(dispatch["execution_owner"], OWNER)
        self.assertEqual(dispatch["source_owner"], HISTORICAL)
        self.assertEqual(dispatch["native_total_steps"], 400)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["teacher_wall_seconds"], 3600)
        self.assertEqual(dispatch["campaign_start_preserved"], data["started_at"])
        self.assertEqual(dispatch["original_segment_started_at"],
                         data["tasks"]["plug_in_charger"]["latest_segment_started_at"])
        self.assertFalse(out["source_index"][NEW]["source_started"])
        self.assertEqual(result["receipt"]["positive_delta"], 0)
        self.assertEqual(result["receipt"]["negative_delta"], 0)

    def test_wrong_executor_active_source_duplicate_prefix_and_budget_rejected(self):
        for kind in ("owner", "active", "duplicate", "prefix", "budget"):
            with self.subTest(kind=kind):
                data, boundary = case()
                if kind == "owner":
                    data["nodes"]["perdon-hou"]["active_chat_id"] = HISTORICAL
                elif kind == "active":
                    data["nodes"]["perdon-hou"]["active_run_id"] = "synthetic_active"
                elif kind == "duplicate":
                    data["source_index"][NEW] = {}
                elif kind == "prefix":
                    boundary["next_preparation"]["prepared"]["source"]["required_accounted_prefix"] = [0, 2]
                else:
                    boundary["next_preparation"]["prepared"]["native_step_limit"] = 700
                with self.assertRaises((AssertionError, ValueError)):
                    invoke(data, boundary)


if __name__ == "__main__":
    unittest.main()
