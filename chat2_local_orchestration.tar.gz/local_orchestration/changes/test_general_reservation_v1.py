"""Synthetic existing-core reservation tests; never write the production ledger."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.insert(0, str(snapshot))
import general_prefix_handoff_v1 as prefix
import general_boundary_handoff_v1 as boundary_adapter
import reserve_general_l7_handoff_v1 as reserve_adapter
from prepare_general_l7_handoff_v1 import metadata_only
from test_common_owner_reservation import AT, REF, fixture
from test_general_revisit_v1 import GeneralPrefixTests


def general_fixture():
    ledger, boundary = fixture()
    state = GeneralPrefixTests()
    state.setUp()
    node = ledger["nodes"]["perdon-hou"]
    task = ledger["tasks"].pop("plug_in_charger")
    task.update(state.task)
    ledger["tasks"][prefix.TASK] = task
    ledger["source_index"].update(deepcopy(state.rows))
    node.update(active_chat_id=prefix.OWNER, fixed_tasks=[prefix.TASK], current_task=prefix.TASK)
    prepared = boundary["next_preparation"]["prepared"]
    prepared["native_step_limit"] = 200
    prepared["source"].update(deepcopy(state.source))
    prepared["source"].update(source_owner="01a16807-8085-7903-be07-66eb332ebf95",
                               execution_owner="01a16807-8085-7903-be07-66eb332ebf95")
    boundary["resource_precheck"]["summary"]["run_id"] = "c2_general_pickup_l7_synthetic_01a16807"
    boundary["legacy_prefix_review"] = deepcopy(state.review)
    boundary["legacy_prefix_review"]["preparation_ref"] = deepcopy(REF)
    boundary["legacy_prefix_review"]["prefix_state_sha256"] = prefix.metadata_hash(prefix.prefix_state(task))
    return ledger, boundary


class GeneralReservationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reserve = staticmethod(prefix.reserver())

    def test_existing_core_accepts_accounted_general_prefix(self):
        d, b = general_fixture()
        before = deepcopy(d)
        out, dispatch = self.reserve(d, b, AT)
        self.assertEqual(d, before)
        self.assertEqual(out["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for sid, row in before["source_index"].items():
            self.assertEqual(out["source_index"][sid], row)
        self.assertEqual(dispatch["native_total_steps"], 200)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["teacher_wall_seconds"], 3600)
        self.assertEqual(dispatch["execution_owner"], prefix.OWNER)
        self.assertFalse(dispatch["source_started"])
        self.assertEqual(out["nodes"]["perdon-hou"]["negative_count"], before["nodes"]["perdon-hou"]["negative_count"])

    def test_missing_prefix_and_changed_nanosecond_rejected(self):
        d, b = general_fixture()
        b["legacy_prefix_review"]["entries"] = b["legacy_prefix_review"]["entries"][1:]
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)
        d, b = general_fixture()
        d["source_index"][f"{prefix.TASK}_b0_l3_synthetic"]["synthetic_ns"] += 1
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)

    def test_active_source_stale_resources_and_wall_reset_rejected(self):
        for key, value in (("active_run_id", "synthetic_live"), ("active_real_simulators", 1),
                           ("user_pause_active", True), ("launch_inflight", True)):
            d, b = general_fixture()
            d["nodes"]["perdon-hou"][key] = value
            with self.assertRaises(ValueError):
                self.reserve(d, b, AT)
        d, b = general_fixture()
        b["at"] = "2026-10-26T11:00:00+00:00"
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)
        d, b = general_fixture()
        d["nodes"]["perdon-hou"]["current_dispatch"]["teacher_wall_seconds"] = 7200
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)

    def test_duplicate_and_full_negative_quota_rejected(self):
        d, b = general_fixture()
        d["source_index"][prefix.NEXT_SOURCE] = {}
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)
        d, b = general_fixture()
        d["tasks"][prefix.TASK]["negative_count"] = 10
        with self.assertRaises(ValueError):
            self.reserve(d, b, AT)

    def test_boundary_uses_original_resource_checks(self):
        ast.parse(boundary_adapter.text)
        for text in (
            'fg.host()', 'fg.allocation()', 'fg.helpers().memory_headroom(120)',
            'fcntl.LOCK_EX | fcntl.LOCK_NB', 'identity["start_ticks"]',
            'disks[str(run)] <= 30 * 1024**3', '"legacy_prefix_review": review',
            '"native_kit_extensions": []', 'RUNTIME_CONTENT_RELEASE_20261031_01a19072.json',
        ):
            self.assertIn(text, boundary_adapter.text)
        self.assertIn('prepared["native_step_limit"] != 200', boundary_adapter.text)
        self.assertIn("c2_general_pickup_l7_common_baseline_0001_01a16807", boundary_adapter.text)
        self.assertIn("layout_id=7", reserve_adapter.text)


if __name__ == "__main__":
    sys.addaudithook(metadata_only)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(GeneralReservationTests)
    result = unittest.TextTestRunner().run(suite)
    raise SystemExit(not result.wasSuccessful())
