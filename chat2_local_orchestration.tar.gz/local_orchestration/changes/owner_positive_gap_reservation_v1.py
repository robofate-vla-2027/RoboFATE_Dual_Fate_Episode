"""Reuse owner/order/resource reservation with explicit zero-negative capacity."""
from pathlib import Path
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
gap.pinned_text(Path(__file__).with_name("owner_reservation_handoff_v1.py"),
                "23585fef5f5b08a7c775ab4644c54923c1f4ee7508a5d2ad89d4745fe9603d20")
import owner_reservation_handoff_v1 as previous

_namespace = dict(vars(previous), **gap.namespace())
exec(compile(gap.reservation_source(previous.text), __file__ + "::capacity", "exec"), _namespace)
OWNER = _namespace["OWNER"]
reserve = _namespace["reserve"]
