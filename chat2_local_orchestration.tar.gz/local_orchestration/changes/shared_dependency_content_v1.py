"""Same original teacher decoder/reviewer, with explicit content diagnostics."""
from pathlib import Path
import hashlib
import common_runtime as runtime
import common_recording_content_v2 as content

path = Path(__file__).with_name("shared_dependency_binding.py")
raw = path.read_bytes()
EXPECTED_BASE_SHA256 = "21c8e46762e974e46ddbacbde3ae74978c0f2b58c910a53d8f2b9d9bccdd4517"
if hashlib.sha256(raw).hexdigest() != EXPECTED_BASE_SHA256:
    raise ValueError("Pinned original teacher dependency binding changed")
text = raw.decode()
text = runtime.edit(text, "    tree=ast.parse(bound);function=",
                    "    bound=content.teacher_source(bound)\n    tree=ast.parse(bound);function=")
text = runtime.edit(text, "'algorithm_changes':False,'scope':'dependency factory, source identity and node paths only'",
                    "'algorithm_changes':True,'scope':'same reader; content diagnostic and integrity checks',"
                    "'content_policy':content.policy_reference()")
exec(compile(text, str(path) + "::content_diagnostic_binding", "exec"), globals())
