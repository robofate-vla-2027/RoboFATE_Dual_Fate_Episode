"""Existing reservation with inheritance from a settled General predecessor."""
import base64
from copy import deepcopy
import datetime
import json
from pathlib import Path
import sys

from prepare_general_append_handoff_v1 import sequence
from prepare_general_l7_handoff_v1 import ADAPTER, OWNER, TASK, metadata_only, need
from general_prefix_handoff_v1 import document, ref


def appended_prefix_accounted(ledger, boundary, source, ordinal):
    previous = boundary.get("general_previous_preparation", {})
    prepared = previous.get("prepared", {}).get("source", {})
    old = ledger["source_index"].get(boundary["settlement"]["source_id"], {})
    layout = source.get("layout_id")
    if type(layout) is not int or not 8 <= layout < 53:
        return False
    prefix = sequence(layout - 1)
    return (
        source.get("task") == prepared.get("task") == old.get("task") == TASK
        and source.get("source_sequence") == sequence(layout)
        and source.get("required_accounted_prefix") == prefix
        and prepared.get("source_sequence") == old.get("source_sequence") == prefix
        and prepared.get("required_accounted_prefix") == old.get("required_accounted_prefix") == prefix[:-1]
        and prepared.get("layout_id") == old.get("layout_id") == layout - 1
        and prepared.get("source_id") == old.get("source_id") == boundary["settlement"]["source_id"]
        and previous.get("ref") == old.get("preparation")
        and old.get("settlement") == boundary["settlement"]["settlement_ref"]
        and old.get("source_started") is True and old.get("host") == "perdon-hou"
        and ledger["tasks"][TASK].get("source_sequence") == prefix
        and type(ordinal) is int and ordinal in prefix
    )


def reserver():
    import owner_reservation_handoff_v1 as original
    seam = "_inherited_prefix(ledger, b, source, i)"
    need(original.text.count(seam) == 1, "Frozen prefix interface changed")
    namespace = dict(original.__dict__)
    namespace["appended_prefix_accounted"] = appended_prefix_accounted
    text = original.text.replace(seam, "(" + seam +
                                 " or appended_prefix_accounted(ledger, b, source, i))", 1)
    exec(compile(text, str(ADAPTER / "common_owner_reservation.py") +
                 "::general_settled_append", "exec"), namespace)
    return namespace["reserve"]


def reserve_next(ledger, boundary, boundary_ref, previous, release, at):
    d, b = deepcopy(ledger), deepcopy(boundary)
    n = d["nodes"]["perdon-hou"]
    source = b["next_preparation"]["prepared"]["source"]
    b["general_previous_preparation"] = previous
    need(appended_prefix_accounted(d, b, source, source["required_accounted_prefix"][0]),
         "Next source is not the immediate frozen continuation")
    need(n["active_chat_id"] == OWNER and n["current_task"] == TASK
         and not n.get("owned_resource_launch_hold", False)
         and n["last_owned_resource_settlement"] == b["resource_predecessor"]["ref"]
         and b["resource_predecessor"]["safe_for_next_simulator"] is True,
         "Current resource boundary or owner changed")
    need(b["next_preparation"]["prepared"]["native_step_limit"] == 200
         and release["native_wall_seconds"] == 2400 and release["teacher_wall_seconds"] == 3600
         and release["foreground_entry"] == str(ADAPTER / "collect_recording_content_v1.py"),
         "Original pipeline or budgets changed")
    n.setdefault("runtime_adoption_history", []).append(deepcopy(n["current_runtime_adoption"]))
    n["current_runtime_adoption"] = {
        "at": at, "runtime_release": b["runtime_release"], "stage": "baseline_prelaunch_adoption",
        "actual_native_started": False, "actual_teacher_verified": False,
        "actual_full_readback_verified": False,
    }
    n.setdefault("dispatch_history", []).append(deepcopy(n["current_dispatch"]))
    n["current_dispatch"] = {"data_kind": "baseline_wall_defaults_not_dispatch",
                            "native_wall_seconds": 2400, "teacher_wall_seconds": 3600}
    n["current_common_foreground"]["actual_entry"] = release["foreground_entry"]
    out, dispatch = reserver()(d, b, at)
    for sid, row in ledger["source_index"].items():
        need(out["source_index"][sid] == row, "Existing source modified")
    row = out["source_index"][source["source_id"]]
    row.update(group_id=source["group_id"], layout_id=source["layout_id"],
               source_sequence=deepcopy(source["source_sequence"]),
               required_accounted_prefix=deepcopy(source["required_accounted_prefix"]),
               preparation=b["next_preparation"]["ref"])
    task = out["tasks"][TASK]
    task.setdefault("source_sequence_history", []).append({
        "at": at, "previous": deepcopy(task["source_sequence"]),
        "adoption": b["next_preparation"]["ref"], "settled_predecessor": b["settlement"],
        "inherited_preparation": previous["ref"], "original_memberships_unchanged": True,
        "old_sources_replayed": False,
    })
    task.update(source_sequence=deepcopy(source["source_sequence"]),
                current_source_projection=b["next_preparation"]["prepared"]["provenance"]["split"],
                next_independent_source_preparation=b["next_preparation"]["ref"])
    node = out["nodes"]["perdon-hou"]
    node["current_reservation_helper"] = ref(Path(__file__))
    return {"ledger": out, "receipt": {
        "at": at, "revision": out["revision"], "run_id": dispatch["run_id"],
        "source_id": dispatch["source_id"], "dispatch": dispatch, "boundary_ref": boundary_ref,
        "metadata_helper": ref(Path(__file__)), "inherited_preparation": previous["ref"],
        "source_sequence_appended": deepcopy(source["source_sequence"]),
        "positive_delta": 0, "negative_delta": 0,
        "node_positive": node["qualified_count"], "node_negative": node["negative_count"],
    }}


def main():
    sys.addaudithook(metadata_only)
    x = json.load(sys.stdin)
    ledger = json.loads(base64.b64decode(x["ledger_b64"]))
    boundary = document(x["boundary_ref"])
    old = ledger["source_index"][boundary["settlement"]["source_id"]]
    previous = {"ref": old["preparation"], "prepared": document(old["preparation"])}
    import task_configured_binding as configured
    configured.load_native_layout(boundary["next_preparation"]["prepared"])
    print(json.dumps(reserve_next(
        ledger, boundary, x["boundary_ref"], previous, document(boundary["runtime_release"]),
        datetime.datetime.now(datetime.timezone.utc).isoformat())))


if __name__ == "__main__":
    main()
