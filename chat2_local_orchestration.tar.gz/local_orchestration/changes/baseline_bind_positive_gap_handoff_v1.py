"""Original one-shot context binder, using the capacity-aware metadata entry."""
from pathlib import Path
import baseline_positive_gap_v1 as gap

gap.pinned_text(Path(gap.__file__), "23c2c5d925b964f25b275d8f8666fe459261b0664ad19fa2082b1380f1f73663")
path = Path(__file__).with_name("baseline_bind_handoff_v1.py")
text = gap.pinned_text(path, "a8fe6225189a8e12c41db7159291a66513b77c13aad5ae491fa53adf80119caf")
text = gap.change(text, "bind_recording_content_v1.py", "bind_positive_gap_context_v1.py")
if __name__ == "__main__":
    exec(compile(text, str(path) + "::positive_gap", "exec"), globals())
