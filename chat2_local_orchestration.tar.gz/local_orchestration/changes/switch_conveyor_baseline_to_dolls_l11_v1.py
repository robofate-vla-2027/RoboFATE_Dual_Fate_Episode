"""Bind the existing closed-baseline revisit to already prepared Dolls L11."""
import hashlib
from pathlib import Path

import switch_fasten_to_prepared_general_v1 as previous
from closed_baseline_resource_v1 import baseline_checks


def source():
    raw = Path(previous.__file__).read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "273196f3e43cda557a096ef708e7894f740b6180292362217aff1399361cde5b"):
        raise ValueError("Frozen scheduling dependency changed")
    text = previous.source().replace("fasten_screws", "pick_from_conveyor_by_image")
    text = text.replace("general_pickup", "sort_nesting_dolls_by_size")
    for old, new in (
        ('prepared["native_step_limit"] == 200', 'prepared["native_step_limit"] == 1050'),
        ('s["layout_id"] == 10 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]',
         's["layout_id"] == 11 and s["source_sequence"] == list(range(12))'),
        ('s["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]',
         's["required_accounted_prefix"] == list(range(11))'),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::conveyor_dolls_l11", "exec"),
     globals())
