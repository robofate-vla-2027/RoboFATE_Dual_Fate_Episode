"""Task binding only: original retained-source revisit after a closed teacher."""
import hashlib
from pathlib import Path

import switch_general_to_retained_classify_v1 as parent


def bind_fasten(text):
    # Rename the previous target first to avoid overlapping task names.
    text = parent.replace_exact(text, "classify_objects", "fasten_screws", 6)
    text = parent.replace_exact(text, "general_pickup", "classify_objects", 6)
    return parent.replace_exact(
        text, '== s["native_budget"] == 1100', '== s["native_budget"] == 1900')


def source():
    expected = "c548e0f262f4de991c20367c3dd8b9296f0f164815b73086d54d50232883aebc"
    if hashlib.sha256(Path(parent.__file__).read_bytes()).hexdigest() != expected:
        raise ValueError("Frozen retained-source scheduling dependency changed")
    return bind_fasten(parent.source())


exec(compile(source(), str(Path(__file__)) + "::classify_fasten_revisit", "exec"),
     globals())
