"""Bind the existing closed-baseline revisit to prepared Play L14."""
import hashlib
from pathlib import Path

import switch_fasten_to_prepared_general_v1 as previous
from closed_baseline_resource_v1 import baseline_checks


def source():
    raw = Path(previous.__file__).read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "273196f3e43cda557a096ef708e7894f740b6180292362217aff1399361cde5b"):
        raise ValueError("Frozen scheduling dependency changed")
    text = previous.source().replace("fasten_screws", "organize_table")
    text = text.replace("general_pickup", "play_stacking_toy")
    for old, new in (
        ('"refate.common_collector.configured_task_binding.v1"',
         '"refate.common_collector.collection_group_binding.v1"'),
        ('import task_configured_binding as binding',
         'import collection_group_binding as binding'),
        ('prepared["native_step_limit"] == 200', 'prepared["native_step_limit"] == 1200'),
        ('s["layout_id"] == 10 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]',
         's["layout_id"] == 14 and s["source_sequence"] == list(range(15))'),
        ('s["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]',
         's["required_accounted_prefix"] == list(range(14))'),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling parameter seam changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::organize_play_l14", "exec"),
     globals())
