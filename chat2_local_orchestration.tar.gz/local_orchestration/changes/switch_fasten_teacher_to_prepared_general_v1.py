"""Original teacher-closure revisit rules, parameterized for Fasten to General10."""
import hashlib
from pathlib import Path

CHANGES = (('sort_nesting_dolls_by_size', 'fasten_screws'), ('put_bottles_into_dustbin', 'general_pickup'), ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 200'), ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))', 's["layout_id"] == 10 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]'), ('s["required_accounted_prefix"] == list(range(12))', 's["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]'), ('s["split"] == "student_train"', 's["split"] in ("student_train", "student_dev")'), ('target["latest_segment_started_at"]', 'target.get("latest_segment_started_at")'))


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d":
        raise ValueError("Original scheduling helper changed")
    text = raw.decode()
    for old, new in CHANGES:
        if old not in text:
            raise ValueError("Original scheduling parameter missing")
        text = text.replace(old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::Fasten_teacher_General10", "exec"), globals())
