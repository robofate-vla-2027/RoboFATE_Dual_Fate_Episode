"""Same metadata operation, with matching Fasten1900 entry references."""
from pathlib import Path
import common_runtime as runtime
import teacher_terminal_handoff_v5 as previous

CHANGES = (('collect_teacher_content_v5', 'collect_teacher_content_v6'), ('c70b36872331116b7f5c92bed8b884c4cf8c3ea0d9171d7167375b6006591d61', 'e9d1f23b5ae9dc931bc8615f2f163fc02e4ba0b7ed0564d2b9fc56ab52d0dcdb'))


def source():
    runtime.read_pin({"path": str(Path(__file__).with_name('teacher_terminal_handoff_v5.py')),
                      "sha256": '81d0dc70d63a8ddf814e775d012e9535e246ae177df8f82509817ee9b18692a1'})
    text = previous.source()
    for old, new in CHANGES:
        text = runtime.edit(text, old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::fasten1900_metadata", "exec"), globals())
