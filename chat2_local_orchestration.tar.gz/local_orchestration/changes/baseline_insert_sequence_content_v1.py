import insert_sequence_handoff_v1 as handoff
handoff.install()
from collection_insert_sequence_content_v1 import source
exec(compile(source("baseline_native"), __file__, "exec"), globals())
