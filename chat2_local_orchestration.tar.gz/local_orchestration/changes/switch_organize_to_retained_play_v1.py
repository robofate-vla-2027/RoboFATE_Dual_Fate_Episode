"""Original 90-minute/two-segment rule, reusing a settled unattempted source."""
import base64
import copy
import datetime
import hashlib
import json
from pathlib import Path
import sys

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")


def document(ref):
    path = Path(ref["path"])
    assert path.is_relative_to(ROOT) and path.resolve() == path
    raw = path.read_bytes()
    assert len(raw) < 4 * 1024**2
    assert hashlib.sha256(raw).hexdigest() == ref["sha256"]
    return json.loads(raw)


def switch_due(d, terminal, terminal_ref, retained, at, reason):
    n = d["nodes"]["perdon-hou"]
    old, target = d["tasks"]["organize_table"], d["tasks"]["play_stacking_toy"]
    now = datetime.datetime.fromisoformat(at)
    assert d["campaign_id"] == "refate-20261022-97baf70d5128"
    assert n["active_chat_id"] == OWNER and n["current_task"] == "organize_table"
    assert not any(n.get(k) for k in ("user_pause_active", "user_stop",
                                    "owned_resource_launch_hold", "launch_inflight"))
    assert n["active_run_id"] is None and n["active_real_simulators"] == 0
    assert n["baseline_accounting"]["baseline_attempts_running"] == 0
    assert len(n["completed_pending_sources"]) <= 2
    assert len(n["common_pending_readback_run_ids"]) <= 2
    assert terminal["task"] == "organize_table" and terminal["execution_owner"] == OWNER
    assert terminal["safe_for_next_simulator"] is True
    assert n["last_owned_resource_settlement"] == terminal_ref
    source = d["source_index"][terminal["source_id"]]
    reservation = d["reservations"][terminal["source_id"]]
    assert source["active_teacher_attempt"]["status"] == "settled"
    assert source["active_teacher_attempt"]["terminal_observation"] == terminal_ref
    assert source["active_teacher_attempt"]["run_id"] == terminal["run_id"]
    assert reservation["status"] == "shared_Evo_teacher_settled"
    assert reservation["current_attempt_settlement"] == terminal["summary_ref"]
    assert reservation["current_attempt_run_id"] == terminal["run_id"]
    assert reservation["positive_slots"] == reservation["negative_slots"] == 0
    assert not reservation["quota_reserved"] and not reservation["negative_quota_reserved"]
    assert terminal["summary"]["qualified_positive"] is False
    start = datetime.datetime.fromisoformat(old["latest_segment_started_at"])
    gain = datetime.datetime.fromisoformat(old["last_core_gain_at"]) if old.get("last_core_gain_at") else start
    elapsed = (now - max(start, gain)).total_seconds()
    assert elapsed >= 5400, "Original no-core-gain window not reached"
    for task in (old, target):
        assert task["assigned_host"] == "perdon-hou" and task["assigned_role"] == "chat2"
        assert task["reserved_count"] == task["negative_reserved_count"] == 0
    assert "play_stacking_toy" in n["fixed_tasks"]
    assert target["scheduling_state"] == "deferred" and target.get("active_run_id") is None
    assert target["qualified_count"] < target["positive_quota"] == 10
    assert target["negative_quota"] == 10
    deferred = datetime.datetime.fromisoformat(target["deferred_at"])
    segments = [row for row in n["task_segments"]
                if row["task"] not in ("play_stacking_toy", "organize_table")
                and deferred < datetime.datetime.fromisoformat(row["ended_at"]) <= start]
    assert segments, "Two-other-segment revisit is not yet due"
    sid = retained["source_id"]
    s, r = d["source_index"][sid], d["reservations"][sid]
    assert s["task"] == "play_stacking_toy" and s["host"] == "perdon-hou"
    assert s["native_success"] is False and s["native_steps"] == s["native_budget"] == 1200
    assert s["complete_readback"] is True and s["reusable_DM_failure"] is True
    assert not any(s.get(k) for k in ("active_teacher_attempt", "teacher_attempt_history",
                                     "provider_safety_refusal", "teacher_replay_prohibited",
                                     "counted_in_quota", "counted_in_negative_quota"))
    for key in ("context", "manifest", "settlement", "readback"):
        assert s[key] == retained[key]
    assert r["status"] == "settled_native_failure_no_quota"
    assert r["settlement"] == s["settlement"] and r["run_id"] == s["run_id"]
    assert not r["quota_reserved"] and not r["negative_quota_reserved"]
    assert r["positive_slots"] == r["negative_slots"] == 0
    event = dict(
        at=at, task="organize_table", started_at=old["latest_segment_started_at"],
        ended_at=at, duration_minutes=(now-start).total_seconds()/60,
        outcome="deferred_after_low_yield_review", seconds_since_last_core_gain=elapsed,
        last_core_gain_at=old.get("last_core_gain_at"),
        last_negative_gain_at=old.get("last_negative_gain_at"),
        negative_shortfall_clock_reset=False,
        counts_at_end=dict(positive=old["qualified_count"], negative=old["negative_count"]),
        deficits=dict(positive=old["positive_quota"]-old["qualified_count"],
                      negative=old["negative_quota"]-old["negative_count"]),
        last_settlement=terminal["summary_ref"], resource_terminal=terminal_ref, reason=reason)
    review = dict(at=at, event="activate_due_retained_failure_first_teacher",
                  from_task="organize_table", task="play_stacking_toy",
                  prior_deferred_at=target["deferred_at"],
                  prior_segment_started_at=target["latest_segment_started_at"],
                  completed_other_segments=[segments[-1], event],
                  source=copy.deepcopy(retained), baseline_replay=False,
                  source_started=False, reserved=False, reason=reason)
    n["task_segments"].append(event)
    old.setdefault("scheduling_history", []).append(copy.deepcopy(event))
    old.update(status="pending", phase="deferred_after_settled_no_gain",
               scheduling_state="deferred", deferred_current=True, deferred_at=at,
               deferred_reason=reason, active_run_id=None, updated_at=at)
    target.setdefault("scheduling_history", []).append(copy.deepcopy(review))
    target.update(status="pending", phase="due_retained_failure_teacher_preparation",
                  scheduling_state="active", deferred_current=False,
                  latest_segment_started_at=at, last_revisit_at=at,
                  last_revisit=review, updated_at=at)
    n.setdefault("scheduling_history", []).append(copy.deepcopy(review))
    n.update(current_task="play_stacking_toy", phase=target["phase"], updated_at=at)
    d["revision"] += 1
    d["updated_at"] = at
    return dict(ledger=d, receipt=dict(
        schema="refate.due_retained_failure_revisit.v1", at=at, revision=d["revision"],
        transition=review, positive_delta=0, negative_delta=0,
        node_positive=n["qualified_count"], node_negative=n["negative_count"],
        lock_inode=27555308))


if __name__ == "__main__":
    x = json.load(sys.stdin)
    d = json.loads(base64.b64decode(x["ledger_b64"]))
    terminal = document(x["terminal_ref"])
    retained = x["retained"]
    for key in ("context", "manifest", "settlement", "readback"):
        document(retained[key])
    print(json.dumps(switch_due(d, terminal, x["terminal_ref"], retained,
                               datetime.datetime.now(datetime.timezone.utc).isoformat(),
                               x["reason"])))
