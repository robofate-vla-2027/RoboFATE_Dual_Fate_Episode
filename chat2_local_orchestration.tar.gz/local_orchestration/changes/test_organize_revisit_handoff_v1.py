"""Synthetic scheduling evidence only; no process, model, or network calls."""
import ast
import copy
from pathlib import Path
import unittest
import negative_shortfall_deferral_handoff_v1 as shortfall
import test_insert_revisit_handoff_v1 as fixtures

NEW, AT = fixtures.NEW, fixtures.AT


def switch_function():
    p = Path(__file__).with_name("switch_insert_to_organize_handoff_v1.py")
    node = next(n for n in ast.parse(p.read_bytes()).body
                if isinstance(n, ast.FunctionDef) and n.name == "switch_due")
    namespace = {}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(p), "exec"), namespace)
    return namespace["switch_due"]


class OrganizeMetadataTests(unittest.TestCase):
    def fixture(self):
        b = fixtures.InsertMetadataTests()
        b.setUp()
        b.e["execution_owner"] = NEW
        b.s["execution_owner"] = NEW
        b.n["fixed_tasks"].append("organize_table")
        b.t["latest_segment_started_at"] = "2026-10-31T10:20:00+00:00"
        b.t["last_core_gain_at"] = "2026-10-29T00:00:00+00:00"
        b.d["tasks"]["organize_table"] = dict(
            assigned_host="perdon-hou", scheduling_state="deferred", qualified_count=0,
            positive_quota=10, negative_count=0, negative_quota=10, reserved_count=0,
            negative_reserved_count=0, deferred_at="2026-10-29T00:00:00+00:00",
            latest_segment_started_at="2026-10-29T00:00:00+00:00")
        return b

    def evidence_fixture(self):
        b = self.fixture()
        b.d["split_manifests"] = {"insert_tubes": {"initial_source_sequence": list(range(41))}}
        b.d["source_index"], b.d["reservations"] = {}, {}
        docs = {}
        for i in range(36, 41):
            sid = f"insert_tubes_b0_l{i}_synthetic"
            s, r, e = copy.deepcopy(b.s), copy.deepcopy(b.r), copy.deepcopy(b.e)
            ref = {"path": sid, "sha256": "synthetic"}
            s.update(source_id=sid, run_id=sid, settlement=ref,
                     initialization_content_sha256=f"{i:064x}", negative_count=0)
            r.update(run_id=sid, settlement=ref)
            e.update(source_id=sid, run_id=sid)
            b.d["source_index"][sid] = s
            b.d["reservations"][sid] = r
            docs[sid] = e
        return b, docs, sid

    def test_original_five_source_window_and_distinctness(self):
        b, docs, sid = self.evidence_fixture()
        read = lambda ref: docs[ref["path"]]
        result = shortfall.review(b.d, sid, read)
        self.assertEqual(result["preserved_consecutive_tail"], [36, 37, 38, 39, 40])
        self.assertFalse(result["negative_shortfall_clock_reset"])
        b.d["source_index"][sid]["initialization_content_sha256"] = f"{36:064x}"
        with self.assertRaises(ValueError):
            shortfall.review(b.d, sid, read)

    def test_success_or_unsettled_source_rejects_window(self):
        b, docs, sid = self.evidence_fixture()
        read = lambda ref: docs[ref["path"]]
        b.d["source_index"][sid]["native_success"] = True
        with self.assertRaises(ValueError):
            shortfall.review(b.d, sid, read)
        b.d["source_index"][sid]["native_success"] = False
        b.d["reservations"][sid]["negative_quota_reserved"] = True
        with self.assertRaises(ValueError):
            shortfall.review(b.d, sid, read)

    def test_short_segment_can_defer_only_using_existing_window(self):
        b = self.fixture()
        trigger = dict(trigger="negative_only_five_consecutive_independent_DM_failures",
                       negative_shortfall_clock_reset=False, preserved_consecutive_tail=[36, 37, 38, 39, 40])
        before = copy.deepcopy(b.d["source_index"])
        result = switch_function()(b.d, b.e, b.ref, AT, lambda d, sid: trigger)
        self.assertEqual(b.n["current_task"], "organize_table")
        self.assertEqual(b.t["qualified_count"], 10)
        self.assertEqual(b.t["negative_count"], 7)
        self.assertEqual(result["ledger"]["source_index"], before)
        self.assertEqual(b.n["task_segments"][-1]["negative_shortfall_review"], trigger)
        self.assertFalse(b.t["retained_failed_source_revisit_records"][-1]["teacher_needed"])

    def test_active_or_successful_source_cannot_switch(self):
        b = self.fixture()
        b.n["active_run_id"] = "synthetic_active"
        with self.assertRaises(AssertionError):
            switch_function()(b.d, b.e, b.ref, AT)
        b.n["active_run_id"] = None
        b.e["native_success"] = True
        with self.assertRaises(AssertionError):
            switch_function()(b.d, b.e, b.ref, AT)

    def test_runtime_and_source_budget_seams(self):
        root = Path(__file__).parent
        boundary = (root / "organize_boundary_handoff_v1.py").read_text()
        reserve = (root / "reserve_organize_content_handoff_v1.py").read_text()
        self.assertIn("prepared['native_step_limit']==1000", boundary)
        self.assertIn("doc(x['current_resource_ref'])", boundary)
        self.assertIn("collect_recording_content_v1", boundary)
        self.assertIn("collect_recording_content_v1", reserve)
        self.assertIn("m['previous_manifest']", reserve)
        self.assertIn("reg['reserved_final']==m['original_partition']['reserved_final']==[53,54]", reserve)


if __name__ == "__main__":
    unittest.main()
