"""Synthetic metadata checks; no model, simulator, or real ledger edits."""
import base64
import copy
import json
import sys
import types
import unittest
from unittest.mock import patch

import profiled_append_handoff_v1 as helper


class ProfiledMetadataTests(unittest.TestCase):
    def test_prepare_is_original_and_registration_changes_only_executor(self):
        archive = json.loads(helper.ARCHIVE.read_bytes())
        self.assertEqual(helper.script("prepare", archive), archive["prepare"])
        changed = helper.script("register", archive)
        self.assertEqual(changed.replace("n['active_chat_id']==EXECUTOR",
                                         "n['active_chat_id']==m.OWNER", 1), archive["register"])

    def test_unknown_operation_rejected(self):
        with self.assertRaises(ValueError):
            helper.script("launch", {})

    def test_integer_roundtrip(self):
        value = 1793484812551538470
        out = helper.evaluate("import json,sys;print(json.dumps(json.load(sys.stdin)))", {"ns": value})
        self.assertEqual(out["ns"], value)

    def test_registration_preserves_foreign_data_and_rejects_active_source(self):
        archive = json.loads(helper.ARCHIVE.read_bytes())
        module = types.ModuleType("configured_source_registration_v2_20261031")
        module.__file__ = "synthetic_original_helper"
        module.OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
        module.CAMPAIGN = "synthetic_campaign"
        task = "put_bottles_into_dustbin"
        prior = {"path": "synthetic/prior", "sha256": "a" * 64}
        current = {"path": "synthetic/current", "sha256": "b" * 64}
        module.ref = lambda path: {"path": path, "sha256": "c" * 64}
        module.profile = lambda name: {"native_budget": 700, "reserved_final": [53, 54]}
        check = {
            "schema": "refate.actual_metadata_preparation.v1",
            "data_kind": "actual_source_metadata_not_execution",
            "task": task, "native_budget": 700, "metadata_helper": module.ref(module.__file__),
            "actual_configuration_roundtrip_passed": True, "runtime_files_modified": False,
            "append_manifest": current, "prior_manifest": prior,
            "cpu_tests": "synthetic_tests", "source_id": "synthetic_bottles_l12",
        }
        module.document = lambda pin: check if pin == "synthetic_check" else {
            "data_kind": "synthetic_not_actual_admission", "actual_test_exit": 0}
        module.lineage = lambda pin, name: {"collection_append": {
            "prior_split": prior, "metadata_helper": check["metadata_helper"], "added_layout": 12}}
        foreign = {"wall_ns": 1793484812551538470, "owner": "synthetic_chat1"}
        ledger = {
            "campaign_id": module.CAMPAIGN, "revision": 31,
            "nodes": {"perdon-hou": {"active_chat_id": helper.EXECUTOR, "current_task": task,
                      "active_run_id": None, "active_real_simulators": 0}, "h20_8": copy.deepcopy(foreign)},
            "tasks": {task: {"assigned_host": "perdon-hou"}, "synthetic_foreign": copy.deepcopy(foreign)},
            "split_manifests": {task: copy.deepcopy(prior)},
            "source_index": {"synthetic_old": {"source_owner": module.OWNER, **foreign}},
        }
        args = {"ledger_b64": base64.b64encode(json.dumps(ledger).encode()).decode(),
                "preparation_check": "synthetic_check"}
        with patch.dict(sys.modules, {"configured_source_registration_v2_20261031": module}):
            out = helper.evaluate(helper.script("register", archive), args)
            changed = out["ledger"]
            self.assertEqual(changed["nodes"]["h20_8"], foreign)
            self.assertEqual(changed["tasks"]["synthetic_foreign"], foreign)
            self.assertEqual(changed["source_index"], ledger["source_index"])
            self.assertEqual(module.OWNER, "01a16807-8085-7903-be07-66eb332ebf95")
            args["ledger_b64"] = base64.b64encode(json.dumps(changed).encode()).decode()
            again = helper.evaluate(helper.script("register", archive), args)
            self.assertTrue(again["receipt"]["idempotent_reuse"])
            self.assertEqual(again["ledger"], changed)
            ledger["nodes"]["perdon-hou"]["active_run_id"] = "synthetic_active"
            args["ledger_b64"] = base64.b64encode(json.dumps(ledger).encode()).decode()
            with self.assertRaises(AssertionError):
                helper.evaluate(helper.script("register", archive), args)


if __name__ == "__main__":
    unittest.main()
