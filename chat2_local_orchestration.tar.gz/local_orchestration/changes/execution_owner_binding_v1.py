"""Explicit future-entry executor; immutable source owners remain unchanged."""
import hashlib
import json
import os
from pathlib import Path
import socket

import isolation_stage as stage

HANDOFF = stage.HERE / "EXECUTION_HANDOFF_20261031_01a19072.json"
HANDOFF_SHA256 = "04ff7671b93ed63338c92961a64dbf68d2e676162cc499cb550ffba7ac90da34"
NEW = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def install():
    stage.need(socket.gethostname() == "nb-5pl2apckdj-0"
               and os.environ.get("REFATE_SSH_ALIAS") == "perdon-hou",
               "Executor binding requires the exact authorized host and alias")
    raw = HANDOFF.read_bytes()
    stage.need(hashlib.sha256(raw).hexdigest() == HANDOFF_SHA256,
               "Explicit ownership handoff changed")
    receipt = json.loads(raw)
    stage.need(receipt["to_chat_id"] == NEW and receipt["lock_inode"] == 27555308
               and receipt["chat1_unchanged"] is True
               and receipt["source_index_and_reservations_unchanged"] is True,
               "Invalid execution handoff")
    stage.need(stage.OWNER in (receipt["from_chat_id"], NEW),
               "Conflicting active executor")
    stage.need(os.environ.get("REFATE_EXECUTION_OWNER", NEW) == NEW,
               "Wrong future-entry executor environment")
    stage.OWNER = NEW
    os.environ["REFATE_EXECUTION_OWNER"] = NEW
    # Publisher execution identity is separate from frozen source metadata.
    import reader_binding
    reader_binding.OWNER_CHAT = NEW
    return {"path": str(HANDOFF), "sha256": HANDOFF_SHA256}
