"""Synthetic CPU projection tests; no ledger, model, simulator or network."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import prepare_fasten_legacy_handoff_v1 as previous
import prepare_fasten_legacy_handoff_v2 as current
from test_fasten_legacy_projection_v1 import fixture


class OriginalL4Tests(unittest.TestCase):
    def test_next_descriptor_preserves_original_sequence_groups_and_precision(self):
        original, projected = fixture(4)
        before = deepcopy((original, projected))
        current.validate_projection(original, projected, 4)
        self.assertEqual((original, projected), before)
        self.assertEqual(projected["layouts"]["4"]["group_id"],
                         projected["layouts"]["2"]["group_id"])
        self.assertEqual(original["historical_ns"], 1800000000000000001)
        self.assertEqual(original["initial_source_sequence"], list(range(7)))
        self.assertNotIn("campaign_id", original)

    def test_old_scope_unchanged_and_old_preparer_still_rejects_l4(self):
        for layout in (2, 3):
            original, projected = fixture(layout)
            previous.validate_projection(original, projected, layout)
            current.validate_projection(original, projected, layout)
        original, projected = fixture(4)
        with self.assertRaises(ValueError):
            previous.validate_projection(original, projected, 4)

    def test_future_unadmitted_and_sealed_layouts_rejected(self):
        original, _ = fixture(4)
        for layout in (True, 0, 1, 5, 6, 7, 52, 53, 54):
            with self.subTest(layout=layout), self.assertRaises(ValueError):
                current.validate_original(original, layout)

    def test_duplicate_initialization_or_changed_membership_rejected(self):
        for key, value in (("initialization_distinct_from_preceding", False),
                           ("group_id", "different"), ("split", "student_dev"),
                           ("native_bank", 1), ("layout_ref", {})):
            original, projected = fixture(4)
            projected["layouts"]["4"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                current.validate_projection(original, projected, 4)

    def test_original_fields_and_scope_remain_frozen(self):
        for case in ("sequence", "sealed", "extra", "ns"):
            original, projected = fixture(4)
            if case == "sequence":
                original["initial_source_sequence"] = [0, 1, 2, 4, 3, 5, 6]
            elif case == "sealed":
                original["opaque_reserved_layouts"] = [51, 52]
            elif case == "extra":
                projected["layouts"]["5"] = deepcopy(projected["layouts"]["4"])
            else:
                projected["historical_ns"] += 1
            with self.subTest(case=case), self.assertRaises(ValueError):
                current.validate_projection(original, projected, 4)

    def test_entry_seam_is_pinned_and_retains_existing_loader(self):
        text = current.source()
        ast.parse(text)
        self.assertIn("configured.prepare_source(", text)
        self.assertIn("configured.load_native_layout(prepared)", text)
        self.assertIn("runtime_files_modified", text)
        with patch.object(Path, "read_bytes", return_value=b"changed"):
            with self.assertRaises(ValueError):
                current.source()


def deny_live_effects(event, args):
    if event.startswith(("socket.", "subprocess.", "os.system", "os.posix_spawn")) or event in ("os.kill", "os.killpg"):
        raise RuntimeError("Synthetic CPU projection cannot contact or launch a peer")


if __name__ == "__main__":
    sys.addaudithook(deny_live_effects)
    unittest.main()
