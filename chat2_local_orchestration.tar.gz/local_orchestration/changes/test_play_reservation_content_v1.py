"""Exercise exact new metadata guards with synthetic dictionaries; no real transactions."""
import ast
import copy
from pathlib import Path
import unittest

from test_play_revisit_metadata_v1 import ordered_case

HERE = Path(__file__).resolve().parent
TEXT = (HERE / "reserve_play_content_handoff_v1.py").read_text()
TREE = ast.parse(TEXT)
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def guard(needle):
    nodes = [node for node in TREE.body if isinstance(node, ast.Assert)
             and needle in ast.unparse(node.test)]
    assert len(nodes) == 1
    return compile(ast.Module(body=nodes, type_ignores=[]), "<synthetic-reservation-guard>", "exec")


class Tests(unittest.TestCase):
    def test_actual_owner_guard_rejects_old_or_active_executor(self):
        value = dict(source={"task": "play_stacking_toy"},
                     n=dict(current_task="play_stacking_toy", active_chat_id=OWNER,
                            owned_resource_launch_hold=False, active_run_id=None,
                            active_real_simulators=0, launch_inflight=False))
        code = guard("n['active_chat_id']")
        exec(code, copy.deepcopy(value))
        for key, wrong in (("active_chat_id", "01a16807-8085-7903-be07-66eb332ebf95"),
                           ("active_run_id", "synthetic_active")):
            changed = copy.deepcopy(value)
            changed["n"][key] = wrong
            with self.assertRaises(AssertionError):
                exec(code, changed)

    def test_actual_release_guard_rejects_stale_entry_set(self):
        release = dict(path=str(HERE / "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"),
                       sha256="b66ce4336280104df6cf44b92df13518b4471ef29e48e0640fe1aa6efc5e0131")
        # The guard deliberately pins the remote adapter, not the test's local directory.
        release["path"] = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"
        code = guard("b['runtime_release']")
        exec(code, {"b": {"runtime_release": release}})
        release["sha256"] = "0" * 64
        with self.assertRaises(AssertionError):
            exec(code, {"b": {"runtime_release": release}})

    def test_exact_original_order_verifier_remains_active(self):
        nodes = [node for node in TREE.body if isinstance(node, ast.FunctionDef)
                 and node.name == "verify_ordered_play_append"]
        self.assertEqual(len(nodes), 1)
        namespace = {}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "<synthetic-order>", "exec"), namespace)
        verify = namespace["verify_ordered_play_append"]
        self.assertEqual(verify(*ordered_case(12)), 12)
        with self.assertRaises(AssertionError):
            verify(*ordered_case(53))

    def test_group_alias_and_wall_scopes_are_preserved(self):
        self.assertIn("s.update(group_id=source['group_id']", TEXT)
        self.assertIn("native_wall_seconds=2400,teacher_wall_seconds=3600", TEXT)
        self.assertIn("/collect_recording_content_v1.py'", TEXT)
        self.assertIn("source_sequence=copy.deepcopy(source['source_sequence'])", TEXT)


if __name__ == "__main__":
    unittest.main()
