"""Synthetic CPU metadata cases; no models, peers, launch, or real ledger edits."""
from copy import deepcopy
from unittest.mock import patch
import unittest

import insert_sequence_handoff_v1 as change
import prepare_insert_sequence_handoff_v1 as preparation
import source_sequence_binding as binding
import test_source_sequence_binding as old


RECEIPT = dict(
    from_chat_id=change.SOURCE_OWNER, to_chat_id=change.EXECUTOR,
    lock_inode=27555308, chat1_unchanged=True,
    source_index_and_reservations_unchanged=True, data_kind="SYNTHETIC",
)


class HandoffTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.code = {
            value["path"]: binding._read(value)
            for value in (binding.HISTORY_REF, binding.ORDER_REF,
                          binding.BINDING_REF, binding.DECODER_REF)
        }

    def setUp(self):
        self.fixture = old.Fixture(self.code)
        self.wrapper = change.wrapped_prior(binding._prior, RECEIPT)

    def future(self, owner=change.EXECUTOR):
        f = self.fixture
        context = f.context()
        split = deepcopy(f.split)
        split["layouts"]["8"] = context["split_addition_proposal"]
        split["layout_to_group"]["8"] = f.group
        split["families"][f.group]["layouts"].append(context["family_addition_proposal"])
        split["initial_source_sequence"] = split["materialized_layouts"] = list(range(9))
        sequence = dict(
            f.sequence, owner_chat=owner, source_sequence=list(range(9)),
            prior_sequence=list(range(8)), added_layout=8, layout=f.refs[8],
        )
        return split, sequence

    def prepare(self, split, sequence, seed=9):
        f = self.fixture
        qr = f.put(f.directory / "future_sequence.json", sequence)
        split = dict(split, source_sequence_extension=qr)
        sr = f.put(f.directory / "future_split.json", split)
        raw = f.put(binding.NATIVE / "Assets/Eval_Layout/RoboDojo/arx_x5/0/insert_tubes_9.json",
                    old.layout(9))
        return f.context(encoded_seed=seed, expected_raw_sha256=raw["sha256"],
                         prior_split_ref=sr, prior_sequence_ref=qr)

    def test_new_sequence_author_preserves_source_and_original_documents(self):
        with self.fixture.install(), patch.object(binding, "_prior", self.wrapper):
            split, sequence = self.future()
            before = deepcopy((split, sequence, self.fixture.anchor))
            context = self.prepare(split, sequence)
            binding.validate_source_context(context)
            self.assertEqual((split, sequence, self.fixture.anchor), before)
            self.assertEqual(context["source"]["source_owner"], change.SOURCE_OWNER)
            self.assertEqual(context["source"]["execution_owner"], change.SOURCE_OWNER)
            self.assertEqual(context["native_step_limit"], 500)
            self.assertFalse(context["source_reserved"])
            self.assertFalse(context["launch_authority"])

    def test_legacy_author_unchanged(self):
        with self.fixture.install():
            split, sequence = self.future(change.SOURCE_OWNER)
            expected = self.prepare(split, sequence)
            with patch.object(binding, "_prior", self.wrapper):
                self.assertEqual(self.prepare(split, sequence), expected)

    def test_conflicting_sequence_author_rejected(self):
        with self.fixture.install(), patch.object(binding, "_prior", self.wrapper):
            with self.assertRaises(ValueError):
                self.prepare(*self.future("unrelated-synthetic-owner"))

    def test_split_owner_cannot_be_relabelled(self):
        with self.fixture.install(), patch.object(binding, "_prior", self.wrapper):
            split, sequence = self.future()
            split["owner_chat"] = change.EXECUTOR
            with self.assertRaises(ValueError):
                self.prepare(split, sequence)

    def test_changed_source_or_partition_still_rejected(self):
        for mutation in (
            lambda s, q: s["layouts"]["7"].update(data_split="eval"),
            lambda s, q: s["original_partition"]["train"].append(9),
            lambda s, q: q.update(added_layout=9),
            lambda s, q: q.update(source_issued=True),
            lambda s, q: q.update(launch_authority=True),
        ):
            with self.subTest(mutation=mutation), self.fixture.install():
                with patch.object(binding, "_prior", self.wrapper):
                    split, sequence = self.future()
                    mutation(split, sequence)
                    with self.assertRaises(ValueError):
                        self.prepare(split, sequence)

    def test_skip_and_sealed_requests_still_rejected(self):
        with self.fixture.install(), patch.object(binding, "_prior", self.wrapper):
            split, sequence = self.future()
            for seed in (10, 53, 54, True):
                with self.subTest(seed=seed), self.assertRaises(ValueError):
                    self.prepare(split, sequence, seed)

    def test_missing_or_conflicting_handoff_rejected(self):
        for key in RECEIPT:
            if key == "data_kind":
                continue
            receipt = dict(RECEIPT)
            receipt.pop(key)
            with self.subTest(key=key), self.assertRaises(ValueError):
                change.wrapped_prior(binding._prior, receipt)

    def test_metadata_guard_allows_hostname_not_network_or_processes(self):
        preparation.metadata_only("socket.gethostname", ())
        for event in (
            "socket.__new__", "socket.connect", "socket.bind",
            "socket.getaddrinfo", "subprocess.Popen", "os.system", "os.spawn",
        ):
            with self.subTest(event=event), self.assertRaises(RuntimeError):
                preparation.metadata_only(event, ())


if __name__ == "__main__":
    unittest.main()
