"""Pinned configured boundary with strict consecutive append compatibility."""
import hashlib
from pathlib import Path

PREVIOUS = Path(__file__).with_name("boundary_configured_handoff_v1.py")
PREVIOUS_SHA = "065e041110bf73a315d5c6b66dc3667383920c231ca079f64395ea10a0880f36"
OLD = (
    "assert ps['source_id']==sid and ps['task']==ns['task']==x['task'] "
    "and ps['source_sequence']==ns['source_sequence']"
)
NEW = (
    "assert ps['source_id']==sid and ps['task']==ns['task']==x['task'] "
    "and configured_sequence_follows(ps,ns)"
)


def configured_sequence_follows(previous, following):
    old = previous["source_sequence"]
    new = following["source_sequence"]
    if old == new:
        return True
    old_layout = previous["layout_id"]
    new_layout = following["layout_id"]
    return (
        type(old_layout) is int
        and type(new_layout) is int
        and old_layout >= 0
        and new_layout == old_layout + 1
        and old == list(range(old_layout + 1))
        and new == old + [new_layout]
        and previous["required_accounted_prefix"] == old[:-1]
        and following["required_accounted_prefix"] == old
    )


def source():
    raw = PREVIOUS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PREVIOUS_SHA:
        raise ValueError("Pinned configured boundary changed")
    text = raw.decode()
    if text.count(OLD) != 1:
        raise ValueError("Configured sequence seam changed")
    return text.replace(OLD, NEW, 1)


if __name__ == "__main__":
    exec(compile(source(), str(PREVIOUS) + "::strict_append", "exec"), globals())
