"""Synthetic CPU metadata only; never read a real ledger or launch processes."""
import ast
from copy import deepcopy
import datetime
import importlib
import os
from pathlib import Path
import re
import runpy
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import baseline_positive_gap_v1 as gap

ROOT = Path(os.environ.get("REFATE_SYNTHETIC_INPUTS", Path(__file__).parent))
OWNER = "01a16807-8085-7903-be07-66eb332ebf95"
CAMPAIGN = "refate-20261022-97baf70d5128"


def no_live_effects(event, args):
    if event.startswith("socket.") or event in {
        "subprocess.Popen", "os.system", "os.fork", "os.posix_spawn",
    }:
        raise AssertionError("Synthetic CPU tests forbid network/process effects")


sys.addaudithook(no_live_effects)


def fixture_function(name, namespace):
    tree = ast.parse((ROOT / name).read_bytes())
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "fixture"]
    assert len(functions) == 1
    exec(compile(ast.Module(body=functions, type_ignores=[]), "<synthetic-fixture>", "exec"), namespace)
    return namespace["fixture"]


reservation_fixture = fixture_function("test_common_owner_reservation.py", dict(
    deepcopy=deepcopy, owner=SimpleNamespace(OWNER=OWNER, CAMPAIGN=CAMPAIGN),
    OLD="plug_in_charger_b0_l0_synthetic", NEW="plug_in_charger_b0_l1_synthetic",
    REF={"path": "/synthetic/not-authority", "sha256": "a" * 64}))
settlement_fixture = fixture_function("test_common_owner_settlement_v3.py", dict(
    OWNER=OWNER, SID="synthetic:baseline-source", RUN="synthetic:baseline-run",
    TASK="insert_tubes"))
reserve_text = gap.pinned_text(ROOT / "common_owner_reservation.py",
                              "b9495cc8a0f316c830ec11a5ca8fbb352e455dabf0db3e324a16dfeaee4871ed")
settle_text = gap.pinned_text(ROOT / "common_owner_settlement_v2.py",
                             "1a27374955b2cbee923e2d354f92fa39d42e72c3f2f148dea93359cce2ed2375")


def compile_pure(text):
    namespace = gap.namespace()
    exec(compile(text, "<synthetic-pure-metadata>", "exec"), namespace)
    return namespace


reserve_old = compile_pure(reserve_text)["reserve"]
reserve_new = compile_pure(gap.reservation_source(reserve_text))["reserve"]
settle_old = compile_pure(settle_text)["settle"]
settle_new = compile_pure(gap.settlement_source(settle_text))["settle"]


def positive_reservation():
    ledger, boundary = reservation_fixture()
    node, task = ledger["nodes"]["perdon-hou"], ledger["tasks"]["plug_in_charger"]
    for scope in (node, task):
        scope.update(negative_count=10, negative_reserved_count=0,
                     qualified_count=3, reserved_count=0, positive_quota=10)
    return ledger, boundary


def positive_settlement(success):
    ledger, evidence = settlement_fixture(success)
    sid = evidence["source_id"]
    task = ledger["tasks"][evidence["task"]]
    node = ledger["nodes"]["perdon-hou"]
    for scope in (node, task):
        scope.update(negative_reserved_count=0, reserved_count=0)
    for category, count in (("negative", 10), ("positive", 3)):
        for i in range(count):
            key = f"synthetic:{category}:{i}"
            ledger["source_index"][key] = dict(
                source_id=key, task=evidence["task"], host="perdon-hou",
                counted_in_quota=category == "positive",
                counted_in_negative_quota=category == "negative")
    dispatch = dict(negative_slots=0)
    gap.mark_positive_dispatch(dispatch, dict(
        negative_count=10, negative_quota=10, qualified_count=3, positive_quota=10))
    ledger["reservations"][sid].update(
        negative_slots=0, negative_quota_reserved=False, dispatch=dispatch)
    ledger["source_index"][sid]["collection_goal"] = gap.MODE
    return ledger, evidence


class PositiveGapTests(unittest.TestCase):
    def test_normal_reservation_unchanged(self):
        d, b = reservation_fixture()
        self.assertEqual(reserve_new(d, b, "2026-10-26T12:00:01+00:00"),
                         reserve_old(d, b, "2026-10-26T12:00:01+00:00"))

    def test_normal_settlement_unchanged(self):
        for success in (False, True):
            d, e = settlement_fixture(success)
            expected, receipt = settle_old(d, e, "synthetic-time")
            expected["reservations"][e["source_id"]].update(
                quota_reserved=False, negative_quota_reserved=False)
            self.assertEqual(settle_new(d, e, "synthetic-time"), (expected, receipt))

    def test_zero_slot_reservation_preserves_quotas_and_peers(self):
        d, b = positive_reservation()
        before = deepcopy(d)
        out, dispatch = reserve_new(d, b, "2026-10-26T12:00:01+00:00")
        self.assertEqual(d, before)
        self.assertTrue(gap.dispatch_slots_valid(dispatch))
        self.assertEqual(dispatch["negative_slots"], 0)
        self.assertEqual(dispatch["positive_slots"], 0)
        self.assertEqual(out["nodes"]["perdon-hou"]["negative_reserved_count"], 0)
        self.assertEqual(out["tasks"]["plug_in_charger"]["negative_quota"], 10)
        self.assertEqual(out["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(dispatch["native_total_steps"], 400)
        self.assertEqual(dispatch["native_wall_seconds"], 2400)
        self.assertEqual(dispatch["teacher_wall_seconds"], 3600)
        self.assertEqual(dispatch["original_segment_started_at"], "synthetic_original_segment")

    def test_full_both_categories_rejected(self):
        d, b = positive_reservation()
        d["tasks"]["plug_in_charger"]["qualified_count"] = 10
        with self.assertRaises(ValueError):
            reserve_new(d, b, "2026-10-26T12:00:01+00:00")

    def test_reserved_positive_capacity_rejected(self):
        d, b = positive_reservation()
        d["tasks"]["plug_in_charger"]["reserved_count"] = 7
        with self.assertRaises(ValueError):
            reserve_new(d, b, "2026-10-26T12:00:01+00:00")

    def test_reserved_negative_is_not_filled_quota(self):
        d, b = positive_reservation()
        d["tasks"]["plug_in_charger"].update(negative_count=9, negative_reserved_count=1)
        with self.assertRaises(ValueError):
            reserve_new(d, b, "2026-10-26T12:00:01+00:00")

    def test_node_positive_capacity_rejected(self):
        d, b = positive_reservation()
        d["nodes"]["perdon-hou"]["qualified_count"] = 10
        with self.assertRaises(ValueError):
            reserve_new(d, b, "2026-10-26T12:00:01+00:00")

    def test_original_owner_pause_active_and_stale_guards(self):
        for key, value in (("active_chat_id", "peer"), ("user_stop", True),
                           ("user_pause_active", True), ("active_real_simulators", 1)):
            d, b = positive_reservation()
            d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                reserve_new(d, b, "2026-10-26T12:00:01+00:00")
        d, b = positive_reservation()
        with self.assertRaises(ValueError):
            reserve_new(d, b, "2026-10-27T12:00:01+00:00")

    def test_original_duplicate_and_prefix_guards(self):
        for case in ("duplicate", "prefix"):
            d, b = positive_reservation()
            source = b["next_preparation"]["prepared"]["source"]
            if case == "duplicate":
                source["initialization_content_sha256"] = "old_synthetic"
            else:
                source["required_accounted_prefix"] = [0, 2]
            with self.subTest(case=case), self.assertRaises(ValueError):
                reserve_new(d, b, "2026-10-26T12:00:01+00:00")

    def test_zero_slot_failure_remains_failure(self):
        d, e = positive_settlement(False)
        out, receipt = settle_new(d, e, "synthetic-time")
        source = out["source_index"][e["source_id"]]
        self.assertTrue(source["reusable_DM_failure"])
        self.assertFalse(source["native_success"])
        self.assertEqual(receipt["negative_delta"], 0)
        self.assertEqual(receipt["positive_delta"], 0)
        self.assertEqual(receipt["backup_negative_delta"], 0)
        self.assertEqual(out["tasks"][e["task"]]["negative_count"], 10)
        self.assertEqual(out["nodes"]["perdon-hou"]["negative_reserved_count"], 0)

    def test_zero_slot_success_is_backup_not_failure_or_core(self):
        d, e = positive_settlement(True)
        before = deepcopy(d)
        out, receipt = settle_new(d, e, "synthetic-time")
        source = out["source_index"][e["source_id"]]
        self.assertEqual(d, before)
        self.assertEqual(receipt["negative_delta"], 0)
        self.assertEqual(receipt["backup_negative_delta"], 1)
        self.assertTrue(source["native_success"])
        self.assertTrue(source["reserve_qualified_negative"])
        self.assertFalse(source["reusable_DM_failure"])
        self.assertFalse(source["counted_in_negative_quota"])
        self.assertEqual(source["negative_qualification_status"], "qualified")
        self.assertEqual(source["negative_manifest"], e["manifest"])
        self.assertEqual(out["tasks"][e["task"]]["negative_count"], 10)
        self.assertEqual(out["nodes"]["perdon-hou"]["baseline_accounting"]["baseline_attempts_native_success"], 1)
        self.assertEqual(out["nodes"]["peer_host"], before["nodes"]["peer_host"])

    def test_backup_settlement_idempotent(self):
        d, e = positive_settlement(True)
        out, _ = settle_new(d, e, "synthetic-time")
        again, receipt = settle_new(out, e, "later")
        self.assertEqual(again, out)
        self.assertTrue(receipt["already_settled"])

    def test_conflicting_backup_settlement_rejected(self):
        d, e = positive_settlement(True)
        out, _ = settle_new(d, e, "synthetic-time")
        changed = deepcopy(e)
        changed["settlement_ref"]["sha256"] = "1" * 64
        with self.assertRaises(ValueError):
            settle_new(out, changed, "later")

    def test_missing_readback_and_unknown_native_result_rejected(self):
        for field, value in (("file_recording_readback_passed", False),
                             ("native_success", None), ("native_steps", 501)):
            d, e = positive_settlement(True)
            e["summary"][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                settle_new(d, e, "synthetic-time")

    def test_actual_success_evidence_cannot_be_rewritten_as_zero(self):
        d, e = positive_settlement(True)
        e["new_negative"] = 0
        with self.assertRaises(ValueError):
            settle_new(d, e, "synthetic-time")

    def test_zero_slot_requires_explicit_issue_proof(self):
        d, e = positive_settlement(True)
        del d["reservations"][e["source_id"]]["dispatch"]["quota_at_issue"]
        with self.assertRaises(ValueError):
            settle_new(d, e, "synthetic-time")

    def test_slot_type_and_count_rejected(self):
        for slots in (False, 0.0, -1, 2):
            self.assertFalse(gap.dispatch_slots_valid(dict(negative_slots=slots)))

    def test_closed_resource_is_not_new_data_gate(self):
        d, e = positive_settlement(True)
        e["safe_for_next_simulator"] = False
        out, receipt = settle_new(d, e, "synthetic-time")
        self.assertEqual(receipt["backup_negative_delta"], 1)
        self.assertEqual(out["nodes"]["perdon-hou"]["active_real_simulators"], 1)

    def test_seam_drift_rejected(self):
        with self.assertRaises(ValueError):
            gap.reservation_source(reserve_text.replace("negative_slots=1", "negative_slots=9", 1))
        with self.assertRaises(ValueError):
            gap.settlement_source(settle_text.replace("    negative = int(q['native_success'])", "changed"))


class EntryTests(unittest.TestCase):
    def setUp(self):
        self.here = Path(__file__).parent
        original = gap.pinned_text(ROOT / "bind_catalog_context.py",
                                  "ed809c02c01e6324afc0e10b81418baafac2b11057fc06eb8146553b44a088ec")
        for old, new in (
            ("import collect_with_extensions as collection\n", "import collect_recording_content_v1 as collection\n"),
            ("stage.HERE / 'collect_with_extensions.py'", "stage.HERE / 'collect_recording_content_v1.py'"),
            ("and source['execution_owner'] == stage.OWNER, 'Source lineage differs')",
             "and historical_preparer_allowed(source), 'Source lineage differs')"),
        ):
            original = gap.change(original, old, new)
        stub = SimpleNamespace(text=original,
                               __file__=str(self.here / "bind_recording_content_v1.py"),
                               historical_preparer_allowed=lambda s: s["execution_owner"] == OWNER)
        with patch.dict(sys.modules, {"bind_recording_content_v1": stub}):
            entry = runpy.run_path(str(self.here / "bind_positive_gap_context_v1.py"))
        self.text = entry["text"]
        stage = SimpleNamespace(OWNER=OWNER, HERE=Path("/synthetic/adapter"),
                                SHARED=Path("/synthetic/shared"), need=gap.need)
        namespace = dict(deepcopy=deepcopy, datetime=datetime, re=re, stage=stage,
                         dispatch_slots_valid=gap.dispatch_slots_valid,
                         historical_preparer_allowed=stub.historical_preparer_allowed)
        tree = ast.parse(self.text)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "assemble")
        exec(compile(ast.Module(body=[fn], type_ignores=[]), "<synthetic-binder>", "exec"), namespace)
        self.assemble = namespace["assemble"]
        fixture_tree = ast.parse((ROOT / "test_bind_catalog_context.py").read_bytes())
        cls = next(n for n in fixture_tree.body if isinstance(n, ast.ClassDef) and n.name == "Binding")
        setup = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "setUp")
        fixture_ns = dict(datetime=datetime, b=SimpleNamespace(stage=stage))
        exec(compile(ast.Module(body=[setup], type_ignores=[]), "<synthetic-binder-fixture>", "exec"), fixture_ns)
        fixture_ns["setUp"](self)
        self.r["foreground_entry"] = str(stage.HERE / "collect_recording_content_v1.py")

    def zero(self):
        self.d["negative_slots"] = 0
        gap.mark_positive_dispatch(self.d, dict(
            negative_count=10, negative_quota=10, qualified_count=3, positive_quota=10))

    def go(self):
        return self.assemble(self.d, self.p, self.r, self.now)

    def test_actual_new_binder_accepts_zero_slot_without_runtime_change(self):
        self.zero()
        result = self.go()
        self.assertEqual(result["ledger_authorization"]["negative_slots"], 0)
        self.assertEqual(result["runtime_files"], self.r["runtime_files"])
        self.assertEqual(result["native_total_steps"], 700)
        self.assertEqual(result["native_wall_seconds"], 2400)
        self.assertEqual(result["teacher_wall_seconds"], 3600)
        self.assertIn("collect_recording_content_v1", self.text)
        self.assertIn("actual_capacity_adapter=capacity_adapter", self.text)

    def test_actual_new_binder_keeps_one_slot(self):
        self.assertEqual(self.go()["ledger_authorization"]["negative_slots"], 1)

    def test_actual_new_binder_rejects_unproven_zero_slot(self):
        self.d["negative_slots"] = 0
        with self.assertRaises(ValueError):
            self.go()

    def test_actual_new_binder_keeps_target_budget_and_renderer_guards(self):
        for key, value in (("host", "other"), ("native_total_steps", 500),
                           ("teacher_wall_seconds", 7200), ("rtx_profile", "wrong"),
                           ("source_started", True)):
            original = deepcopy(self.d)
            self.zero()
            self.d[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.go()
            self.d = original

    def test_cli_entries_select_new_metadata_helpers(self):
        for filename, expected in (
            ("reserve_positive_gap_handoff_v1.py", "import owner_positive_gap_reservation_v1 as helper"),
            ("settle_positive_gap_handoff_v1.py", "import owner_positive_gap_settlement_v1 as helper"),
            ("baseline_bind_positive_gap_handoff_v1.py", "bind_positive_gap_context_v1.py"),
        ):
            entry = runpy.run_path(str(self.here / filename))
            self.assertIn(expected, entry["text"])
            ast.parse(entry["text"])

    def test_actual_clock_entry_uses_core_delta_not_backup_success(self):
        entry = runpy.run_path(str(self.here / "settle_positive_gap_handoff_v1.py"))
        self.assertIn("if receipt.get('negative_delta',0):", entry["text"])
        self.assertNotIn("if e['new_negative']:", entry["text"])
        self.assertIn("closed.baseline_checks(e)", entry["text"])

    def test_mac_locked_helpers_have_only_capacity_seam_changed(self):
        if os.uname().sysname != "Darwin":
            self.skipTest("Mac-only ledger helper source check is performed on the Mac")
        for name in ("record_baseline_binding.py", "record_baseline_start.py"):
            original = (self.here.parent / name).read_text()
            modified = gap.local_source(original)
            self.assertEqual(modified.replace("local_reservation_valid(d,r,s,n,t)", "r['negative_slots']==1"), original)
            self.assertIn("27555308", modified)
            self.assertIn("fcntl.flock", modified)
            ast.parse(modified)

    def actual_pure_adapter(self, filename, invoke):
        names = ("owner_positive_gap_reservation_v1", "owner_positive_gap_settlement_v1",
                 "owner_reservation_handoff_v1", "common_owner_reservation_v2")
        files = ("baseline_positive_gap_v1.py", "owner_positive_gap_reservation_v1.py",
                 "owner_positive_gap_settlement_v1.py", "owner_reservation_handoff_v1.py",
                 "common_owner_reservation_v2.py", "common_owner_reservation.py",
                 "common_owner_settlement_v2.py")
        with tempfile.TemporaryDirectory(prefix="synthetic-refate-capacity-") as folder:
            for name in files:
                source = self.here / name
                if not source.exists():
                    source = ROOT / name
                shutil.copyfile(source, Path(folder) / name)
            old_path = list(sys.path)
            try:
                sys.path.insert(0, folder)
                with patch.dict(sys.modules):
                    for name in names:
                        sys.modules.pop(name, None)
                    invoke(importlib.import_module(filename))
            finally:
                sys.path[:] = old_path

    def test_actual_owner_reservation_adapter_keeps_historical_preparer(self):
        def invoke(module):
            d, b = positive_reservation()
            d["nodes"]["perdon-hou"]["active_chat_id"] = module.OWNER
            source = b["next_preparation"]["prepared"]["source"]
            source.update(source_owner=OWNER, execution_owner=OWNER)
            out, dispatch = module.reserve(d, b, "2026-10-26T12:00:01+00:00")
            self.assertEqual(dispatch["negative_slots"], 0)
            self.assertEqual(dispatch["execution_owner"], "01a19072-9e5e-7e02-b77a-8f115cfc9bd0")
            self.assertEqual(dispatch["source_owner"], OWNER)
            self.assertEqual(out["source_index"][dispatch["source_id"]]["collection_goal"], gap.MODE)
        self.actual_pure_adapter("owner_positive_gap_reservation_v1", invoke)

    def test_actual_owner_settlement_adapter_keeps_backup_out_of_core(self):
        def invoke(module):
            d, e = positive_settlement(True)
            owner = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
            d["nodes"]["perdon-hou"]["active_chat_id"] = owner
            d["source_index"][e["source_id"]]["execution_owner"] = owner
            e["execution_owner"] = owner
            out, receipt = module.settle(d, e, "synthetic-time")
            self.assertEqual(receipt["backup_negative_delta"], 1)
            self.assertEqual(receipt["negative_delta"], 0)
            self.assertEqual(out["tasks"][e["task"]]["negative_count"], 10)
        self.actual_pure_adapter("owner_positive_gap_settlement_v1", invoke)


if __name__ == "__main__":
    unittest.main()
