"""Task binding for the already adopted independent-negative shortage rule."""
import hashlib
from pathlib import Path
import switch_general_to_retained_classify_v1 as parent


def source():
    if hashlib.sha256(Path(parent.__file__).read_bytes()).hexdigest() != (
            "c548e0f262f4de991c20367c3dd8b9296f0f164815b73086d54d50232883aebc"):
        raise ValueError("Frozen retained-source scheduling dependency changed")
    text = parent.source()
    text = parent.replace_exact(text, "general_pickup", "organize_table", 6)
    text = parent.replace_exact(text, "classify_objects", "play_stacking_toy", 6)
    return parent.replace_exact(text, '== s["native_budget"] == 1100',
                                '== s["native_budget"] == 1200')


exec(compile(source(), str(Path(__file__)) + "::organize_play_revisit", "exec"),
     globals())
