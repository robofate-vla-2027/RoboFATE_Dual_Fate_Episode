"""Synthetic bookkeeping only; original review reads a mocked document store."""
import copy
import unittest
from unittest.mock import patch

import test_general_baseline_retained_classify_v1 as fixture
import switch_general_negative_to_retained_classify_v1 as current


class NegativeRetainedTests(unittest.TestCase):
    def setUp(self):
        fixture.ClosedGeneralRetainedTests.setUp(self)
        self.at = "2026-10-31T10:10:00+00:00"
        task = self.d["tasks"]["general_pickup"]
        task.update(qualified_count=10, negative_count=1, source_sequence=list(range(19, 24)),
                    last_negative_gain_at="2026-10-30T10:00:00+00:00")
        old = self.d["source_index"].pop("old")
        reservation = self.d["reservations"].pop("old")
        self.latest = "general_pickup_b0_l23_synthetic"
        self.e.update(source_id=self.latest, native_budget=200, new_positive=0, new_negative=0)
        self.documents = {}
        for ordinal in range(19, 24):
            sid = f"general_pickup_b0_l{ordinal}_synthetic"
            ref = self.ref if ordinal == 23 else dict(path=f"synthetic/{ordinal}", sha256=str(ordinal))
            source = dict(old, source_id=sid, source_started=True, complete_readback=True,
                          native_success=False, negative_count=0, settlement=ref,
                          initialization_content_sha256=f"{ordinal:064x}")
            event = dict(self.e, source_id=sid, context=source["context"])
            self.d["source_index"][sid] = source
            self.d["reservations"][sid] = dict(reservation, settlement=ref)
            self.documents[ref["sha256"]] = event
        self.e = self.documents[self.ref["sha256"]]

    def run_switch(self):
        def review(ledger, sid):
            return current.five.review_negative_shortfall(
                ledger, sid, lambda ref: self.documents[ref["sha256"]])
        with patch.object(current, "review_negative_shortfall", review):
            return current.switch_due(self.d, self.e, self.ref, self.retained,
                                      self.at, "Synthetic fixture, not scientific data")

    def test_original_five_failure_review_without_a_new_ninety_minute_wait(self):
        out = self.run_switch()
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["negative_shortfall_review"]["preserved_consecutive_tail"],
                         [19, 20, 21, 22, 23])
        self.assertEqual(event["scheduling_trigger"],
                         "negative_only_five_consecutive_independent_DM_failures")
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_no_replay_credit_or_peer_nanosecond_change(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        self.assertFalse(out["receipt"]["transition"]["baseline_replay"])

    def test_recent_teacher_gain_does_not_clear_failure_tail(self):
        self.d["tasks"]["general_pickup"]["last_core_gain_at"] = "2026-10-31T10:09:00+00:00"
        self.run_switch()
        self.assertEqual(self.d["tasks"]["general_pickup"]["qualified_count"], 10)

    def test_missing_independent_failure_or_repeated_initialization_rejected(self):
        for key, value in (("native_success", True), ("complete_readback", False),
                           ("source_started", False),
                           ("initialization_content_sha256", f"{23:064x}")):
            self.setUp()
            self.d["source_index"]["general_pickup_b0_l19_synthetic"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()

    def test_outstanding_reservation_and_wrong_native_budget_rejected(self):
        self.d["reservations"]["general_pickup_b0_l19_synthetic"]["quota_reserved"] = True
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()
        self.setUp()
        self.documents["19"]["native_budget"] = 500
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()

    def test_retained_attempt_refusal_or_unread_source_rejected(self):
        for key, value in (("teacher_attempt_history", [{"synthetic": True}]),
                           ("provider_safety_refusal", {"synthetic": True}),
                           ("complete_readback", False)):
            self.setUp()
            self.d["source_index"]["retained"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()

    def test_live_resources_and_pause_rejected(self):
        for key, value in (("active_real_simulators", 1), ("launch_inflight", True),
                           ("user_pause_active", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()

    def test_not_due_target_and_not_negative_only_rejected(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()
        self.setUp()
        self.d["tasks"]["general_pickup"]["qualified_count"] = 9
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()

    def test_only_existing_window_and_event_seams_change(self):
        expected = current.previous.source().replace(current.OLD, current.NEW, 1)
        expected = expected.replace(current.EVENT, current.NEW_EVENT, 1)
        self.assertEqual(current.source(), expected)
        self.assertIs(current.baseline_checks, current.previous.baseline_checks)
        self.assertIs(current.review_negative_shortfall, current.five.review_negative_shortfall)


if __name__ == "__main__":
    unittest.main()
