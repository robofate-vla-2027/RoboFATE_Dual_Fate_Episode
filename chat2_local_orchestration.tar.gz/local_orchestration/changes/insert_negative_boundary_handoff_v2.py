"""Original closed-source boundary with the matching sequence-author-aware entry."""
from pathlib import Path
import insert_sequence_handoff_v1 as handoff
handoff.install()
import common_runtime as runtime

path = Path(__file__).with_name("insert_negative_boundary_handoff_v1.py")
text = runtime.read_pin({
    "path": str(path),
    "sha256": "09295397e1ef4b739f8c41976e48546a6a6856ab839eaa08723984f3176d62dc",
}).decode()
text = runtime.edit(text, "import collect_recording_content_v1 as collection;",
                    "import collect_insert_sequence_content_v1 as collection;")
text = runtime.edit(
    text, "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json",
    "RUNTIME_INSERT_SEQUENCE_CONTENT_RELEASE_20261103_01a19072.json",
)
exec(compile(text, str(path) + "::sequence_handoff", "exec"), globals())
