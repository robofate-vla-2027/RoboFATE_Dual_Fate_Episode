"""Append frozen General metadata through the existing configured-source loader."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import types

import prepare_general_l7_handoff_v1 as legacy


def need(value, message):
    legacy.need(value, message)


def sequence(layout):
    need(type(layout) is int and 7 <= layout < 53, "Sealed or invalid ordinal")
    return legacy.PREFIX + list(range(7, layout + 1))


def validate_projection(original, projected, layout):
    legacy.extended_manifest(original)
    expected = deepcopy(original)
    expected["initial_source_sequence"] = sequence(layout)
    for key, value in expected.items():
        need(projected.get(key) == (legacy.CATALOG_OWNER if key == "owner_chat" else value),
             "Original field changed: " + key)
    need(projected["historical_manifest_owner"] == legacy.LEGACY_OWNER
         and projected["original_partition"] == original["previous_plan"]["partition"],
         "Historical owner or sealed partition changed")
    need(set(projected["layouts"]) == {str(i) for i in sequence(layout)},
         "Unexpected projected source")
    for i in sequence(layout):
        group = original["layout_to_group"][str(i)]
        family = original["families"][group]
        members = [m for m in family["layouts"] if m["bank"] == 0 and m["layout_id"] == i]
        need(len(members) == 1 and family["split"] in ("student_train", "student_dev"),
             "Ambiguous or sealed original family")
        row = projected["layouts"][str(i)]
        need(row["layout_id"] == i and row["native_bank"] == 0
             and row["group_id"] == group and row["split"] == family["split"]
             and row["layout_ref"] == {k: members[0][k] for k in ("path", "sha256")},
             "Frozen source membership changed")
    need(projected["layouts"][str(layout)]["initialization_distinct_from_preceding"] is True,
         "Duplicate full initialization")
    return True


def extend(original, prior, layout):
    need(type(layout) is int and 8 <= layout < 53, "Only a next unsealed source")
    validate_projection(original, prior, layout - 1)
    out = deepcopy(original)
    out["initial_source_sequence"] = sequence(layout)
    return out


def main():
    sys.addaudithook(legacy.metadata_only)
    x = json.load(sys.stdin)
    need(set(x) == {"execution_owner", "layout", "prior_manifest"}
         and x["execution_owner"] == legacy.OWNER, "Wrong metadata scope")
    layout = x["layout"]
    sequence(layout)
    need(layout >= 8, "L7 already prepared; reuse its original files")
    sys.path.insert(0, str(legacy.ADAPTER))
    import task_configured_binding as configured
    from general_prefix_handoff_v1 import document
    from prepare_classify_legacy_handoff_v2 import ref, save

    directory = legacy.ADAPTER / "task_sources" / legacy.TASK
    need(x["prior_manifest"]["path"] ==
         str(directory / f"SPLIT_LEGACY_APPEND_L{layout - 1}_001.json"),
         "Not the immediately preceding frozen projection")
    prior = document(x["prior_manifest"])
    original = document(legacy.ORIGINAL)
    extended = extend(original, prior, layout)
    paths = [directory / f"SPLIT_LEGACY_APPEND_L{layout}_001.json",
             directory / f"PREPARATION_L{layout}_CONFIGURED_001.json",
             directory / f"PREPARATION_L{layout}_HANDOFF_01a19072_001.json"]
    need(not any(p.exists() for p in paths), "Inspect existing preparation; never overwrite")
    path = legacy.ADAPTER / "task_binding_v10.py"
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == legacy.HELPER_SHA, "Frozen projection core changed")
    helper = types.ModuleType("_refate_general_append_projection_only")
    helper.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), helper.__dict__)
    helper.TASK = legacy.TASK
    raw_by_layout = {}
    for i in sequence(layout):
        _, family, member = helper.member(original, i)
        need(family["split"] in ("student_train", "student_dev"), "Sealed family")
        expected_path = helper.base.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{legacy.TASK}_{i}.json"
        raw_by_layout[i] = helper.base.original.decode(helper.base.read_ref(
            {k: member[k] for k in ("path", "sha256")}, expected_path=expected_path))
    projected = helper.legacy_view(extended, layout, raw_by_layout)
    validate_projection(original, projected, layout)
    need(all(projected["layouts"][str(i)] == prior["layouts"][str(i)]
             for i in sequence(layout - 1)), "Prior source descriptor changed")
    projected["metadata_projection"] = {
        "schema": "refate.legacy_split.configured_sequence_append.v1",
        "original_manifest": legacy.ORIGINAL, "prior_manifest": x["prior_manifest"],
        "required_accounted_prefix": sequence(layout - 1), "appended_original_layout": layout,
        "existing_family_assignments_unchanged": True, "prepared_by": legacy.OWNER,
        "historical_manifest_owner": legacy.LEGACY_OWNER,
        "catalog_descriptor_owner": legacy.CATALOG_OWNER,
        "new_family_registered": False, "sealed_layout_content_read": False,
        "original_file_modified": False, "projection_is_not_execution_authority": True,
    }
    split_ref = save(paths[0], projected)
    task_ref = ref(helper.base.NATIVE / f"task/RoboDojo/tasks/{legacy.TASK}.py")
    prepared, native_layout = configured.prepare_source(
        task=legacy.TASK, layout_id=layout, split_ref=split_ref, native_total=200, task_ref=task_ref)
    need(configured.load_native_layout(prepared) == native_layout, "Configured loader disagrees")
    preparation_ref = save(paths[1], prepared)
    need(ref(Path(legacy.ORIGINAL["path"])) == legacy.ORIGINAL
         and ref(Path(x["prior_manifest"]["path"])) == x["prior_manifest"],
         "Existing source evidence changed")
    result = {
        "data_kind": "preparation_only", "execution_owner": legacy.OWNER,
        "source_id": prepared["source"]["source_id"], "source_owner": prepared["source"]["source_owner"],
        "preparation_ref": preparation_ref, "split_ref": split_ref, "metadata_helper": ref(Path(__file__)),
        "original_split": legacy.ORIGINAL, "prior_manifest": x["prior_manifest"],
        "native_budget": 200, "required_accounted_prefix": sequence(layout - 1),
        "source_sequence": sequence(layout), "split": prepared["source"]["split"],
        "source_registered": False, "source_reserved": False, "actual_launch": False,
        "old_sources_replayed": False, "runtime_files_modified": False,
        "sealed_content_read": False, "positive_delta": 0, "negative_delta": 0,
    }
    result["evidence_ref"] = save(paths[2], result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
