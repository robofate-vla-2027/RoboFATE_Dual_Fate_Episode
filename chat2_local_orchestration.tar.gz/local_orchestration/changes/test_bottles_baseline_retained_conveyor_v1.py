"""Synthetic CPU metadata only; imported fixture denies all live effects."""
import copy
import unittest

import test_general_baseline_retained_classify_v1 as fixture
import switch_bottles_baseline_to_retained_conveyor_v1 as current

OLD = "put_bottles_into_dustbin"
TARGET = "pick_from_conveyor_by_image"


def task_names(value):
    names = {"general_pickup": OLD, "classify_objects": TARGET}
    if isinstance(value, dict):
        return {names.get(k, k): task_names(v) for k, v in value.items()}
    if isinstance(value, list):
        return [task_names(v) for v in value]
    return names.get(value, value) if isinstance(value, str) else value


class BottlesConveyorTests(unittest.TestCase):
    def setUp(self):
        fixture.ClosedGeneralRetainedTests.setUp(self)
        self.d = task_names(self.d)
        self.e = task_names(self.e)
        self.d["tasks"][OLD].update(qualified_count=3, negative_count=10)
        self.d["source_index"]["retained"].update(native_steps=700, native_budget=700)

    def run_switch(self):
        return current.switch_due(self.d, self.e, self.ref, self.retained,
                                  self.at, "synthetic fixture, not scientific data")

    def test_counts_sources_peers_and_integer_nanoseconds_preserved(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], TARGET)
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for name in (OLD, TARGET):
            for key in ("qualified_count", "negative_count", "last_core_gain_at",
                        "last_negative_gain_at"):
                self.assertEqual(self.d["tasks"][name].get(key),
                                 before["tasks"][name].get(key))
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)
        transition = out["receipt"]["transition"]
        for key in ("baseline_replay", "source_started", "reserved"):
            self.assertFalse(transition[key])
        self.assertEqual(len(transition["completed_other_segments"]), 2)

    def test_backup_success_is_not_recounted_or_clock_reset(self):
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"
        self.d["source_index"]["old"].update(
            counted_in_quota=False, counted_in_negative_quota=False, negative_count=0)
        self.test_counts_sources_peers_and_integer_nanoseconds_preserved()

    def test_recent_core_gain_rejected_even_with_old_negative_clock(self):
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_early_window_rejected(self):
        self.at = "2026-10-31T11:29:00+00:00"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_two_other_segments_required(self):
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_live_resources_and_user_holds_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"),
                           ("active_real_simulators", 1),
                           ("owned_resource_launch_hold", True),
                           ("launch_inflight", True), ("user_pause_active", True),
                           ("user_stop", True)):
            with self.subTest(key=key):
                self.setUp()
                self.d["nodes"]["perdon-hou"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.run_switch()

    def test_retained_attempts_refusals_and_incomplete_data_rejected(self):
        for key, value in (("active_teacher_attempt", {"synthetic": True}),
                           ("teacher_attempt_history", [{"synthetic": True}]),
                           ("provider_safety_refusal", {"synthetic": True}),
                           ("teacher_replay_prohibited", True),
                           ("counted_in_quota", True), ("counted_in_negative_quota", True),
                           ("complete_readback", False), ("reusable_DM_failure", False),
                           ("native_success", True), ("native_budget", 1100)):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_source_context_host_and_unsettled_baseline_rejected(self):
        for key, value in (("task", "synthetic-foreign"), ("host", "synthetic-foreign"),
                           ("context", {}), ("run_id", "synthetic-different"),
                           ("settlement", {})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["old"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()
        self.setUp()
        self.d["reservations"]["old"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_missing_readback_and_outcome_mismatch_rejected(self):
        self.e["first_readback_passed"] = False
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.e["summary"]["qualified_negative"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_wrong_owner_and_retained_binding_rejected(self):
        self.d["nodes"]["perdon-hou"]["active_chat_id"] = "synthetic-other-owner"
        with self.assertRaises(AssertionError):
            self.run_switch()
        for key, value in (("task", OLD), ("host", "synthetic-foreign"),
                           ("context", {"synthetic": "mismatch"})):
            with self.subTest(key=key):
                self.setUp()
                self.d["source_index"]["retained"][key] = value
                with self.assertRaises(AssertionError):
                    self.run_switch()

    def test_full_target_and_outstanding_reservation_rejected(self):
        self.d["tasks"][TARGET]["qualified_count"] = 10
        with self.assertRaises(AssertionError):
            self.run_switch()
        self.setUp()
        self.d["reservations"]["retained"]["negative_quota_reserved"] = True
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_only_task_binding_and_phase_label_changed(self):
        text = current.source()
        expected = current.parent.source()
        expected = expected.replace("classify_objects", TARGET)
        expected = expected.replace("general_pickup", OLD)
        expected = expected.replace('== s["native_budget"] == 1100',
                                    '== s["native_budget"] == 700')
        expected = expected.replace('phase="deferred_after_settled_negative_shortfall"',
                                    'phase="deferred_after_settled_no_gain"')
        self.assertEqual(text, expected)


if __name__ == "__main__":
    unittest.main()
