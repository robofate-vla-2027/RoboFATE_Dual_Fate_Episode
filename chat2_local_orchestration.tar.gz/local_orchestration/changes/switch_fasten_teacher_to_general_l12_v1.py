"""Reuse the original closed-teacher revisit, for the existing General L12."""
import hashlib
from pathlib import Path
import switch_fasten_teacher_to_prepared_general_v1 as previous

PARENT_SHA = "48d8d278f9a2ba3e43b1f5e90bad7b6978dabeb79d51ed09d960befb0cb465c6"
CHANGES = (
    ("s[\"layout_id\"] == 10 and s[\"source_sequence\"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]",
     "s[\"layout_id\"] == 12 and s[\"source_sequence\"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10, 11, 12]"),
    ("s[\"required_accounted_prefix\"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]",
     "s[\"required_accounted_prefix\"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10, 11]"),
)


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != PARENT_SHA:
        raise ValueError("Frozen teacher-to-General scheduling helper changed")
    text = previous.source()
    for old, new in CHANGES:
        if text.count(old) != 1:
            raise ValueError("Original General source-sequence seam changed")
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::prepared_general_l12", "exec"), globals())
