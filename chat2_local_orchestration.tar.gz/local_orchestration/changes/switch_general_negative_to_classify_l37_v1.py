"""Reuse the frozen five-failure review for the next prepared Classify L37."""
from pathlib import Path

import switch_general_negative_to_classify_l47_v1 as previous

SEQUENCE = previous.SEQUENCE
baseline = previous.baseline
baseline_checks = previous.baseline_checks
review_negative_shortfall = previous.review_negative_shortfall


def source():
    previous.pinned(
        previous.__file__,
        "d0d665229c4083ac6f24e462d1f65e86e28f4ec8227851760bc74d6acd1ff01d")
    text = previous.source()
    for old, new in (
        ('s["layout_id"] == 47 and s["source_sequence"] == SEQUENCE',
         's["layout_id"] == 37 and s["source_sequence"] == SEQUENCE'),
        ('s["required_accounted_prefix"] == SEQUENCE[:15]',
         's["required_accounted_prefix"] == SEQUENCE[:20]'),
    ):
        text = previous.replace_once(text, old, new)
    return text


exec(compile(source(), str(Path(__file__)) + "::general_negative_classify37", "exec"),
     globals())
