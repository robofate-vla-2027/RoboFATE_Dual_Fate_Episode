"""Synthetic CPU bookkeeping only; no real ledger, peers, model or simulator."""
import ast
from copy import deepcopy
import sys
import unittest


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("SYNTHETIC_METADATA_ONLY " + event)


sys.addaudithook(reject_live)
import test_fasten_general_boundary_v1 as original
import switch_classify_baseline_to_organize_l15_v1 as scheduling
import organize_l15_from_classify_boundary_v1 as boundary

original.OLD = "classify_objects"
original.NEXT = "organize_table"
original.SEQUENCE = list(range(16))


class ClassifyOrganizeTests(original.ClosedFastenTests):
    def setUp(self):
        super().setUp()
        self.prep.update(native_step_limit=1000,
                         binding_schema="refate.common_collector.task_source_binding.v1")
        self.prep["source"].update(layout_id=15, source_sequence=list(range(16)),
                                   required_accounted_prefix=list(range(15)))

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
            at or self.f.at, "Synthetic boundary only, no scientific credit")


class OrganizeResourceTests(unittest.TestCase):
    def setUp(self):
        self.prep = {
            "native_step_limit": 1000,
            "source": {
                "task": "organize_table", "layout_id": 15,
                "source_id": "organize_table_b0_l15_5e2f05f1dbd6a2fb",
                "source_sequence": list(range(16)),
                "required_accounted_prefix": list(range(15)),
            },
        }
        self.baseline = {"task": "organize_table",
                         "source_id": "organize_table_b0_l14_ab614f8c58a8a134"}
        self.teacher = deepcopy(self.baseline)

    def test_exact_original_pair_is_not_modified(self):
        before = deepcopy((self.prep, self.baseline, self.teacher))
        boundary.validate_pair(self.prep, self.baseline, self.teacher)
        self.assertEqual((self.prep, self.baseline, self.teacher), before)

    def test_wrong_or_sealed_source_rejected(self):
        for key, value in (("layout_id", 53), ("required_accounted_prefix", [14]),
                           ("source_sequence", list(reversed(range(16))))):
            candidate = deepcopy(self.prep)
            candidate["source"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                boundary.validate_pair(candidate, self.baseline, self.teacher)
        self.teacher["source_id"] = "different_synthetic_source"
        with self.assertRaises(ValueError):
            boundary.validate_pair(self.prep, self.baseline, self.teacher)

    def test_existing_resource_guards_and_release_preserved(self):
        text = boundary.source()
        ast.parse(text)
        for marker in ("memory_headroom(120)", "fcntl.LOCK_NB", "baseline_checks(current)",
                       "te['own_process_checks']", "be['process_closure']['checks']",
                       "ident['start_ticks']", "native_step_limit']==1000",
                       "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json",
                       "current['task']=='classify_objects'"):
            self.assertIn(marker, text)


if __name__ == "__main__":
    unittest.main()
