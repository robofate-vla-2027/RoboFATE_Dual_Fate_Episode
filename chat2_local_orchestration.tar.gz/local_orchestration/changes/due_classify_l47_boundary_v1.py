"""Reuse the original resource boundary for the frozen Classify L34 to L47 pair."""
import hashlib
from pathlib import Path

import due_classify_l22_boundary_v1 as previous

SEQUENCE = previous.SEQUENCE


def validate_pair(previous_preparation, prepared):
    ps, ns = previous_preparation["source"], prepared["source"]
    if not (ps["task"] == ns["task"] == "classify_objects"
            and ps["source_sequence"] == ns["source_sequence"] == SEQUENCE
            and ps["layout_id"] == 34 and ns["layout_id"] == 47
            and ps["required_accounted_prefix"] == SEQUENCE[:14]
            and ns["required_accounted_prefix"] == SEQUENCE[:15]
            and ns["required_accounted_prefix"] ==
            ps["required_accounted_prefix"] + [ps["layout_id"]]):
        raise ValueError("Not the next original Classify source after settled L34")


def source():
    if hashlib.sha256(Path(previous.__file__).read_bytes()).hexdigest() != (
            "dc7a21996ce220bb0e9a8d2e275b545d308406da4c55a67bc9d4f2693ac17366"):
        raise ValueError("Frozen resource boundary changed")
    return previous.source()


if __name__ == "__main__":
    exec(compile(source(), str(Path(__file__)) + "::classify_l47_metadata", "exec"),
         globals())
