"""Add Classify1100 metadata to the unchanged shared teacher catalog."""
from pathlib import Path
import common_runtime as runtime
import teacher_catalog_binding_v8 as previous
import task_configured_binding as configured

_TEXT = runtime.edit(previous._TEXT,
    "'sort_nesting_dolls_by_size': 1050}",
    "'sort_nesting_dolls_by_size': 1050, 'classify_objects': 1100}")
if _TEXT.count("teacher_catalog_binding_v8") != 6:
    raise ValueError("Frozen catalog import sites changed")
_TEXT = _TEXT.replace("teacher_catalog_binding_v8", "teacher_catalog_binding_v9")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_restore_v8'", "'_refate_shared_task_restore_v9'")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_persistence_v8'", "'_refate_shared_task_persistence_v9'")
exec(compile(_TEXT, str(Path(__file__).with_name("teacher_task_binding.py")) +
             "::classify1100_catalog_v9", "exec"), globals())


def load_native_layout(context):
    if context.get("binding_schema") == configured.SCHEMA and context["source"]["task"] == "classify_objects":
        need(type(context["native_step_limit"]) is int and context["native_step_limit"] == 1100,
             "Original Classify1100 budget required")
        return configured.load_native_layout(context)
    return previous.load_native_layout(context)
