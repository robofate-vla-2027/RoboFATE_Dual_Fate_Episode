"""Original capacity settlement plus the exact current node/task schema."""
from pathlib import Path
import positive_gap_node_schema_v2 as schema

schema.base.pinned_text(Path(schema.__file__), "d1ddfb4fed65efda35ea6a335200f57a34bddec5ea71cdfed7ca12d9f5b21e11")
schema.install()
path = Path(__file__).with_name("settle_positive_gap_handoff_v1.py")
text = schema.base.pinned_text(path, "e07ad70ec608c646613c77e16ab504372edb15ce57cb63d543247bb0de519598")
if __name__ == "__main__":
    exec(compile(text, str(path) + "::node_schema_v2", "exec"), globals())
