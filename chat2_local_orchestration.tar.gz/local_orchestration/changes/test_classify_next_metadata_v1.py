"""Synthetic next-source ordering and unchanged inherited-prefix checks."""
import ast
from copy import deepcopy
from pathlib import Path
import unittest

from prepare_classify_legacy_handoff_v2 import TASK, next_prefix


def fixture():
    sequence = [1, 2, 3, 4, 5, 6, 0, 42, 7]
    original = {"initial_source_sequence": sequence,
                "previous_plan": {"partition": {"reserved_final": [53, 54]}}}
    previous = {"source": {"task": TASK, "source_id": "synthetic_l6", "layout_id": 6,
                           "source_sequence": deepcopy(sequence),
                           "required_accounted_prefix": [1, 2, 3, 4, 5]}}
    return original, previous


class NextSourceTests(unittest.TestCase):
    def test_next_is_zero_not_seven(self):
        original, previous = fixture()
        before = deepcopy((original, previous))
        self.assertEqual(next_prefix(original, previous, 0), [1, 2, 3, 4, 5, 6, 0])
        self.assertEqual((original, previous), before)
        with self.assertRaises(ValueError):
            next_prefix(original, previous, 7)

    def test_no_replay_or_skip(self):
        original, previous = fixture()
        for layout in (1, 6, 42, 53, True):
            with self.assertRaises(ValueError):
                next_prefix(original, previous, layout)

    def test_preserves_nonascending_following_order(self):
        original, previous = fixture()
        previous["source"].update(layout_id=0, required_accounted_prefix=[1, 2, 3, 4, 5, 6])
        self.assertEqual(next_prefix(original, previous, 42), [1, 2, 3, 4, 5, 6, 0, 42])

    def test_rejects_foreign_or_changed_prefix(self):
        original, previous = fixture()
        for key, value in (("task", "foreign"), ("required_accounted_prefix", [1, 2]),
                           ("source_sequence", [1, 2, 3, 4, 5, 6, 7])):
            changed = deepcopy(previous)
            changed["source"][key] = value
            with self.assertRaises(ValueError):
                next_prefix(original, changed, 0)

    def test_rejects_sealed_or_exhausted(self):
        original, previous = fixture()
        original["previous_plan"]["partition"]["reserved_final"].append(0)
        with self.assertRaises(ValueError):
            next_prefix(original, previous, 0)
        original, previous = fixture()
        previous["source"].update(layout_id=7, required_accounted_prefix=[1, 2, 3, 4, 5, 6, 0, 42])
        with self.assertRaises(ValueError):
            next_prefix(original, previous, 0)

    def test_original_prefix_helper_checks_identity_and_settlement(self):
        try:
            import owner_reservation_handoff_v1 as helper
        except ModuleNotFoundError:
            self.skipTest("Original remote reservation dependency is not available locally")
        original, previous = fixture()
        source = dict(previous["source"], source_id="synthetic_l0", layout_id=0,
                      required_accounted_prefix=[1, 2, 3, 4, 5, 6])
        pin = {"path": "/synthetic/preparation.json", "sha256": "a" * 64}
        terminal = {"path": "/synthetic/settlement.json", "sha256": "b" * 64}
        prior = dict(previous["source"], preparation=pin, settlement=terminal, source_started=True)
        ledger = {"source_index": {"synthetic_l6": prior}}
        boundary = {"settlement": {"source_id": "synthetic_l6", "settlement_ref": terminal},
                    "inherited_prefix": {"source_id": "synthetic_l6",
                                         "preparation_ref": pin, "prepared_source": previous["source"]}}
        self.assertTrue(helper._inherited_prefix(ledger, boundary, source, 2))
        self.assertTrue(helper._inherited_prefix(ledger, boundary, source, 6))
        self.assertFalse(helper._inherited_prefix(ledger, boundary, source, 0))
        altered = deepcopy(ledger)
        altered["source_index"]["synthetic_l6"]["source_started"] = False
        self.assertFalse(helper._inherited_prefix(altered, boundary, source, 2))

    def test_boundary_validates_predecessor_before_creating_run(self):
        path = Path(__file__).with_name("boundary_configured_handoff_v1.py")
        source = path.read_text()
        ast.parse(source)
        self.assertLess(source.index("previous=doc(x['prior_preparation_ref'])"),
                        source.index("run.mkdir()"))
        self.assertIn("import task_configured_binding as binding", source)
        self.assertIn("b['inherited_prefix']", source)


if __name__ == "__main__":
    unittest.main()
