"""Synthetic safe-boundary bookkeeping; no real ledger, network, or simulator."""
from copy import deepcopy
from pathlib import Path
import unittest

import test_dolls_bottles_revisit_v1 as old
import switch_classify_teacher_to_insert_l41_v1 as current


def rename(value):
    if isinstance(value, str):
        return value.replace("sort_nesting_dolls_by_size", "classify_objects").replace(
            "put_bottles_into_dustbin", "insert_tubes")
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class RevisitTests(unittest.TestCase):
    def setUp(self):
        self.f = old.DueBottlesTests()
        self.f.setUp()
        self.d, self.e, self.prep = rename(self.f.d), rename(self.f.e), rename(self.f.prep)
        self.prep.update(binding_schema="refate.common_collector.source_sequence_binding.v1",
                         native_step_limit=500)
        self.prep["source"].update(layout_id=41, source_sequence=list(range(42)),
                                   required_accounted_prefix=list(range(41)))
        self.d["tasks"]["insert_tubes"].update(qualified_count=10, negative_count=7)

    def switch(self, at=None):
        return current.switch_due(self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
                                  at or self.f.at, "Synthetic only; no scientific credit")

    def test_original_scheduling_logic_is_preserved(self):
        text = current.source()
        for before, after in reversed(current.CHANGES):
            text = text.replace(after, before)
        self.assertEqual(text, Path(current.__file__).with_name(
            "switch_dolls_to_prepared_bottles_v1.py").read_text())

    def test_counts_sources_peer_nanoseconds_and_negative_clock_are_unchanged(self):
        before = deepcopy(self.d)
        result = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        for name in self.d["tasks"]:
            for key in ("qualified_count", "negative_count", "last_negative_gain_at"):
                self.assertEqual(self.d["tasks"][name][key], before["tasks"][name][key])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "insert_tubes")
        self.assertFalse(result["receipt"]["transition"]["source_registered"])

    def test_recent_teacher_positive_does_not_reset_negative_window(self):
        self.d["tasks"]["classify_objects"]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        self.e["summary"]["qualified_positive"] = True
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)

    def test_early_live_unsettled_or_not_due_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        for modify in (
            lambda: self.d["nodes"]["perdon-hou"].update(active_real_simulators=1),
            lambda: self.d["source_index"]["old"]["active_teacher_attempt"].update(status="running"),
            lambda: self.d["nodes"]["perdon-hou"].update(task_segments=[]),
        ):
            self.setUp()
            modify()
            with self.assertRaises(AssertionError):
                self.switch()

    def test_duplicate_sealed_changed_budget_and_positive_shortfall_rejected(self):
        for modify in (
            lambda: self.d["source_index"].update(synthetic_new={}),
            lambda: self.prep["source"].update(layout_id=53),
            lambda: self.prep.update(native_step_limit=501),
            lambda: self.prep["source"].update(source_sequence=list(range(43))),
            lambda: self.d["tasks"]["insert_tubes"].update(qualified_count=9),
        ):
            self.setUp()
            modify()
            with self.assertRaises(AssertionError):
                self.switch()


if __name__ == "__main__":
    unittest.main()
