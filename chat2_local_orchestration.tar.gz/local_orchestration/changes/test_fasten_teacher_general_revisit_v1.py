"""Synthetic due-revisit tests; no real ledger, source, network or simulator."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

from test_dolls_bottles_revisit_v1 import DueBottlesTests, reject_live
import switch_fasten_teacher_to_prepared_general_v1 as current

sys.addaudithook(reject_live)
SEQUENCE = [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]


def rename(value):
    if isinstance(value, str):
        return value.replace("sort_nesting_dolls_by_size", "fasten_screws").replace(
            "put_bottles_into_dustbin", "general_pickup")
    if isinstance(value, list):
        return [rename(v) for v in value]
    if isinstance(value, dict):
        return {rename(k): rename(v) for k, v in value.items()}
    return value


class TeacherRevisitTests(unittest.TestCase):
    def setUp(self):
        self.f = DueBottlesTests()
        self.f.setUp()
        self.d, self.e, self.prep = rename(self.f.d), rename(self.f.e), rename(self.f.prep)
        self.prep["native_step_limit"] = 200
        self.prep["source"].update(layout_id=10, source_sequence=SEQUENCE,
                                   required_accounted_prefix=SEQUENCE[:-1],
                                   split="student_dev")

    def switch(self, at=None):
        return current.switch_due(self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
                                  at or self.f.at, "Synthetic boundary, no scientific credit")

    def test_only_original_parameters_change(self):
        text = current.source()
        for old, new in reversed(current.CHANGES):
            text = text.replace(new, old)
        self.assertEqual(text, (Path(current.__file__).parent / "switch_dolls_to_prepared_bottles_v1.py").read_text())

    def test_closed_teacher_preserves_peers_sources_counts_and_precision(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "general_pickup")
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))

    def test_teacher_positive_does_not_reset_negative_shortfall(self):
        self.d["tasks"]["fasten_screws"]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        self.e["summary"]["qualified_positive"] = True
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_negative_gain"], 5460)
        self.assertFalse(event["negative_shortfall_clock_reset"])

    def test_early_unsettled_or_not_due_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["source_index"]["old"]["active_teacher_attempt"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_duplicate_wrong_sequence_and_budget_rejected(self):
        self.d["nodes"]["perdon-hou"]["active_real_simulators"] = 1
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.prep["source"]["source_sequence"] = list(range(11))
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.prep["native_step_limit"] = 1900
        with self.assertRaises(AssertionError):
            self.switch()


if __name__ == "__main__":
    unittest.main(defaultTest="TeacherRevisitTests")
