"""Synthetic scheduling tests only; no live ledger, network, model or processes."""
import ast
import datetime
import sys
import unittest

import due_plug_revisit_handoff_v3 as adapter


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("Synthetic metadata tests prohibit live effects")


sys.addaudithook(reject_live)
TEXT = adapter.source()
TREE = ast.parse(TEXT)
ROUTE = next(n.test for n in ast.walk(TREE)
             if isinstance(n, ast.Assert) and "put_bottles_into_dustbin" in ast.unparse(n.test))
FUNCTION = next(n for n in TREE.body if isinstance(n, ast.FunctionDef)
                and n.name == "negative_shortfall_window")
SCOPE = {"datetime": datetime}
exec(compile(ast.Module(body=[FUNCTION], type_ignores=[]), "<synthetic-clock>", "exec"), SCOPE)


class DuePlugTests(unittest.TestCase):
    def route(self, task, **changes):
        node = dict(current_task=task, active_run_id=None,
                    active_real_simulators=0, launch_inflight=False)
        node.update(changes)
        return eval(compile(ast.Expression(ROUTE), "<synthetic-route>", "eval"),
                    {"x": {"from_task": task}, "n": node})

    def test_conveyor_and_old_routes(self):
        for task in ("pick_from_conveyor_by_image", "put_bottles_into_dustbin", "play_stacking_toy"):
            self.assertTrue(self.route(task))

    def test_foreign_task_rejected(self):
        self.assertFalse(self.route("foreign_task"))

    def test_active_execution_rejected(self):
        for changes in ({"active_run_id": "synthetic-live"},
                        {"active_real_simulators": 1}, {"launch_inflight": True},
                        {"current_task": "foreign_task"}):
            self.assertFalse(self.route("pick_from_conveyor_by_image", **changes))

    def test_only_predecessor_tuple_changes(self):
        self.assertEqual(TEXT, adapter.PREVIOUS.read_text().replace(adapter.OLD, adapter.NEW, 1))

    def test_blocked_time_and_teacher_gain_do_not_reset_window(self):
        task = dict(negative_count=0, negative_quota=10,
                    latest_segment_started_at="2026-11-03T15:22:12.057139+00:00",
                    last_core_gain_at="2026-11-04T03:15:00+00:00")
        now = datetime.datetime.fromisoformat("2026-11-04T03:22:12.057139+00:00")
        self.assertEqual(SCOPE["negative_shortfall_window"](task, now), 43200)

    def test_budget_and_closed_baseline_checks_preserved(self):
        for guard in ("r['positive_slots']==r['negative_slots']==0",
                      "r['settlement']==current['settlement_ref']",
                      "release['native_wall_seconds']==2400",
                      "release['teacher_wall_seconds']==3600", "native_step_limit']==400",
                      "not n.get('owned_resource_launch_hold',False)"):
            self.assertIn(guard, TEXT)


if __name__ == "__main__":
    unittest.main()
