"""Original due-revisit rules, bound to General's terminal and Classify L22."""
import hashlib
from pathlib import Path

SEQUENCE = [1, 2, 3, 4, 5, 6, 0, 42, 14, 22, 48, 16, 19, 44, 34, 47,
            31, 20, 8, 27, 37, 24, 32, 38, 28, 10, 51, 25, 50, 46, 39, 12,
            52, 26, 13, 9, 35, 15, 33, 43, 23, 36, 18, 11, 17, 49, 30, 41,
            21, 29, 45, 7, 40]


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"):
        raise ValueError("Frozen scheduling helper changed")
    text = raw.decode().replace("sort_nesting_dolls_by_size", "general_pickup")
    text = text.replace("put_bottles_into_dustbin", "classify_objects")
    for old, new in (
        ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 1100'),
        ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
         's["layout_id"] == 22 and s["source_sequence"] == SEQUENCE'),
        ('s["required_accounted_prefix"] == list(range(12))',
         's["required_accounted_prefix"] == SEQUENCE[:9]'),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling interface changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::classify_l22_metadata", "exec"), globals())
