"""Offline synthetic metadata tests; no live peers, model, simulator, or ledger."""
import ast
import copy
import unittest

import test_dolls_bottles_revisit_v1 as original
import switch_general_to_classify_l42_v1 as scheduling
import due_classify_l42_boundary_v1 as boundary

original.OLD = "general_pickup"
original.NEXT = "classify_objects"


class ClassifyRevisitTests(original.DueBottlesTests):
    def setUp(self):
        super().setUp()
        self.prep["native_step_limit"] = 1100
        self.prep["source"].update(
            layout_id=42, source_sequence=list(scheduling.SEQUENCE),
            required_accounted_prefix=scheduling.SEQUENCE[:7])

    def run_switch(self):
        return scheduling.switch_due(
            self.d, self.e, self.ref, self.prep, self.prep_ref, self.at,
            "Synthetic fixture only, not a scientific or live permission result")

    def test_changed_frozen_sequence_rejected(self):
        self.prep["source"]["source_sequence"][-2:] = [40, 7]
        with self.assertRaises(AssertionError):
            self.run_switch()

    def test_boundary_reuses_original_resource_checks_and_release(self):
        text = boundary.source()
        ast.parse(text)
        for marker in ("memory_headroom(120)", "fcntl.LOCK_NB",
                       "latest['own_process_checks']", "'inherited_prefix'",
                       "'native_step_limit']==1100", "RUNTIME_CONTENT_RELEASE_20261031_01a19072.json"):
            self.assertIn(marker, text)


class PairTests(unittest.TestCase):
    def setUp(self):
        source = dict(task="classify_objects", layout_id=0,
                      source_sequence=list(scheduling.SEQUENCE),
                      required_accounted_prefix=scheduling.SEQUENCE[:6])
        self.previous = {"source": source}
        self.next = {"source": dict(source, layout_id=42,
                                   required_accounted_prefix=scheduling.SEQUENCE[:7])}

    def test_exact_original_continuation(self):
        before = copy.deepcopy((self.previous, self.next))
        boundary.validate_pair(self.previous, self.next)
        self.assertEqual((self.previous, self.next), before)

    def test_wrong_predecessor_rejected(self):
        self.previous["source"]["layout_id"] = 6
        with self.assertRaises(ValueError):
            boundary.validate_pair(self.previous, self.next)

    def test_reorder_or_sealed_or_missing_prefix_rejected(self):
        for field, value in (("source_sequence", list(reversed(scheduling.SEQUENCE))),
                             ("layout_id", 53), ("required_accounted_prefix", [0])):
            candidate = copy.deepcopy(self.next)
            candidate["source"][field] = value
            with self.assertRaises(ValueError):
                boundary.validate_pair(self.previous, candidate)

    def test_foreign_task_rejected(self):
        self.next["source"]["task"] = "general_pickup"
        with self.assertRaises(ValueError):
            boundary.validate_pair(self.previous, self.next)


if __name__ == "__main__":
    unittest.main()
