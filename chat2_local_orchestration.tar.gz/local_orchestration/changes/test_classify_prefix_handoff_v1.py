"""Offline synthetic reservation metadata, never scientific qualification."""
from copy import deepcopy
import unittest

from classify_prefix_handoff_v1 import (
    NEXT_SOURCE, TASK, metadata_hash, original_classify_prefix_accounted,
)


def fixture():
    row = {"source_id": TASK + "_b0_l2_synthetic", "host": "perdon-hou",
           "task": TASK, "native_success": False, "counted_in_quota": False,
           "wall_ns": 1793461079151749929}
    ledger = {"source_index": {row["source_id"]: row}}
    preparation = {"path": "/synthetic/preparation.json", "sha256": "0" * 64}
    boundary = {"next_preparation": {"ref": preparation}, "legacy_prefix_review": {
        "schema": "refate.classify.original_prefix.accounted.v1",
        "next_source_id": NEXT_SOURCE, "preparation_ref": preparation,
        "old_source_qualification_changed": False, "old_sources_replayed": False,
        "live_referenced_processes": [],
        "entries": [{"layout": 2, "source_id": row["source_id"],
                     "source_metadata_sha256": metadata_hash(row), "source_consumed": True,
                     "new_positive": 0, "new_negative": 0}],
    }}
    source = {"source_id": NEXT_SOURCE, "task": TASK, "layout_id": 6,
              "required_accounted_prefix": [1, 2, 3, 4, 5]}
    return ledger, boundary, source


class PrefixTests(unittest.TestCase):
    def test_accounted_does_not_relabel_or_mutate(self):
        ledger, boundary, source = fixture()
        before = deepcopy(ledger)
        self.assertTrue(original_classify_prefix_accounted(ledger, boundary, source, 2))
        self.assertEqual(ledger, before)

    def test_changed_historical_row_rejected(self):
        ledger, boundary, source = fixture()
        next(iter(ledger["source_index"].values()))["wall_ns"] += 1
        self.assertFalse(original_classify_prefix_accounted(ledger, boundary, source, 2))

    def test_wrong_next_source_rejected(self):
        ledger, boundary, source = fixture()
        source["source_id"] = TASK + "_b0_l2_synthetic"
        self.assertFalse(original_classify_prefix_accounted(ledger, boundary, source, 2))

    def test_live_legacy_process_rejected(self):
        ledger, boundary, source = fixture()
        boundary["legacy_prefix_review"]["live_referenced_processes"] = [{"pid": 123}]
        self.assertFalse(original_classify_prefix_accounted(ledger, boundary, source, 2))

    def test_new_credit_rejected(self):
        ledger, boundary, source = fixture()
        boundary["legacy_prefix_review"]["entries"][0]["new_negative"] = 1
        self.assertFalse(original_classify_prefix_accounted(ledger, boundary, source, 2))

    def test_other_task_not_admitted(self):
        ledger, boundary, source = fixture()
        source["task"] = "unrelated_synthetic_task"
        self.assertFalse(original_classify_prefix_accounted(ledger, boundary, source, 2))


if __name__ == "__main__":
    unittest.main()
