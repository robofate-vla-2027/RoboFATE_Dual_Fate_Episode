"""Reuse the due-revisit rules with an actually settled Fasten baseline."""
import hashlib
from pathlib import Path

from closed_baseline_resource_v1 import baseline_checks


def source():
    path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != (
            "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d"):
        raise ValueError("Frozen scheduling helper changed")
    text = raw.decode().replace("sort_nesting_dolls_by_size", "fasten_screws")
    text = text.replace("put_bottles_into_dustbin", "general_pickup")
    teacher_checks = '''    assert source["active_teacher_attempt"]["status"] == "settled"
    assert source["active_teacher_attempt"]["terminal_observation"] == terminal_ref
    assert source["active_teacher_attempt"]["run_id"] == terminal["run_id"]
    assert reservation["status"] == "shared_Evo_teacher_settled"
    assert reservation["current_attempt_settlement"] == terminal["summary_ref"]
    assert reservation["current_attempt_run_id"] == terminal["run_id"]'''
    baseline_validation = '''    baseline_checks(terminal)
    assert terminal["first_readback_passed"] is True
    assert source["run_id"] == reservation["run_id"] == terminal["run_id"]
    assert source["context"] == terminal["context"]
    assert source["settlement"] == reservation["settlement"] == terminal_ref
    assert reservation["status"] in ("settled_native_failure_no_quota", "settled_qualified_negative")
    assert terminal["native_success"] is terminal["summary"]["native_success"]
    assert terminal["summary"]["qualified_negative"] is terminal["native_success"]'''
    for old, new in (
        (teacher_checks, baseline_validation),
        ('type(terminal["summary"]["qualified_positive"]) is bool',
         'type(terminal["summary"]["qualified_negative"]) is bool'),
        ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 200'),
        ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
         's["layout_id"] == 10 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10]'),
        ('s["required_accounted_prefix"] == list(range(12))',
         's["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6, 7, 8, 9]'),
        ('s["split"] == "student_train"', 's["split"] in ("student_train", "student_dev")'),
        ('prior_segment_started_at=target["latest_segment_started_at"]',
         'prior_segment_started_at=target.get("latest_segment_started_at")'),
        ('phase="deferred_after_settled_no_gain"',
         'phase="deferred_after_settled_negative_shortfall"'),
    ):
        if text.count(old) != 1:
            raise ValueError("Frozen scheduling interface changed: " + old)
        text = text.replace(old, new, 1)
    return text


exec(compile(source(), str(Path(__file__)) + "::closed_fasten_general_l10", "exec"), globals())
