"""Synthetic predecessor inheritance through the unchanged reservation core."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

snapshot = Path(__file__).resolve().parent.parent / "snapshot"
if snapshot.is_dir():
    sys.path.insert(0, str(snapshot))
import reserve_general_append_handoff_v1 as adapter
from test_common_owner_reservation import AT, REF, fixture


def general_fixture():
    d, b = fixture()
    task = d["tasks"].pop("plug_in_charger")
    task["source_sequence"] = adapter.sequence(7)
    d["tasks"][adapter.TASK] = task
    node = d["nodes"]["perdon-hou"]
    node.update(active_chat_id=adapter.OWNER, fixed_tasks=[adapter.TASK], current_task=adapter.TASK,
                last_owned_resource_settlement=deepcopy(REF), qualified_count=0)
    old_id = "general_pickup_b0_l7_synthetic"
    old = d["source_index"].pop("plug_in_charger_b0_l0_synthetic")
    old.update(source_id=old_id, task=adapter.TASK, layout_id=7, source_started=True,
               source_sequence=adapter.sequence(7), required_accounted_prefix=adapter.sequence(7)[:-1],
               preparation=deepcopy(REF), synthetic_ns=1793496102759665601)
    d["source_index"][old_id] = old
    d["reservations"][old_id] = d["reservations"].pop("plug_in_charger_b0_l0_synthetic")
    b["settlement"]["source_id"] = old_id
    b["resource_predecessor"] = {"ref": deepcopy(REF), "safe_for_next_simulator": True}
    b["resource_precheck"]["summary"]["run_id"] = "c2_general_pickup_l8_synthetic_01a16807"
    source = b["next_preparation"]["prepared"]["source"]
    source.update(task=adapter.TASK, source_id="general_pickup_b0_l8_synthetic", layout_id=8,
                  execution_owner=adapter.OWNER, source_owner=adapter.OWNER,
                  source_sequence=adapter.sequence(8), required_accounted_prefix=adapter.sequence(7))
    b["next_preparation"]["prepared"]["native_step_limit"] = 200
    previous = {"ref": deepcopy(REF), "prepared": {"source": deepcopy(old)}}
    release = {"native_wall_seconds": 2400, "teacher_wall_seconds": 3600,
               "foreground_entry": str(adapter.ADAPTER / "collect_recording_content_v1.py")}
    return d, b, previous, release


class GeneralAppendReservationTests(unittest.TestCase):
    def reserve(self, d, b, previous, release):
        return adapter.reserve_next(d, b, REF, previous, release, AT)

    def test_existing_core_keeps_peers_history_nanoseconds_and_budgets(self):
        d, b, previous, release = general_fixture()
        original = deepcopy(d)
        result = self.reserve(d, b, previous, release)
        out = result["ledger"]
        self.assertEqual(d, original)
        self.assertEqual(out["nodes"]["h20_8"], original["nodes"]["h20_8"])
        for sid, row in original["source_index"].items():
            self.assertEqual(out["source_index"][sid], row)
        dispatch = result["receipt"]["dispatch"]
        self.assertEqual((dispatch["native_total_steps"], dispatch["native_wall_seconds"],
                          dispatch["teacher_wall_seconds"]), (200, 2400, 3600))
        self.assertEqual(out["tasks"][adapter.TASK]["source_sequence"], adapter.sequence(8))
        self.assertFalse(dispatch["source_started"])

    def test_unsettled_or_unstarted_predecessor_rejected(self):
        for key, value in (("source_started", False), ("settlement", None), ("layout_id", 6),
                           ("preparation", None)):
            d, b, previous, release = general_fixture()
            d["source_index"][b["settlement"]["source_id"]][key] = value
            with self.subTest(field=key), self.assertRaises(ValueError):
                self.reserve(d, b, previous, release)

    def test_reordered_or_skipped_sources_rejected(self):
        for key, value in (("source_sequence", list(range(9))),
                           ("required_accounted_prefix", [1, 2, 3, 4, 0, 5, 6]),
                           ("layout_id", 9), ("layout_id", 53)):
            d, b, previous, release = general_fixture()
            b["next_preparation"]["prepared"]["source"][key] = value
            with self.subTest(field=key), self.assertRaises(ValueError):
                self.reserve(d, b, previous, release)

    def test_live_source_owner_and_stale_boundary_rejected(self):
        for key, value in (("active_run_id", "synthetic_live"), ("active_chat_id", "foreign"),
                           ("user_pause_active", True), ("launch_inflight", True)):
            d, b, previous, release = general_fixture()
            d["nodes"]["perdon-hou"][key] = value
            with self.subTest(field=key), self.assertRaises(ValueError):
                self.reserve(d, b, previous, release)
        d, b, previous, release = general_fixture()
        b["at"] = "2026-10-25T12:00:00+00:00"
        with self.assertRaises(ValueError):
            self.reserve(d, b, previous, release)

    def test_used_source_and_wall_increase_rejected(self):
        d, b, previous, release = general_fixture()
        release["teacher_wall_seconds"] = 7200
        with self.assertRaises(ValueError):
            self.reserve(d, b, previous, release)
        d, b, previous, release = general_fixture()
        d["source_index"][b["next_preparation"]["prepared"]["source"]["source_id"]] = {}
        with self.assertRaises(ValueError):
            self.reserve(d, b, previous, release)


if __name__ == "__main__":
    unittest.main()
