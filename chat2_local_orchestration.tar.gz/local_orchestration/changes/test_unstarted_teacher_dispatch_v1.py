"""Synthetic CPU metadata fixtures: no network, model, simulator or real receipts."""
import copy
import unittest
from unittest.mock import patch

import renew_unstarted_teacher_dispatch_v1 as r
import teacher_observe_context_v1 as observer


class RenewalTests(unittest.TestCase):
    def setUp(self):
        self.now = "2026-11-03T12:10:00+00:00"
        self.c = dict(run_id=r.RUN, source_id=r.SID, execution_owner=r.OWNER,
                      native_limit=1000, t1=48, remaining_steps=952,
                      actor_wall_s=3600, native_wall_seconds=3600,
                      dispatch_ref={"path": "/synthetic/dispatch", "sha256": "synthetic"},
                      wall_ns=1793700000123456789, identity={"epoch": 4684})
        self.d = dict(run_id=r.RUN, source_id=r.SID, execution_owner=r.OWNER,
                      native_total_steps=1000, t1=48, remaining_steps=952,
                      native_wall_seconds=3600, teacher_wall_seconds=3600,
                      positive_slots=1, negative_slots=0, source_reserved=True,
                      issued_at="2026-11-03T09:25:00+00:00",
                      valid_until="2026-11-03T11:25:00+00:00",
                      original_segment_started_at="2026-11-03T09:24:48+00:00")
        self.e = dict(markers={n: False for n in r.MARKERS},
                      session_execution_dirs={n: False for n in ("agent", "runtime", "oci")},
                      inputs_present=True, matching_processes=[],
                      exclusive_native_lock_available=True,
                      memory=dict(available_bytes=130*1024**3, minimum_free_gib=120))

    def test_preserves_identity_budget_clocks_and_ns(self):
        before = copy.deepcopy((self.c, self.d, self.e))
        c, d = r.renew_documents(self.c, self.d, self.e, self.now)
        self.assertEqual(c, self.c)
        self.assertEqual((self.c, self.d, self.e), before)
        self.assertEqual({k: v for k, v in d.items() if k not in ("valid_until", "unstarted_renewal")},
                         {k: v for k, v in self.d.items() if k != "valid_until"})
        self.assertEqual(d["valid_until"], "2026-11-03T14:10:00+00:00")
        self.assertEqual(c["wall_ns"], 1793700000123456789)

    def test_each_execution_marker_rejected(self):
        for name in r.MARKERS:
            with self.subTest(name=name):
                evidence = copy.deepcopy(self.e)
                evidence["markers"][name] = True
                with self.assertRaises(ValueError):
                    r.renew_documents(self.c, self.d, evidence, self.now)

    def test_missing_marker_and_live_process_rejected(self):
        for mutation in ("missing", "process", "lock", "memory", "inputs"):
            with self.subTest(mutation=mutation):
                e = copy.deepcopy(self.e)
                if mutation == "missing": e["markers"].pop(r.MARKERS[0])
                if mutation == "process": e["matching_processes"] = [{"pid": 1}]
                if mutation == "lock": e["exclusive_native_lock_available"] = False
                if mutation == "memory": e["memory"]["available_bytes"] = 119*1024**3
                if mutation == "inputs": e["inputs_present"] = False
                with self.assertRaises(ValueError):
                    r.renew_documents(self.c, self.d, e, self.now)

    def test_started_session_rejected(self):
        for name in ("agent", "runtime", "oci"):
            e = copy.deepcopy(self.e)
            e["session_execution_dirs"][name] = True
            with self.assertRaises(ValueError):
                r.renew_documents(self.c, self.d, e, self.now)

    def test_budget_owner_quota_and_fresh_dispatch_rejected(self):
        for key, value in (("native_wall_seconds", 7200), ("t1", 49),
                           ("execution_owner", "other"), ("positive_slots", 2),
                           ("valid_until", "2026-11-04T00:00:00+00:00")):
            d = dict(self.d, **{key: value})
            with self.assertRaises(ValueError):
                r.renew_documents(self.c, d, self.e, self.now)

    def test_observers_change_only_context_filename(self):
        for name, (_, count) in observer.HELPERS.items():
            text = "\n".join(["CONTEXT_001.json"] * count)
            self.assertEqual(observer.adapt(text, count).replace(r.CONTEXT_NAME, "CONTEXT_001.json"), text)
            with self.assertRaises(ValueError):
                observer.adapt(text, count + 1)

    def test_context_and_dispatch_tampering_rejected(self):
        c, d = r.renew_documents(self.c, self.d, self.e, self.now)
        c["dispatch_ref"] = {"path": "/synthetic/new", "sha256": "synthetic-new"}
        evidence = dict(run_id=r.RUN, actual_launch_issued=False, scientific_attempt_started=False)
        with patch.object(r, "read", return_value=self.d):
            r.verify_renewal(self.c, c, d, evidence)
            with self.assertRaises(ValueError):
                r.verify_renewal(self.c, dict(c, t1=49), d, evidence)
            with self.assertRaises(ValueError):
                r.verify_renewal(self.c, c, dict(d, teacher_wall_seconds=7200), evidence)


if __name__ == "__main__":
    unittest.main()
