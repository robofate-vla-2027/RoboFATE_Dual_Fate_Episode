"""Synthetic CPU metadata only; no real ledger, network, model or simulator."""
import ast
from copy import deepcopy
from pathlib import Path
import unittest
from unittest.mock import patch

import test_fasten_general_boundary_v1 as fixtures
import switch_bottles_baseline_to_insert_l42_v1 as scheduling

OLD, NEXT = "put_bottles_into_dustbin", "insert_tubes"


def rename(value):
    if isinstance(value, str):
        return value.replace("fasten_screws", OLD).replace("general_pickup", NEXT)
    if isinstance(value, list):
        return [rename(item) for item in value]
    if isinstance(value, dict):
        return {rename(key): rename(item) for key, item in value.items()}
    return value


class BottlesInsertTests(unittest.TestCase):
    def setUp(self):
        f = fixtures.ClosedFastenTests()
        f.setUp()
        self.f = f
        self.d, self.e, self.prep = rename(f.d), rename(f.e), rename(f.prep)
        self.d["tasks"][OLD].update(
            qualified_count=3, negative_count=10,
            last_core_gain_at="2026-10-30T10:00:00+00:00")
        self.d["tasks"][NEXT].update(qualified_count=10, negative_count=7)
        self.prep.update(native_step_limit=500,
                         binding_schema="refate.common_collector.source_sequence_binding.v1")
        self.prep["source"].update(layout_id=42, source_sequence=list(range(43)),
                                   required_accounted_prefix=list(range(42)),
                                   split="student_train")
        self.e["native_success"] = True
        self.e["summary"].update(native_success=True, qualified_negative=True)
        self.d["reservations"]["old"]["status"] = "settled_qualified_negative"

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.f.ref, self.prep, self.f.f.prep_ref,
            at or self.f.f.at, "Synthetic metadata, zero scientific credit")

    def test_counts_peers_history_and_nanoseconds_preserved(self):
        before = deepcopy(self.d)
        out = self.switch()
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], NEXT)
        for task in (OLD, NEXT):
            for key in ("qualified_count", "negative_count", "last_core_gain_at"):
                self.assertEqual(self.d["tasks"][task].get(key),
                                 before["tasks"][task].get(key))
        self.assertEqual((out["receipt"]["positive_delta"], out["receipt"]["negative_delta"]), (0, 0))

    def test_backup_negative_does_not_reset_positive_gap_clock(self):
        before = self.d["tasks"][OLD]["last_core_gain_at"]
        event = self.switch()["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["seconds_since_last_core_gain"], 5460)
        self.assertIsNone(event["seconds_since_last_negative_gain"])
        self.assertEqual(event["last_core_gain_at"], before)

    def test_early_or_recent_true_core_gain_and_missing_segments_rejected(self):
        with self.assertRaises(AssertionError):
            self.switch("2026-10-31T11:29:00+00:00")
        self.d["tasks"][OLD]["last_core_gain_at"] = "2026-10-31T11:30:00+00:00"
        with self.assertRaises(AssertionError):
            self.switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises(AssertionError):
            self.switch()

    def test_live_or_unclosed_resource_rejected(self):
        for key, value in (("active_run_id", "synthetic-live"),
                           ("active_real_simulators", 1), ("launch_inflight", True),
                           ("user_stop", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.e["process_closure"]["checks"][0]["original_process_absent"] = False
        with self.assertRaises(ValueError):
            self.switch()

    def test_wrong_source_identity_or_settlement_rejected(self):
        for key, value in (("run_id", "different"), ("context", {}),
                           ("settlement", {}), ("host", "foreign")):
            self.setUp()
            self.d["source_index"]["old"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.d["reservations"]["old"]["status"] = "running"
        with self.assertRaises(AssertionError):
            self.switch()

    def test_wrong_order_budget_schema_and_duplicate_rejected(self):
        for key, value in (("layout_id", 53), ("source_sequence", list(range(42))),
                           ("required_accounted_prefix", list(range(41))),
                           ("split", "sealed"), ("native_bank", 1)):
            self.setUp()
            self.prep["source"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        for key, value in (("native_step_limit", 700), ("binding_schema", "wrong")):
            self.setUp()
            self.prep[key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()
        self.setUp()
        self.d["source_index"]["synthetic_new"] = {}
        with self.assertRaises(AssertionError):
            self.switch()

    def test_only_positive_full_negative_deficit_target(self):
        for key, value in (("qualified_count", 9), ("negative_count", 10)):
            self.setUp()
            self.d["tasks"][NEXT][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.switch()

    def test_complete_unattempted_failure_retained(self):
        self.e["native_success"] = False
        self.e["summary"].update(native_success=False, qualified_negative=False)
        self.d["reservations"]["old"]["status"] = "settled_native_failure_no_quota"
        before = deepcopy(self.d["source_index"])
        self.switch()
        self.assertEqual(self.d["source_index"], before)

    def test_switch_never_registers_reserves_or_starts(self):
        review = self.switch()["receipt"]["transition"]
        for key in ("source_registered", "reserved", "source_started"):
            self.assertFalse(review[key])

    def test_exact_parameter_adaptation_and_dependency_pins(self):
        expected = scheduling.previous.source()
        for old, new in scheduling.CHANGES:
            expected = expected.replace(old, new)
        self.assertEqual(scheduling.source(), expected)
        ast.parse(expected)
        with patch.object(Path, "read_bytes", return_value=b"synthetic changed pin"):
            with self.assertRaises(ValueError):
                scheduling.source()


if __name__ == "__main__":
    unittest.main()
