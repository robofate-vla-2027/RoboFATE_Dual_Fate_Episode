import json,hashlib,datetime,sys
from pathlib import Path
x=json.load(sys.stdin);r=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];c=json.loads((r/'CONTEXT_001.json').read_text());fg=json.loads((r/'foreground_started.json').read_text());native=json.loads((r/'native_started.json').read_text());pid=native['pid'];tail=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();ident={'pid':pid,'start_ticks':int(tail[19]),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'process_group':int(tail[2])};assert ident['process_group']==pid
p=r/'ACTUAL_START_OBSERVATION_001.json';d={'data_kind':'actual','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':c['run_id'],'source_id':c['source_id'],'foreground':fg,'native':native,'actual_native_identity':ident,'foreground_tool_session':x['tool_session'],'context':fg['context_ref'],'mode':'independent_DM0.5','native_budget':c['native_total_steps'],'physical_policy_gpu':0,'physical_simulation_gpu':1,'teacher_started':False,'sample_qualified':False}
owned=json.loads((r/'owned_native.json').read_bytes());assert owned['identity']==ident
assert c['execution_owner']=='01a19072-9e5e-7e02-b77a-8f115cfc9bd0'
for expected in (fg['identity'],ident):
 stat=(Path('/proc')/str(expected['pid'])/'stat').read_text().rsplit(')',1)[1].split()
 assert int(stat[19])==expected['start_ticks'] and expected['boot_id']==ident['boot_id']
d.update(execution_owner=c['execution_owner'],source_owner=c['source_owner'])
with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
d['evidence_ref']={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};print(json.dumps(d))