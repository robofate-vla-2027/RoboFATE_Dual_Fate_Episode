"""Original lossless reservation transaction, naming the matching future entry."""
from pathlib import Path
import common_runtime as runtime

path = Path(__file__).with_name("reserve_insert_content_handoff_v1.py")
text = runtime.read_pin({
    "path": str(path),
    "sha256": "d4cdb9765a1c881f5f9ce89afe9e1e2af44bd970fe054dbee0c0ce17bfb8d899",
}).decode()
text = runtime.edit(text, "collect_recording_content_v1.py",
                    "collect_insert_sequence_content_v1.py")
exec(compile(text, str(path) + "::sequence_handoff", "exec"), globals())
