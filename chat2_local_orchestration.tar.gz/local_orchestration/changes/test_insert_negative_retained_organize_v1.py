"""Synthetic metadata only; inherited audit hook denies network and processes."""
import copy
import json
import unittest
from unittest.mock import patch

import test_general_negative_retained_classify_v1 as fixture
import switch_insert_negative_to_retained_organize_v1 as current


class InsertRetainedTests(unittest.TestCase):
    def setUp(self):
        fixture.NegativeRetainedTests.setUp(self)

        def renamed(value):
            return json.loads(json.dumps(value).replace("general_pickup", "insert_tubes")
                              .replace("classify_objects", "organize_table"))

        self.d, self.e = renamed(self.d), renamed(self.e)
        self.documents = renamed(self.documents)
        self.latest = self.latest.replace("general_pickup", "insert_tubes")
        self.d["nodes"]["perdon-hou"]["task_segments"][0]["task"] = "synthetic_other_task"
        self.d["split_manifests"] = {
            "insert_tubes": {"initial_source_sequence": list(range(19, 24))}}
        for document in self.documents.values():
            document["native_budget"] = 500
        self.e = self.documents[self.ref["sha256"]]
        self.d["source_index"]["retained"].update(native_steps=1000, native_budget=1000)

    def run_switch(self):
        def review(ledger, source):
            return current.negative.review(
                ledger, source, lambda ref: self.documents[ref["sha256"]])
        with patch.object(current, "review_negative_shortfall", review):
            return current.switch_due(
                self.d, self.e, self.ref, self.retained, self.at,
                "Synthetic only: no simulation, provider request, or scientific credit")

    def test_original_tail_and_no_credit_or_peer_change(self):
        before = copy.deepcopy(self.d)
        out = self.run_switch()
        self.assertEqual(self.d["nodes"]["perdon-hou"]["current_task"], "organize_table")
        event = out["receipt"]["transition"]["completed_other_segments"][-1]
        self.assertEqual(event["negative_shortfall_review"]["preserved_consecutive_tail"],
                         [19, 20, 21, 22, 23])
        self.assertFalse(event["negative_shortfall_clock_reset"])
        for key in ("source_index", "reservations"):
            self.assertEqual(self.d[key], before[key])
        self.assertEqual(self.d["nodes"]["h20_8"], before["nodes"]["h20_8"])
        self.assertEqual(out["receipt"]["positive_delta"], 0)
        self.assertEqual(out["receipt"]["negative_delta"], 0)

    def test_no_revisit_or_teacher_gain_reset(self):
        self.d["tasks"]["insert_tubes"]["last_core_gain_at"] = self.at
        self.run_switch()
        self.assertEqual(self.d["tasks"]["insert_tubes"]["qualified_count"], 10)

    def test_original_failure_evidence_and_budget_required(self):
        for key, value in (("native_success", True), ("complete_readback", False),
                           ("source_started", False),
                           ("initialization_content_sha256", f"{23:064x}")):
            self.setUp()
            self.d["source_index"]["insert_tubes_b0_l19_synthetic"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()
        self.setUp()
        self.documents["19"]["native_budget"] = 200
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()

    def test_retained_source_must_be_complete_unattempted_and_unrefused(self):
        for key, value in (("teacher_attempt_history", [{"synthetic": True}]),
                           ("provider_safety_refusal", {"synthetic": True}),
                           ("complete_readback", False), ("native_budget", 1100),
                           ("counted_in_quota", True)):
            self.setUp()
            self.d["source_index"]["retained"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()

    def test_live_resources_holds_and_not_due_are_rejected(self):
        for key, value in (("active_real_simulators", 1), ("launch_inflight", True),
                           ("user_pause_active", True), ("owned_resource_launch_hold", True)):
            self.setUp()
            self.d["nodes"]["perdon-hou"][key] = value
            with self.assertRaises((AssertionError, ValueError)):
                self.run_switch()
        self.setUp()
        self.d["nodes"]["perdon-hou"]["task_segments"] = []
        with self.assertRaises((AssertionError, ValueError)):
            self.run_switch()

    def test_only_task_budget_and_original_reviewer_are_adapted(self):
        expected = current.previous.source().replace("general_pickup", "insert_tubes")
        expected = expected.replace("classify_objects", "organize_table")
        expected = expected.replace('== s["native_budget"] == 1100',
                                    '== s["native_budget"] == 1000')
        self.assertEqual(current.source(), expected)
        self.assertIs(current.review_negative_shortfall, current.negative.review)
        self.assertIs(current.baseline_checks, current.previous.baseline_checks)


if __name__ == "__main__":
    unittest.main()
