"""Use the existing closed-source scheduling rules for the next General source."""
import hashlib
from pathlib import Path

from prepare_general_l7_handoff_v1 import PREFIX

path = Path(__file__).with_name("switch_dolls_to_prepared_bottles_v1.py")
raw = path.read_bytes()
if hashlib.sha256(raw).hexdigest() != "592cf0a7e1b6c7f64e92226e1867e7cf7170bb41490518b95b7961b9e2eab12d":
    raise ValueError("Frozen due-revisit helper changed")
text = raw.decode()
text = text.replace("put_bottles_into_dustbin", "general_pickup")
text = text.replace("sort_nesting_dolls_by_size", "put_bottles_into_dustbin")
for old, new in (
    ('prepared["native_step_limit"] == 700', 'prepared["native_step_limit"] == 200'),
    ('s["layout_id"] == 12 and s["source_sequence"] == list(range(13))',
     's["layout_id"] == 7 and s["source_sequence"] == [1, 2, 3, 4, 0, 5, 6, 7]'),
    ('s["required_accounted_prefix"] == list(range(12))',
     's["required_accounted_prefix"] == [1, 2, 3, 4, 0, 5, 6]'),
    ('s["split"] == "student_train"', 's["split"] in ("student_train", "student_dev")'),
    ('target["latest_segment_started_at"]', 'target.get("latest_segment_started_at")'),
):
    if text.count(old) != 1:
        raise ValueError("Frozen scheduling interface changed: " + old)
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::general200_due_revisit", "exec"), globals())
