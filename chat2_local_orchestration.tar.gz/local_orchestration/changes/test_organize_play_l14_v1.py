"""Synthetic CPU bookkeeping only; no actual ledger, model, peer or simulator."""
import ast
import sys
import unittest


def reject_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        raise RuntimeError("SYNTHETIC_METADATA_ONLY " + event)


sys.addaudithook(reject_live)
import test_fasten_general_boundary_v1 as original
import switch_organize_baseline_to_play_l14_v1 as scheduling

original.OLD = "organize_table"
original.NEXT = "play_stacking_toy"
original.SEQUENCE = list(range(15))


class OrganizePlayTests(original.ClosedFastenTests):
    def setUp(self):
        super().setUp()
        self.prep.update(native_step_limit=1200,
                         binding_schema="refate.common_collector.collection_group_binding.v1")
        self.prep["source"].update(layout_id=14, source_sequence=list(range(15)),
                                   required_accounted_prefix=list(range(14)))

    def switch(self, at=None):
        return scheduling.switch_due(
            self.d, self.e, self.f.ref, self.prep, self.f.prep_ref,
            at or self.f.at, "Synthetic boundary only, no scientific credit")

    def test_wrong_loader_schema_is_rejected(self):
        self.prep["binding_schema"] = "refate.common_collector.configured_task_binding.v1"
        with self.assertRaises(AssertionError):
            self.switch()

    def test_effective_metadata_entry_uses_existing_group_loader(self):
        text = scheduling.source()
        ast.parse(text)
        self.assertIn("import collection_group_binding as binding", text)
        self.assertNotIn("import task_configured_binding as binding", text)
        for marker in ("baseline_checks(terminal)", "negative_shortfall_clock_reset=False",
                       'negative_elapsed >= 5400', 'native_step_limit"] == 1200',
                       'sid not in d["source_index"] and sid not in d["reservations"]'):
            self.assertIn(marker, text)


if __name__ == "__main__":
    unittest.main()
