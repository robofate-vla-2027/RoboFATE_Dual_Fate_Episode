"""Offline metadata wiring checks, without executing operational helper main bodies."""
import ast
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent


def text(name):
    value = (HERE / (name + ".py")).read_text()
    ast.parse(value)
    return value


class MetadataTests(unittest.TestCase):
    def test_preparation_exact_extension(self):
        old = text("teacher_prepare_metadata_handoff_v1")
        expected = old.replace("teacher_catalog_binding_v8", "teacher_catalog_binding_v9")
        expected = expected.replace("collect_teacher_content_v1", "collect_teacher_content_v2")
        expected = expected.replace("'sort_nesting_dolls_by_size':'DOLLS'",
                                    "'sort_nesting_dolls_by_size':'DOLLS','classify_objects':'CLASSIFY'")
        expected = expected.replace("TEACHER_CONTENT_RELEASE_20261031_01a19072",
                                    "TEACHER_CLASSIFY_CONTENT_RELEASE_20261101_01a19072")
        expected = expected.replace("f782c1ba4815746c30d88049f39ecd8591a5a50d7f398001ffa151beeb515969",
                                    "e63ae7a5294fc3b3c7a783e2b8bcca7c8c9662308d3fd80e8bdc2d02a8d8dd6a")
        expected = expected.replace("'plug_in_charger','put_bottles_into_dustbin')",
                                    "'plug_in_charger','put_bottles_into_dustbin','classify_objects')")
        self.assertEqual(text("teacher_prepare_metadata_handoff_v2"), expected)

    def test_reservation_exact_extension(self):
        expected = text("teacher_reserve_handoff_v1")
        expected = expected.replace("teacher_catalog_binding_v8", "teacher_catalog_binding_v9")
        expected = expected.replace("'sort_nesting_dolls_by_size':'dolls'",
                                    "'sort_nesting_dolls_by_size':'dolls','classify_objects':'classify'")
        self.assertEqual(text("teacher_reserve_handoff_v2"), expected)

    def test_binding_exact_extension(self):
        expected = text("teacher_bind_handoff_v1").replace("prepare_teacher_content_v1",
                                                         "prepare_teacher_content_v2")
        self.assertEqual(text("teacher_bind_handoff_v2"), expected)

    def test_terminal_exact_extension(self):
        expected = text("teacher_terminal_handoff_v2").replace("collect_teacher_content_v1",
                                                              "collect_teacher_content_v2")
        expected = expected.replace("164a68e76dd97de0371dcf5b855900244ddb7b3ca71a17c5607b41974ede51d5",
                                    "461b383cef47a116e7e6620816f1da4da4dd8e3ce29afc93226c607b426632cc")
        self.assertEqual(text("teacher_terminal_handoff_v3"), expected)

    def test_settlement_only_adapter_and_provenance_change(self):
        expected = text("teacher_settle_handoff_v2").replace("teacher_ledger_owner_handoff_v1",
                                                            "teacher_ledger_owner_handoff_v2")
        added = "adoption['classify1100_parameter_extension']=dict(adapter=cli.r.ref(Path(owner_core.__file__)),task='classify_objects',native_limit=1100,shared_cli='shared_teacher_ledger_cli_v12',scientific_conditions_unchanged=True)\n"
        actual = text("teacher_settle_handoff_v3")
        self.assertEqual(actual.count(added), 1)
        self.assertEqual(actual.replace(added, ""), expected)

    def test_pre_actor_predicate_remains_fail_closed(self):
        module = ast.parse(text("teacher_terminal_handoff_v3"))
        function = next(n for n in module.body if isinstance(n, ast.FunctionDef)
                        and n.name == "verified_pre_actor_failure")
        scope = {}
        exec(compile(ast.Module(body=[function], type_ignores=[]), "<synthetic-test>", "exec"), scope)
        check = scope["verified_pre_actor_failure"]
        context = {"source_id": "synthetic", "run_id": "synthetic", "t1": 37,
                   "native_limit": 1100, "remaining_steps": 1063}
        failure = {"source_id": "synthetic", "run_id": "synthetic",
                   "stage": "initial_boundary_saved", "type": "RuntimeError",
                   "message": "Restored physical/discrete state mismatch",
                   "native_used": 37, "actual_control_steps": 370,
                   "native_done": False, "native_success": False}
        comparison = {"all_compared_fields_within_candidate_rules": False,
                      "context_budget": {"total": 1100, "t1": 37, "remaining": 1063}}
        sha = "461b383cef47a116e7e6620816f1da4da4dd8e3ce29afc93226c607b426632cc"
        self.assertTrue(check(context, failure, comparison, {"synthetic_actor": False}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": True}, sha))
        self.assertFalse(check(context, failure, comparison, {}, sha))
        self.assertFalse(check(context, failure, comparison, {"synthetic_actor": False}, "wrong"))
        self.assertFalse(check(context, dict(failure, message="unverified failure"), comparison,
                               {"synthetic_actor": False}, sha))


if __name__ == "__main__":
    unittest.main()
