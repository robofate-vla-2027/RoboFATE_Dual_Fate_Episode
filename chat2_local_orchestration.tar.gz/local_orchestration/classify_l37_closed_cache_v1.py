"""Bind existing bounded maintenance to one pinned, closed private run."""
import base64
import hashlib
import io
import json
from pathlib import Path
import sys

import closed_classify_cache_pass_v2 as original

RUN_ID = "c2_classify_objects_l37_evo_common_teacher_0001_01a16807"
TERMINAL_SHA = "38b820ad1693bf8306feecefbd3763a6bbb0ae80feb805aeebf95f87ff71938c"
PARENT_SHA = "624abb7e8f11aac8ad9a96b61856c684a93643862c113fa678227202f079f9e9"
ADVICE_SHA = "6ae32e4b2102c25a339bbac928bc493657bf07e1a662ad624f083f12c7fd3564"


def configure(layout):
    assert type(layout) is int and layout == 37, "Different closed private run"
    assert hashlib.sha256(Path(original.__file__).read_bytes()).hexdigest() == PARENT_SHA
    original.scope.RUN = original.scope.ROOT / "runs" / RUN_ID
    original.scope.CACHE = original.scope.RUN / "runtime/cache"
    original.scope.TERMINAL_SHA = TERMINAL_SHA
    original.scope.inspect_live = original.live_scope.inspect_live


def advice(inspection):
    configure(37)
    import closed_private_cache_pilot_v1 as pilot
    assert hashlib.sha256(Path(pilot.__file__).read_bytes()).hexdigest() == ADVICE_SHA
    pilot.scope = original.scope
    raw = Path(inspection).read_bytes()
    request = dict(inspection_b64=base64.b64encode(raw).decode(),
                   inspection_sha256=hashlib.sha256(raw).hexdigest())
    previous = sys.stdin
    try:
        sys.stdin = io.StringIO(json.dumps(request))
        pilot.main()
    finally:
        sys.stdin = previous


def main():
    original.configure = configure
    mode = sys.argv[1]
    if mode == "inspect":
        original.inspect(37, sys.argv[2])
    elif mode == "advice":
        advice(sys.argv[2])
    elif mode == "reclaim":
        original.reclaim(37, sys.argv[2], sys.argv[3])
    else:
        raise ValueError("Explicit inspection, advice pilot or bounded pass required")


if __name__ == "__main__":
    main()
