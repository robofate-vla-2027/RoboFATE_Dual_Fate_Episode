"""Read-only check of the next frozen Insert preparation; no launch or ledger."""
import hashlib
import json
import os
from pathlib import Path
import socket
import sys

ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
            "20261022_collection_chat2_01a16338/teacher/shared_teacher")
ADAPTER = ROOT / "perdon_adapter_20261026"
assert socket.gethostname() == "nb-5pl2apckdj-0"
assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
assert os.environ["REFATE_EXECUTION_OWNER"] == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
sys.path.insert(0, str(ADAPTER))
import source_sequence_binding as binding

assert hashlib.sha256(Path(binding.__file__).read_bytes()).hexdigest() == (
    "1724f8f8c46bca22c48ecf7c706a7cd26d6cda9eea05f8dc4aed7f723ad12fad")


def ref(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


prior = ROOT / "runs/c2_insert_tubes_l40_common_baseline_0044_01a16807"
split = ref(prior / "SPLIT_MANIFEST_L40_001.json")
sequence = ref(prior / "SEQUENCE_EXTENSION_001.json")
raw = Path("/vla/mxk/projects/Robodojo/Assets/Eval_Layout/"
           "RoboDojo/arx_x5/0/insert_tubes_41.json")
assert not (ROOT / "preparations/INSERT_L41_COMMON_PREPARATION_001.json").exists()
try:
    prepared = binding.prepare_source(
        task="insert_tubes", encoded_seed=41,
        expected_raw_sha256=ref(raw)["sha256"],
        prior_split_ref=split, prior_sequence_ref=sequence)
except Exception as error:
    print(json.dumps(dict(
        data_kind="read_only_preparation_check", passed=False,
        prior_split=split, prior_sequence=sequence, raw_layout=ref(raw),
        exception_type=type(error).__name__, exception=str(error),
        source_reserved=False, actual_launch=False)))
    raise
else:
    print(json.dumps(dict(
        data_kind="read_only_preparation_check", passed=True, prepared=prepared,
        actual_preparer=os.environ["REFATE_EXECUTION_OWNER"],
        source_reserved=False, actual_launch=False)))
