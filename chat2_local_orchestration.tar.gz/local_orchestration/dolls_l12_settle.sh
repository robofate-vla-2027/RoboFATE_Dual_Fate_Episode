#!/bin/bash
# One foreground, manually invoked settlement using the existing helpers.
set -euo pipefail
set -C
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'PY'
import json
from pathlib import Path
p=Path("dolls_l12_foreground.exit.json")
exit_record=json.loads(p.read_bytes())
assert exit_record["run_id"]=="c2_sort_nesting_dolls_by_size_l12_common_baseline_0013_01a16807"
with Path("dolls_l12_terminal.args.json").open("x") as stream:
    json.dump(exit_record,stream)
PY
remote_env='env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 PYTHONDONTWRITEBYTECODE=1'
py=/vla/mxk/projects/Robodojo/.runtime-env/bin/python
a=/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
sh ./remote.sh --command "$remote_env $py -B $a/baseline_terminal_handoff_v1.py" \
    < dolls_l12_terminal.args.json > dolls_l12_terminal.result.json \
    2> dolls_l12_terminal.stderr.log
python3 - <<'PY'
import base64,json
from pathlib import Path
with Path("dolls_l12_settlement.args.json").open("x") as stream:
    json.dump(dict(evidence_b64=base64.b64encode(
        Path("dolls_l12_terminal.result.json").read_bytes()).decode()),stream)
PY
python3 ./ledger_transaction.py snapshot ./dolls_l12_settlement \
    --arguments ./dolls_l12_settlement.args.json
gzip -c dolls_l12_settlement.request.json | \
    sh ./remote.sh --command "bash -o pipefail -c 'gzip -dc | $remote_env $py -B $a/baseline_settle_handoff_v1.py | gzip -c'" \
    > dolls_l12_settlement.result.json.gz \
    2> dolls_l12_settlement.stderr.log
gzip -dc dolls_l12_settlement.result.json.gz > dolls_l12_settlement.result.json
python3 ./ledger_transaction.py commit ./dolls_l12_settlement
sh ./remote.sh --command "$remote_env $py -B $a/baseline_content_diagnostics_v1.py" \
    < dolls_l12_health.args.json > dolls_l12_content_readback.result.json \
    2> dolls_l12_content_readback.stderr.log
python3 - <<'PY'
import json
from pathlib import Path
d=json.loads(Path("dolls_l12_content_readback.result.json").read_bytes())
print(json.dumps({k:d[k] for k in (
    "observed_boundaries","decoded_RGB_images","constant_rgb_frames",
    "real_constant_frame_scenario_verified","full_payload_decode_repeated")}))
PY
