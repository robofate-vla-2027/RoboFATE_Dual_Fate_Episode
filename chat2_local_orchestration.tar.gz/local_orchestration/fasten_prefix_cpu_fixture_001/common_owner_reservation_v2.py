"""Exact settled-teacher predecessor compatibility; science and counters unchanged."""
from pathlib import Path
import hashlib


def _settled_predecessor(ledger, prior, boundary):
    row = ledger['reservations'][prior['source_id']]
    status = row['status']
    if status.startswith('settled_'):
        return True
    if status != 'shared_Evo_teacher_settled':
        return False
    expected = boundary.get('last_teacher_settlement')
    run_id = row.get('current_attempt_run_id')
    return (row.get('positive_slots') == 0 and row.get('negative_slots') == 0
            and row.get('quota_reserved') is False
            and row.get('negative_quota_reserved') is False
            and isinstance(expected, dict) and set(expected) == {'path', 'sha256'}
            and isinstance(run_id, str) and bool(run_id)
            and Path(expected['path']).parent.parent.name == run_id
            and row.get('current_attempt_settlement') == expected
            and isinstance(row.get('settled_at'), str))



def _inherited_prefix(ledger, boundary, source, ordinal):
    inherited = boundary.get('inherited_prefix')
    if not isinstance(inherited, dict):
        return False
    prior = boundary['settlement']
    old = ledger['source_index'].get(prior['source_id'], {})
    prepared = inherited.get('prepared_source', {})
    previous_prefix = prepared.get('required_accounted_prefix')
    previous_ordinal = prepared.get('layout_id')
    return (inherited.get('source_id') == prior['source_id']
            and inherited.get('preparation_ref') == old.get('preparation')
            and prepared.get('source_id') == prior['source_id']
            and prepared.get('task') == source['task'] == old.get('task')
            and old.get('source_started') is True
            and old.get('settlement') == prior['settlement_ref']
            and isinstance(previous_prefix, list) and type(previous_ordinal) is int
            and old.get('required_accounted_prefix') == previous_prefix
            and prepared.get('source_sequence') == source.get('source_sequence') == old.get('source_sequence')
            and source['required_accounted_prefix'] == previous_prefix + [previous_ordinal]
            and ordinal in previous_prefix + [previous_ordinal])

_path = Path(__file__).with_name('common_owner_reservation.py')
_raw = _path.read_bytes()
if hashlib.sha256(_raw).hexdigest() != 'b9495cc8a0f316c830ec11a5ca8fbb352e455dabf0db3e324a16dfeaee4871ed':
    raise ValueError('Pinned original reservation helper changed')
_old = "ledger['reservations'][prior['source_id']]['status'].startswith('settled_')"
_text = _raw.decode()
if _text.count(_old) != 1:
    raise ValueError('Reservation predecessor seam changed')
_text = _text.replace(_old, '_settled_predecessor(ledger, prior, b)', 1)
_prefix = "len(matches) == 1 and matches[0].get('settlement') is not None"
if _text.count(_prefix) != 1:
    raise ValueError('Reservation prefix seam changed')
_text = _text.replace(_prefix, '(' + _prefix + ') or _inherited_prefix(ledger, b, source, i)', 1)
exec(compile(_text, str(_path) + '::settled_teacher_v2', 'exec'), globals())
