"""Synthetic in-memory bookkeeping only; no production ledger, model or Native."""
from copy import deepcopy
import unittest
import common_owner_reservation as owner
AT='2026-10-26T12:00:01+00:00'
OLD='plug_in_charger_b0_l0_synthetic'
NEW='plug_in_charger_b0_l1_synthetic'
REF={'path':'/synthetic/not_authority.json','sha256':'a'*64}


def fixture():
    source=dict(task='plug_in_charger',source_id=NEW,execution_owner=owner.OWNER,
        source_owner='synthetic_historical_owner',initialization_content_sha256='new_synthetic',
        required_accounted_prefix=[0],group_id='synthetic_family',split='student_train',layout_sha256='b'*64)
    prep=dict(source=source,native_step_limit=400,mode='independent_baseline',requested_initial_native_count=0,
        renderer_profile='synthetic_pt4',prospective_teacher_renderer_profile='synthetic_pt4',provenance={'split':deepcopy(REF)})
    ledger=dict(campaign_id=owner.CAMPAIGN,revision=10,started_at='synthetic_original_start',
        nodes={'perdon-hou':dict(active_chat_id=owner.OWNER,user_pause_active=False,user_stop=False,
            fixed_tasks=['plug_in_charger'],current_task='plug_in_charger',active_real_simulators=0,
            active_run_id=None,launch_inflight=False,baseline_accounting={'baseline_attempts_running':0},
            completed_pending_sources=[],common_pending_readback_run_ids=[],negative_count=9,
            negative_reserved_count=0,negative_quota=210,current_runtime_adoption={'runtime_release':deepcopy(REF)},
            current_dispatch={'teacher_wall_seconds':3600,'native_wall_seconds':2400},
            current_common_foreground={'actual_entry':'synthetic_collect.py'},unknown_field={'keep':[1,2]}),
            'h20_8':{'unknown_peer':[1,2]}},
        tasks={'plug_in_charger':dict(assigned_host='perdon-hou',negative_count=0,negative_reserved_count=0,
            negative_quota=10,latest_segment_started_at='synthetic_original_segment')},
        source_index={OLD:dict(source_id=OLD,task='plug_in_charger',host='perdon-hou',
            settlement=deepcopy(REF),initialization_content_sha256='old_synthetic',history=['old_failure_preserved'])},
        reservations={OLD:{'status':'settled_native_failure_no_quota'}})
    boundary=dict(at='2026-10-26T12:00:00+00:00',next_preparation={'ref':deepcopy(REF),'prepared':prep},
        resource_precheck={'ref':deepcopy(REF),'summary':{'run_id':'c2_plug_in_charger_l1_synthetic_01a16807'}},
        settlement={'source_id':OLD,'safe_for_next_simulator':True,'settlement_ref':deepcopy(REF)},
        runtime_release=deepcopy(REF),teacher_supplement_present=False)
    return ledger,boundary


class ReservationTests(unittest.TestCase):
    def test_preservation_and_real_start_not_claimed(self):
        d,b=fixture(); original=deepcopy(d); out,dispatch=owner.reserve(d,b,AT)
        self.assertEqual(d,original); self.assertEqual(out['nodes']['h20_8'],d['nodes']['h20_8'])
        self.assertEqual(out['source_index'][OLD],d['source_index'][OLD])
        self.assertEqual(dispatch['source_owner'],'synthetic_historical_owner')
        self.assertEqual(dispatch['execution_owner'],owner.OWNER)
        self.assertEqual(dispatch['original_segment_started_at'],'synthetic_original_segment')
        self.assertEqual(out['nodes']['perdon-hou']['negative_count'],9)
        self.assertEqual(out['nodes']['perdon-hou']['negative_reserved_count'],1)
        self.assertEqual(out['nodes']['perdon-hou']['current_common_foreground']['actual_entry'],'synthetic_collect.py')
        self.assertFalse(out['source_index'][NEW]['source_started']);self.assertEqual(out['revision'],11)
    def test_budgets(self):
        for budget in (400,800,1900):
            with self.subTest(budget=budget):
                d,b=fixture();b['next_preparation']['prepared']['native_step_limit']=budget
                _,v=owner.reserve(d,b,AT);self.assertEqual(v['native_total_steps'],budget);self.assertEqual(v['teacher_wall_seconds'],3600)
    def test_owner_pause_and_active(self):
        for field,value in [('active_chat_id','third_party'),('user_pause_active',True),('user_stop',True),('active_real_simulators',1),('active_run_id','another'),('launch_inflight',True)]:
            with self.subTest(field=field):
                d,b=fixture();d['nodes']['perdon-hou'][field]=value
                with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_used_source_and_initialization(self):
        d,b=fixture();d['source_index'][NEW]={}
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
        d,b=fixture();b['next_preparation']['prepared']['source']['initialization_content_sha256']='old_synthetic'
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_predecessor_and_prefix(self):
        d,b=fixture();d['reservations'][OLD]['status']='running'
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
        d,b=fixture();b['next_preparation']['prepared']['source']['required_accounted_prefix']=[0,2]
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_stale_resources(self):
        d,b=fixture();b['at']='2026-10-26T11:40:00+00:00'
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_quota_backlog_and_budget_type(self):
        for case in ('quota','backlog','budget'):
            d,b=fixture()
            if case=='quota':d['tasks']['plug_in_charger']['negative_count']=10
            elif case=='backlog':d['nodes']['perdon-hou']['completed_pending_sources']=[1,2,3]
            else:b['next_preparation']['prepared']['native_step_limit']=True
            with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_runtime_and_wall_scope(self):
        d,b=fixture();b['runtime_release']['sha256']='c'*64
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
        d,b=fixture();d['nodes']['perdon-hou']['current_dispatch']['teacher_wall_seconds']=7200
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_protected_source(self):
        d,b=fixture();b['next_preparation']['prepared']['source']['source_id']='classify_objects_b0_l2_6b3a30251bd92a46'
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)
    def test_used_run(self):
        d,b=fixture();d['source_index'][OLD]['run_id']=b['resource_precheck']['summary']['run_id']
        with self.assertRaises(ValueError):owner.reserve(d,b,AT)

if __name__=='__main__':unittest.main()
