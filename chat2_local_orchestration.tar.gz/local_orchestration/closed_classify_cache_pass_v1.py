"""Foreground bounded passes over four pinned, closed, private run caches."""
import contextlib
import datetime
import json
import os
from pathlib import Path
import sys
import time
import classify_l34_pageout_pilot_v2 as pilot
import classify_l34_resident_scope_v1 as inventory
import closed_classify_l34_cache_inspect_v1 as scope

PINS = {
    34: "bfad4f6f59f3c75596eb7e79dbe20038bfbcc6cf3670f92424946b06d9bd21dc",
    42: "abde2770a82a9de42fba08be71c93ef78f8632b847e4ba26b27c28527cfb70f5",
    22: "993c47de385f37204ea8beb482d2a2e592a4fb84ded778e7e13074cb6374ecf8",
    19: "2807da681340839efb0842ce076f1c8dbb0014981b816eb4a752b07a2e2c7970",
}
BINARY_SHA = "ff03060a2503189ac9d7a6dcdd9f0454fbf40e68f50ee93fcce77cb3a5a34627"
MAX_PASS_BYTES = 1024**3
STOP_HEADROOM = 120 * 1024**3 + 256 * 1024**2


def configure(layout):
    layout = int(layout)
    assert layout in PINS, "Unlisted private cache"
    scope.RUN = scope.ROOT / f"runs/c2_classify_objects_l{layout}_evo_common_teacher_0001_01a16807"
    scope.CACHE = scope.RUN / "runtime/cache"
    scope.TERMINAL_SHA = PINS[layout]


def inspect(layout, output):
    configure(layout)
    with Path(output).open("x") as stream, contextlib.redirect_stdout(stream):
        inventory.main()
    plan = json.loads(Path(output).read_bytes())
    print(json.dumps(dict(run=scope.RUN.name, resident_bytes=plan["resident_bytes"],
                          exclusion_complete=plan["exclusion_complete"],
                          errors=plan["process_inspection_errors"])), flush=True)
    assert plan["exclusion_complete"], "Fresh active-user exclusion failed; no reclamation"


def reclaim(layout, inspection, output):
    configure(layout)
    plan = json.loads(Path(inspection).read_bytes())
    assert plan["exclusion_complete"] and plan["run_id"] == scope.RUN.name
    assert plan["terminal_sha256"] == scope.TERMINAL_SHA
    dest = Path(output)
    dest.mkdir()
    binary = Path(__file__).with_name("private_file_pageout_16m_v1").resolve()
    begun, issued, reduced, completed = time.monotonic(), 0, 0, 0
    before = scope.memory()
    page = os.sysconf("SC_PAGE_SIZE")
    candidates = sorted(plan["candidates"], key=lambda row: row["resident_bytes"], reverse=True)
    for index, candidate in enumerate(candidates[:256]):
        if scope.memory()["headroom_bytes"] >= STOP_HEADROOM:
            break
        if time.monotonic() - begun >= 300:
            break
        length = min(16 * 1024**2, candidate["signature"][3] // page * page)
        if length <= 0 or candidate["resident_bytes"] < length:
            continue
        if issued + length > MAX_PASS_BYTES:
            break
        with (dest / f"file_{index:03d}.json").open("x") as stream:
            with contextlib.redirect_stdout(stream):
                pilot.run(inspection, str(binary), BINARY_SHA, index)
        result = json.loads((dest / f"file_{index:03d}.json").read_bytes())
        issued += length
        reduced += result["resident_reduction_bytes"]
        completed += 1
        assert result["resident_reduction_bytes"] > 0, "No measurable yield; stop"
        if completed % 4 == 0:
            print(json.dumps(dict(completed=completed, reduced_bytes=reduced,
                                  headroom_bytes=scope.memory()["headroom_bytes"])), flush=True)
    result = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  data_kind="actual_bounded_closed_private_cache_pass",
                  run_id=scope.RUN.name, completed=completed, issued_bytes=issued,
                  resident_reduction_bytes=reduced, memory_before=before,
                  memory_after=scope.memory(), max_pass_bytes=MAX_PASS_BYTES,
                  max_pass_seconds=300, stopped_without_relaunch=True,
                  no_anonymous_pressure=True, no_signals=True, no_files_deleted=True,
                  scientific_samples_added=0)
    (dest / "SUMMARY.json").write_text(json.dumps(result) + "\n")
    print(json.dumps({k: result[k] for k in
                      ("at", "run_id", "completed", "resident_reduction_bytes")}), flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "inspect":
        inspect(*sys.argv[2:])
    elif sys.argv[1] == "reclaim":
        reclaim(*sys.argv[2:])
    else:
        raise ValueError("Explicit inspect or bounded reclaim required")
