"""Local, metadata-only backfill from an already counted independent negative."""
import base64
from copy import deepcopy
import datetime
import hashlib
import json
import os
import sys

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def compute(ledger, evidence, evidence_ref, at):
    node = ledger["nodes"]["perdon-hou"]
    task = ledger["tasks"]["classify_objects"]
    sid = evidence["source_id"]
    source = ledger["source_index"][sid]
    assert node["active_chat_id"] == OWNER and node["current_task"] == "classify_objects"
    assert not node["user_pause_active"] and not node["user_stop"]
    assert source["task"] == "classify_objects" and source["host"] == "perdon-hou"
    assert source["counted_in_negative_quota"] is True and source["counted_in_quota"] is False
    assert source["negative_qualification_status"] == "qualified"
    negatives = [s for s in ledger["source_index"].values()
                 if s.get("task") == "classify_objects" and s.get("host") == "perdon-hou"
                 and s.get("counted_in_negative_quota") is True]
    assert len(negatives) == task["negative_count"] == 1
    assert evidence["data_kind"] == "actual_existing_metadata_not_new_data"
    assert evidence["positive_delta"] == evidence["negative_delta"] == 0
    for key in ("negative_receipt", "negative_remote_commit"):
        assert evidence["references"][key] == source[key]
    acceptance = evidence["documents"]["negative_receipt"]
    commit = evidence["documents"]["negative_remote_commit"]
    assert acceptance["source_id"] == commit["source_id"] == sid
    assert acceptance["data_type"] == "dm_native_success"
    assert acceptance["negative_qualification_status"] == "qualified"
    assert acceptance["teacher_success_contribution"] == 0
    assert commit["lock_inode"] == 27555308 and commit["core_negative_count"] == 1
    stamp = commit["timestamp"]
    assert stamp == source["negative_qualified_at"] == source["negative_ledger_commit"]["timestamp"]
    assert commit["revision"] == source["negative_ledger_commit"]["revision"]
    assert datetime.datetime.fromisoformat(stamp) < datetime.datetime.fromisoformat(task["latest_segment_started_at"])
    existing = task.get("last_negative_gain_at")
    assert existing is None or existing == stamp, "Do not overwrite a newer negative gain"
    out = deepcopy(ledger)
    receipt = dict(at=at, source_id=sid, run_id=source["negative_core_episode_id"],
                   positive_delta=0, negative_delta=0, last_negative_gain_at=stamp,
                   already_present=existing is not None, evidence=evidence_ref)
    if existing is None:
        target = out["tasks"]["classify_objects"]
        target["last_negative_gain_at"] = stamp
        target["negative_clock_origin"] = dict(
            source_id=sid, original_commit=source["negative_remote_commit"],
            original_acceptance=source["negative_receipt"], evidence=evidence_ref,
            backfilled_at=at, qualification_changed=False, source_rows_changed=False)
        target["updated_at"] = at
        out["revision"] += 1
        out["updated_at"] = at
    receipt.update(revision=out["revision"], node_positive=node["qualified_count"],
                   node_negative=node["negative_count"])
    return {"ledger": out, "receipt": receipt}


if __name__ == "__main__":
    assert os.uname().sysname == "Darwin", "Local ledger helper only"
    request = json.load(sys.stdin)
    raw = base64.b64decode(request["evidence_b64"])
    assert hashlib.sha256(raw).hexdigest() == request["evidence_ref"]["sha256"]
    result = compute(json.loads(base64.b64decode(request["ledger_b64"])), json.loads(raw),
                     request["evidence_ref"], datetime.datetime.now(datetime.timezone.utc).isoformat())
    print(json.dumps(result))
