"""Inspect saved L11 state/action metadata; no replay or RGB decoding."""
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import sys


def metadata_only(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
            "os.system", "os.kill", "os.killpg", "os.fork", "os.posix_spawn"):
        if event != "socket.gethostname":
            raise RuntimeError("Saved source metadata only: " + event)


sys.addaudithook(metadata_only)
import conveyor_causal_cutoff_v1 as cutoff
import failure_summary_report_size_v1 as failure
from teacher_catalog_binding_v13 import restore as r

adapter = Path(cutoff.__file__).resolve()
assert hashlib.sha256(adapter.read_bytes()).hexdigest() == (
    "be6c670e88ea000ea56e6aee434eae0430edc157c630006a7a36eac7ff4a1234")
source = adapter.parent.parent / "runs" / (
    "c2_pick_from_conveyor_by_image_l11_common_baseline_0012_01a16807")
material = r.source_material(
    r.ref(source / "CONTEXT_001.json"),
    r.ref(source / "SOURCE_MANIFEST_001.json"),
    failure.project(r.ref(source / "readback_once_001/SUMMARY.json")), t1=10)
assert material["source_id"] == "pick_from_conveyor_by_image_b0_l11_dddf030ef8468955"
assert material["source_identity"]["layout_id"] == 11
later_ref = r.ref(source / "physics_000100.json")
initial, boundary, later = [
    r.document(pin) for pin in
    (material["initial_ref"], material["boundary_ref"], later_ref)]
with (source / "native_actions.jsonl").open() as stream:
    actions = [json.loads(line) for line in itertools.islice(stream, 10)]
result = cutoff.check(
    initial, boundary, later, actions, task=material["task"],
    t1=10, total=material["native_limit"], later_step=100)
result.update(
    schema="refate.source_causal_cutoff_selection.v1",
    data_kind="actual_source_metadata_not_restore_admission",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_id=material["source_id"], source_context=material["source_context"],
    source_manifest=material["source_manifest"],
    source_readback=material["source_readback"], initial=material["initial_ref"],
    boundary=material["boundary_ref"], later_source_evidence_for_main_only=later_ref,
    metadata_adapter=r.ref(adapter),
    basis="Actual saved ConveyorL11 source only. Reuse the unchanged early-open-"
          "gripper moving-belt check at10 against100, leaving690 of700 native "
          "steps. This is not restored-state, native-success or qualification "
          "evidence. Later state remains main-side selection only.",
    source_reexecuted=False, full_payload_redecoded=False, teacher_started=False)
path = source / "CONVEYOR_L11_T10_CAUSAL_SELECTION_001.json"
with path.open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
result["evidence_ref"] = r.ref(path)
print(json.dumps(result))
