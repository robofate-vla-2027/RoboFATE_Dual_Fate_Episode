#!/bin/sh
set -euC
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
python3 - <<'GUARD'
import json
from pathlib import Path
n = json.loads(Path('../ReFATE_collection_progress.json').read_bytes())['nodes']['perdon-hou']
assert n['active_chat_id'] == '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'
assert n['active_run_id'] == 'c2_general_pickup_l14_evo_common_teacher_0001_01a16807'
assert n['launch_inflight'] and n['active_real_simulators'] == 0
assert not n['user_pause_active'] and not n['user_stop'] and not n['owned_resource_launch_hold']
GUARD
test ! -e general_l14_teacher_foreground.result.json
test ! -e general_l14_teacher_foreground.exit.json
set +e
sh ./remote.sh --command 'env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 CUDA_VISIBLE_DEVICES=0,1 CUDA_DEVICE_ORDER=PCI_BUS_ID MODEL_UPSTREAM=http://127.0.0.1:28181 PYTHONDONTWRITEBYTECODE=1 /vla/mxk/projects/Robodojo/.runtime-env/bin/python -B /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/collect_teacher_content_v6.py --context /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs/c2_general_pickup_l14_evo_common_teacher_0001_01a16807/CONTEXT_001.json --sha256 30cd9a218f6c030950c6c1b141339ad0124b8d1d21dcc7949b3e1c01d1a842ad' > general_l14_teacher_foreground.result.json 2> general_l14_teacher_foreground.stderr.log
rc=$?
set -e
printf '{"run_id":"c2_general_pickup_l14_evo_common_teacher_0001_01a16807","tool_returncode":%s}\n' "$rc" > general_l14_teacher_foreground.exit.json
cat general_l14_teacher_foreground.exit.json
exit "$rc"
