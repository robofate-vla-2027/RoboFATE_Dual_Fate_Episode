#!/bin/bash
set -euo pipefail
cd /Users/maxiangkai.1/Desktop/PythonProjects/ReFATE_chat2_handoff_20261031_01a19072
tar -cf - -C changes switch_dolls_teacher_to_general_l23_v1.py \
    due_general_l23_from_dolls_boundary_v1.py test_dolls_general_l23_revisit_v1.py |
    sh ./remote.sh --command '
        set -eu
        cd /mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026
        for f in switch_dolls_teacher_to_general_l23_v1.py due_general_l23_from_dolls_boundary_v1.py test_dolls_general_l23_revisit_v1.py; do
            test ! -e "$f"
        done
        tar -xf -
        sha256sum switch_dolls_teacher_to_general_l23_v1.py due_general_l23_from_dolls_boundary_v1.py test_dolls_general_l23_revisit_v1.py
        env REFATE_SSH_ALIAS=perdon-hou REFATE_EXECUTION_OWNER=01a19072-9e5e-7e02-b77a-8f115cfc9bd0 PYTHONDONTWRITEBYTECODE=1 /vla/mxk/projects/Robodojo/.runtime-env/bin/python -B test_dolls_general_l23_revisit_v1.py
        sha256sum collect_recording_content_v1.py collect_teacher_content_v6.py common_recording_content_v2.py
    '
