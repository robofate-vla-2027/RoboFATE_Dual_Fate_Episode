"""One bounded advice call on a verified cold private cache file; no pressure."""
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import closed_private_cache_inspect_v1 as scope

MAX_BYTES = 16 * 1024**2


def validate(row, cache, now_ns):
    path = Path(row["path"])
    if not path.is_relative_to(cache) or path.resolve(strict=True) != path:
        raise ValueError("Outside canonical private cache")
    before = scope.signature(path)
    if before != row["signature"] or now_ns - before[4] < 300 * 10**9:
        raise ValueError("Private file changed or too recent")
    page = os.sysconf("SC_PAGE_SIZE")
    length = min(MAX_BYTES, before[3] // page * page)
    if length <= 0 or row["resident_bytes"] < length:
        raise ValueError("Known resident aligned range required")
    return path, before, length


def resident(path):
    rows = json.loads(subprocess.run(
        ["fincore", "-J", "-b", "-o", "FILE,RES", str(path)],
        check=True, text=True, capture_output=True).stdout)["fincore"]
    assert len(rows) == 1 and rows[0]["file"] == str(path)
    return int(rows[0]["res"])


def main():
    assert os.environ["REFATE_SSH_ALIAS"] == "perdon-hou"
    assert os.uname().nodename == "nb-5pl2apckdj-0"
    assert os.environ["CUDA_VISIBLE_DEVICES"] == ""
    x = json.load(sys.stdin)
    raw = base64.b64decode(x["inspection_b64"])
    assert hashlib.sha256(raw).hexdigest() == x["inspection_sha256"]
    plan = json.loads(raw)
    assert plan["run_id"] == scope.RUN.name and plan["execution_owner"] == scope.OWNER
    assert plan["cache_root"] == str(scope.CACHE) and plan["exclusion_complete"]
    terminal_raw = (scope.RUN / "MAIN_TERMINAL_OBSERVATION_001.json").read_bytes()
    assert hashlib.sha256(terminal_raw).hexdigest() == scope.TERMINAL_SHA
    terminal = json.loads(terminal_raw)
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    for row in terminal["own_process_checks"]:
        old = row["identity"]
        try:
            actual = scope.identity(old["pid"])
        except FileNotFoundError:
            continue
        assert boot != old["boot_id"] or actual["start_ticks"] != old["start_ticks"]
    row = sorted(plan["candidates"], key=lambda r: r["resident_bytes"], reverse=True)[0]
    path, before, length = validate(row, scope.CACHE, time.time_ns())
    processes, errors, users = scope.inspect_live({(before[0], before[1])})
    assert not errors and not users, (errors, users)
    memory_before = scope.memory()
    resident_before = resident(path)
    assert resident_before >= length and scope.signature(path) == before
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        st = os.fstat(fd)
        assert [st.st_dev, st.st_ino, st.st_mode, st.st_size,
                st.st_mtime_ns, st.st_ctime_ns] == before
        os.posix_fadvise(fd, 0, length, os.POSIX_FADV_DONTNEED)
    finally:
        os.close(fd)
    after = scope.signature(path)
    resident_after = resident(path)
    memory_after = scope.memory()
    assert after == before, "File content metadata changed"
    output = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        data_kind="actual_bounded_private_cache_advice", run_id=scope.RUN.name,
        path=str(path), signature_before=before, signature_after=after,
        advice="POSIX_FADV_DONTNEED", offset=0, length=length,
        resident_before=resident_before, resident_after=resident_after,
        resident_reduction_bytes=resident_before-resident_after,
        eviction_observed=resident_after < resident_before, syscall_accepted=True,
        memory_before=memory_before, memory_after=memory_after,
        protected_processes=processes, active_file_exclusion_errors=errors,
        live_candidate_users=users, inspection_sha256=x["inspection_sha256"],
        no_files_deleted=True, no_file_data_writes=True, no_signals=True,
        no_global_cache_controls=True, no_memory_pressure=True,
        temporary_descriptors_closed=True, scientific_samples_added=0)
    print(json.dumps(output))


if __name__ == "__main__":
    main()
