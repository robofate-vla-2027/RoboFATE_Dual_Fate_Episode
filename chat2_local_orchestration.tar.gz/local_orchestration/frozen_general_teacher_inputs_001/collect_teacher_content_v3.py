"""Same teacher foreground/readers, with its source-frozen Native dependency."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import collect_teacher_content_v2 as previous

text = previous.text
for old, new in (
    ("import native_teacher_content_v2 as native", "import native_teacher_content_v3 as native"),
    ("stage.HERE/'native_teacher_content_v2.py'", "stage.HERE/'native_teacher_content_v3.py'"),
    ("from teacher_catalog_binding_v9 import restore\n", "from teacher_catalog_binding_v10 import restore\n"),
    ("helpers=base.helpers();unused,native_env=base.environment(run,helpers)",
     "import teacher_native_extension_v1\n    helpers=base.helpers();unused,native_env=teacher_native_extension_v1.environment(base.environment,c)(run,helpers)"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("collect_shared_teacher.py")) +
             "::conveyor700_content", "exec"), globals())
