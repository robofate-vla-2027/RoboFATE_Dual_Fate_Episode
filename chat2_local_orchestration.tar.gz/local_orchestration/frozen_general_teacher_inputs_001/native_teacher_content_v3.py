"""Existing teacher Native with Conveyor700 catalog and original extension pins."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import native_teacher_content_v2 as previous
import teacher_catalog_binding_v10 as catalog

text = previous.text
if text.count("teacher_catalog_binding_v9") != 3:
    raise ValueError("Frozen Native catalog sites changed")
text = text.replace("teacher_catalog_binding_v9", "teacher_catalog_binding_v10")
text = runtime.edit(text, "    return c,material\n",
                    "    import teacher_native_extension_v1\n    teacher_native_extension_v1.validate(c)\n    return c,material\n")
exec(compile(text, str(Path(__file__).with_name("native_shared_teacher.py")) +
             "::conveyor700_content", "exec"), globals())
