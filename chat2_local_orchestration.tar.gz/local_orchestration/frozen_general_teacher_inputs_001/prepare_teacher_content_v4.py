"""Matching Conveyor source-format preparation; original budgets retained."""
from pathlib import Path
import common_runtime as runtime
import prepare_teacher_content_v3 as previous

text=previous.text
for old,new in (
    ("import native_teacher_content_v3 as native_shared_teacher\n","import native_teacher_content_v4 as native_shared_teacher\n"),
    ("from teacher_catalog_binding_v10 import restore, budget as _bound_budget\n","from teacher_catalog_binding_v11 import restore, budget as _bound_budget\n"),
    ("from teacher_catalog_binding_v10 import persistence as teacher_persistence_binding\n","from teacher_catalog_binding_v11 import persistence as teacher_persistence_binding\n"),
):text=runtime.edit(text,old,new)
exec(compile(text,str(Path(__file__).with_name("prepare_shared_teacher.py"))+"::conveyor_source_formats","exec"),globals())
