"""Matching Conveyor source-format catalog; Native behavior is unchanged."""
from pathlib import Path
import common_runtime as runtime
import native_teacher_content_v3 as previous

text=previous.text
if text.count("teacher_catalog_binding_v10")!=3:
    raise ValueError("Frozen Native catalog sites changed")
text=text.replace("teacher_catalog_binding_v10","teacher_catalog_binding_v11")
exec(compile(text,str(Path(__file__).with_name("native_shared_teacher.py"))+"::conveyor_source_formats","exec"),globals())
