"""Existing preparation with the matching Conveyor content entry set."""
from pathlib import Path
import execution_owner_binding_v1 as execution
execution.install()
import common_runtime as runtime
import teacher_catalog_binding_v10 as catalog

text = catalog.prepare_source()
for old, new in (
    ("import native_shared_teacher_v4 as native_shared_teacher\n", "import native_teacher_content_v3 as native_shared_teacher\n"),
    ("import common_recording\n", "import common_recording_content_v2 as common_recording\n"),
    ("import shared_dependency_binding\n", "import shared_dependency_content_v1 as shared_dependency_binding\n"),
):
    text = runtime.edit(text, old, new)
exec(compile(text, str(Path(__file__).with_name("prepare_shared_teacher.py")) +
             "::conveyor700_content", "exec"), globals())
