"""Accept existing Conveyor source formats through their original validators."""
from pathlib import Path
import common_runtime as runtime
import teacher_catalog_binding_v10 as previous
import task_configured_binding as configured

_TEXT = previous._TEXT
if _TEXT.count("teacher_catalog_binding_v10") != 6:
    raise ValueError("Frozen catalog import sites changed")
_TEXT = _TEXT.replace("teacher_catalog_binding_v10", "teacher_catalog_binding_v11")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_restore_v10'", "'_refate_shared_task_restore_v11'")
_TEXT = runtime.edit(_TEXT, "'_refate_shared_task_persistence_v10'", "'_refate_shared_task_persistence_v11'")
exec(compile(_TEXT, str(Path(__file__).with_name("teacher_task_binding.py")) +
             "::conveyor_source_formats_v11", "exec"), globals())


def load_native_layout(context):
    if context["source"]["task"] == "pick_from_conveyor_by_image":
        need(type(context["native_step_limit"]) is int and context["native_step_limit"] == 700,
             "Original Conveyor700 budget required")
        return configured.load_native_layout(context)
    return previous.load_native_layout(context)
