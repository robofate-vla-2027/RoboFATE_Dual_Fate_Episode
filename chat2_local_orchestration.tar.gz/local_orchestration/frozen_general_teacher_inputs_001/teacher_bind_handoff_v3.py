import sys,json,os
from pathlib import Path
x=json.load(sys.stdin);d=x['dispatch'];A=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher')/'runs'/d['run_id'];p=run/'DISPATCH_001.json'
os.environ.update(REFATE_EXECUTION_OWNER='01a19072-9e5e-7e02-b77a-8f115cfc9bd0',CUDA_VISIBLE_DEVICES='0,1',CUDA_DEVICE_ORDER='PCI_BUS_ID',MODEL_UPSTREAM='http://127.0.0.1:28181');sys.path.insert(0,str(A));import prepare_teacher_content_v4 as prep
with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
print(json.dumps(prep.prepare(p)))