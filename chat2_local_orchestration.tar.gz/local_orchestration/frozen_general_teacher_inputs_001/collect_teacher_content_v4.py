"""Matching Conveyor source-format Native; foreground and readers unchanged."""
from pathlib import Path
import common_runtime as runtime
import collect_teacher_content_v3 as previous

text=previous.text
for old,new in (
    ("import native_teacher_content_v3 as native","import native_teacher_content_v4 as native"),
    ("stage.HERE/'native_teacher_content_v3.py'","stage.HERE/'native_teacher_content_v4.py'"),
    ("from teacher_catalog_binding_v10 import restore\n","from teacher_catalog_binding_v11 import restore\n"),
):text=runtime.edit(text,old,new)
exec(compile(text,str(Path(__file__).with_name("collect_shared_teacher.py"))+"::conveyor_source_formats","exec"),globals())
