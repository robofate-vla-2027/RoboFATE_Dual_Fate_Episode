import sys,json,datetime,hashlib,math,itertools,fcntl,os,socket,re
from pathlib import Path
sys.path.insert(0,'/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026');import failure_summary_binding as failure
from teacher_catalog_binding_v11 import restore as r, TASK_TOTALS
import collect_teacher_content_v4 as collect
import preparation_metadata_compat_v1 as preparation_compat
import preparation_metadata_compat_v4 as legacy_compat
assert r.ref(Path(legacy_compat.__file__))=={"path":"/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/preparation_metadata_compat_v4.py","sha256":"db329f2e67799ed0d5d8d65e4fae1c788ca67617bbcfd8c08f4476ac9e967185"}
import preparation_metadata_compat_v2 as early_motion_compat
assert r.ref(Path(early_motion_compat.__file__))=={"path":"/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/preparation_metadata_compat_v2.py","sha256":"df6a61dfe5d6cc5fd743179c386eb54656800af82985d3574981f32a25c51ded"}
assert hashlib.sha256(Path(preparation_compat.__file__).read_bytes()).hexdigest()=='611ffa107a76cc6e108894c58de5ad8e411e1f01301844741b5ee2a9a4356351'
def verify_preclosure(actions,t1,arm):
 assert arm in ('left','right'),'Unknown closing arm'
 assert type(t1) is int and 3<=t1 and t1+2<len(actions)
 key=arm+'_ee_joint_state'
 assert all(actions[i]['action'][key][0]>.99 for i in range(t1-3,t1))
 assert actions[t1]['action'][key][0]<.99 and actions[t1+2]['action'][key][0]<actions[t1]['action'][key][0]
 return key
x=json.load(sys.stdin);fg=collect.base;fg.host();run=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['run_id'];source=Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs')/x['source_run'];t1=x['t1'];layout=x['layout'];task=x['task'];assert task in TASK_TOTALS;total=TASK_TOTALS[task];tag={'insert_tubes':'INSERT','arrange_largest_number':'ARRANGE','organize_table':'ORGANIZE','play_stacking_toy':'PLAY','plug_in_charger':'PLUG','put_bottles_into_dustbin':'BOTTLES','sort_nesting_dolls_by_size':'DOLLS','classify_objects':'CLASSIFY','pick_from_conveyor_by_image':'CONVEYOR'}[task];assert re.fullmatch(r'c2_'+re.escape(task)+r'_l'+str(layout)+r'_evo_common_teacher_[0-9]{4}_01a16807',x['run_id']) and not run.exists()
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write(chr(10))
 return r.ref(p)
summary_ref=r.ref(source/'readback_once_001/SUMMARY.json');compat=failure.project(summary_ref);m=r.source_material(r.ref(source/'CONTEXT_001.json'),r.ref(source/'SOURCE_MANIFEST_001.json'),compat,t1=t1);assert m['task']==task and m['native_limit']==total and m['source_identity']['layout_id']==layout
a=[json.loads(line) for line in itertools.islice((source/'native_actions.jsonl').open(),t1+3)];initial=r.document(m['initial_ref']);boundary=r.document(m['boundary_ref']);shifts={}
for k,v in initial['objects'].items():
 p=v['world_pose'][0];q=boundary['objects'][k]['world_pose'][0]
 while isinstance(p[0],list):p=p[0];q=q[0]
 shifts[k]=math.dist(p,q)
assert a[t1-1]['native_count_after']==t1 and boundary['task']['native_count']==[t1] and boundary['task']['end_flag']==[False]
arm=x.get('closing_arm','right');early=None
if x.get('causal_selection_ref'):
 early=r.document(x['causal_selection_ref']);assert early['schema']=='refate.source_causal_cutoff_selection.v1' and early['data_kind']=='actual_source_metadata_not_restore_admission'
 for key,value in [('source_id',m['source_id']),('task',m['task']),('source_context',m['source_context']),('source_manifest',m['source_manifest']),('source_readback',m['source_readback']),('initial',m['initial_ref']),('boundary',m['boundary_ref']),('native_limit',total),('t1',t1),('remaining_steps',total-t1)]:assert early[key]==value
 later=r.document(early['later_source_evidence_for_main_only'])
 if early['selection_kind']=='before_observed_object_translation':
  assert early['metadata_adapter']==r.ref(Path(preparation_compat.__file__))
  checked=preparation_compat.before_object_translation(initial,boundary,later,task=task,t1=t1,total=total,object_key=early['object_key'],later_step=early['later_source_boundary'])
 elif early['selection_kind']=='adjacent_initial_source_boundary_before_translation_growth':
  assert early['metadata_adapter']==r.ref(Path(early_motion_compat.__file__))
  prior=r.document(early['prior_source_evidence_for_main_only'])
  checked=early_motion_compat.adjacent_initial_source_boundary(initial,prior,boundary,later,task=task,t1=t1,total=total,object_key=early['object_key'],later_step=early['later_source_boundary'])
 elif early['selection_kind']=='early_open_gripper_conveyor_motion':
  import conveyor_causal_cutoff_v1 as conveyor_cut
  assert early['metadata_adapter']==r.ref(Path(conveyor_cut.__file__))
  checked=conveyor_cut.check(initial,boundary,later,a,task=task,t1=t1,total=total,later_step=early['later_source_boundary'])
 else:raise ValueError('Unsupported source-cut evidence kind')
 for key,value in checked.items():assert early[key]==value
 assert arm in ('left','right');gripper_key=arm+'_ee_joint_state';assert a[t1-1]['action'][gripper_key][0]>.99
else:gripper_key=verify_preclosure(a,t1,arm)
at=datetime.datetime.now(datetime.timezone.utc).isoformat();selection=dict(schema='refate.source_causal_cutoff_selection.v1',data_kind='actual_source_metadata_not_restore_admission',at=at,source_id=m['source_id'],task=m['task'],source_owner=m['source_owner'],native_limit=total,t1=t1,remaining_steps=total-t1,source_context=m['source_context'],source_manifest=m['source_manifest'],source_readback=m['source_readback'],initial=m['initial_ref'],boundary=m['boundary_ref'],observed_object_translation_m=shifts,source_task_state_at_boundary=boundary['task'],last_prefix_index=t1-1,observed_closing_arm=arm,last_prefix_gripper=a[t1-1]['action'][gripper_key][0],following_original_gripper_for_main_selection_only=[a[i]['action'][gripper_key][0] for i in range(t1,t1+3)],basis=x['basis'],cutoff_basis_kind=early['selection_kind'] if early else 'before_sustained_gripper_closure',causal_selection_ref=x.get('causal_selection_ref'),actual_restore_verified=False,teacher_started=False,qualified=False,source_reexecuted=False,full_payload_redecoded=False,dispatch_issued=False,reserved=False)
sel=write(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/preparations')/(tag+'_L'+str(layout)+'_EVO_T'+str(t1)+'_PREPARATION_001.json'),selection);allocation=fg.allocation()
with fg.LOCK.open('r+') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(f,fcntl.LOCK_UN)
term=r.document(r.ref(source/'MAIN_SETTLEMENT_001.json'))
if term.get('schema')=='refate.common_baseline.settlement.v1':term=legacy_compat.failed_baseline_view(term,r.document(term['summary_ref']),r.document(term['cleanup_ref']),m['source_id'],task)
assert term['safe_for_next_simulator'] and term['first_readback_passed'] and not term['native_success'];boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for row in term['process_closure']['checks']:
 ident=row['identity'];p=Path('/proc')/str(ident['pid'])/'stat';assert not (p.exists() and boot==ident['boot_id'] and int(p.read_text().rsplit(')',1)[1].split()[19])==ident['start_ticks'])
with socket.create_connection(('127.0.0.1',28181),timeout=3):pass
run.mkdir();peers=[]
for line in allocation['existing_processes'].splitlines():
 pid=int(line.split(',')[0]);p=Path('/proc')/str(pid);peers.append({'identity':fg.identity(pid),'uid':p.stat().st_uid,'executable':os.readlink(p/'exe')})
disks={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in ['/',str(run)]};assert disks['/']>256*1024**2 and disks[str(run)]>30*1024**3
resource=dict(schema='refate.actual_resource_precheck.v1',data_kind='actual',at=at,host='perdon-hou',hostname='nb-5pl2apckdj-0',ssh_endpoint='root@116.198.70.4:1122',run_id=x['run_id'],source_id=m['source_id'],allocation=allocation,existing_processes=peers,disk_free_bytes=disks,exclusive_native_lock_available=True,estimated_native_gpu1_mib=18000,policy_gpu0_reserve_mib=15000,safety_headroom_mib=12000,temporary_logs_cache_root=str(run/'runtime'),actual_launch=False,existing_peers_untouched=True,model_listener_reachable=True,provider_request_made=False)
resource_ref=write(run/'RESOURCE_PRECHECK_001.json',resource);release=r.ref(Path('/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/TEACHER_CONVEYOR_CONTENT_RELEASE_V2_20261101_01a19072.json'));assert release['sha256']=='74d2cdf5bb0ad1b688c002d792ae67f2b2af168a7314435e32abc5911dbb1ffd'
print(json.dumps({'at':at,'selection_ref':sel,'source_context':m['source_context'],'source_manifest':m['source_manifest'],'source_readback':compat,'source_id':m['source_id'],'source_owner':m['source_owner'],'task':m['task'],'native_limit':total,'t1':t1,'remaining_steps':total-t1,'resource':resource,'resource_ref':resource_ref,'runtime_release':release,'run_id':x['run_id'],'layout':layout,'split_manifest':r.document(m['source_context'])['split_manifest_ref'] if task in ('organize_table','play_stacking_toy','plug_in_charger','put_bottles_into_dustbin','classify_objects','pick_from_conveyor_by_image') else r.document(r.ref(source/'DISPATCH_001.json'))['split_manifest'],'settlement_ref':r.ref(source/'MAIN_SETTLEMENT_001.json'),'object_shifts_m':shifts}))