"""Read-only file-user exclusion, including at most three PID generations."""
import os
from pathlib import Path


def inspect_live(keys, proc=Path("/proc"), rounds=3):
    assert 1 <= rounds <= 3
    processes, errors, used, checked = [], [], [], set()

    def identity(path):
        values = (path / "stat").read_text().rsplit(")", 1)[1].split()
        return int(path.name), int(values[19])

    def discover():
        found = {}
        for path in proc.iterdir():
            if not path.name.isdigit():
                continue
            try:
                found[identity(path)] = path
            except FileNotFoundError:
                if path.exists():
                    errors.append(dict(pid=int(path.name), error="Live identity disappeared"))
            except (OSError, ValueError, IndexError) as error:
                errors.append(dict(pid=int(path.name), error_type=type(error).__name__))
        return found

    pending = discover()
    for _ in range(rounds):
        for ident, path in pending.items():
            if ident in checked:
                continue
            checked.add(ident)
            try:
                assert identity(path) == ident, "PID changed before inspection"
                status = (path / "status").read_text()
                row = dict(pid=ident[0], start_ticks=ident[1],
                           name=(path / "comm").read_text().strip(),
                           rss_kib=next((int(line.split()[1]) for line in status.splitlines()
                                         if line.startswith("VmRSS:")), 0),
                           cgroup=(path / "cgroup").read_text())
                for line in (path / "maps").read_text().splitlines():
                    fields = line.split(None, 5)
                    major, minor = (int(value, 16) for value in fields[3].split(":"))
                    key = (os.makedev(major, minor), int(fields[4]))
                    if key in keys:
                        used.append(dict(pid=ident[0], kind="mapped", key=list(key)))
                for fd in (path / "fd").iterdir():
                    try:
                        st = fd.stat()
                    except FileNotFoundError:
                        continue
                    if (st.st_dev, st.st_ino) in keys:
                        used.append(dict(pid=ident[0], kind="open",
                                         key=[st.st_dev, st.st_ino]))
                assert identity(path) == ident, "PID changed during inspection"
                processes.append(row)
            except FileNotFoundError:
                if path.exists():
                    errors.append(dict(pid=ident[0], error="Live process metadata disappeared"))
            except (OSError, ValueError, IndexError, AssertionError) as error:
                errors.append(dict(pid=ident[0], error_type=type(error).__name__,
                                   error=str(error)))
        pending = {key: value for key, value in discover().items() if key not in checked}
        if not pending or errors:
            break
    if pending:
        errors.append(dict(error="Uninspected live process generation",
                           identities=[list(key) for key in pending]))
    return processes, errors, used
