"""Matched teacher014 with only future optional web search disabled."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v14.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v14"', '"native_teacher_h20_v15"'),
    ('"collect_teacher_h20_v14"', '"collect_teacher_h20_v15"'),
    ('"prepare_teacher_h20_v14"', '"prepare_teacher_h20_v15"'),
    ('"_refate_h20_teacher_native_scope_v14"', '"_refate_h20_teacher_native_scope_v15"'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::future_optional_tool_config", "exec"), globals())

from teacher_web_search_disabled_h20_v1 import install
install(stage)
assert collection.native is preparation.native_shared_teacher is native

