"""Chat2 execution-host binding; original frozen source/data identities retained."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import types

D = Path('/data/refate_chat2_20261106_01a19072')
R = Path('/vla/mxk/projects/ReFATE/coordination/20261106_chat2_h20_01a19072')
PROJECT = R/'source_tree'
A = PROJECT/'coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026'
B = Path('/data/agent_rsi_validation_20261022_01a161cf')
NATIVE = D/'native'
POLICY_ENV = B/'data/dual_fate/chat1_01a16338/dm05/venv'
MODEL = B/'data/dual_fate/chat1_01a16338/dm05/assets/DM05-MEM-Robodojo-Sim'
OWNER = '01a19072-9e5e-7e02-b77a-8f115cfc9bd0'
UUIDS = ('GPU-d2150afd-372d-4c5f-de58-fb675e6ef7a9', 'GPU-b34ba2c2-7c64-ec8e-a6bd-83c10d3ff526')
sys.path.insert(0, str(A))


def need(value, message):
    if not value:
        raise ValueError(message)


def host():
    need(socket.gethostname() == '20250103-instance'
         and os.environ.get('REFATE_SSH_ALIAS') == 'h20_8'
         and os.environ.get('REFATE_EXECUTION_OWNER') == OWNER,
         'Exact h20_8/chat2 execution binding required')


def edit(text, old, new, count=1):
    need(text.count(old) == count, 'Migration source seam changed: '+old[:80])
    return text.replace(old, new)


def read_pin(ref):
    need(type(ref) is dict and set(ref) == {'path', 'sha256'}, 'Exact reference required')
    p = Path(ref['path'])
    need(p.is_absolute() and p.resolve(strict=True) == p
         and (p.is_relative_to(PROJECT) or p.is_relative_to(D)), 'Outside chat2 runtime/data roots')
    need(p.is_file() and 0 < p.stat().st_size <= 8*1024**2, 'Bounded metadata required')
    raw = p.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == ref['sha256'], 'Pinned metadata changed')
    return raw


def optix_metadata():
    host()
    path = Path('/usr/share/nvidia/nvoptix.bin')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    need(path.stat().st_size == 99616380 and digest ==
         '54aab7dcfa3b79b5c439cb4360294f2f5986781b4dc9b4dadf851997935ba931',
         'H20 native OptiX asset changed')
    return {'path': str(path), 'size': path.stat().st_size, 'sha256': digest,
            'binding': 'readonly', 'expected_host_driver_version': '555.42.06',
            'execution_proven_by_asset_presence': False}


def make_app(launcher, args):
    host()
    class BoundLauncher(launcher):
        def _create_app(self):
            self._sim_app_config.update(active_gpu=7, physics_gpu=1, multi_gpu=False)
            return super()._create_app()
    return BoundLauncher(args, multi_gpu=False, active_gpu=7, physics_gpu=1,
                         fast_shutdown=True, renderer='RaytracedLighting')


def memory_headroom(minimum_gib):
    need(minimum_gib == 120, 'Original120GiB admission required')
    mem = dict((line.split(':', 1)[0], int(line.split()[1])*1024)
               for line in Path('/proc/meminfo').read_text().splitlines()
               if line.startswith(('MemAvailable:', 'MemTotal:')))
    limits = [mem['MemAvailable']]
    rows = []
    cgroups = Path('/proc/self/cgroup').read_text().splitlines()
    for line in cgroups:
        _, controllers, rel = line.split(':', 2)
        if not controllers:
            base, usage_name, limit_name = Path('/sys/fs/cgroup'), 'memory.current', 'memory.max'
        elif 'memory' in controllers.split(','):
            base, usage_name, limit_name = Path('/sys/fs/cgroup/memory'), 'memory.usage_in_bytes', 'memory.limit_in_bytes'
        else:
            continue
        current = base/rel.lstrip('/')
        if not (current/usage_name).exists():
            current = base
        while current == base or current.is_relative_to(base):
            if (current/usage_name).is_file() and (current/limit_name).is_file():
                used = int((current/usage_name).read_text())
                raw = (current/limit_name).read_text().strip()
                limit = None if raw == 'max' else int(raw)
                rows.append({'path': str(current), 'usage_bytes': used, 'limit_bytes': limit})
                if limit is not None:
                    limits.append(limit-used)
            if current == base:
                break
            current = current.parent
    need(rows, 'No readable cgroup memory accounting')
    available = min(limits)
    need(available >= minimum_gib*1024**3, 'Insufficient H20 host/cgroup memory headroom')
    return {'available_bytes': available, 'minimum_free_gib': minimum_gib,
            'host': mem, 'cgroups': rows, 'inherited_wait_clocks_reset': False}


def policy_library_path():
    host()
    sites = [POLICY_ENV/'lib/python3.10/site-packages', Path('/vla/mxk/envs/fastwam/lib/python3.10/site-packages')]
    paths = [sites[0]/'torch/lib']
    components = set()
    for site in sites:
        for path in sorted((site/'nvidia').glob('*/lib')):
            if path.parent.name not in components:
                components.add(path.parent.name)
                paths.append(path)
    need('cuda_runtime' in components and all(p.is_dir() for p in paths), 'Matched CUDA wheel libraries missing')
    return ':'.join(map(str, paths))


def load_source(name, text):
    module = types.ModuleType(name)
    module.__file__ = str(D/'runtime'/(name+'.py'))
    exec(compile(text, module.__file__, 'exec'), module.__dict__)
    return module


def bootstrap():
    host()
    import isolation_stage as stage
    import common_runtime as runtime
    import execution_owner_binding_v1 as execution
    runtime.read_pin = read_pin
    original = Path(execution.__file__).read_bytes()
    text = original.decode()
    text = edit(text, '"nb-5pl2apckdj-0"', '"20250103-instance"')
    text = edit(text, '"perdon-hou"', '"h20_8"')
    function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == 'install')
    exec(compile(ast.Module(body=[function], type_ignores=[]), execution.__file__+'::h20_binding', 'exec'), execution.__dict__)
    execution.install()
    stage.SHARED = D/'teacher'
    import node_native as node
    node.NATIVE = NATIVE
    node.OFFLINE = NATIVE/'deployment/policy_eval_20260925/policy_episode.py'
    node.GPUS = UUIDS
    node._h20_make_app = make_app
    raw = Path(node.__file__).read_bytes()
    text = edit(raw.decode(), "os.environ.get('CUDA_VISIBLE_DEVICES') == '0,1'", "os.environ.get('CUDA_VISIBLE_DEVICES') == '1,7'")
    text = edit(text, "namespace = dict(module.__dict__, _node_adjust_config=_adjust_config, _node_prepare_native=_prepare_native)",
                "namespace = dict(module.__dict__, _node_adjust_config=_adjust_config, _node_prepare_native=_prepare_native, _h20_make_app=_h20_make_app)")
    function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == 'install')
    exec(compile(ast.Module(body=[function], type_ignores=[]), node.__file__+'::h20_binding', 'exec'), node.__dict__)
    import node_experience_binding as experience
    experience.EXPERIENCE = NATIVE/'third_party/IsaacLab/apps/isaaclab.python.headless.rendering.kit'
    experience.LAUNCHER = NATIVE/'third_party/IsaacLab/source/isaaclab/isaaclab/app/app_launcher.py'
    previous_creation = experience.creation_source
    def creation(raw):
        text = previous_creation(raw)
        return edit(text, 'self.app = AppLauncher(args, multi_gpu=False, active_gpu=1, physics_gpu=1, fast_shutdown=True, renderer="RaytracedLighting").app',
                    'self.app = _h20_make_app(AppLauncher, args).app')
    experience.creation_source = creation
    import source_sequence_binding as sequence
    sequence.NATIVE = NATIVE
    sequence.ASSETS = B/'assets/robodojo'
    import task_source_binding as metadata
    metadata.NATIVE = NATIVE
    import reader_binding
    reader_binding.PROJECT = D
    reader_binding.OWNER_CHAT = OWNER
    import common_recording as recording
    text = Path(recording.__file__).read_text()
    function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == 'initialize_recording')
    text = ast.get_source_segment(text, function)
    text = edit(text, "camera['renderer_settings']['/renderer/activeGpu'] == 1", "camera['renderer_settings']['/renderer/activeGpu'] == 7")
    text = text.replace('exclusively assigned GPU1', 'exclusively assigned physical GPU7')
    exec(compile(text, recording.__file__+'::h20_device_check', 'exec'), recording.__dict__)
    return stage, node


stage, node = bootstrap()
import collection_insert_sequence_content_v1 as original_wiring
text = original_wiring.source('baseline_native')
text = edit(text, '    from optix_binding import resolve_cached_binding, process_asset_metadata\n    optix=process_asset_metadata(resolve_cached_binding())',
            '    from h20_runtime_binding_v1 import optix_metadata\n    optix=optix_metadata()')
text = edit(text, "ready['alias']=='perdon-hou' and ready['hostname']=='nb-5pl2apckdj-0'", "ready['alias']=='h20_8' and ready['hostname']=='20250103-instance'")
text = edit(text, "ready['physical_gpu']==0", "ready['physical_gpu']==1")
text = edit(text, "'physics_gpu':1,'policy_gpu':0", "'physics_gpu':7,'policy_gpu':1,'physics_cuda_logical_device':1")
baseline_source = text
baseline_module = load_source('_refate_h20_baseline', text)


def allocation():
    host()
    assignments = {k:v for k,v in os.environ.items() if k.startswith(('SLURM_', 'PBS_', 'LSB_'))}
    for key in ('SLURM_STEP_GPUS', 'SLURM_JOB_GPUS'):
        if key in assignments:
            need({'1','7'}.issubset(set(assignments[key].split(','))), 'Scheduler does not allocate physical1/7')
    need(not any(k in assignments for k in ('PBS_JOBID','LSB_JOBID')),
         'Non-Slurm scheduler allocation requires explicit device verification')
    text = subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total,utilization.gpu','--format=csv,noheader,nounits'],text=True)
    rows = {int(row.split(',')[0]): [x.strip() for x in row.split(',')] for row in text.splitlines()}
    for physical, uuid, minimum in ((1,UUIDS[0],45000),(7,UUIDS[1],35000)):
        need(rows[physical][1] == uuid and int(rows[physical][2]) >= minimum, 'GPU UUID/headroom mismatch')
    processes = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True)
    return {'gpu_rows':text,'existing_processes':processes,'scheduler_environment':assignments,
            'authorized_physical_gpus':[1,7],'cuda_logical_to_physical':{'0':1,'1':7},
            'vulkan_requested_physical_gpu':7,'peer_processes_are_not_managed':True}


def environment(run, reference):
    host()
    base = {k:v for k,v in os.environ.items() if not k.startswith(('REFATE_','ROBODOJO_'))}
    runtime = run/'runtime'
    for name in ('home','tmp','cache','torch_extensions','kit','xdg'):
        (runtime/name).mkdir(parents=True,exist_ok=True)
    base.update(REFATE_SSH_ALIAS='h20_8',REFATE_EXECUTION_OWNER=OWNER,REFATE_RTX_OWNER_CHAT=OWNER,
        PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',PYTHONFAULTHANDLER='1',
        OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
        HOME=str(runtime/'home'),TMPDIR=str(runtime/'tmp'),XDG_CACHE_HOME=str(runtime/'cache'),
        XDG_RUNTIME_DIR=str(runtime/'xdg'),CUDA_DEVICE_ORDER='PCI_BUS_ID')
    policy = dict(base,CUDA_VISIBLE_DEVICES='1',LD_LIBRARY_PATH=policy_library_path(),
        HF_HOME=str(runtime/'cache/hf'),TRITON_CACHE_DIR=str(runtime/'cache/triton'),
        TORCHINDUCTOR_CACHE_DIR=str(runtime/'cache/inductor'),WANDB_MODE='offline',
        NO_ALBUMENTATIONS_UPDATE='1',PYTHONPATH=f'{D}/runtime/policy_deps:{NATIVE}:{NATIVE}/XPolicyLab')
    native = dict(base,CUDA_VISIBLE_DEVICES='1,7',NVIDIA_VISIBLE_DEVICES=','.join(UUIDS),
        LD_LIBRARY_PATH='/usr/local/nvidia/lib:/usr/local/nvidia/lib64',ROBODOJO_PHYSICAL_GPU='7',
        TORCH_EXTENSIONS_DIR=str(runtime/'torch_extensions'),VK_ICD_FILENAMES='/etc/vulkan/icd.d/nvidia_icd.json',
        OMNI_KIT_ACCEPT_EULA='YES',ACCEPT_EULA='Y',PYTHONNOUSERSITE='1',
        PYTHONPATH=f'{D}/runtime:{stage.UPSTREAM}:{A}:{NATIVE}:{NATIVE}/XPolicyLab:{NATIVE}/third_party/IsaacLab/source/isaaclab:{NATIVE}/third_party/IsaacLab/source/isaaclab_tasks:{NATIVE}/third_party/curobo',
        EMBODIEDEVO_ROBODOJO_KIT_ARGS=f'--portable-root {runtime}/kit --enable isaacsim.sensors.camera --enable isaacsim.replicator.behavior --/exts/omni.kit.renderer.core/autostartImGuiRenderer=false --/persistent/rtx/modes/rt/enabled=true --/persistent/rtx/modes/pt/enabled=true')
    return policy,native


text = original_wiring.source('foreground_common')
text = edit(text, 'from collection_insert_sequence_content_v1 import baseline_module as baseline\n',
            'from h20_runtime_binding_v1 import baseline_module as baseline\n')
text = edit(text, "node.stage.HERE/'baseline_insert_sequence_content_v1.py'", repr(str(D/'runtime/native_h20_v1.py')))
text = edit(text, "meta['physical_gpu']==0", "meta['physical_gpu']==1")
for filename, old in (('policy_h20_v1.py','88884fb9602858fd843828e0f6cf84244cfe8f2e8849a1731b57559bdf64f914'),
                      ('policy_h20_v1.yaml','be39b69053f47f04918bb21b22142238c03ccb4c5f3858b77d5329ecc433fb2d')):
    text = edit(text, old, hashlib.sha256((D/'runtime'/filename).read_bytes()).hexdigest())
foreground_source = text
foreground = load_source('_refate_h20_foreground', text)
foreground.host = host
foreground.allocation = allocation
foreground.environment = environment
foreground.POLICY = D/'runtime/policy_h20_v1.py'
foreground.CONFIG = D/'runtime/policy_h20_v1.yaml'
foreground.POLICY_PYTHON = POLICY_ENV/'bin/python'
foreground.NATIVE_PYTHON = B/'envs/native-thin/bin/python'
foreground.LOCK = D/'runtime/simulator.lock'
_original_helpers = foreground.helpers

def helpers():
    result = _original_helpers()
    result.memory_headroom = memory_headroom
    result.policy_library_path = policy_library_path
    return result

foreground.helpers = helpers
import finish_common_content_v1 as finish
text = finish._TEXT
text = edit(text, "os.environ.get('REFATE_SSH_ALIAS')=='perdon-hou' and socket.gethostname()=='nb-5pl2apckdj-0'",
            "os.environ.get('REFATE_SSH_ALIAS')=='h20_8' and socket.gethostname()=='20250103-instance'")
function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == 'settle')
exec(compile(ast.Module(body=[function],type_ignores=[]),str(D/'runtime/finish_h20_v1.py'),'exec'),finish.__dict__)


def h20_reader_source(raw):
    text = raw.decode() if isinstance(raw,bytes) else raw
    text = edit(text, 'os.uname().nodename == "nb-5pl2apckdj-0", "Only authorized perdon-hou node"',
                'os.uname().nodename == "20250103-instance" and os.environ.get("REFATE_SSH_ALIAS") == "h20_8", "Only authorized h20_8 chat2 execution node"', count=2)
    text = edit(text, 'PROJECT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")',
                'PROJECT = Path('+repr(str(D))+')')
    return text


import reader_binding as _reader
_text = h20_reader_source(Path(_reader.__file__).read_bytes())
for _name in ('load_baseline_reader','load_minimum_publish'):
    _function = next(n for n in ast.parse(_text).body if isinstance(n,ast.FunctionDef) and n.name == _name)
    exec(compile(ast.Module(body=[_function],type_ignores=[]),_reader.__file__+'::h20_host_binding','exec'),_reader.__dict__)
import reader_content_binding_v1 as _content_reader
_text = _content_reader.text
_text = edit(_text, 'exec(compile(BASE.read_bytes(), str(BASE), "exec"), base.__dict__)',
             'exec(compile(_h20_reader_source(BASE.read_bytes()), str(BASE)+"::h20_host_binding", "exec"), base.__dict__)')
_content_reader._h20_reader_source = h20_reader_source
_function = next(n for n in ast.parse(_text).body if isinstance(n,ast.FunctionDef) and n.name == 'load_baseline_reader')
exec(compile(ast.Module(body=[_function],type_ignores=[]),str(D/'runtime/reader_h20_v1.py'),'exec'),_content_reader.__dict__)
