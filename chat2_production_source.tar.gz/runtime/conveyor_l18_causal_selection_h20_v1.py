"""Reuse the saved Conveyor cutoff check for complete L18, without RGB decoding."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_l16_causal_selection_h20_v1.py")
text = path.read_text()
for old, new in (
    ("import h20_teacher_binding_v5 as binding",
     "import h20_teacher_binding_v14 as binding"),
    ("c2_pick_from_conveyor_by_image_l16_h20_baseline_0017_01a16807",
     "c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807"),
    ("pick_from_conveyor_by_image_b0_l16_b57ec8ad37fae639",
     "pick_from_conveyor_by_image_b0_l18_3fa06e4e9f91d205"),
    ('material["source_identity"]["layout_id"] == 16',
     'material["source_identity"]["layout_id"] == 18'),
    ("Saved ConveyorL16 only.", "Saved ConveyorL18 only."),
    ("CONVEYOR_L16_T10_CAUSAL_SELECTION_001.json",
     "CONVEYOR_L18_T10_CAUSAL_SELECTION_001.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::L18_source_metadata_only", "exec"), globals())
