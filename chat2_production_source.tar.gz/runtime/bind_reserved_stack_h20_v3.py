"""Existing context13 binder for Stack L7 on the matched baseline038."""
from bind_reserved_plug_h20_v3 import source as previous_source


def source():
    text = previous_source()
    old = "c2_plug_in_charger_l27_h20_baseline_0028_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_stack_blocks_by_language_l7_h20_baseline_0008_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Stack7_baseline038", "exec"), globals())
