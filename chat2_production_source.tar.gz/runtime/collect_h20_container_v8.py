"""Retain the diagnostic collector with the paired private metadata binding."""
from pathlib import Path

path = Path(__file__).with_name("collect_h20_container_v7.py")
text = path.read_text()
old = "import h20_container_binding_v6 as binding"
assert text.count(old) == 1
text = text.replace(old, "import h20_container_binding_v7 as binding")
exec(compile(text, str(path) + "::owned_insert_metadata", "exec"), globals())
