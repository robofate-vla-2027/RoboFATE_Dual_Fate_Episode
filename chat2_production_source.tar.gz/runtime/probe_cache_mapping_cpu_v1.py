"""CPU-only isolated mount reproduction; the mapped synthetic bytes are never run."""
import datetime
import json
import mmap
import os
from pathlib import Path
import tempfile

root = Path(os.environ["REFATE_CPU_OUTPUT"])
assert root.name == "CACHE_MAPPING_CPU_001"
assert os.environ.get("NVIDIA_VISIBLE_DEVICES") == "void"
result = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "data_kind": "synthetic_CPU_not_scientific_data",
          "model_calls": False, "gpu_calls": False, "simulator_calls": False,
          "network_calls": False, "mapped_bytes_executed": False, "paths": {}}
for directory in (Path("/tmp"), root):
    noexec = bool(os.statvfs(directory).f_flag & os.ST_NOEXEC)
    with tempfile.TemporaryFile(dir=directory) as stream:
        stream.write(b"\0" * mmap.PAGESIZE)
        stream.flush()
        error = None
        try:
            with mmap.mmap(stream.fileno(), mmap.PAGESIZE, flags=mmap.MAP_PRIVATE,
                           prot=mmap.PROT_READ | mmap.PROT_EXEC):
                pass
        except OSError as exc:
            error = {"type": type(exc).__name__, "errno": exc.errno, "message": str(exc)}
    result["paths"][str(directory)] = {"noexec": noexec, "mapping_passed": error is None,
                                       "error": error}
assert result["paths"]["/tmp"]["noexec"]
assert not result["paths"]["/tmp"]["mapping_passed"]
assert not result["paths"][str(root)]["noexec"]
assert result["paths"][str(root)]["mapping_passed"]
with (root / "RESULT.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
