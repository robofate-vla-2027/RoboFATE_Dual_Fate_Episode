"""Existing first metadata checks with only Sweep budget and release bindings."""
from pathlib import Path

path = Path(__file__).with_name("observe_swap_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_swap_T_l", "c2_sweep_blocks_l"),
    ('start["native_budget"] == 400', 'start["native_budget"] == 1000'),
    ("native_total=400", "native_total=1000"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_025.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Sweep1000_metadata_only", "exec"), globals())
