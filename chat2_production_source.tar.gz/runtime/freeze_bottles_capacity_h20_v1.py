"""Bind the proven zero-negative-slot metadata mode; runtime science unchanged."""
import datetime
import hashlib
import json
from pathlib import Path

import bind_h20_container_context_v11 as binder
import collect_h20_container_v10 as collector

b = collector.binding
b.previous.host()
assert collector.original.core.foreground is binder.collection.core.foreground is b.foreground
valid = binder.dispatch_slots_valid
proof = dict(negative_slots=0, collection_goal="positive_failure_source_after_negative_quota",
             quota_at_issue=dict(negative_count=10, negative_quota=10, positive_count=3, positive_quota=10))
assert valid(proof) and valid(dict(negative_slots=1))
assert not valid(dict(negative_slots=0)) and not valid(dict(negative_slots=True))
assert not valid(dict(proof, quota_at_issue=dict(negative_count=9, negative_quota=10, positive_count=3, positive_quota=10)))
prior = b.D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_015.json"
assert hashlib.sha256(prior.read_bytes()).hexdigest() == "63a183a825692bec45c0288676774ba28f6b2cefa1a8556ff3c345926eaa22a4"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


value = json.loads(prior.read_bytes())
pins = {pin["path"]: pin for pin in value["runtime_files"]}
for path in (b.D / "runtime/bind_h20_container_context_v11.py",
             b.D / "runtime/freeze_bottles_capacity_h20_v1.py",
             b.A / "bind_positive_gap_context_v1.py", b.A / "baseline_positive_gap_v1.py"):
    pins[str(path)] = ref(path)
value.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_capacity_release=ref(prior), runtime_files=list(pins.values()),
    context_builder=ref(b.D / "runtime/bind_h20_container_context_v11.py"),
    actual_adoption=False, actual_positive_published=False,
    capacity_cpu=dict(synthetic_cases=5, model_native_API_called=False),
    change_scope="Original zero-negative-slot positive-deficit dispatch binder only. "
                 "Baseline collector, Native, writer, reader, actions, physics, source, "
                 "teacher, 2400/3600-second limits and all quota values unchanged.")
output = b.D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_016.json"
with output.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
print(json.dumps({"baseline_release": ref(output), "actual_adoption": False,
                  "unchanged_collector": value["foreground_entry"]}))
