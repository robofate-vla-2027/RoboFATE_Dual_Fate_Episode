"""Matched existing teacher entries with the retained Bottles storage binding."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v6.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v6"', '"native_teacher_h20_v7"'),
    ('"collect_teacher_h20_v6"', '"collect_teacher_h20_v7"'),
    ('"prepare_teacher_h20_v6"', '"prepare_teacher_h20_v7"'),
    ('"_refate_h20_teacher_native_scope_v6"', '"_refate_h20_teacher_native_scope_v7"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::retained_bottles_storage", "exec"), globals())

from h20_bottles_metadata_storage_v1 import install_runtime
from h20_retained_bottles_storage_v1 import install
install_runtime()
import sys
install(sys.modules[__name__])
