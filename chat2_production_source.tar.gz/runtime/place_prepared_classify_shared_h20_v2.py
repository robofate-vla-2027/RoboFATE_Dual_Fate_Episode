"""Existing unstarted Classify metadata placement, restricted to L51."""
from pathlib import Path

path = Path(__file__).with_name("place_prepared_classify_shared_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_classify_objects_l(10)_h20_baseline_(0001)_01a16807",
     "c2_classify_objects_l(51)_h20_baseline_(0001)_01a16807"),
    ("int(match[1]) == 10 and int(match[2]) == 1",
     "int(match[1]) == 51 and int(match[2]) == 1"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Classify51_prepared_metadata_only", "exec"), globals())
