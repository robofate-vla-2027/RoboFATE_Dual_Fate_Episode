"""Use existing terminal/readback evidence through the Stack400 teacher."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_terminal_h20_v9.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v8") == 1
exec(compile(text.replace("h20_teacher_binding_v8", "h20_teacher_binding_v9"),
             str(path) + "::stack400", "exec"), globals())
