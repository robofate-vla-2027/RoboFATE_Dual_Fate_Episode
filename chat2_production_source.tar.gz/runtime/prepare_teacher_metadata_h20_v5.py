"""Retain genuine resource predecessor checks with release004."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v4.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_TEACHER_20261106_003.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_TEACHER_20261106_004.json")
old = 'exec(compile(text, str(path) + "::readonly_guest_python_release003", "exec"), globals())'
assert text.count(old) == 1
extra = '''
text = text.replace('"h20_teacher_binding_v3"', '"h20_teacher_binding_v4"')
text = text.replace('"collect_teacher_h20_v3.py"', '"collect_teacher_h20_v4.py"')
'''
text = text.replace(old, extra + "\n" + old)
exec(compile(text, str(path) + "::private_container_tmp", "exec"), globals())
