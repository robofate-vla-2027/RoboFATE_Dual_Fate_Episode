"""Original initial-source checks after the actually settled Stack L6 teacher."""
from stack_initial_inputs_h20_v1 import source as previous_source, teacher_checks


def source():
    text = previous_source()
    changes = (
        ('assert resource_run_id == "c2_sort_nesting_dolls_by_size_l27_h20_baseline_0028_01a16807"',
         'assert resource_run_id == "c2_stack_blocks_by_language_l6_evo_common_teacher_0001_01a16807"'),
        ('prior = host.D / "teacher/runs" / resource_run_id\nprior_settlement_ref = resource_ref',
         'prior = host.D / "teacher/runs/c2_stack_blocks_by_language_l6_h20_baseline_0007_01a16807"\n'
         'prior_settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")'),
        ('old["task"] == "sort_nesting_dolls_by_size" and old["layout_id"] == 27',
         'old["task"] == "stack_blocks_by_language" and old["layout_id"] == 6'),
        ('task = "stack_blocks_by_language"', 'task = "store_laptop_and_headphones"'),
        ('prepared["native_step_limit"] == 400', 'prepared["native_step_limit"] == 800'),
        ('"migration/STACK_L0_PREPARATION_CPU_001.json"',
         '"migration/LAPTOP_L0_PREPARATION_CPU_001.json"'),
        ("h20_container_binding_v9", "h20_container_binding_v10"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_017.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_023.json"),
        ('out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)',
         'out["initial_split"] = manifest\nout["initial_cpu"] = cpu\n'
         'out["laptop_cache_cpu_ref"] = release["laptop_cache_cpu"]\n'
         'out["laptop_cache_cpu"] = document(out["laptop_cache_cpu_ref"])\n'
         'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'),
    )
    for old, new in changes:
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::initial_laptop800_boundary", "exec"), globals())
