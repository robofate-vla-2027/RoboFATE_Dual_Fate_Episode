"""Same scoped saved-readback export through the matched teacher012 binding."""
from export_teacher011_settlement_metadata_h20_v2 import source as previous_source


def source():
    text = previous_source()
    assert text.count("h20_teacher_binding_v11") == 1
    return text.replace("h20_teacher_binding_v11", "h20_teacher_binding_v12", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::catalog012_export", "exec"), globals())
