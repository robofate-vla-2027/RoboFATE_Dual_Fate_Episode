"""Use an owner-private executable data directory; keep all frozen cache bytes."""
import mmap
import os
from pathlib import Path
import tempfile

from policy_cache_seed_h20_v1 import stage, verified_payloads


def check_mapping(directory):
    assert not directory.is_symlink()
    stat = os.statvfs(directory)
    assert not stat.f_flag & os.ST_NOEXEC, "Cache backing filesystem is noexec"
    assert stat.f_bavail * stat.f_frsize > 128 * 1024**2
    with tempfile.TemporaryFile(dir=directory) as stream:
        stream.write(b"\0" * mmap.PAGESIZE)
        stream.flush()
        with mmap.mmap(stream.fileno(), mmap.PAGESIZE, flags=mmap.MAP_PRIVATE,
                       prot=mmap.PROT_READ | mmap.PROT_EXEC):
            pass
    return {"file_executable_mapping_passed": True, "mapped_bytes_executed": False}


def source():
    text = Path(__file__).with_name("policy_cache_seed_h20_v1.py").read_text()
    start = text.index('    mounts = Path("/proc/self/mountinfo")')
    end = text.index('    roots = ', start)
    text = text[:start] + (
        '    from policy_cache_seed_h20_v2 import check_mapping\n'
        '    parent = D / "private_policy_compiled_cache"\n'
        '    parent.mkdir(mode=0o700, exist_ok=True)\n'
        '    assert not parent.is_symlink()\n'
        '    mapping = check_mapping(parent)\n'
    ) + text[end:]
    old = 'scratch = Path("/tmp") / ("refate-policy-cache-" + run.name)'
    assert text.count(old) == 1
    text = text.replace(old, 'scratch = parent / run.name', 1)
    old = '    result.update(\n'
    assert text.count(old) == 1
    return text.replace(old, '    result.update(cache_backing_directory=str(scratch), **mapping)\n' + old, 1)


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::private_data_directory", "exec"), namespace)
    return namespace["install"](run)
