"""Same matched content/RNG/readers; bounded policy and primary-error diagnostics."""
import hashlib
import h20_container_binding_v9 as _prior
from h20_container_binding_v9 import *

_text = edit(_prior._text, str(D / "runtime/native_h20_container_v7.py"),
             str(D / "runtime/native_h20_container_v8.py"))
_text = edit(_text, "28f8610c2f457d3ba46f14be20564f9a65efc3039aba21f91606e8f8f235fc89",
             hashlib.sha256((D / "runtime/policy_h20_container_v2.py").read_bytes()).hexdigest())
foreground = previous.load_source("_refate_h20_container_v10_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))
foreground.POLICY = D / "runtime/policy_h20_container_v2.py"

