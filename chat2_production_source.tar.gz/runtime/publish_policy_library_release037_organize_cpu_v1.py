"""Pending library-copy release, selecting the prepared Organize L26 entry."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("publish_policy_library_release037_cpu_v1.py").read_text()
    old = '''    prelaunch = d / "runtime/prelaunch_sweep_policy_cache_h20_v3.py"
    pin = next(p for p in release["runtime_files"] if p["path"] == str(prelaunch))
    assert ref(prelaunch) == pin'''
    new = '''    import prelaunch_organize_policy_cache_h20_v1 as previous_launch
    import prelaunch_organize_policy_cache_h20_v2 as next_launch
    previous_prelaunch = d / "runtime/prelaunch_organize_policy_cache_h20_v1.py"
    pin = next(p for p in release["runtime_files"] if p["path"] == str(previous_prelaunch))
    assert ref(previous_prelaunch) == pin
    prelaunch = d / "runtime/prelaunch_organize_policy_cache_h20_v2.py"
    old_run = "c2_organize_table_l25_h20_baseline_0026_01a16807"
    new_run = "c2_organize_table_l26_h20_baseline_0027_01a16807"
    assert next_launch.source() == previous_launch.source().replace(old_run, new_run, 1)
    compile(next_launch.source(), "offline_Organize26_entry", "exec")
    preparation = binding.A.parent / "preparations/ORGANIZE_L26_COMMON_PREPARATION_001.json"
    assert ref(preparation)["sha256"] == (
        "3ff33b6c5848b1a2f885c03d59be21220b92422058537cc0ebee9dbd370fc4fd")
    prepared = json.loads(preparation.read_bytes())
    assert prepared["native_step_limit"] == 1000
    assert prepared["source"]["layout_id"] == 26
    assert prepared["source"]["source_sequence"] == list(range(27))
    assert prepared["source"]["required_accounted_prefix"] == list(range(26))'''
    for before, after in (
        (old, new),
        ('        "publish_policy_library_release037_cpu_v1.py",',
         '        "publish_policy_library_release037_organize_cpu_v1.py",\n'
         '        "prelaunch_organize_policy_cache_h20_v2.py",'),
        ("baseline container and the existing Sweep prelaunch selection.",
         "baseline container and the original Organize prelaunch restricted to L26."),
    ):
        assert text.count(before) == 1, before
        text = text.replace(before, after, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Organize26_pending_library_copies", "exec"),
         globals())
