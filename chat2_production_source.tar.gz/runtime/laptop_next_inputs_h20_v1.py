"""Existing source-order and ended-resource checks for Laptop L1-L6."""
from stack_next_inputs_h20_v2 import source as previous_source, teacher_checks


def source():
    text = previous_source()
    for old, new, count in (
        ('task = "stack_blocks_by_language"', 'task = "store_laptop_and_headphones"', 1),
        ('prepared["native_step_limit"] == 400', 'prepared["native_step_limit"] == 800', 1),
        ("migration/STACK_L", "migration/LAPTOP_L", 1),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_022.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_023.json", 1),
        ("stack_cache_cpu", "laptop_cache_cpu", 4),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_laptop_source_boundary", "exec"), globals())
