"""The existing reversible metadata path rule, scoped to Bottles."""
from pathlib import Path

path = Path(__file__).with_name("h20_plug_metadata_storage_v1.py")
text = path.read_text()
for old, new, count in (
    ('TASK = "plug_in_charger"', 'TASK = "put_bottles_into_dustbin"', 1),
    ("_refate_plug_storage_v1", "_refate_bottles_storage_v1", 2),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::bottles_paths_only", "exec"), globals())
