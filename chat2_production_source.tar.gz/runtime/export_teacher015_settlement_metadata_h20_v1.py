"""Existing saved-readback export with the matched optional-tool binding."""
from export_teacher014_settlement_metadata_h20_v1 import source as previous_source


def source():
    text = previous_source()
    assert text.count("h20_teacher_binding_v14") == 1
    return text.replace("h20_teacher_binding_v14", "h20_teacher_binding_v15", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::optional_tool_binding", "exec"), globals())

