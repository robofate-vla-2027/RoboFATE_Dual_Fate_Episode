"""Existing Plug400 prelaunch restricted to the next L27 run."""
from prelaunch_plug_policy_cache_h20_v2 import source as previous_source


def source():
    text = previous_source()
    old = "c2_plug_in_charger_l26_h20_baseline_0027_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_plug_in_charger_l27_h20_baseline_0028_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Plug27_original_collector", "exec"), globals())
