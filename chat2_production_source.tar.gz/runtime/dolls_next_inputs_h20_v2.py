"""Accept a closed teacher resource predecessor without changing source order."""
from pathlib import Path


def teacher_checks(terminal, expected_run):
    assert terminal["schema"] == "refate.actual_terminal_observation.v1"
    assert terminal["data_kind"] == "actual"
    assert terminal["execution_owner"] == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
    assert terminal["run_id"] == expected_run
    assert terminal["safe_for_next_simulator"] is True
    checks = terminal["own_process_checks"]
    assert {"foreground", "native"} <= {row["role"] for row in checks}
    for row in checks:
        assert row["original_process_absent"] is True
        identity = row["identity"]
        pid = identity["pid"]
        assert type(pid) is int and pid > 0
        process = Path(f"/proc/{pid}/stat")
        if process.exists():
            fields = process.read_text().rsplit(")", 1)[1].split()
            boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
            assert (boot, int(fields[19])) != (identity["boot_id"], identity["start_ticks"])


def source():
    path = Path(__file__).with_name("dolls_next_inputs_h20_v1.py")
    text = path.read_text()
    old = 'assert re.fullmatch(r"c2_[a-z0-9_]+_h20_baseline_\\d{4}_01a16807", resource_run_id)'
    new = 'assert re.fullmatch(r"c2_[a-z0-9_]+_(?:h20_baseline|evo_common_teacher)_\\d{4}_01a16807", resource_run_id)'
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
    old = '''resource_ref = ref(host.D / "teacher/runs" / resource_run_id / "MAIN_SETTLEMENT_001.json")
terminal = document(resource_ref)
baseline_checks(terminal)
assert terminal["execution_owner"] == host.OWNER
assert terminal["safe_for_next_simulator"] and terminal["first_readback_passed"]'''
    new = '''is_teacher = "_evo_common_teacher_" in resource_run_id
resource_name = "MAIN_TERMINAL_OBSERVATION_001.json" if is_teacher else "MAIN_SETTLEMENT_001.json"
resource_ref = ref(host.D / "teacher/runs" / resource_run_id / resource_name)
terminal = document(resource_ref)
if is_teacher:
    teacher_checks(terminal, resource_run_id)
else:
    baseline_checks(terminal)
    assert terminal["first_readback_passed"]
assert terminal["execution_owner"] == host.OWNER
assert terminal["safe_for_next_simulator"]'''
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::teacher_resource_boundary", "exec"), globals())

