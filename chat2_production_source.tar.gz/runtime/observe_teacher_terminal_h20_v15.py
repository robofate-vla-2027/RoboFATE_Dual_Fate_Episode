"""Original terminal checks using the matched catalog012 source identity."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_terminal_h20_v13.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v10", "h20_teacher_binding_v12"),
    ("teacher_history_pre_actor_h20_v1", "teacher_history_pre_actor_catalog012_v1"),
):
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::catalog012_terminal", "exec"), globals())
