"""Original Native loop with initialization diagnostics before SDK closure."""
from pathlib import Path
import sys

import h20_container_binding_v2 as binding
import native_init_evidence_v1 as evidence

if __name__ == "__main__":
    context = Path(sys.argv[sys.argv.index("--context") + 1])
    evidence.install(binding.node, context.parent)
    raise SystemExit(binding.baseline_module.main())

