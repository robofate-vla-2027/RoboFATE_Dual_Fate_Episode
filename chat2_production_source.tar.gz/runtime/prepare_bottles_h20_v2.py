"""Reuse the frozen preparer for the next original Bottles source, L34."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_bottles_h20_v1.py").read_text()
    for old, new in (
        ("assert index == 33", "assert index == 34"),
        ("SPLIT_APPEND_L32_001.json", "SPLIT_APPEND_L33_001.json"),
        ("list(range(34))", "list(range(35))"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L34_same_preparer", "exec"), globals())
