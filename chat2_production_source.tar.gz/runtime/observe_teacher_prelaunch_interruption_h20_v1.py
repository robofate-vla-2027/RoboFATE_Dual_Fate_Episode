"""Record an exited owned container that failed before foreground or model start."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import datetime
import h20_teacher_binding_v3 as binding

binding.execution.previous.host()
run_id = sys.argv[1]
D = binding.execution.D
run = D / "teacher/runs" / run_id
records = D / "container_records" / run_id


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


context_ref = ref(run / "CONTEXT_001.json")
c = binding.preparation.restore.document(context_ref)
assert c["run_id"] == run_id and c["execution_owner"] == binding.execution.OWNER
cid = (records / "container.cid").read_text().strip()
inspect = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
assert inspect["Id"] == cid
labels = inspect["Config"]["Labels"]
assert labels["refate.owner"] == binding.execution.OWNER
assert labels["refate.role"] == "chat2" and labels["refate.run"] == run_id
assert not inspect["State"]["Running"] and inspect["State"]["Pid"] == 0
assert inspect["State"]["ExitCode"] == 1 and (records / "exit").read_text().strip() == "1"
assert not any(v.startswith("MODEL_UPSTREAM=") for v in inspect["Config"]["Env"])
absent = [run / name for name in (
    "foreground_started.json", "native_started.json", "owned_native.json",
    "ready.json", "result.json", "dense", "initial", "process_cleanup.json")]
session = Path(c["runtime_binding"]["run_dir"])
absent.extend(session / name for name in ("agent", "runtime"))
assert all(not p.exists() for p in absent)
summary_ref = ref(run / "teacher_readback_001/SUMMARY.json")
summary = binding.preparation.restore.document(summary_ref)
assert summary["run_id"] == run_id and summary["source_id"] == c["source_id"]
assert summary["native_result"] is None and summary["qualified_positive"] is False
assert summary["new_positive"] == summary["new_negative"] == 0
assert summary["complete_positive_reader_run"] is False
console = (records / "console.log").read_text()
assert '"message": "Existing authorized model route required"' in console
launcher = json.loads((records / "host_admission.json").read_bytes())
stat = Path(f"/proc/{launcher['pid']}/stat")
same = stat.exists() and (
    Path("/proc/sys/kernel/random/boot_id").read_text().strip() == launcher["boot_id"]
    and int(stat.read_text().rsplit(")", 1)[1].split()[19]) == launcher["launcher_start_ticks"])
assert not same
value = {
    "schema": "refate.teacher_prelaunch_interruption.v1", "data_kind": "actual",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": binding.execution.OWNER, "run_id": run_id,
    "source_id": c["source_id"], "task": c["task"], "context": context_ref,
    "summary_ref": summary_ref, "summary": summary,
    "container_id": cid, "container_created": inspect["Created"],
    "container_finished": inspect["State"]["FinishedAt"],
    "container_state": inspect["State"], "labels": labels,
    "launcher_original_process_absent": True, "launcher_admission": ref(records / "host_admission.json"),
    "console_ref": ref(records / "console.log"), "actual_tool_returncode": 1,
    "failure": "Existing authorized model route required",
    "confirmed_cause": "MODEL_UPSTREAM was omitted from this launch environment.",
    "provider_safety_refusal": False, "model_or_api_called": False,
    "native_started": False, "foreground_started": False,
    "safe_for_next_simulator": True, "absent_paths": [str(p) for p in absent],
    "new_positive": 0, "new_negative": 0,
}
path = run / "MAIN_PRELAUNCH_INTERRUPTION_001.json"
with path.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
value["evidence_ref"] = ref(path)
documents = []
for pin in (context_ref, summary_ref):
    raw = binding.storage.runtime.read_pin(pin)
    documents.append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
safety = session / "agent/provider_safety.json"
assert not safety.exists()
metadata = {"run_id": run_id, "context": context_ref, "documents": documents,
            "absent_paths": value["absent_paths"] + [str(safety)]}
with (run / "PRELAUNCH_ACCOUNTING_METADATA_001.json").open("x") as stream:
    json.dump(metadata, stream, indent=2)
    stream.write("\n")
print(json.dumps(value))

