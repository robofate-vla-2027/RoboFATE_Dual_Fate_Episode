"""Same terminal checks, including the pre-model case, through teacher011."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_terminal_h20_v13.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v10") == 1
exec(compile(text.replace("h20_teacher_binding_v10", "h20_teacher_binding_v11"),
             str(path) + "::causal_history_binding", "exec"), globals())
