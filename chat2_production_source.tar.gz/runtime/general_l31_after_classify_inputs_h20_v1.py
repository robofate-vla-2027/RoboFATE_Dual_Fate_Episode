"""Original General boundary export for L31 after its actual Classify teacher."""
from general_next_inputs_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("assert index == 26", "assert index == 31"),
        ("c2_classify_objects_l32_evo_common_teacher_0001_01a16807",
         "c2_classify_objects_l10_evo_common_teacher_0001_01a16807"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_017.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261108_032.json"),
        ('release = json.loads(release_path.read_bytes())',
         'assert ref(release_path)["sha256"] == '
         '"c4171b83beecc40612493067e660450bf7e2c9a4cd2c0b7c6bf66cd9d035b544"\n'
         'release = json.loads(release_path.read_bytes())'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General31_after_Classify10", "exec"), globals())
