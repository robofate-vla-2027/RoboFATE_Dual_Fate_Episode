"""Reuse original CPU source preparation for the native800 laptop task."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("prepare_stack_initial_h20_v1.py")
    text = path.read_text()
    for old, new in (
        ('TASK = "stack_blocks_by_language"', 'TASK = "store_laptop_and_headphones"'),
        ("STACK_L0_PREPARATION_CPU_001.json", "LAPTOP_L0_PREPARATION_CPU_001.json"),
        ("configured.source_module(TASK, 400, task_ref)",
         "configured.source_module(TASK, 800, task_ref)"),
        ("module.task_budget(TASK)[0] == 400", "module.task_budget(TASK)[0] == 800"),
        ('"native_budget": 400', '"native_budget": 800'),
        ("native_total=400", "native_total=800"),
        ('"native_total": 400', '"native_total": 800'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_laptop800_preparation", "exec"), globals())
