"""Original Native action loop with explicit h20_8 storage/device binding."""
import h20_runtime_binding_v1 as binding
if __name__ == '__main__':
    raise SystemExit(binding.baseline_module.main())
