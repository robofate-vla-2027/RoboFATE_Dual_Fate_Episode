"""Original frozen Classify preparation through the currently deployed catalog."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_classify_h20_v1.py").read_text()
    old = "import h20_container_binding_v9 as execution"
    assert text.count(old) == 1
    return text.replace(
        old, "import h20_teacher_binding_v14 as runtime\nexecution = runtime.execution", 1
    )


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::matched_catalog014_metadata_only", "exec"), globals())
