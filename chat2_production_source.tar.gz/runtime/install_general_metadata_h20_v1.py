"""Install the six byte-identical General metadata files through the same guard."""
from pathlib import Path

path = Path(__file__).with_name("install_insert_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("insert_metadata_batch_011.manifest.json", "general_metadata_batch_014.manifest.json"),
    ("assert len(manifest) == 4", "assert len(manifest) == 6"),
    ("INSERT_METADATA_VERIFICATION_001.json", "GENERAL_METADATA_VERIFICATION_001.json"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::general_six_metadata_files", "exec"), globals())
