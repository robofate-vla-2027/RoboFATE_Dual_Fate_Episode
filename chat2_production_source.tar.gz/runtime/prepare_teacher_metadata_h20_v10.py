"""Same metadata workflow, adding Stack's tag and matched task catalog only."""
from pathlib import Path
import h20_teacher_binding_v9
import teacher_prepare_metadata_handoff_v6 as original

_source = original.source


def stack_source():
    text = _source()
    assert text.count("from teacher_catalog_binding_v13 import") == 1
    text = text.replace("from teacher_catalog_binding_v13 import",
                        "from teacher_catalog_stack_h20_v1 import", 1)
    old = "'fasten_screws':'FASTEN'}"
    assert text.count(old) == 1
    return text.replace(old, "'fasten_screws':'FASTEN','stack_blocks_by_language':'STACK'}", 1)


original.source = stack_source
path = Path(__file__).with_name("prepare_teacher_metadata_h20_v9.py")
text = path.read_text()
for old, new in (
    ("RUNTIME_H20_CHAT2_TEACHER_20261107_008.json",
     "RUNTIME_H20_CHAT2_TEACHER_20261107_009.json"),
    ("h20_teacher_binding_v8", "h20_teacher_binding_v9"),
    ("collect_teacher_h20_v8.py", "collect_teacher_h20_v9.py"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::stack400_metadata", "exec"), globals())
