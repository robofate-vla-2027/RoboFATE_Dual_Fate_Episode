"""Original General L26 boundary metadata after the settled Classify teacher."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("general_next_inputs_h20_v1.py").read_text()
    for old, new in (
        ("from closed_baseline_resource_v1 import baseline_checks",
         "from dolls_next_inputs_h20_v2 import teacher_checks"),
        ("assert 25 <= index < 53", "assert index == 26"),
        ('assert re.fullmatch(r"c2_[a-z0-9_]+_h20_baseline_\\d{4}_01a16807", resource_run_id)',
         'assert resource_run_id == "c2_classify_objects_l32_evo_common_teacher_0001_01a16807"'),
        ('resource_run_id / "MAIN_SETTLEMENT_001.json"',
         'resource_run_id / "MAIN_TERMINAL_OBSERVATION_001.json"'),
        ('baseline_checks(terminal)\nassert terminal["execution_owner"] == host.OWNER\n'
         'assert terminal["safe_for_next_simulator"] and terminal["first_readback_passed"]',
         'teacher_checks(terminal, resource_run_id)\n'
         'assert terminal["execution_owner"] == host.OWNER'),
        ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General26_after_Classify_teacher", "exec"), globals())
