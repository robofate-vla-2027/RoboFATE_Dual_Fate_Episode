"""Use the same saved-readback observer with the active Conveyor-aware entry."""
from pathlib import Path

path = Path(__file__).with_name("observe_h20_baseline_terminal_v1.py")
text = path.read_text()
old = "import collect_h20_container_v4 as collection"
assert text.count(old) == 1
text = text.replace(old, "import collect_h20_container_v5 as collection")
exec(compile(text, str(path) + "::matching_v5_collector", "exec"), globals())
