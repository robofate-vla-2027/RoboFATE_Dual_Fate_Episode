"""Original General27 preparation, with the actual closed Classify resource predecessor."""
from general_next_inputs_h20_v3 import source as previous_source


def call_timeout_checks(terminal):
    assert terminal["schema"] == "refate.actual_interrupted_baseline.v1"
    assert terminal["run_id"] == "c2_classify_objects_l28_h20_baseline_0001_01a16807"
    assert terminal["policy_model_ready"] and terminal["safe_for_next_simulator"]
    assert terminal["source_started"] is True and terminal["source_retry_allowed"] is False
    assert terminal["native_terminal"] is terminal["native_success"] is False
    assert terminal["last_actual_executed_tick"] == 0
    assert terminal["observations_committed"] == 1 and terminal["full_readback_passed"] is False
    assert terminal["new_positive"] == terminal["new_negative"] == 0


def source():
    text = previous_source()
    for old, new in (
        ("assert 27 <= index < 53", "assert index == 27"),
        ('resource_run_id / "MAIN_SETTLEMENT_001.json"',
         'resource_run_id / "MAIN_INTERRUPTION_SETTLEMENT_002.json"'),
        ("baseline_checks(terminal)", "call_timeout_checks(terminal)"),
        ('terminal["safe_for_next_simulator"] and terminal["first_readback_passed"]',
         'terminal["safe_for_next_simulator"] and not terminal["full_readback_passed"]'),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_017.json", "RUNTIME_H20_CHAT2_CONTENT_20261107_019.json"),
        ('out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)',
         'out["call_diagnostic_cpu_ref"] = release["cpu_check"]\n'
         'out["call_diagnostic_cpu"] = document(out["call_diagnostic_cpu_ref"])\n'
         'library = host.D / "migration/TRITON_LIBRARY_READ_20261107_001.json"\n'
         'out["library_read_ref"] = ref(library)\n'
         'out["library_read"] = document(out["library_read_ref"])\n'
         'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::closed_Classify_to_General27", "exec"), globals())

