"""Reuse the frozen initial-sequence preparer for SwapT's original400 steps."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_stack_existing_h20_v1.py").read_text()
    for old, new in (
        ('task = "stack_blocks_by_language"', 'task = "swap_T"'),
        ("migration/STACK_L", "migration/SWAP_L"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_swap_initial_sequence", "exec"), globals())
