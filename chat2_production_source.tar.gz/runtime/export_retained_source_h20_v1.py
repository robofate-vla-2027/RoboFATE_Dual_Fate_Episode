"""Read only the four pinned metadata records of a retained complete source."""
import base64
import json
from pathlib import Path
import sys
import h20_teacher_binding_v3 as binding

binding.execution.previous.host()
retained = json.load(sys.stdin)
documents = []
decoded = {}
for key in ("context", "manifest", "settlement", "readback"):
    pin = retained[key]
    assert Path(pin["path"]).is_relative_to(binding.execution.D / "teacher/runs")
    raw = binding.storage.runtime.read_pin(pin)
    documents.append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
    decoded[key] = json.loads(raw)
assert all(value["source_id"] == retained["source_id"] for value in decoded.values())
assert decoded["readback"]["file_recording_readback_passed"] is True
assert decoded["readback"]["native_success"] is False
assert decoded["settlement"]["safe_for_next_simulator"] is True
print(json.dumps({"retained": retained, "documents": documents,
                  "RGB_decoded": False, "source_replayed": False, "model_or_API_called": False}))

