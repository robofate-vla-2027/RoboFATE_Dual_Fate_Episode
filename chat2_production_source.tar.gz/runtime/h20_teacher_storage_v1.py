"""Map frozen chat2 teacher dependencies to their verified H20 storage copies."""
import ast
from pathlib import Path
import sys
import types

import h20_container_binding_v3 as execution
import common_runtime as runtime

ORIGINAL_ROOT = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")
PROJECT = execution.previous.PROJECT
_read_pin = runtime.read_pin
mapped_pins = []


def read_pin(ref):
    path = Path(ref["path"])
    if path.is_relative_to(ORIGINAL_ROOT):
        mapped = {"path": str(PROJECT / path.relative_to(ORIGINAL_ROOT)),
                  "sha256": ref["sha256"]}
        raw = _read_pin(mapped)
        mapped_pins.append({"historical": ref, "execution": mapped})
        return raw
    return _read_pin(ref)


runtime.read_pin = read_pin
runtime.ROOT = execution.D
text = Path(runtime.__file__).read_text()
text = execution.edit(
    text, "[str(stage.UPSTREAM), '/vla/mxk/projects/Robodojo', str(stage.HERE)]",
    "[str(stage.UPSTREAM), " + repr(str(execution.NATIVE)) + ", str(stage.HERE)]",
)
function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == "install")
exec(compile(ast.Module(body=[function], type_ignores=[]), __file__ + "::runtime_native_path", "exec"),
     runtime.__dict__)

path = execution.A / "teacher_append_source_binding.py"
text = execution.edit(path.read_text(), "row['path']==str(HERE/filename)",
                      "row['path']==str(_historical_here/filename)")
module = types.ModuleType("teacher_append_source_binding")
module.__file__ = str(path)
module._historical_here = ORIGINAL_ROOT / execution.A.relative_to(PROJECT)
sys.modules[module.__name__] = module
exec(compile(text, str(path) + "::historical_release_identity", "exec"), module.__dict__)

import teacher_catalog_binding_v13
import native_teacher_content_v6
import collect_teacher_content_v6
import prepare_teacher_content_v6
import shared_dependency_binding
import shared_dependency_content_v1

for dependency in (shared_dependency_binding, shared_dependency_content_v1):
    dependency.SUPPLEMENT = execution.A.parent / "reference_chat1_dependency_supplement_20261026"
