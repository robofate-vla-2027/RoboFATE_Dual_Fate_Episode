"""Original private disposable cache placement, restricted to General L26."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prelaunch_kit_cache_tmpfs_v1.py").read_text()
    for old, new in (
        (r"c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807",
         r"c2_general_pickup_l26_h20_baseline_0001_01a16807"),
        ('value["native_total_steps"] == 400', 'value["native_total_steps"] == 200'),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General200_same_cache", "exec"), globals())
