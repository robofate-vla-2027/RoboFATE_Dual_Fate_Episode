"""Restore the original RTX copy layer and bind missing userspace dispatchers."""
import h20_container_binding_v1 as _container
from h20_container_binding_v1 import *


def environment(run, reference):
    policy, native = _container.environment(run, reference)
    native.update(
        LD_LIBRARY_PATH=str(D / "runtime/system_libs") + ":" + native["LD_LIBRARY_PATH"],
        VK_LAYER_PATH=str(D / "runtime/rtx_copy_lifecycle_h20_v1"),
        VK_INSTANCE_LAYERS="VK_LAYER_REFATE_image_copy_staging",
        REFATE_VK_COPY_MODE="stage",
        REFATE_VK_COPY_LOG=str(run / "copy_layer.log"),
        OMNI_VULKAN_ENV_SKIP="0",
    )
    return policy, native


foreground.environment = environment
_text = _container._text

