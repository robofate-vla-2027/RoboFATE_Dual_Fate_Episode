"""Freeze read-only diagnostics, not a claim that the allocator fault is fixed."""
import datetime
import hashlib
import json
from pathlib import Path

import test_memory_diagnostics_cpu_v1
import collect_h20_container_v7 as collector
import bind_h20_container_context_v7 as binder

binding = collector.binding
D, A = binding.D, binding.A
assert collector.original.core.foreground is binding.foreground
assert binder.collection.core.foreground is binding.foreground
prepared_path = A.parent / "preparations/CONVEYOR_L15_COMMON_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
binding.foreground.baseline.source_sequence_binding.load_native_layout(prepared)
assert prepared["native_step_limit"] == 700
assert "native_h20_container_v4.py" in binding._text


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/MEMORY_DIAGNOSTICS_CPU_001.json", {
    "schema": "refate.readonly_memory_diagnostics_cpu.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "synthetic_v1_v2_readonly_tests_passed": True,
    "matched_collector_native_binder_verified": True,
    "existing_conveyor_l15_validator_passed": True,
    "real_model_api_native_calls": False, "scientific_samples": 0,
    "allocation_failure_fixed": False,
})
prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_011.json"
release = json.loads(prior.read_bytes())
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    foreground_entry=str(D / "runtime/collect_h20_container_v7.py"),
    context_builder=ref(D / "runtime/bind_h20_container_context_v7.py"),
    prior_migration_release=ref(prior), cpu_check=cpu, actual_adoption=False,
    binding_fix="Read-only before/after container memory counters added to matched "
                "v6 Native/storage binding. No cache reclamation, limit changes, "
                "renderer changes or qualification changes. Allocator cause unresolved.",
)
files = {row["path"]: row for row in release["runtime_files"]}
for name in ("collect_h20_container_v7.py", "bind_h20_container_context_v7.py",
             "memory_diagnostics_h20_v1.py", "test_memory_diagnostics_cpu_v1.py",
             "freeze_memory_diagnostics_h20_v1.py"):
    row = ref(D / "runtime" / name)
    files[row["path"]] = row
release["runtime_files"] = list(files.values())
print(json.dumps({"release": save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_012.json", release),
                  "cpu_check": cpu, "allocation_failure_fixed": False}))
