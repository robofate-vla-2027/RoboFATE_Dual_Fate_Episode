"""Address-only binding of the existing General source-sequence preparer."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_container_binding_v7 as execution
from h20_insert_private_metadata_v1 import metadata_locations
import prepare_general_append_handoff_v1 as original

execution.previous.host()
legacy = original.legacy
legacy.ROOT = execution.A.parents[2]
legacy.ADAPTER = execution.A
legacy.ORIGINAL = metadata_locations(legacy.ORIGINAL)

import general_prefix_handoff_v1 as prefix

prefix.ROOT = legacy.ROOT
read_original_document = prefix.document


def document(reference):
    value = read_original_document(reference)
    assert isinstance(value, dict) and str(value.get("schema", "")).startswith("refate.")
    return metadata_locations(value)


prefix.document = document


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    layout = int(sys.argv[1])
    assert 25 <= layout < 53
    directory = execution.A / "task_sources/general_pickup"
    prior = directory / f"SPLIT_LEGACY_APPEND_L{layout - 1}_001.json"
    request = {"execution_owner": execution.OWNER, "layout": layout,
               "prior_manifest": ref(prior)}
    captured = io.StringIO()
    sys.stdin = io.StringIO(json.dumps(request))
    with contextlib.redirect_stdout(captured):
        original.main()
    result = json.loads(captured.getvalue())
    prepared = json.loads(Path(result["preparation_ref"]["path"]).read_bytes())
    import task_configured_binding as configured
    raw_layout = configured.load_native_layout(prepared)
    assert configured.previous.base.original.same(
        raw_layout,
        json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes()))
    receipt = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "data_kind": "actual_metadata_CPU_only",
        "execution_owner": execution.OWNER,
        "preparation": result,
        "execution_binding": ref(Path(__file__)),
        "original_helper": ref(Path(original.__file__)),
        "actual_configured_loader_passed": True,
        "raw_layout_unchanged": True,
        "original_manifest_unchanged": ref(Path(legacy.ORIGINAL["path"])) == legacy.ORIGINAL,
        "sealed_content_read": False,
        "native_model_API_calls": False,
        "source_registered": False, "source_reserved": False, "source_launched": False,
    }
    assert receipt["original_manifest_unchanged"]
    path = execution.D / f"migration/GENERAL_L{layout}_PREPARATION_CPU_001.json"
    with path.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"preparation": result, "CPU_receipt": ref(path)}))


if __name__ == "__main__":
    main()
