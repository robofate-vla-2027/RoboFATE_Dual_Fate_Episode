"""Reuse the frozen initial-sequence preparer for Laptop's original800 steps."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("prepare_stack_existing_h20_v1.py")
    text = path.read_text()
    for old, new, count in (
        ('task = "stack_blocks_by_language"', 'task = "store_laptop_and_headphones"', 1),
        ('prior["native_step_limit"] == 400', 'prior["native_step_limit"] == 800', 1),
        ("native_total=400", "native_total=800", 1),
        ('"native_total": 400', '"native_total": 800', 1),
        ("migration/STACK_L", "migration/LAPTOP_L", 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_laptop_initial_sequence", "exec"), globals())
