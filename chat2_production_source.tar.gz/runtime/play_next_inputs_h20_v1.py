"""Use the release013 loader and existing resource checks for ordered Play."""
from pathlib import Path

path = Path(__file__).with_name("organize_next_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ('23 <= index < 53', '17 <= index < 53'),
    ('binding.A.parent / f"preparations/ORGANIZE_L{index}_COMMON_PREPARATION_001.json"',
     'binding.A / f"task_sources/play_stacking_toy/PREPARATION_L{index}_COLLECTION_GROUP_001.json"'),
    ('organize_table', 'play_stacking_toy'),
    ('prepared["native_step_limit"] == 1000', 'prepared["native_step_limit"] == 1200'),
    ('"native_total": 1000', '"native_total": 1200'),
    ('ORGANIZE_L{index}_PREPARATION_CPU_001.json',
     'PLAY_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json'),
):
    assert old in text
    text = text.replace(old, new)
seam = 'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'
assert text.count(seam) == 1
text = text.replace(seam, '''
parent_ref = manifest["source_sequence_extension"]["parent_manifest"]
out["prior_manifest_ref"] = parent_ref
out["prior_manifest"] = json.loads(host.read_pin(parent_ref))
storage_path = host.D / "migration/PLAY_L16_STORAGE_BINDING_001.json"
out["storage_binding_ref"] = ref(storage_path)
out["storage_binding"] = json.loads(storage_path.read_bytes())
assert out["storage_binding"]["inverse_mapping_equals_original"]
''' + seam)
exec(compile(text, str(path) + "::play_original_boundary", "exec"), globals())

