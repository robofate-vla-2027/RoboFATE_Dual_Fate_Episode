"""Bounded foreground wait for the existing actual-start observer; no runtime control."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time

import h20_runtime_binding_v1 as binding

binding.host()
run_id, tool_session = sys.argv[1], int(sys.argv[2])
assert re.fullmatch(r"c2_[a-z0-9_]+_h20_baseline_\d{4}_01a16807", run_id)
run = binding.D / "teacher/runs" / run_id
started = time.monotonic()
names = ("server/model_ready.json", "native_started.json", "owned_native.json", "owned_policy.json")
while not all((run / name).exists() for name in names):
    if (run / "process_cleanup.json").exists() or (run / "foreground_error.json").exists():
        raise RuntimeError("Run closed before full start evidence; inspect original outcome")
    if time.monotonic() - started > 1050:
        raise TimeoutError("Observation bound reached; no collection/model budget was changed")
    time.sleep(10)
subprocess.run(
    [sys.executable, "-B", str(binding.D / "runtime/observe_h20_baseline_start_v1.py")],
    input=json.dumps(dict(run_id=run_id, tool_session=tool_session)), text=True, check=True)

