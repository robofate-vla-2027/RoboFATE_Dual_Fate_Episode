"""Address-only binding of the saved Dolls preparer; registration is forbidden."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_container_binding_v7 as execution
from h20_insert_private_metadata_v1 import metadata_locations
import dolls_append_handoff_v1 as original

execution.previous.host()
old_root = str(original.ROOT)
original.ROOT = execution.A.parent
original.ADAPTER = execution.A
original.ARCHIVE = original.ROOT / original.ARCHIVE.relative_to(Path(old_root))
sys.path.insert(0, str(original.ROOT / "preparations"))
import dolls_source_registration_20261030 as registration

registration.ROOT = execution.A / "task_sources/sort_nesting_dolls_by_size"
registration.NATIVE = execution.NATIVE
registration.BASE = metadata_locations(registration.BASE)
read_original_document = registration.document


def document(reference):
    return metadata_locations(read_original_document(metadata_locations(reference)))


registration.document = document
archived_script = original.script


def prepare_script(mode, archive):
    assert mode == "prepare", "Ledger registration runs only on the Mac"
    text = archived_script(mode, archive)
    assert text.count(old_root) == 1
    return text.replace(old_root, str(original.ROOT))


original.script = prepare_script


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    index = int(sys.argv[1])
    assert 15 <= index < 28
    prior = registration.ROOT / f"SPLIT_APPEND_L{index - 1}_001.json"
    args = {
        "execution_owner": execution.OWNER, "operation": "prepare", "layout": index,
        "prior_manifest": ref(prior),
        "cpu_receipt": ref(original.ROOT / "preparations/DOLLS_SOURCE_REGISTRATION_CPU_001.json"),
    }
    captured = io.StringIO()
    sys.stdin = io.StringIO(json.dumps(args))
    with contextlib.redirect_stdout(captured):
        original.main()
    result = json.loads(captured.getvalue())
    prepared = json.loads(Path(result["preparation_ref"]["path"]).read_bytes())
    import task_configured_binding as configured
    raw = configured.load_native_layout(prepared)
    assert configured.previous.base.original.same(
        raw, json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes()))
    manifest = registration.lineage(result["append_manifest"])
    assert manifest["original_partition"]["reserved_final"] == [28, 29]
    receipt = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "data_kind": "actual_metadata_CPU_only",
        "execution_owner": execution.OWNER, "preparation": result,
        "execution_binding": ref(Path(__file__)),
        "original_preparer": ref(Path(original.__file__)),
        "original_registration_helper": ref(Path(registration.__file__)),
        "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
        "source_sequence": manifest["initial_source_sequence"],
        "sealed_layouts": [28, 29], "sealed_content_read": False,
        "native_model_API_calls": False,
        "registered": False, "reserved": False, "launched": False,
    }
    path = execution.D / f"migration/DOLLS_L{index}_PREPARATION_CPU_001.json"
    with path.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"preparation": result, "CPU_receipt": ref(path)}))
