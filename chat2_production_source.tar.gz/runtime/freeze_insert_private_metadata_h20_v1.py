"""Freeze matched future entries; do not adopt them for the in-flight source."""
import datetime
import hashlib
import json
from pathlib import Path

import collect_h20_container_v8 as collector
import bind_h20_container_context_v8 as binder

binding = collector.binding
D, A = binding.D, binding.A
sequence = binding.private_insert_metadata.sequence
assert sequence._read._refate_owned_insert_metadata
assert collector.original.core.foreground is binding.foreground
assert binder.collection.core.foreground is binding.foreground
assert "native_h20_container_v5.py" in binding._text
prepared_path = A.parent / "preparations/INSERT_L44_COMMON_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
sequence.load_native_layout(prepared)
assert prepared["native_step_limit"] == 500
assert prepared["source"]["source_sequence"] == list(range(45))


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/INSERT_PRIVATE_METADATA_ENTRY_CPU_001.json", {
    "schema": "refate.owned_insert_metadata_cpu.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "existing_L43_entry_changed": False, "new_L44_original_validator_passed": True,
    "matched_future_collector_native_binder": True,
    "original_hash_size_regular_file_canonical_path_checks_retained": True,
    "real_model_api_native_calls": False, "scientific_samples": 0,
    "preparation": ref(prepared_path),
})
prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_012.json"
release = json.loads(prior.read_bytes())
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    foreground_entry=str(D / "runtime/collect_h20_container_v8.py"),
    native_entry=str(D / "runtime/native_h20_container_v5.py"),
    context_builder=ref(D / "runtime/bind_h20_container_context_v8.py"),
    prior_migration_release=ref(prior), cpu_check=cpu, actual_adoption=False,
    binding_fix="Admit only owned Insert split/sequence metadata in the private "
                "H20 run directory. Preserve original hash/size/canonical-path "
                "and sealed-layout checks. No RGB, renderer, budget or library changes.",
)
files = {row["path"]: row for row in release["runtime_files"]}
for name in (
    "h20_insert_private_metadata_v1.py", "h20_container_binding_v7.py",
    "native_h20_container_v5.py", "collect_h20_container_v8.py",
    "bind_h20_container_context_v8.py", "test_insert_private_metadata_cpu_v1.py",
    "prepare_insert_h20_v1.py", "freeze_insert_private_metadata_h20_v1.py",
):
    row = ref(D / "runtime" / name)
    files[row["path"]] = row
release["runtime_files"] = list(files.values())
print(json.dumps({
    "release": save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_013.json", release),
    "cpu_check": cpu, "actual_adoption": False,
}))
