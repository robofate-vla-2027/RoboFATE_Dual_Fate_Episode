"""CPU/link/namespace check only. No simulator, model load, API, or data result."""
import ctypes
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import h20_container_binding_v3 as binding
import collect_h20_container_v3 as collection
import bind_h20_container_context_v3
import common_recording_content_v2 as content
import torch

assert collection.original.core.foreground is binding.foreground
assert collection.original.core.finish is binding.finish
assert content.initialize_recording.__code__.co_filename.endswith("container_camera_device_check.py")
assert "/runtime/native_h20_container_v2.py" in binding._text
libc = ctypes.CDLL("libc.so.6")
libc.gnu_get_libc_version.restype = ctypes.c_char_p
glibc = libc.gnu_get_libc_version().decode()
assert tuple(map(int, glibc.split("."))) >= (2, 35)
policy, native = binding.environment(binding.D/"migration/cpu_fixture", {})
assert policy["CUDA_VISIBLE_DEVICES"] == "0"
assert native["CUDA_VISIBLE_DEVICES"] == "0,1"
assert native["CUDA_HOME"] == "/usr/local/cuda-12.5"
ctypes.CDLL(native["LD_PRELOAD"])
assert native["OMNI_VULKAN_ENV_SKIP"] == "0"
assert (binding.D/"native/utils/pipeline_utils.py").is_file()
for lib in ("libEGL.so.1", "libGLU.so.1", "libXt.so.6", "libSM.so.6", "libICE.so.6"):
    ctypes.CDLL(str(binding.D/"runtime/system_libs"/lib))
assert (binding.D/"native/third_party/curobo").resolve() == binding.D/"runtime/curobo_original_895c651"
report = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "kind": "migration_cpu_namespace_check_not_scientific_result",
    "python": sys.version, "torch": torch.__version__, "glibc": glibc,
    "compiler": subprocess.check_output(["g++", "--version"], text=True).splitlines()[0],
    "allocation": binding.allocation(),
    "memory": binding.previous.memory_headroom(120),
    "effective_collector_and_binder_match": True,
    "content_initialize_recording": content.initialize_recording.__code__.co_filename,
    "native_started": False, "model_loaded": False, "teacher_called": False,
    "constant_frame_real_validation": False,
}
path = binding.D/"migration/CONTAINER_CPU_CHECK_003.json"
with path.open("x") as f:
    json.dump(report, f, indent=2)
print(json.dumps({"report": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "glibc": glibc, "torch": torch.__version__, "passed": True}))

