"""Accept actual prelaunch resource closure without fabricating a baseline."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v2.py")
text = path.read_text()
old = 'exec(compile(text, str(path) + "::exact_code_scope", "exec"), globals())'
assert text.count(old) == 1
extra = '''
old_check = '    assert terminal["first_readback_passed"]'
new_check = """    if terminal.get("schema") == "refate.teacher_prelaunch_interruption.v1":
        assert terminal["native_started"] is terminal["foreground_started"] is False
        assert terminal["model_or_api_called"] is False
        assert terminal["container_state"]["Running"] is False
        assert terminal["container_state"]["Pid"] == 0
        assert terminal["launcher_original_process_absent"]
        assert all(not Path(p).exists() for p in terminal["absent_paths"])
    else:
        assert terminal["first_readback_passed"]"""
assert text.count(old_check) == 1
text = text.replace(old_check, new_check, 1)
'''
text = text.replace(old, extra + "\n" + old)
exec(compile(text, str(path) + "::prelaunch_resource_boundary", "exec"), globals())

