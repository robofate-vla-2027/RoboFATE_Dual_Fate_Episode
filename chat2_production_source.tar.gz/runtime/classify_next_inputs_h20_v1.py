"""Original Classify source order with separate historical and resource roots."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys

import h20_teacher_binding_v10 as teacher
import task_configured_binding as configured
from dolls_next_inputs_h20_v2 import teacher_checks
from prepare_classify_legacy_handoff_v2 import next_prefix
from h20_insert_private_metadata_v1 import metadata_locations

execution = teacher.execution
host = execution.previous
host.host()
index, predecessor_index, resource_run_id = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
assert (index, predecessor_index) == (32, 24)
assert resource_run_id == "c2_classify_objects_l24_evo_common_teacher_0001_01a16807"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(pin):
    raw = host.read_pin(metadata_locations(pin))
    return json.loads(raw)


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


task = "classify_objects"
resource_ref = ref(host.D / "teacher/runs" / resource_run_id / "MAIN_TERMINAL_OBSERVATION_002.json")
terminal = document(resource_ref)
teacher_checks(terminal, resource_run_id)
prior = execution.A.parent / "runs/c2_classify_objects_l24_common_baseline_0001_01a16807"
prior_dispatch = json.loads((prior / "DISPATCH_001.json").read_bytes())
previous = {"ref": prior_dispatch["source_preparation"],
            "prepared": document(prior_dispatch["source_preparation"])}
prior_settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")
prior_settlement_ref["path"] = (
    "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
    "20261022_collection_chat2_01a16338/teacher/shared_teacher/runs/"
    "c2_classify_objects_l24_common_baseline_0001_01a16807/MAIN_SETTLEMENT_001.json"
)
assert document(prior_settlement_ref)["source_id"] == previous["prepared"]["source"]["source_id"]
prepared_path = execution.A / f"task_sources/{task}/PREPARATION_L{index}_CONFIGURED_001.json"
prepared = json.loads(prepared_path.read_bytes())
configured.load_native_layout(prepared)
manifest = document(prepared["provenance"]["split"])
original_manifest = document(manifest["metadata_projection"]["original_manifest"])
prefix = next_prefix(original_manifest, previous["prepared"], index)
assert prepared["source"]["required_accounted_prefix"] == prefix[:-1]
assert prepared["source"]["source_sequence"] == original_manifest["initial_source_sequence"]
assert manifest["original_partition"]["reserved_final"] == [53, 54]
assert prepared["native_step_limit"] == 1100
cpu_ref = ref(host.D / f"migration/CLASSIFY_L{index}_PREPARATION_CPU_001.json")
cpu = document(cpu_ref)
assert cpu["actual_configured_loader_passed"] and cpu["raw_layout_unchanged"]
release_path = host.D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"
assert ref(release_path)["sha256"] == "b180c8531d7d3f4f8eb3b3ae567a867828c77d1e9947f275ceb3159775631764"
release = json.loads(release_path.read_bytes())
resource = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": "20250103-instance", "allocation": host.allocation(),
    "memory": host.memory_headroom(120), "native_started": False,
}
assert shutil.disk_usage(host.D).free > 30 * 1024**3
run_id = f"c2_{task}_l{index}_h20_baseline_0001_01a16807"
run = host.D / "teacher/runs" / run_id
run.mkdir()
admission_ref = save(run / "RESOURCE_PRECHECK_001.json", resource)
out = {
    "run_id": run_id, "preparation": prepared, "preparation_ref": ref(prepared_path),
    "previous": previous, "prior_settlement_ref": prior_settlement_ref,
    "prior_source_id": previous["prepared"]["source"]["source_id"],
    "current_resource_predecessor": resource_ref, "terminal": terminal,
    "release_ref": ref(release_path), "release": release, "manifest": manifest,
    "original_manifest": original_manifest,
    "cpu_ref": cpu_ref, "resource": resource, "resource_ref": admission_ref,
    "native_started": False,
}
out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)
print(json.dumps(out))
