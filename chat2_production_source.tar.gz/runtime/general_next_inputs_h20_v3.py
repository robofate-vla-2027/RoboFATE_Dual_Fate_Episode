"""Continue the original General sequence after a settled H20 baseline."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("general_next_inputs_h20_v1.py").read_text()
    for old, new in (
        ("assert 25 <= index < 53", "assert 27 <= index < 53"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General_next_original_baseline_boundary", "exec"), globals())
