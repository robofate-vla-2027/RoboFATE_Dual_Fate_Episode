"""Pin the complete metadata/observer entry set around unchanged teacher015."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import sys


def offline(event, args):
    if event in ("subprocess.Popen", "os.system", "os.exec", "socket.connect",
                 "socket.bind", "socket.getaddrinfo", "os.kill", "os.killpg"):
        raise RuntimeError("CPU configuration check forbids external effects: " + event)


sys.addaudithook(offline)
import prepare_teacher_metadata_h20_v17 as metadata
import h20_teacher_binding_v15 as teacher
teacher.execution.previous.host()
D = teacher.execution.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261109_015.json"
assert ref(prior)["sha256"] == "12f440e1acf9428aa50fa0aaae9876493ce0175292a936bb94518ab720ef6287"
release = json.loads(prior.read_bytes())
assert metadata.previous.previous.binding is teacher
assert metadata.catalog is teacher.native.source_sequence_binding
assert metadata.catalog.TASK_TOTALS["play_stacking_toy"] == 1200
text = metadata.previous.main_source()
assert text.count("collect_teacher_h20_v14.py") == 1
ast.parse(text.replace("collect_teacher_h20_v14.py", "collect_teacher_h20_v15.py", 1))
assert getattr(teacher.stage.original_command, "_refate_search_disabled", False)
assert hashlib.sha256(teacher._text.encode()).hexdigest() == release["effective_native_source_sha256"]
pins = {p["path"]: p for p in release["runtime_files"]}
names = (
    "prepare_teacher_metadata_h20_v17.py", "observe_teacher015_start_h20_v1.py",
    "observe_teacher015_first_h20_v1.py", "export_teacher015_settlement_metadata_h20_v1.py",
    "freeze_teacher_search_entrypoints_h20_v1.py",
)
for name in names:
    p = D / "runtime" / name
    compile(p.read_text(), str(p), "exec")
    pins[str(p)] = ref(p)
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_entry_set_release=ref(prior), runtime_files=list(pins.values()),
    metadata_preparation_entry=str(D / "runtime/prepare_teacher_metadata_h20_v17.py"),
    actual_start_observer=str(D / "runtime/observe_teacher015_start_h20_v1.py"),
    first_action_observer=str(D / "runtime/observe_teacher015_first_h20_v1.py"),
    settlement_metadata_export=str(D / "runtime/export_teacher015_settlement_metadata_h20_v1.py"),
    entry_set_CPU={"matched_binding": True, "Play_native_total": 1200,
                   "model_API_simulator_calls": False, "scientific_samples": 0},
    actual_adoption=False,
)
out = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261109_016.json"
with out.open("x") as stream:
    json.dump(release, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"teacher_release": ref(out), "actual_adoption": False,
                  "matched_entry_set_CPU": True}))

