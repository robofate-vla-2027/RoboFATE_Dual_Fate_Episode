"""Same Kit tmpfs and collector; compiled policy cache uses private executable data."""
from prelaunch_general_cache_tmpfs_v5 import source as previous_source


def source():
    text = previous_source()
    assert text.count("policy_cache_seed_h20_v1") == 2
    return text.replace("policy_cache_seed_h20_v1", "policy_cache_seed_h20_v2")


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::private_policy_cache_backing", "exec"), globals())
