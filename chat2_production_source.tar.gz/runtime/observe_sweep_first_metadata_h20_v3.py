"""Same actual first-segment checks, paired with the container cache path fix."""
from pathlib import Path

path = Path(__file__).with_name("observe_sweep_first_metadata_h20_v2.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261108_027.json"
assert text.count(old) == 1
exec(compile(text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261108_028.json"),
             __file__ + "::release028", "exec"), globals())
