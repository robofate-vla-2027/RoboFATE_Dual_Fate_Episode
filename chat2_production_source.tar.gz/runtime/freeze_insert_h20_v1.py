"""Freeze the matched future entry without adopting it for an in-flight run."""
import datetime
import hashlib
import json
from pathlib import Path

import h20_container_binding_v6 as binding
import collect_h20_container_v6 as collector

D, A = binding.D, binding.A


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    return ref(path)


prepared_path = A.parent / "preparations/INSERT_L43_H20_STORAGE_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
storage = binding.insert_storage
assert storage.sequence._helpers is storage.storage_helpers
assert collector.original.core.foreground is binding.foreground
assert collector.original.core.finish is binding.finish
assert "native_h20_container_v4.py" in binding._text
storage.sequence.load_native_layout(prepared)
assert prepared["native_step_limit"] == 500
assert binding.extensions.verify({
    "task": "insert_tubes", "native_total_steps": 500, "native_kit_extensions": [],
}) is None
cpu = save(D / "migration/INSERT_ENTRY_BINDING_CPU_001.json", {
    "schema": "refate.h20.insert_entry_cpu.v1",
    "data_kind": "offline_cpu_binding_check_not_scientific_data",
    "preparation": ref(prepared_path), "original_context_validator_passed": True,
    "collector_native_storage_bindings_match": True,
    "original_task_budget": 500, "real_model_api_native_calls": False,
    "actual_entry_launched": False, "current_conveyor_entry_changed": False,
})
prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_010.json"
release = json.loads(prior.read_bytes())
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    foreground_entry=str(D / "runtime/collect_h20_container_v6.py"),
    native_entry=str(D / "runtime/native_h20_container_v4.py"),
    context_builder=ref(D / "runtime/bind_h20_container_context_v6.py"),
    prior_migration_release=ref(prior), cpu_check=cpu, actual_adoption=False,
    binding_fix="Reversible metadata-only Insert storage translation after original "
                "hash checks. Raw layouts, source ownership, family/order checks, "
                "content recorder/reader and original budgets unchanged.",
)
files = {row["path"]: row for row in release["runtime_files"]}
for name in ("h20_container_binding_v6.py", "native_h20_container_v4.py",
             "collect_h20_container_v6.py", "bind_h20_container_context_v6.py",
             "h20_insert_metadata_binding_v1.py", "freeze_insert_h20_v1.py"):
    row = ref(D / "runtime" / name)
    files[row["path"]] = row
for key in ("SPLIT_REF", "SEQUENCE_REF", "HISTORY_REF", "ORDER_REF"):
    row = getattr(storage.sequence, key)
    assert ref(Path(row["path"])) == row
    files[row["path"]] = row
release["runtime_files"] = list(files.values())
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_011.json", release)
print(json.dumps({"release": output, "cpu_check": cpu, "actual_adoption": False}))
