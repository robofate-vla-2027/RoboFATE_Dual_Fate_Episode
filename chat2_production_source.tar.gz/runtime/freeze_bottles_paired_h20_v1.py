"""Freeze matched future entries after path-only CPU checks, not simulation."""
import datetime
import hashlib
import json
from pathlib import Path

import collect_h20_container_v10 as collector
import bind_h20_container_context_v10 as binder
import h20_teacher_binding_v8 as teacher
import task_configured_binding as configured
import collection_append_binding_v1 as append
import teacher_catalog_binding_v13 as catalog
from h20_retained_bottles_storage_v1 import RUN, SOURCE_ID

b = collector.binding
b.previous.host()
D = b.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


assert collector.original.core.foreground is binder.collection.core.foreground is b.foreground
assert "native_h20_container_v7.py" in b._text
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
prepared_path = b.A / "task_sources/put_bottles_into_dustbin/PREPARATION_L32_CONFIGURED_001.json"
prepared = append.document(ref(prepared_path))
assert prepared["native_step_limit"] == 700 and prepared["source"]["layout_id"] == 32
assert configured.load_native_layout(prepared) == catalog.load_native_layout(prepared)
source_path = RUN / "source_identity.json"
raw = json.loads(source_path.read_bytes())
expected = teacher.preparation.restore.document(ref(source_path))
assert raw != expected
assert teacher.preparation.restore._identity_source_id(raw, expected) == SOURCE_ID
assert raw == json.loads(source_path.read_bytes())
cpu = save(D / "migration/BOTTLES_L32_PAIRED_ENTRY_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "actual_metadata_CPU_only_not_simulation",
    "preparation": ref(prepared_path), "native_total": 700,
    "existing_preparation_reused": True, "source_preparation_repeated": False,
    "actual_installed_loader_passed": True, "raw_layout_unchanged": True,
    "L31_original_identity_matches_after_two_path_normalization": True,
    "original_full_identity_check_preserved": True,
    "matched_baseline_entries": True, "matched_teacher_entries": True,
    "actual_t1_restore_verified": False, "native_model_API_calls": False, "qualified_samples": 0,
})


def freeze(prior_name, expected_sha, name, names, changes):
    prior = D / "runtime" / prior_name
    assert ref(prior)["sha256"] == expected_sha
    value = json.loads(prior.read_bytes())
    pins = {pin["path"]: pin for pin in value["runtime_files"]}
    for pin in pins.values():
        teacher.storage.runtime.read_pin(pin)
    for filename in names:
        pin = ref(D / "runtime" / filename)
        pins[pin["path"]] = pin
    value.update(changes)
    value.update(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        prior_bottles_path_release=ref(prior), runtime_files=list(pins.values()),
        bottles_metadata_cpu=cpu, actual_adoption=False, actual_positive_published=False,
        change_scope="Bottles metadata paths plus reversible comparison of two layout-path "
                     "identity fields. All other source fields, hashes, RGB, native actions, "
                     "physics, scoring, renderer, budgets and teacher remain unchanged.")
    return save(D / "runtime" / name, value)


shared = ("h20_bottles_metadata_storage_v1.py", "freeze_bottles_paired_h20_v1.py")
baseline = freeze(
    "RUNTIME_H20_CHAT2_CONTENT_20261107_014.json",
    "0765b426fe5ce0ea794ff8e590384ba0c7e6638207428591a489cf2488e2a33b",
    "RUNTIME_H20_CHAT2_CONTENT_20261107_015.json",
    shared + ("h20_container_binding_v9.py", "collect_h20_container_v10.py",
              "native_h20_container_v7.py", "bind_h20_container_context_v10.py"),
    {"foreground_entry": str(D / "runtime/collect_h20_container_v10.py"),
     "native_entry": str(D / "runtime/native_h20_container_v7.py"),
     "context_builder": ref(D / "runtime/bind_h20_container_context_v10.py"),
     "cpu_check": cpu})
teacher_release = freeze(
    "RUNTIME_H20_CHAT2_TEACHER_20261107_007.json",
    "7ea1180556572ec8bac7adc5647675b49732750a8c3ce2792bd33489ed5f5a50",
    "RUNTIME_H20_CHAT2_TEACHER_20261107_008.json",
    shared + ("h20_source_identity_paths_v1.py", "h20_teacher_binding_v8.py",
              "native_teacher_h20_v8.py", "collect_teacher_h20_v8.py",
              "prepare_teacher_h20_v8.py", "prepare_teacher_metadata_h20_v9.py",
              "launch_bound_teacher_release008.sh"),
    {"foreground_entry": str(D / "runtime/collect_teacher_h20_v8.py"),
     "native_entry": str(D / "runtime/native_teacher_h20_v8.py"),
     "preparation_entry": str(D / "runtime/prepare_teacher_h20_v8.py"),
     "launch_environment_binding": ref(D / "runtime/launch_bound_teacher_release008.sh")})
print(json.dumps({"baseline_release": baseline, "teacher_release": teacher_release,
                  "cpu": cpu, "actual_adoption": False}))
