"""Same Insert append boundary using the immediately preceding H20 source."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

import h20_runtime_binding_v1 as host
import h20_container_binding_v7 as execution
import common_owner_reservation_v3 as original
from closed_baseline_resource_v1 import baseline_checks

host.host()
index, prior_id = int(sys.argv[1]), sys.argv[2]
assert 44 <= index < 53
assert re.fullmatch(r"c2_insert_tubes_l\d+_h20_baseline_\d{4}_01a16807", prior_id)
D, A = host.D, host.A


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(reference):
    path = Path(reference["path"])
    assert ref(path) == reference
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


prior = D / "teacher/runs" / prior_id
dispatch = json.loads((prior / "DISPATCH_001.json").read_bytes())
settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")
settlement = document(settlement_ref)
baseline_checks(settlement)
assert settlement["execution_owner"] == host.OWNER and settlement["task"] == "insert_tubes"
assert settlement["first_readback_passed"] and type(settlement["native_success"]) is bool
prepared_path = A.parent / f"preparations/INSERT_L{index}_COMMON_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
execution.private_insert_metadata.sequence.load_native_layout(prepared)
old_prepared = document(dispatch["source_preparation"])
assert old_prepared["source"]["layout_id"] == index - 1
cp = {
    "source_id": dispatch["source_id"], "prepared": old_prepared,
    "preparation_ref": dispatch["source_preparation"], "settlement_ref": settlement_ref,
    "split_ref": dispatch["split_manifest"], "split": document(dispatch["split_manifest"]),
    "sequence_ref": ref(prior / "SEQUENCE_EXTENSION_001.json"),
}
assert prepared["provenance"]["prior_split"] == cp["split_ref"]
assert prepared["provenance"]["prior_sequence"] == cp["sequence_ref"]
release_path = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_013.json"
release = json.loads(release_path.read_bytes())
resource = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": "20250103-instance", "allocation": host.allocation(),
    "memory": host.memory_headroom(120), "native_started": False,
}
assert shutil.disk_usage(D).free > 30 * 1024**3
run_id = f"c2_insert_tubes_l{index}_h20_baseline_{index+4:04d}_01a16807"
run = D / "teacher/runs" / run_id
run.mkdir()
resource_ref = write(run / "RESOURCE_PRECHECK_001.json", resource)
extension = {
    "schema": "refate.insert.source_sequence_extension.v1", "data_kind": "preparation_only",
    "owner_chat": host.OWNER, **prepared["sequence_extension_proposal"],
    "qualification": False, "source_issued": False, "launch_authority": False,
    "predecessor_disposition": settlement_ref,
}
extension_ref = write(run / "SEQUENCE_EXTENSION_001.json", extension)
manifest = original.append_manifest(prepared, cp["split"], extension_ref, resource["at"])
manifest_ref = write(run / f"SPLIT_MANIFEST_L{index}_001.json", manifest)
print(json.dumps({
    "run_id": run_id, "preparation": prepared, "preparation_ref": ref(prepared_path),
    "insert_prefix_checkpoint": cp, "prior_settlement": settlement,
    "release_ref": ref(release_path), "cpu_ref": release["cpu_check"],
    "foreground_entry": release["foreground_entry"], "native_started": False,
    "resource": resource, "resource_ref": resource_ref,
    "current_resource_predecessor": settlement_ref,
    "publication": {"at": resource["at"], "manifest": manifest,
                    "manifest_ref": manifest_ref, "extension_ref": extension_ref},
}))
