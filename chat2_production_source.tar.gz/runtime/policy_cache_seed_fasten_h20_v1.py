"""Same container-writable compiled cache, bound to original Fasten1900."""
from policy_cache_seed_sweep_nfs_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "sweep_blocks"', 'context["task"] == "fasten_screws"'),
        ('context["native_total_steps"] == 1000', 'context["native_total_steps"] == 1900'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::Fasten1900_cache_only", "exec"), namespace)
    return namespace["install"](run)
