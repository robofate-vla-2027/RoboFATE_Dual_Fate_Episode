"""Synthetic CPU video check only; no model, API, physics, or scientific data."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import h20_container_binding_v4 as binding
import collect_h20_container_v4 as collection
import bind_h20_container_context_v4
import numpy as np

assert collection.original.core.foreground is binding.foreground
assert collection.original.core.finish is binding.finish
root = binding.D / "migration/ffmpeg_synthetic_cpu_001"
root.mkdir(exist_ok=False)
_, native = binding.environment(root, {})
os.environ.update(native)
version = subprocess.check_output(["ffmpeg", "-version"], text=True)
assert version.startswith("ffmpeg version 4.4.2-0ubuntu0.22.04.1")
sys.path.insert(0, str(binding.D / "native"))
from utils.save_file import VideoStreamWriter

frames = [np.zeros((480, 640, 3), dtype=np.uint8),
          np.full((480, 640, 3), 127, dtype=np.uint8),
          np.tile(np.arange(640, dtype=np.uint8)[None, :, None], (480, 1, 3))]
before = [hashlib.sha256(f.tobytes()).hexdigest() for f in frames]
output = root / "synthetic.mp4"
writer = VideoStreamWriter(str(output), 480, 640, 3, fps=25)
for frame in frames:
    writer.append(frame)
writer.close(announce=False)
assert before == [hashlib.sha256(f.tobytes()).hexdigest() for f in frames]
probe = json.loads(subprocess.check_output([
    "ffprobe", "-v", "error", "-count_frames", "-show_entries",
    "stream=codec_name,width,height,r_frame_rate,nb_read_frames",
    "-of", "json", str(output)], text=True))["streams"][0]
assert probe == {"codec_name": "h264", "width": 640, "height": 480,
                 "r_frame_rate": "25/1", "nb_read_frames": "3"}, probe
subprocess.run(["ffmpeg", "-v", "error", "-i", str(output),
                "-f", "null", "-"], check=True)
report = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "kind": "synthetic_cpu_video_dependency_check_not_scientific_data",
    "original_ffmpeg_version": version.splitlines()[0],
    "original_writer_sha256": hashlib.sha256(
        (binding.D / "native/utils/save_file.py").read_bytes()).hexdigest(),
    "writer_input_unchanged": True, "probe": probe,
    "collector_and_binder_match": True,
    "native_started": False, "model_loaded": False, "teacher_called": False,
    "constant_frame_real_validation": False,
}
path = binding.D / "migration/FFMPEG_CPU_CHECK_001.json"
with path.open("x") as f:
    json.dump(report, f, indent=2)
print(json.dumps({"passed": True, "report": str(path),
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}))
