"""Bounded CPU import diagnostic for modules observed in the failed prediction."""
import importlib
import json
import os
import sys
import time

assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
assert os.environ.get("PYTHONDONTWRITEBYTECODE") == "1"
assert os.environ.get("REFATE_EXECUTION_OWNER") == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def isolate(event, args):
    if event in ("subprocess.Popen", "os.system", "os.exec", "socket.connect",
                 "socket.bind", "socket.getaddrinfo", "os.kill", "os.killpg"):
        raise RuntimeError("CPU import diagnostic forbids external effects: " + event)


sys.addaudithook(isolate)
started = time.monotonic()
for name in ("torch", "transformers.models.gemma3.modeling_gemma3",
             "liger_kernel.ops.layer_norm", "triton.compiler.compiler"):
    before = time.monotonic()
    print(json.dumps({"stage": "import_start", "module": name}), flush=True)
    module = importlib.import_module(name)
    print(json.dumps({"stage": "import_complete", "module": name,
                      "seconds": time.monotonic() - before,
                      "origin": module.__file__}), flush=True)
print(json.dumps({"stage": "complete_import_only_not_prediction",
                  "seconds": time.monotonic() - started,
                  "model_calls": False, "network_calls": False,
                  "GPU_execution_calls": False, "simulator_calls": False,
                  "scientific_quota_delta": 0}), flush=True)
