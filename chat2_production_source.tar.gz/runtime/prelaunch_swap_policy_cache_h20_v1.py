"""Original cache placement and collector11 for SwapT's first seven sources."""
from prelaunch_stack_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_stack_h20_v1", "policy_cache_seed_swap_h20_v1", 2),
        ("c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807",
         "c2_swap_T_l[0-6]_h20_baseline_000[1-7]_01a16807", 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::SwapT400_existing_collector", "exec"), globals())
