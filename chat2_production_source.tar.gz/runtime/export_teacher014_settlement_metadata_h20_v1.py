"""Existing saved-readback export through the matched teacher014 binding."""
from export_teacher013_settlement_metadata_h20_v1 import source as previous_source


def source():
    text = previous_source()
    assert text.count("h20_teacher_binding_v13") == 1
    return text.replace("h20_teacher_binding_v13", "h20_teacher_binding_v14", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::catalog014_export", "exec"), globals())
