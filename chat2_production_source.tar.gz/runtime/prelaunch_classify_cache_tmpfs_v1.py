"""Same private disposable-cache placement, with the original Classify budget."""
from pathlib import Path

path = Path(__file__).with_name("prelaunch_kit_cache_tmpfs_v1.py")
text = path.read_text()
for old, new in (
    (r"c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807",
     r"c2_classify_objects_l32_h20_baseline_0001_01a16807"),
    ('value["native_total_steps"] == 400', 'value["native_total_steps"] == 1100'),
):
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::classify1100_same_cache", "exec"), globals())
