"""Same metadata workflow bound to the future causal-history release."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v11.py")
text = path.read_text()
for old, new, count in (
    ("h20_teacher_binding_v10", "h20_teacher_binding_v11", 2),
    ("RUNTIME_H20_CHAT2_TEACHER_20261107_010.json",
     "RUNTIME_H20_CHAT2_TEACHER_20261107_011.json", 1),
    ("collect_teacher_h20_v10.py", "collect_teacher_h20_v11.py", 1),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::causal_history_release011", "exec"), globals())
