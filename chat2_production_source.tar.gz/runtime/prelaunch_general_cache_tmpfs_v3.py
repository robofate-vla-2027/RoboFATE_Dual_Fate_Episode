"""Same private General disposable cache with the diagnostic collector binding."""
from prelaunch_general_cache_tmpfs_v2 import source as previous_source

text = previous_source()
marker = 'exec(compile(source(), __file__ + "::General_same_disposable_cache", "exec"), globals())'
assert text.count(marker) == 1
text = text.replace(marker, """
text = source()
old = "ENTRY = D / \\"runtime/collect_h20_container_v10.py\\""
assert text.count(old) == 1
text = text.replace(old, "ENTRY = D / \\"runtime/collect_h20_container_v11.py\\"", 1)
exec(compile(text, __file__ + "::General_diagnostic_entry_cache", "exec"), globals())
""", 1)
if __name__ == "__main__":
    exec(compile(text, __file__ + "::General27_diagnostic_cache", "exec"), globals())

