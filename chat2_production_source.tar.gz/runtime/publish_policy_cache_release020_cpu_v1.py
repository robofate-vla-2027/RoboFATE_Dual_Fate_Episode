"""Validate only bounded cache relocation, then pin the unchanged collector plus prelaunch."""
import datetime
import hashlib
import json
from pathlib import Path
import tempfile

import h20_container_binding_v10 as binding
import policy_cache_seed_h20_v1 as cache
import prelaunch_general_cache_tmpfs_v5 as prelaunch

binding.previous.host()
d = binding.D
reference = lambda p: dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
manifest = json.loads(cache.MANIFEST.read_bytes())
before = cache.verified_payloads(manifest)
with tempfile.TemporaryDirectory(prefix="cache_copy_cpu_", dir=d / "migration") as temporary:
    root = Path(temporary)
    result = cache.stage(manifest, root / "staged",
                         {"triton": root / "logical/triton", "cuda": root / "logical/cuda"})
    assert cache.verified_payloads(manifest) == before
    changed = set(result["rewritten_group_paths_only"])
    for relative, raw in before.items():
        if relative not in changed:
            assert (root / "staged" / relative).read_bytes() == raw
text = prelaunch.source()
compile(text, "CPU_only_cache_prelaunch_expansion", "exec")
assert 'ENTRY = D / "runtime/collect_h20_container_v11.py"' in text
assert 'value["native_wall_seconds"] == 2400' in text
assert 'value["native_total_steps"] == 200' in text
assert "policy_cache_seed_h20_v1.install(run)" in text
cpu = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    data_kind="CPU_cache_copy_not_scientific_data",
    cache_manifest=reference(cache.MANIFEST), compiled_artifacts_byte_identical=True,
    source_cache_unchanged=True, only_group_child_paths_relocated=True,
    files=result["files"], bytes=result["bytes"], group_paths_relocated=len(changed),
    synthetic_tests_passed=4, real_compiled_artifacts_executed=False,
    model_calls=False, gpu_calls=False, simulator_calls=False,
    observation_or_action_or_rng_state_reused=False,
    original_request_timeout_seconds=120, model_loading_allowance_seconds=900,
    baseline_wall_seconds=2400, teacher_wall_seconds=3600,
    actual_latency_improvement_verified=False, actual_future_source_started=False)
cp = d / "migration/POLICY_COMPILED_CACHE_CPU_001.json"
with cp.open("x") as stream:
    json.dump(cpu, stream, indent=2)
    stream.write("\n")
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_019.json"
release = json.loads(old.read_bytes())
release.update(
    at=cpu["at"], prior_compiled_cache_release=reference(old),
    cache_cpu_check=reference(cp), compiled_cache_manifest=reference(cache.MANIFEST),
    prelaunch_entry=reference(d / "runtime/prelaunch_general_cache_tmpfs_v5.py"),
    actual_adoption=False,
    change_scope="Same collector/native/policy/readers; private disposable compiled-cache reuse only. "
                 "All actions, RNG, model, physics, RGB and original timeout values unchanged.")
for name in ("policy_cache_seed_h20_v1.py", "prelaunch_general_cache_tmpfs_v5.py"):
    release["runtime_files"].append(reference(d / "runtime" / name))
new = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_020.json"
with new.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(release=reference(new), cache_cpu=reference(cp),
                     cache_manifest=reference(cache.MANIFEST), prelaunch=release["prelaunch_entry"],
                     actual_adoption=False)))

