"""Read a byte-verified migrated failure without changing historical evidence."""
import ast
import hashlib
import json
from pathlib import Path

RUN_ID = "c2_put_bottles_into_dustbin_l31_common_baseline_0032_01a16807"
SOURCE_ID = "put_bottles_into_dustbin_b0_l31_e96af0f6b935aa36"
OLD = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
           "20261022_collection_chat2_01a16338/teacher/shared_teacher")
D = Path("/data/refate_chat2_20261106_01a19072")
OLD_RUN = OLD / "runs" / RUN_ID
RUN = D / "teacher/runs" / RUN_ID
HISTORICAL_NAMES = {"CONTEXT_001.json", "SOURCE_MANIFEST_001.json", "MAIN_SETTLEMENT_001.json"}


def translate(value, mapper):
    if not isinstance(value, dict):
        return value
    if (value.get("source_id") != SOURCE_ID and value.get("run_id") != RUN_ID
            and value.get("run") != str(OLD_RUN) and value.get("source_root") != str(OLD_RUN)):
        return value
    from h20_bottles_metadata_storage_v1 import verify_storage_only
    result = mapper(value)
    verify_storage_only(value, result, mapper)
    return result


def install(binding):
    from h20_insert_metadata_binding_v1 import locations
    import failure_summary_report_size_v1 as failure
    runtime = binding.storage.runtime
    previous_document = runtime.document
    if getattr(previous_document, "_refate_retained_bottles_v1", False):
        return

    def mapper(value, *, inverse=False):
        if isinstance(value, dict):
            return {key: mapper(item, inverse=inverse) for key, item in value.items()}
        if isinstance(value, list):
            return [mapper(item, inverse=inverse) for item in value]
        old, new = (str(OLD_RUN), str(RUN))
        if inverse:
            old, new = new, old
        if isinstance(value, str) and (value == old or value.startswith(old + "/")):
            return new + value[len(old):]
        return locations(value, inverse=inverse)

    def document(raw):
        return translate(previous_document(raw), mapper)

    document._refate_retained_bottles_v1 = True
    runtime.document = document
    restore = binding.preparation.restore
    previous_ref = restore.ref

    def ref(path):
        pin = previous_ref(path)
        path = Path(path)
        if path.parent == RUN and path.name in HISTORICAL_NAMES:
            original = {"path": str(OLD_RUN / path.name), "sha256": pin["sha256"]}
            assert runtime.read_pin(original) == path.read_bytes()
            return original
        return pin

    restore.ref = ref

    def verify_migration(inventory, summary_ref):
        root = binding.execution.previous.PROJECT.parent
        transfer = root / "transfer/bottles_audit_batch_020.manifest.json"
        audit_manifest = json.loads(transfer.read_bytes())
        assert len(audit_manifest) == 1
        name, expected = next(iter(audit_manifest.items()))
        audit_path = root / "dependency_tree" / name
        raw = audit_path.read_bytes()
        assert len(raw) == expected["bytes"]
        assert hashlib.sha256(raw).hexdigest() == expected["sha256"]
        audit_sha = expected["sha256"]
        audit = json.loads(raw)
        assert audit["source_host"] == "nb-dn22t489hz-0" and audit["source_id"] == SOURCE_ID
        assert audit["source_payload_predates_saved_readback"]
        assert audit["source_payload_matches_transfer_manifest"] and not audit["ctime_backdated"]
        manifest = root / "transfer/bottles_l31_batch_019.manifest.json"
        assert hashlib.sha256(manifest.read_bytes()).hexdigest() == audit["transfer_manifest_sha256"]
        assert set(inventory) == set(audit["payload"]) and len(inventory) == 6315
        for name, signature in inventory.items():
            path = RUN / name
            assert failure.signature(path) == signature
            raw = path.read_bytes()
            expected = audit["payload"][name]
            assert len(raw) == expected["bytes"]
            assert hashlib.sha256(raw).hexdigest() == expected["sha256"]
            assert failure.signature(path) == signature
        return {
            "kind": "byte_verified_migration_signature_snapshot",
            "source_integrity": {"path": str(audit_path), "sha256": audit_sha},
            "destination_ctime_is_actual": True,
            "source_metadata_not_later_than_saved_readback": False,
            "source_payload_predates_saved_readback": True,
            "destination_bytes_equal_source": True, "signature_file_count": len(inventory),
            "legacy_key_is_interface_alias_only": True,
        }

    # The projected inventory records new filesystem identities, not old ctimes.
    text = failure.source()
    replacements = (
        ("os.environ.get('REFATE_SSH_ALIAS') == 'perdon-hou'\n"
         "               and os.uname().nodename == 'nb-5pl2apckdj-0'",
         "os.environ.get('REFATE_SSH_ALIAS') == 'h20_8'\n"
         "               and os.uname().nodename == '20250103-instance'"),
        ("output = run/'readback_once_001/FAILURE_SUMMARY_COMPAT_001.json'",
         "output = run/('readback_once_001/FAILURE_SUMMARY_COMPAT_H20_001.json' "
         "if summary['source_id']==_migrated_source_id else "
         "'readback_once_001/FAILURE_SUMMARY_COMPAT_001.json')"),
        ("    need(all(max(s[4], s[5]) <= cutoff for s in inventory.values()),\n"
         "         'Source data changed after the saved passing readback; targeted comparison required')",
         "    migration = (_verify_migration(inventory, summary_ref)\n"
         "                 if summary['source_id']==_migrated_source_id else None)\n"
         "    if migration is None:\n"
         "        need(all(max(s[4], s[5]) <= cutoff for s in inventory.values()),\n"
         "             'Source data changed after the saved passing readback; targeted comparison required')"),
        ("inventory_path = run/'readback_once_001/SOURCE_SIGNATURES_AFTER_READBACK_001.json'",
         "inventory_path = run/('readback_once_001/SOURCE_SIGNATURES_H20_AFTER_TRANSFER_001.json' "
         "if migration else 'readback_once_001/SOURCE_SIGNATURES_AFTER_READBACK_001.json')"),
        ("    with output.open('x') as f:",
         "    if migration:\n"
         "        projected['inventory_provenance'] = migration\n"
         "        projected['payload_rehashed'] = True\n"
         "    with output.open('x') as f:"),
    )
    for old, new in replacements:
        assert text.count(old) == 1
        text = text.replace(old, new)
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == "project")
    failure.__dict__.update(_migrated_source_id=SOURCE_ID, _verify_migration=verify_migration)
    exec(compile(ast.Module(body=[node], type_ignores=[]),
                 __file__ + "::verified_source_copy_projection", "exec"), failure.__dict__)
