"""Original Play storage/source checks, using the matched collector11 release."""
from pathlib import Path

path = Path(__file__).with_name("play_next_inputs_h20_v1.py")
text = path.read_text()
seam = 'exec(compile(text, str(path) + "::play_original_boundary", "exec"), globals())'
assert text.count(seam) == 1
extra = '''
for before, after in (
    ("import h20_container_binding_v7 as binding",
     "import h20_container_binding_v10 as binding"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_035.json"),
    ("collect_h20_container_v8.py", "collect_h20_container_v11.py"),
    ("PLAY_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json",
     "PLAY_L{index}_CACHE_BINDING_CPU_001.json"),
):
    assert text.count(before) == 1, before
    text = text.replace(before, after, 1)
'''
text = text.replace(seam, extra + "\n" + seam, 1)
exec(compile(text, str(path) + "::matched_Play1200_inputs", "exec"), globals())
