"""Existing H20 storage and content rules, with the one additional task catalog."""
import types
from h20_teacher_storage_v2 import *
import h20_teacher_storage_v2 as previous
import teacher_catalog_stack_h20_v1 as teacher_catalog_binding_v13

for _name, _count in (("native_teacher_content_v6", 3),
                      ("collect_teacher_content_v6", 1),
                      ("prepare_teacher_content_v6", 2)):
    _old = getattr(previous, _name)
    assert _old.text.count("teacher_catalog_binding_v13") == _count
    _module = types.ModuleType("_refate_stack_" + _name)
    _module.__dict__.update(_old.__dict__)
    _module.text = _old.text.replace("teacher_catalog_binding_v13",
                                    "teacher_catalog_stack_h20_v1")
    globals()[_name] = _module
