"""Original initial-source preparation for SwapT's unchanged400-step task."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_stack_initial_h20_v1.py").read_text()
    for old, new in (
        ('TASK = "stack_blocks_by_language"', 'TASK = "swap_T"'),
        ("STACK_L0_PREPARATION_CPU_001.json", "SWAP_L0_PREPARATION_CPU_001.json"),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_SwapT400_metadata", "exec"), globals())
