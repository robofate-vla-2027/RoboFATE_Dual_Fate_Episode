"""Place a new, unbound Stack run on retained storage without changing paths."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

D = Path("/data/refate_chat2_20261106_01a19072")
SHARED = Path("/vla/mxk/projects/ReFATE/coordination/20261106_chat2_h20_01a19072/run_data")
NAMES = frozenset(("RESOURCE_PRECHECK_001.json", "BOUNDARY_INPUTS_001.json"))


def copy_prepared_metadata(run, destination):
    assert run.is_dir() and not run.is_symlink() and not os.path.ismount(run)
    assert {p.name for p in run.iterdir()} == NAMES, "Only unbound preparation files allowed"
    assert not destination.exists() and not destination.is_symlink()
    payloads = {}
    for name in sorted(NAMES):
        path = run / name
        assert path.is_file() and not path.is_symlink()
        assert 0 < path.stat().st_size <= 8 * 1024**2
        payloads[name] = path.read_bytes()
    destination.mkdir(mode=0o700)
    for name, raw in payloads.items():
        with (destination / name).open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        assert (destination / name).read_bytes() == raw == (run / name).read_bytes()
    fd = os.open(destination, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return payloads


def main():
    import h20_runtime_binding_v1 as binding

    binding.host()
    run_id = sys.argv[1]
    match = re.fullmatch(
        r"c2_stack_blocks_by_language_l([2-6])_h20_baseline_(000[3-7])_01a16807",
        run_id,
    )
    assert match and int(match[2]) == int(match[1]) + 1
    run = D / "teacher/runs" / run_id
    destination = SHARED / run_id
    assert run.resolve(strict=True) == run and SHARED.resolve(strict=True) == SHARED
    inputs = json.loads((run / "BOUNDARY_INPUTS_001.json").read_bytes())
    assert inputs["run_id"] == run_id and inputs["native_started"] is False
    prepared = inputs["preparation"]
    assert prepared["source"]["task"] == "stack_blocks_by_language"
    assert prepared["source"]["layout_id"] == int(match[1])
    assert prepared["native_step_limit"] == 400
    assert inputs["terminal"]["safe_for_next_simulator"] is True
    assert os.statvfs(SHARED).f_bavail * os.statvfs(SHARED).f_frsize > 30 * 1024**3
    payloads = copy_prepared_metadata(run, destination)
    # The original directory and byte-identical metadata stay beneath this mount.
    subprocess.run(["mount", "--bind", str(destination), str(run)], check=True)
    mount = json.loads(subprocess.check_output(
        ["findmnt", "--json", "--target", str(run), "-o", "TARGET,SOURCE,FSTYPE"],
        text=True,
    ))["filesystems"][0]
    assert mount["target"] == str(run) and mount["fstype"].startswith("nfs")
    assert run.resolve(strict=True) == run and os.path.ismount(run)
    assert (run.stat().st_dev, run.stat().st_ino) == (
        destination.stat().st_dev, destination.stat().st_ino
    )
    assert all((run / name).read_bytes() == raw for name, raw in payloads.items())
    value = {
        "schema": "refate.prepared_run_storage_binding.v1",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": binding.OWNER, "execution_ssh_alias": "h20_8",
        "run_id": run_id, "visible_run_path": str(run),
        "physical_run_path": str(destination), "mount": mount,
        "copied_metadata": {name: hashlib.sha256(raw).hexdigest()
                            for name, raw in payloads.items()},
        "original_metadata_retained_under_mount": True,
        "old_runs_modified": False, "native_started": False,
        "scientific_data_moved": False, "runtime_or_budget_changed": False,
        "actual_container_adoption_verified": False,
        "performance_benefit_verified": False,
    }
    path = run / "RUN_STORAGE_BINDING_001.json"
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    value["evidence_ref"] = {
        "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()
    }
    print(json.dumps(value))


if __name__ == "__main__":
    main()
