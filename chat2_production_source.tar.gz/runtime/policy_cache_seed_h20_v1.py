"""Copy only closed-run compiled caches into a new run's private disposable tmpfs."""
import hashlib
import json
import os
from pathlib import Path

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
D = Path("/data/refate_chat2_20261106_01a19072")
OLD_RUN = "c2_general_pickup_l27_h20_baseline_0001_01a16807"
MANIFEST = D / "migration/GENERAL_L27_COMPILED_CACHE_MANIFEST_001.json"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def verified_payloads(manifest):
    payloads = {}
    total = 0
    for row in manifest["files"]:
        relative = Path(row["relative"])
        assert not relative.is_absolute() and ".." not in relative.parts
        assert relative.parts[0] in ("triton", "cuda")
        source = Path(manifest["roots"][relative.parts[0]]) / Path(*relative.parts[1:])
        assert source.is_file() and not source.is_symlink()
        raw = source.read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], "Compiled cache changed"
        assert str(relative) not in payloads
        total += len(raw)
        assert len(payloads) < 256 and total <= 32 * 1024**2
        payloads[str(relative)] = raw
    assert payloads and total == manifest["bytes"]
    return payloads


def stage(manifest, scratch, logical_roots):
    assert not scratch.exists() and not scratch.is_symlink()
    payloads = verified_payloads(manifest)
    rewritten = []
    for relative, raw in list(payloads.items()):
        path = Path(relative)
        if path.parts[0] != "triton" or not path.name.startswith("__grp__"):
            continue
        group = json.loads(raw)
        assert set(group) == {"child_paths"} and isinstance(group["child_paths"], dict)
        for name, old_path in group["child_paths"].items():
            assert Path(name).name == name
            suffix = Path(old_path).relative_to(Path(manifest["roots"]["triton"]))
            assert "triton/" + str(suffix) in payloads
            assert suffix.parent == Path(*path.parts[1:]).parent
            assert suffix.name == name
            group["child_paths"][name] = str(logical_roots["triton"] / suffix)
        payloads[relative] = (json.dumps(group, sort_keys=True) + "\n").encode()
        rewritten.append(relative)
    scratch.mkdir(mode=0o700)
    digests = {}
    for relative, raw in payloads.items():
        target = scratch / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(raw)
        assert target.read_bytes() == raw
        digests[relative] = sha(raw)
    return {"files": len(payloads), "bytes": sum(map(len, payloads.values())),
            "rewritten_group_paths_only": rewritten, "staged_sha256": digests}


def install(run):
    import h20_runtime_binding_v1 as binding

    binding.host()
    assert run.parent == D / "teacher/runs" and run.name != OLD_RUN
    assert not (run / "foreground_started.json").exists()
    context = json.loads((run / "CONTEXT_001.json").read_bytes())
    assert context["execution_owner"] == OWNER and context["task"] == "general_pickup"
    assert context["native_total_steps"] == 200 and context["native_wall_seconds"] == 2400
    assert os.environ["CUDA_VISIBLE_DEVICES"] == "0,1"
    assert os.environ["NVIDIA_VISIBLE_DEVICES"] == ",".join(binding.UUIDS)
    manifest = json.loads(MANIFEST.read_bytes())
    assert manifest["execution_owner"] == OWNER and manifest["source_run"] == OLD_RUN
    assert manifest["owned_processes_closed"] and not manifest["scientific_state_reused"]
    for row in manifest["software"]:
        assert sha(Path(row["path"]).read_bytes()) == row["sha256"], "Compiled-cache software changed"
    mounts = Path("/proc/self/mountinfo").read_text().splitlines()
    assert any(row.split()[4] == "/tmp" and row.split(" - ", 1)[1].split()[0] == "tmpfs"
               for row in mounts)
    space = os.statvfs("/tmp")
    assert space.f_bavail * space.f_frsize > 128 * 1024**2
    roots = {"triton": run / "runtime/cache/triton", "cuda": run / "runtime/home/.nv"}
    for path in roots.values():
        assert not path.exists() and not path.is_symlink()
    scratch = Path("/tmp") / ("refate-policy-cache-" + run.name)
    result = stage(manifest, scratch, roots)
    for kind, path in roots.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.symlink_to(scratch / kind, target_is_directory=True)
        assert path.resolve() == (scratch / kind).resolve()
    result.update(
        execution_owner=OWNER, run_id=run.name,
        manifest={"path": str(MANIFEST), "sha256": sha(MANIFEST.read_bytes())},
        source_run=OLD_RUN, original_caches_modified=False,
        scientific_state_reused=False, model_or_rng_changed=False,
        timeout_changed=False, actual_latency_benefit_verified=False)
    with (run / "POLICY_COMPILED_CACHE_ADOPTION_001.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result

