"""Content-v6 teacher Native with matched release013 device and asset bindings."""
from pathlib import Path
import sys
import h20_teacher_binding_v3 as binding
import native_init_evidence_v1 as evidence

if __name__ == "__main__":
    context = Path(sys.argv[sys.argv.index("--context") + 1])
    evidence.install(binding.execution.node, context.parent)
    raise SystemExit(binding.native.main())

