"""Resource closure for the observed zero-control, pre-actor identity error."""
SOURCE = "put_bottles_into_dustbin_b0_l31_e96af0f6b935aa36"
RUN = "c2_put_bottles_into_dustbin_l31_evo_common_teacher_0001_01a16807"
NATIVE_SHA = "2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376"


def verified(context, failure, artifacts, native_sha):
    return bool(
        isinstance(context, dict) and isinstance(failure, dict)
        and context.get("source_id") == failure.get("source_id") == SOURCE
        and context.get("run_id") == failure.get("run_id") == RUN
        and context.get("task") == "put_bottles_into_dustbin"
        and context.get("native_limit") == 700 and context.get("t1") == 33
        and failure.get("type") == "ValueError"
        and failure.get("message") == "Original full source identity differs"
        and failure.get("stage") == "before_native"
        and type(failure.get("native_used")) is int and failure["native_used"] == 0
        and type(failure.get("actual_control_steps")) is int and failure["actual_control_steps"] == 0
        and failure.get("native_success") is False and failure.get("native_done") is False
        and failure.get("qualified") is False and native_sha == NATIVE_SHA
        and isinstance(artifacts, dict) and len(artifacts) == 7
        and {key.rsplit("/", 1)[-1] for key in artifacts} == {
            "agent", "oci", "runtime", "actual_t1_verified.json", "teacher_ready.json",
            "teacher_first_native_action.json", "result.json"}
        and all(value is False for value in artifacts.values())
    )
