"""Reuse the owned per-run storage binder for unstarted Fasten L7 only."""
from pathlib import Path

path = Path(__file__).with_name("place_prepared_stack_shared_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_stack_blocks_by_language_l([2-6])_h20_baseline_(000[3-7])_01a16807",
     "c2_fasten_screws_l(7)_h20_baseline_(0001)_01a16807"),
    ("int(match[2]) == int(match[1]) + 1", "int(match[1]) == 7 and int(match[2]) == 1"),
    ('prepared["source"]["task"] == "stack_blocks_by_language"',
     'prepared["source"]["task"] == "fasten_screws"'),
    ('prepared["native_step_limit"] == 400', 'prepared["native_step_limit"] == 1900'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Fasten_prepared_metadata_only", "exec"), globals())
