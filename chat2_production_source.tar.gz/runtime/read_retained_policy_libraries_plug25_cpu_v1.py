"""Bounded read-only library diagnosis; prior mapping is not a current capture."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("read_observed_policy_libraries_cpu_v1.py")
    text = path.read_text()
    for old, new in (
        ('run = "c2_sweep_blocks_l2_h20_baseline_0003_01a16807"',
         'run = "c2_plug_in_charger_l25_h20_baseline_0026_01a16807"'),
        ('evidence = root / "MAIN_FIRST_PREDICTION_WAIT_001.json"',
         'evidence = binding.D / "teacher/runs/c2_sweep_blocks_l2_h20_baseline_0003_01a16807/MAIN_FIRST_PREDICTION_WAIT_001.json"'),
        ("SWEEP_L2_MAPPED_LIBRARY_READ_CPU_001.json",
         "PLUG_L25_RETAINED_LIBRARY_READ_CPU_001.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    old = '    selected = [Path(p) for p in paths if p.startswith(prefix)]'
    assert text.count(old) == 1
    text = text.replace(old, '''
    policy = json.loads((root / "owned_policy.json").read_bytes())
    assert policy["command"][0] == prefix + "bin/python"
    assert closed["primary_failure_preserved"] and closed["model_request_default_seconds"] == 120
''' + old, 1)
    old = '    with target.open("x") as stream:'
    assert text.count(old) == 1
    return text.replace(old, '''
    value.update(
        current_closed_source=run,
        current_interruption_ref={
            "path": str(root / "MAIN_INTERRUPTION_SETTLEMENT_001.json"),
            "sha256": hashlib.sha256((root / "MAIN_INTERRUPTION_SETTLEMENT_001.json").read_bytes()).hexdigest(),
        },
        selected_from_prior_policy_mapping=True,
        current_policy_mapping_captured=False,
        prediction_latency_fixed=False,
        new_DM_source_authorized=False,
        current_teacher_controlled=False,
    )
''' + old, 1)


if __name__ == "__main__":
    import sys

    def deny_live(event, args):
        if ((event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname")
                or event in ("os.system", "os.exec", "os.posix_spawn", "os.fork",
                             "os.kill", "os.killpg")):
            raise RuntimeError("Read-only CPU diagnosis attempted a live external effect")

    sys.addaudithook(deny_live)
    exec(compile(source(), __file__ + "::read_only_current_closed_source", "exec"), globals())
