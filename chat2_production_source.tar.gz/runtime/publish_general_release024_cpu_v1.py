"""Reuse release023 core and the existing General200 cache entry without execution."""
import datetime
import hashlib
import json
from pathlib import Path

import h20_container_binding_v10 as binding
import prelaunch_general_cache_tmpfs_v6 as entry

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_023.json"
assert ref(old)["sha256"] == "a3626ccccde3b53c6abcc01ba46c0ef06355b4eaada4a74cee05877d825d252e"
release = json.loads(old.read_bytes())
text = entry.source()
compile(text, "CPU_General200_existing_entry", "exec")
assert 'ENTRY = D / "runtime/collect_h20_container_v11.py"' in text
assert 'value["native_total_steps"] == 200' in text
assert 'value["native_wall_seconds"] == 2400' in text
assert "policy_cache_seed_h20_v2.install(run)" in text
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_general_revisit_release=ref(old),
    prelaunch_entry=ref(d / "runtime/prelaunch_general_cache_tmpfs_v6.py"),
    actual_adoption=False,
    change_scope="Use existing General200 prelaunch6 with unchanged release023 core, "
    "context13, collector11, Native8, policy2, cache2 and paired content/RNG readers. "
    "No scientific state reuse, new model, renderer change, timeout change or qualification.",
)
assert release["native_wall_seconds"] == 2400 and release["teacher_wall_seconds"] == 3600
assert release["physical_gpus"] == [1, 7]
assert release["context_builder"]["path"].endswith("bind_h20_container_context_v13.py")
assert any(pin == release["prelaunch_entry"] for pin in release["runtime_files"])
path = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_024.json"
with path.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(release=ref(path), prelaunch=release["prelaunch_entry"],
                      core_unchanged=True, model_calls=False, gpu_calls=False,
                      simulator_calls=False, actual_adoption=False)))
