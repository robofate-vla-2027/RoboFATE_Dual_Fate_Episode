"""Same compiled-cache installation for the original laptop800 context."""
from policy_cache_seed_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "general_pickup"',
         'context["task"] == "store_laptop_and_headphones"'),
        ('context["native_total_steps"] == 200', 'context["native_total_steps"] == 800'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::laptop800_original_budget", "exec"), namespace)
    return namespace["install"](run)
