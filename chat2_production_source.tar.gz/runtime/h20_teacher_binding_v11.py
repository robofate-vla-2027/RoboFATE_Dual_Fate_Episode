"""Matched future teacher with address-only migrated causal-history views."""
from pathlib import Path
import sys

path = Path(__file__).with_name("h20_teacher_binding_v10.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v10"', '"native_teacher_h20_v11"'),
    ('"collect_teacher_h20_v10"', '"collect_teacher_h20_v11"'),
    ('"prepare_teacher_h20_v10"', '"prepare_teacher_h20_v11"'),
    ('"_refate_h20_teacher_native_scope_v10"', '"_refate_h20_teacher_native_scope_v11"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::causal_history_storage", "exec"), globals())

from teacher_causal_history_storage_h20_v1 import install
install(sys.modules[__name__])
assert collection.native is preparation.native_shared_teacher is native
