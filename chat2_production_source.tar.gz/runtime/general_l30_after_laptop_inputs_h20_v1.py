"""Original General source export, with the actual Laptop resource predecessor."""
from general_next_inputs_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("assert index == 26", "assert index == 30"),
        ("c2_classify_objects_l32_evo_common_teacher_0001_01a16807",
         "c2_store_laptop_and_headphones_l0_evo_common_teacher_0001_01a16807"),
        ("MAIN_TERMINAL_OBSERVATION_001.json", "MAIN_RESOURCE_ABSENCE_001.json"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_017.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261108_024.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::existing_General30_boundary", "exec"), globals())
