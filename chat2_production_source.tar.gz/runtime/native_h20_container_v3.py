"""Same Native loop and diagnostics with the relocated Conveyor extension."""
from pathlib import Path
import sys
import h20_container_binding_v5 as binding
import native_init_evidence_v1 as evidence

if __name__ == "__main__":
    context = Path(sys.argv[sys.argv.index("--context") + 1])
    evidence.install(binding.node, context.parent)
    raise SystemExit(binding.baseline_module.main())
