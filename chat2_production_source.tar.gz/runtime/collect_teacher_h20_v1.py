"""Original teacher collector; fixed provider route on a private H20 port."""
import h20_teacher_binding_v1 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())
