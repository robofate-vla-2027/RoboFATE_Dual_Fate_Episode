"""Use the original measured-device observer for the future teacher binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_start_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v2") == 1
text = text.replace("h20_teacher_binding_v2", "h20_teacher_binding_v3")
exec(compile(text, str(path) + "::frozen_v3_source", "exec"), globals())

