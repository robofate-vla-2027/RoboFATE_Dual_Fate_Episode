"""Matched future teacher entries; original v8 behavior plus Stack400 catalog."""
from pathlib import Path
import sys
import h20_teacher_storage_stack_v1 as stack_storage

# The frozen assembly imports this compatibility name inside its generated source.
# Only this new process is rebound; no frozen file or running process is changed.
sys.modules["h20_teacher_storage_v2"] = stack_storage
path = Path(__file__).with_name("h20_teacher_binding_v8.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v8"', '"native_teacher_h20_v9"'),
    ('"collect_teacher_h20_v8"', '"collect_teacher_h20_v9"'),
    ('"prepare_teacher_h20_v8"', '"prepare_teacher_h20_v9"'),
    ('"_refate_h20_teacher_native_scope_v8"', '"_refate_h20_teacher_native_scope_v9"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::stack400_catalog", "exec"), globals())
assert storage is stack_storage
assert collection.native is preparation.native_shared_teacher is native
