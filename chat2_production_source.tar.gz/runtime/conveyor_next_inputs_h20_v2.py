"""Original complete-predecessor boundary checks for Conveyor L19/release038."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_next_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ("mode == \"inputs\" and index == 18", "mode == \"inputs\" and index == 19"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_034.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Conveyor19_same_boundary_checks", "exec"), globals())
