"""Export only existing pure accounting code for its required Mac-side execution."""
import ast
import base64
import hashlib
import inspect
import json
from pathlib import Path
import h20_teacher_binding_v2 as binding
import shared_teacher_ledger_cli_v12 as cli
import teacher_ledger_owner_handoff_v5 as owner
import teacher_settle_handoff_v7 as settlement
import collection_group_ledger_compat_v1 as groups

binding.execution.previous.host()


def function(text, name):
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(text, node) + "\n"


def packet(raw):
    if isinstance(raw, str):
        raw = raw.encode()
    return {"sha256": hashlib.sha256(raw).hexdigest(),
            "raw_b64": base64.b64encode(raw).decode()}


base = owner.BASE.read_bytes()
assert hashlib.sha256(base).hexdigest() == owner.BASE_SHA
settle_text = settlement.source()
offset = settle_text.index("def current_stats(")
pins = []
for node in ast.parse(settle_text[:offset]).body:
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
        call = node.value
        if ast.unparse(call.func) == "cli.r.document":
            pins.append(ast.literal_eval(call.args[0]))
assert pins
code = {
    "cli_compute": function(cli._TEXT, "compute"),
    "transaction_compute": function(cli._text, "compute"),
    "publication_verdict": inspect.getsource(cli._prior._publication_verdict),
    "refresh_latest": inspect.getsource(cli._view._refresh_latest),
    "owner_apply_commit": function(owner._TEXT, "apply_commit"),
    "collection_group_guard": inspect.getsource(groups.guard),
    "ledger_contract": base,
    "settlement_body": settle_text[offset:],
}
result = {
    "schema": "refate.chat2.local_accounting_code_bundle.v1",
    "execution_owner": binding.execution.OWNER,
    "source_host": "h20_8", "source_root": str(binding.execution.A),
    "purpose": "Original accounting executes on Mac under original ledger lock/CAS.",
    "ledger_included": False, "scientific_payload_included": False,
    "model_or_simulator_called": False,
    "sources": {name: packet(raw) for name, raw in code.items()},
    "bindings": owner._BINDINGS, "teacher": owner.TEACHER, "ref_keys": sorted(owner.KEYS),
    "base_contract_sha256": owner.BASE_SHA,
    "collection_group_task": groups.TASK, "collection_group_split": groups.SPLIT,
    "accounting_release_pins": pins,
    "accounting_release_documents": [
        {"ref": pin, **packet(binding.storage.runtime.read_pin(pin))} for pin in pins],
}
path = binding.execution.D / "migration/LOCAL_TEACHER_ACCOUNTING_CODE_001.json"
with path.open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
