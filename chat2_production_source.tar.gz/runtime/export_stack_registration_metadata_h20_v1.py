"""Export only the existing Stack L7 metadata for local locked registration."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("export_bottles_registration_metadata_h20_v1.py").read_text()
    for old, new in (
        ("assert index == 34", "assert index == 7"),
        ("put_bottles_into_dustbin", "stack_blocks_by_language"),
        ('teacher / "preparations/CONFIGURED_SOURCE_REGISTRATION_V2_CPU_001.json"',
         'host.D / "runtime/STACK_APPEND_PROFILE_CPU_001.json"'),
        ('teacher / "preparations/configured_source_registration_v2_20261031.py"',
         'host.D / "runtime/configured_stack_source_registration_h20_v1.py"'),
    ):
        assert text.count(old) >= 1
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Stack7_metadata_only", "exec"), globals())
