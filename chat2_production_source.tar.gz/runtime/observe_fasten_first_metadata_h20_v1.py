"""Existing partial metadata observer for Fasten1900 and paired release029."""
from pathlib import Path

path = Path(__file__).with_name("observe_swap_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_swap_T_l[0-6]_h20_baseline_[0-9]{4}_01a16807",
     "c2_fasten_screws_l7_h20_baseline_0001_01a16807"),
    ('start["native_budget"] == 400', 'start["native_budget"] == 1900'),
    ("native_total=400", "native_total=1900"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_025.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_029.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Fasten_metadata_only", "exec"), globals())
