"""Teacher011 accounting export with a scoped, hash-pinned report allowance."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("export_teacher_settlement_metadata_h20_v1.py")
    text = path.read_text()
    for old, new in (
        ("import h20_teacher_binding_v3 as binding",
         "import h20_teacher_binding_v11 as binding\n"
         "from settlement_readback_transport_v1 import read_settlement_pin"),
        ("documents = {}", "documents = {}\nreadback_pin = None"),
        ("raw = binding.storage.runtime.read_pin(pin)",
         "raw = read_settlement_pin(pin, readback_pin, run, binding.storage.runtime.read_pin)"),
        ('assert summary == terminal["summary"]',
         'assert summary == terminal["summary"]\n'
         'readback_pin = summary.get("readback_ref") if summary["qualified_positive"] else None'),
        ("LOCAL_SETTLEMENT_METADATA_001.json", "LOCAL_SETTLEMENT_METADATA_002.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::scoped_report_transport", "exec"), globals())
