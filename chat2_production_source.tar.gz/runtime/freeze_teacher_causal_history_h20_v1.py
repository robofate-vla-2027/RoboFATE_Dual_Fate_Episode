"""CPU-only causal prefix check and immutable future teacher release."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace


def deny_live_effects(event, args):
    if event in {"socket.__new__", "subprocess.Popen", "os.system", "os.posix_spawn",
                 "os.kill", "os.killpg"}:
        raise RuntimeError("CPU history check forbids real peer/process effects")


sys.addaudithook(deny_live_effects)
import h20_teacher_binding_v11 as teacher
from teacher_causal_history_storage_h20_v1 import NEW, OLD, RUNS

teacher.execution.previous.host()
D = teacher.execution.D
source = NEW / RUNS[0]
history = teacher.native.common_teacher


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


before = {name: ref(source/name) for name in ("native_actions.jsonl", "native_observations.jsonl")}
decoded_folders = []


def folder_path(root, index):
    return root / ("initial" if index == 0 else f"macro_obs_{index:06d}")


def mocked_decode(folder):
    assert folder.is_dir()
    decoded_folders.append(str(folder))
    return {"synthetic_image_decode": True}


public = history.public_observation
history.public_observation = lambda observation, policy: observation
try:
    result = history.load_causal_history(
        source_run=str(source), t1=43, budget=1100,
        core_modules={
            "collect_source": SimpleNamespace(recorded_observation_path=folder_path),
            "observation_io": SimpleNamespace(decode_observation=mocked_decode),
        },
        policy_observation=None,
    )
finally:
    history.public_observation = public
assert len(result) == 44
assert [row["native_step"] for row in result] == list(range(44))
assert decoded_folders == [str(folder_path(source, i)) for i in range(44)]
assert before == {name: ref(source/name) for name in before}
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
assert getattr(history._read_prefix, "_refate_history_storage_v1", False)
assert hashlib.sha256(teacher._text.encode()).hexdigest() == (
    "f1e14823fd6c21b4d136dc1689fe03c8847b650d519518301c00f433b3f484e2"
)
cpu = save(D/"migration/TEACHER_CAUSAL_HISTORY_STORAGE_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "actual_saved_prefix_metadata_with_synthetic_image_decoder_CPU_only",
    "source_run": str(source), "historical_run": str(OLD/RUNS[0]),
    "t1": 43, "original_native_total": 1100, "observations_checked": 44,
    "original_DM_actions_checked": 43, "original_prefix_files": before,
    "original_files_unchanged": True, "causal_cutoff_unchanged": True,
    "matched_teacher_entries": True, "RGB_decoded": 0,
    "real_model_API_or_simulator_called": False, "new_scientific_samples": 0,
    "prior_L24_failure_remains_failed": True, "L24_restart_authorized_by_test": False,
})
prior = D/"runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_010.json"
assert ref(prior)["sha256"] == "e0905105f64f0bb223b7f2ddf59305a37c6eeb3a5e9ab6874946780b7194c0c7"
release = json.loads(prior.read_bytes())
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
for name in (
    "teacher_causal_history_storage_h20_v1.py", "h20_teacher_binding_v11.py",
    "native_teacher_h20_v11.py", "collect_teacher_h20_v11.py",
    "prepare_teacher_h20_v11.py", "prepare_teacher_metadata_h20_v12.py",
    "launch_bound_teacher_release011.sh", "freeze_teacher_causal_history_h20_v1.py",
):
    pin = ref(D/"runtime"/name)
    pins[pin["path"]] = pin
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_causal_history_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D/"runtime/collect_teacher_h20_v11.py"),
    native_entry=str(D/"runtime/native_teacher_h20_v11.py"),
    preparation_entry=str(D/"runtime/prepare_teacher_h20_v11.py"),
    launch_environment_binding=ref(D/"runtime/launch_bound_teacher_release011.sh"),
    causal_history_cpu=cpu, actual_adoption=False, actual_positive_published=False,
    change_scope="Reversible address-only views for two already byte-verified retained "
                 "history files; preserve original causal checks, RGB, physics, teacher, "
                 "budgets and failed attempts. No L24 retry implied.")
output = save(D/"runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_011.json", release)
print(json.dumps({
    "teacher_release": output, "cpu": cpu, "actual_adoption": False,
    "baseline_release": ref(D/"runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"),
}))
