"""Next original General source after the closed cache mapping interruption."""
from general_l28_cache_inputs_h20_v1 import source as previous_source


def cache_mapping_checks(terminal):
    assert terminal["schema"] == "refate.actual_interrupted_baseline.v1"
    assert terminal["run_id"] == "c2_general_pickup_l28_h20_baseline_0001_01a16807"
    assert terminal["safe_for_next_simulator"] and terminal["policy_model_ready"]
    assert terminal["last_actual_executed_tick"] == 0
    assert terminal["native_terminal"] is terminal["native_success"] is False
    assert "failed to map segment from shared object" in terminal["failure_detail"]["message"]
    assert terminal["final_reset_completed"] is True and terminal["source_retry_allowed"] is False


def source():
    text = previous_source()
    for old, new in (
        ("assert index == 28", "assert index == 29"),
        ("late_prediction_checks(terminal)", "cache_mapping_checks(terminal)"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_020.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_021.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General29_original_sequence", "exec"), globals())
