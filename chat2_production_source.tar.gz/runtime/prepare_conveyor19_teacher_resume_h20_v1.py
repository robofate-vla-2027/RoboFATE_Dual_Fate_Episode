"""Resume metadata preparation after a failed local-listener connectivity check."""

SELECTION = (
    "/data/refate_chat2_20261106_01a19072/teacher/preparations/"
    "CONVEYOR_L19_EVO_T10_PREPARATION_001.json"
)
SELECTION_SHA = "13d876082c6d2cff4e7bba34a686f1645b52d3b5ad7ccc2ef915a0c346439262"


def resume_source(text):
    old = "def write(p,d):\n"
    assert text.count(old) == 1
    new = (
        "def write(p,d):\n"
        f" if str(p)=={SELECTION!r}:\n"
        f"  pin=r.ref(p);assert pin['sha256']=={SELECTION_SHA!r}\n"
        "  saved=r.document(pin)\n"
        "  assert saved['source_id']=='pick_from_conveyor_by_image_b0_l19_817ea42961adec26'\n"
        "  assert saved['t1']==10 and saved['remaining_steps']==690\n"
        "  assert saved['teacher_started'] is saved['qualified'] is False\n"
        "  assert {k:v for k,v in saved.items() if k!='at'}=="
        "{k:v for k,v in d.items() if k!='at'}\n"
        "  return pin\n"
    )
    return text.replace(old, new, 1)


def main():
    import prepare_teacher_metadata_h20_v16 as metadata

    original = metadata.previous.source
    metadata.previous.source = lambda: resume_source(original())
    metadata.previous.__dict__["_metadata_task_totals"] = dict(metadata.catalog.TASK_TOTALS)
    exec(compile(metadata.main_source(), __file__ + "::reuse_pinned_preparation_only", "exec"),
         metadata.previous.__dict__)
    metadata.previous.main()


if __name__ == "__main__":
    main()
