"""Future process-only SwapT catalog binding; retain all teacher012 repairs."""
from pathlib import Path
import sys
import h20_teacher_storage_swap_v1 as swap_storage

sys.modules["h20_teacher_storage_stack_v1"] = swap_storage
path = Path(__file__).with_name("h20_teacher_binding_v11.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v11"', '"native_teacher_h20_v13"'),
    ('"collect_teacher_h20_v11"', '"collect_teacher_h20_v13"'),
    ('"prepare_teacher_h20_v11"', '"prepare_teacher_h20_v13"'),
    ('"_refate_h20_teacher_native_scope_v11"', '"_refate_h20_teacher_native_scope_v13"'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::swap_catalog_only", "exec"), globals())
assert storage is swap_storage
assert collection.native is preparation.native_shared_teacher is native
