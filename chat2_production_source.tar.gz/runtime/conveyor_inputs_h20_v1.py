"""Gather bounded source and real admission metadata; never start a simulator."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import h20_runtime_binding_v1 as binding

D, A = binding.D, binding.A
index = int(sys.argv[1])


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


release_path = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_010.json"
release = json.loads(release_path.read_bytes())
prepared_path = A.parent / f"preparations/CONVEYOR_L{index}_COMMON_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
split = Path(prepared["provenance"]["split"]["path"])
assert ref(split) == prepared["provenance"]["split"]
resource = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": "20250103-instance", "allocation": binding.allocation(),
    "memory": binding.memory_headroom(120), "native_started": False,
    "disk": subprocess.check_output(["df", "-PB1", str(D), str(A)], text=True),
}
resource_path = D / f"migration/H20_CONVEYOR_L{index}_RESOURCE_001.json"
with resource_path.open("x") as stream:
    json.dump(resource, stream, indent=2)
storage_path = D / "migration/CONVEYOR_L11_STORAGE_BINDING_001.json"
print(json.dumps({
    "release_ref": ref(release_path), "resource_ref": ref(resource_path),
    "resource": resource, "cpu_ref": release["cpu_check"],
    "preparation_ref": ref(prepared_path), "preparation": prepared,
    "manifest_ref": ref(split), "manifest": json.loads(split.read_bytes()),
    "storage_binding_ref": ref(storage_path),
    "storage_binding": json.loads(storage_path.read_bytes()),
    "native_extension_pins": release["native_extension_pins"],
    "run_id": f"c2_pick_from_conveyor_by_image_l{index}_h20_baseline_{index+1:04d}_01a16807",
    "foreground_entry": release["foreground_entry"], "native_started": False,
}))
