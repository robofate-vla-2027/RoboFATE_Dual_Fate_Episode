"""Future process-only Laptop catalog binding; retain all teacher011 repairs."""
from pathlib import Path
import sys
import h20_teacher_storage_laptop_v1 as laptop_storage

# Only this new process resolves the assembly's compatibility name differently.
sys.modules["h20_teacher_storage_stack_v1"] = laptop_storage
path = Path(__file__).with_name("h20_teacher_binding_v11.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v11"', '"native_teacher_h20_v12"'),
    ('"collect_teacher_h20_v11"', '"collect_teacher_h20_v12"'),
    ('"prepare_teacher_h20_v11"', '"prepare_teacher_h20_v12"'),
    ('"_refate_h20_teacher_native_scope_v11"', '"_refate_h20_teacher_native_scope_v12"'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::laptop_catalog_only", "exec"), globals())
assert storage is laptop_storage
assert collection.native is preparation.native_shared_teacher is native
