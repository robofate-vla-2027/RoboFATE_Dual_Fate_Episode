"""Original settlement metadata export through the matching future binding."""
from pathlib import Path

path = Path(__file__).with_name("export_teacher009_settlement_metadata_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v9") == 1
exec(compile(text.replace("h20_teacher_binding_v9", "h20_teacher_binding_v10"),
             str(path) + "::classify_storage", "exec"), globals())
