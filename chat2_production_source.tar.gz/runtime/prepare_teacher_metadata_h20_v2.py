"""Prepare future teacher metadata through the exact-code-scope release."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v2", "h20_teacher_binding_v3"),
    ("RUNTIME_H20_CHAT2_TEACHER_20261106_001.json",
     "RUNTIME_H20_CHAT2_TEACHER_20261106_002.json"),
    ("collect_teacher_h20_v2.py", "collect_teacher_h20_v3.py"),
):
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::exact_code_scope", "exec"), globals())

