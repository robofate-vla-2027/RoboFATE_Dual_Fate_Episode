"""Reuse exact saved-readback export for the H20-local retained Dolls L25."""
from pathlib import Path

path = Path(__file__).with_name("export_retained_bottles_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v7", "h20_teacher_binding_v14"),
    ("from h20_retained_bottles_storage_v1 import OLD_RUN, SOURCE_ID",
     'OLD_RUN = Path("/data/refate_chat2_20261106_01a19072/teacher/runs/'
     'c2_sort_nesting_dolls_by_size_l25_h20_baseline_0026_01a16807")\n'
     'SOURCE_ID = "sort_nesting_dolls_by_size_b0_l25_42c18e07761ce859"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::retained_h20_dolls25", "exec"), globals())

