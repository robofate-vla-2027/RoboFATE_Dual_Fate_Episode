"""Parameterize only the layout of the existing byte-pinned metadata export."""
from pathlib import Path
import sys

index = int(sys.argv[1])
assert 16 <= index < 28
path = Path(__file__).with_name("dolls_h20_metadata_bundle_v1.py")
text = path.read_text()
for old, new in (
    ("range(7, 16)", f"range(7, {index+1})"),
    ("L15", f"L{index}"),
):
    assert old in text
    text = text.replace(old, new)
exec(compile(text, str(path) + f"::DollsL{index}_metadata_only", "exec"),
     {"__name__": "__main__", "__file__": __file__})
