"""Translate only metadata storage locations after original byte/hash checks."""
from types import SimpleNamespace

import h20_container_binding_v5 as execution
import insert_sequence_handoff_v1 as handoff
import source_sequence_binding as sequence

handoff.install()
MAPPINGS = (
    ("/mnt/workspace/users/maxiangkai/projects/ReFATE", str(execution.previous.PROJECT)),
    ("/vla/mxk/projects/Robodojo", str(execution.NATIVE)),
    ("/mnt/workspace/datasets/robodojo/Assets", str(sequence.ASSETS)),
)


def locations(value, *, inverse=False):
    if isinstance(value, dict):
        return {key: locations(item, inverse=inverse) for key, item in value.items()}
    if isinstance(value, list):
        return [locations(item, inverse=inverse) for item in value]
    if isinstance(value, str):
        for old, new in MAPPINGS:
            if inverse:
                old, new = new, old
            if value == old or value.startswith(old + "/"):
                return new + value[len(old):]
    return value


original_helpers = sequence._helpers


def storage_helpers():
    history, common, order, scene = original_helpers()

    def decode(raw):
        data = common.decode(raw)
        # Raw layouts are never translated: their actual bytes define the source.
        if isinstance(data, dict) and str(data.get("schema", "")).startswith("refate."):
            mapped = locations(data)
            execution.need(locations(mapped, inverse=True) == data,
                           "Metadata storage mapping is not reversible")
            return mapped
        return data

    return history, SimpleNamespace(decode=decode, raw_order=common.raw_order), order, scene


sequence._helpers = storage_helpers
