"""Offline Plug400 binding checks; no model, API, simulator or ledger."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if (event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname") or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline binding check attempted a live external effect")


sys.addaudithook(deny_live)
import h20_container_binding_v10 as binding
import policy_cache_seed_play_h20_v1 as prior_cache
import policy_cache_seed_plug_h20_v1 as cache
import prelaunch_play_policy_cache_h20_v1 as prior_launch
import prelaunch_plug_policy_cache_h20_v1 as launch

binding.previous.host()
D = binding.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_035.json"
assert ref(prior)["sha256"] == "35fde998c5749af0fb68e71ede220de03f393fcaf4aa34b87b33fa8d71929ca3"
assert cache.source() == prior_cache.source().replace(
    'context["task"] == "play_stacking_toy"',
    'context["task"] == "plug_in_charger"', 1
).replace('context["native_total_steps"] == 1200', 'context["native_total_steps"] == 400', 1)
assert launch.source() == prior_launch.source().replace(
    "policy_cache_seed_play_h20_v1", "policy_cache_seed_plug_h20_v1", 2
).replace(
    "c2_play_stacking_toy_l18_h20_baseline_0019_01a16807",
    "c2_plug_in_charger_l25_h20_baseline_0026_01a16807", 1
).replace('value["native_total_steps"] == 1200', 'value["native_total_steps"] == 400', 1)
compile(cache.source(), "offline_Plug400_cache_source", "exec")
compile(launch.source(), "offline_Plug25_prelaunch_source", "exec")
preparation = binding.A / "task_sources/plug_in_charger/PREPARATION_L25_APPEND_001.json"
assert ref(preparation)["sha256"] == "cecfa7bbf507b80d95749d1e3bdfb4c9cf5173a6f857fd1ab99af290fa7688d1"
prepared = json.loads(preparation.read_bytes())
raw_layout = binding.foreground.baseline.source_sequence_binding.load_native_layout(prepared)
assert raw_layout == json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes())
assert prepared["native_step_limit"] == 400 and prepared["source"]["layout_id"] == 25
assert prepared["source"]["source_sequence"] == list(range(26))
assert prepared["source"]["required_accounted_prefix"] == list(range(25))
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = save(D / "migration/PLUG_L25_CACHE_BINDING_CPU_001.json", {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 5, "task_only_cache_source_equality": True,
    "task_only_prelaunch_source_equality": True, "frozen_source_order_retained": True,
    "actual_installed_loader_passed": True, "raw_layout_unchanged": True,
    "model_API_simulator_calls": 0, "source_preparation": ref(preparation),
    "preparation": ref(preparation), "native_budget": 400,
    "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "actual_Plug_L25_launch_verified": False, "reservation_or_launch_authority": False,
})
release["runtime_files"].extend(ref(D / "runtime" / name) for name in (
    "policy_cache_seed_plug_h20_v1.py", "prelaunch_plug_policy_cache_h20_v1.py",
    "publish_plug_release036_cpu_v1.py",
))
release.update(
    at=at, prior_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_plug_policy_cache_h20_v1.py"),
    plug_cache_cpu=cpu, actual_adoption=False,
    change_scope="Plug L25/native400 task and run binding only. Preserve collector11, "
                 "Native8, writable compiled cache, content/RNG/readers, model, RTX and timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_036.json", release)
print(json.dumps({"release": output, "CPU": cpu, "actual_adoption": False}))
