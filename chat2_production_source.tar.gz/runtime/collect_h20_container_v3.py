"""Existing collector with the original RTX layer and private graphics libraries."""
import argparse
import json
from pathlib import Path
import h20_container_binding_v3 as binding
import collect_insert_sequence_content_v1 as original

original.core.foreground = binding.foreground
original.core.finish = binding.finish
if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--context", type=Path, required=True)
    p.add_argument("--sha256", required=True)
    p.add_argument("--settle-only", action="store_true")
    a = p.parse_args()
    result = original.collect(a.context, a.sha256, settle_only=a.settle_only)
    print(json.dumps(result, indent=2), flush=True)
    if result["bridge_status"] == "failed" or result["readback_error"] is not None:
        raise SystemExit(1)

