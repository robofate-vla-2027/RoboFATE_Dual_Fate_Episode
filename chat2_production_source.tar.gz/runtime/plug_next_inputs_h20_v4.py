"""Resolve the existing Plug inputs with release036 and preserved predecessors."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("plug_next_inputs_h20_v1.py")
    code = path.read_text()
    old = 'exec(compile(text, str(path) + "::plug_original_boundary", "exec"), globals())'
    assert code.count(old) == 1
    scope = {"__file__": str(path)}
    exec(compile(code.replace(old, "resolved_source = text", 1),
                 str(path) + "::resolve_only", "exec"), scope)
    text = scope["resolved_source"]
    for old, new in (
        ("h20_container_binding_v8", "h20_container_binding_v10"),
        ("PLUG_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json",
         "PLUG_L{index}_CACHE_BINDING_CPU_001.json"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_014.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261108_036.json"),
        ("collect_h20_container_v9.py", "collect_h20_container_v11.py"),
        ('assert mode in ("check", "inputs") and 23 <= index < 53',
         'assert mode == "inputs" and index == 25'),
        ("run.mkdir()",
         "run.mkdir()\nresource.update(run_id=run_id, source_id=prepared['source']['source_id'])"),
        ('"last_teacher_settlement": None,',
         '"last_teacher_settlement": (terminal["summary_ref"] '
         'if resource_kind == "closed_teacher_resource_v1" '
         'and terminal["source_id"] == source_predecessor["source_id"] else None),'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    old = 'assert cpu["preparation"] == ref(prepared_path) and cpu["actual_installed_loader_passed"]'
    assert text.count(old) == 1
    text = text.replace(
        old, old + '\nassert cpu["native_budget"] == prepared["native_step_limit"] == 400', 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::release036_inputs", "exec"), globals())
