"""CPU-only source binding and immutable future teacher release."""
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import sys


def deny_live_effects(event, args):
    if event in {"socket.__new__", "subprocess.Popen", "os.system", "os.posix_spawn"}:
        raise RuntimeError("CPU source-binding check forbids real peer/process launches")


sys.addaudithook(deny_live_effects)
import h20_teacher_binding_v10 as teacher
import failure_summary_report_size_v1 as failure
from h20_retained_classify_storage_v1 import RUN, OLD_RUN, SOURCE_ID, D

teacher.execution.previous.host()
r = teacher.preparation.restore


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


summary = failure.project(r.ref(RUN / "readback_once_001/SUMMARY.json"))
context, manifest = (r.ref(RUN / name)
                     for name in ("CONTEXT_001.json", "SOURCE_MANIFEST_001.json"))
assert context["path"] == str(OLD_RUN / "CONTEXT_001.json")
material = r.source_material(context, manifest, summary, t1=43)
assert material["source_id"] == SOURCE_ID and material["native_limit"] == 1100
assert material["profile"]["remaining_native_steps"] == 1057
assert material["source"] == str(RUN)
with (RUN / "native_actions.jsonl").open() as stream:
    actions = [json.loads(line) for line in itertools.islice(stream, 47)]
values = [a["action"]["left_ee_joint_state"][0] for a in actions[40:47]]
assert all(value > .99 for value in values[:3])
assert values[3] < .99 and values[5] < values[3]
assert actions[42]["native_count_after"] == 43
import teacher_catalog_stack_h20_v1 as catalog
assert catalog.load_native_layout(material["source_preparation"])
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
assert hashlib.sha256(teacher._text.encode()).hexdigest() == (
    "f1e14823fd6c21b4d136dc1689fe03c8847b650d519518301c00f433b3f484e2"
)
cpu = save(D / "migration/CLASSIFY_L24_MIGRATED_ENTRY_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "actual_source_metadata_CPU_only_not_restore_or_simulation",
    "source_id": SOURCE_ID, "source_context": context, "source_manifest": manifest,
    "projected_first_readback": summary, "t1": 43, "remaining_steps": 1057,
    "original_native_total": 1100, "left_gripper_indices40_46": values,
    "matched_teacher_entries": True, "raw_layout_unchanged": True,
    "source_baseline_rerun": False, "full_RGB_decode": False,
    "actual_restore_verified": False, "API_or_model_called": False,
    "qualified_samples": 0,
})
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_009.json"
assert ref(prior)["sha256"] == (
    "0a7e12a590e5d7a854d69962f81394083bf7957be1eb20bc303e29175c4ba895"
)
release = json.loads(prior.read_bytes())
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
for name in (
    "h20_classify_metadata_storage_v1.py",
    "h20_retained_classify_storage_v1.py", "h20_teacher_binding_v10.py",
    "native_teacher_h20_v10.py", "collect_teacher_h20_v10.py",
    "prepare_teacher_h20_v10.py", "prepare_teacher_metadata_h20_v11.py",
    "launch_bound_teacher_release010.sh", "freeze_retained_classify_teacher_h20_v1.py",
):
    pin = ref(D / "runtime" / name)
    pins[pin["path"]] = pin
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_retained_source_storage_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v10.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v10.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v10.py"),
    launch_environment_binding=ref(D / "runtime/launch_bound_teacher_release010.sh"),
    retained_source_cpu=cpu, actual_adoption=False, actual_positive_published=False,
    change_scope="One byte-verified Classify L24 source path binding only; "
                 "Bottles projection and Stack catalog preserved. Original source identity, "
                 "RGB, state, action, renderer, scoring, budget and teacher unchanged.")
output = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_010.json", release)
print(json.dumps({"teacher_release": output, "cpu": cpu, "actual_adoption": False}))
