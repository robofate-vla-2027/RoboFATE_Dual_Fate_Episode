"""Actual start observer using the original recorder and explicit H20 binding."""
from pathlib import Path
import h20_runtime_binding_v1 as binding

binding.host()
path = Path(__file__).with_name("baseline_start_handoff_v1.py")
text = path.read_text()
text = binding.edit(
    text,
    "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs",
    str(binding.D / "teacher/runs"),
)
text = binding.edit(text, "'physical_policy_gpu':0,'physical_simulation_gpu':1",
                    "'physical_policy_gpu':1,'physical_simulation_gpu':7")
text = binding.edit(
    text, "with p.open('x') as f:",
    """ready=json.loads((r/'server/model_ready.json').read_bytes())
policy=json.loads((r/'owned_policy.json').read_bytes())['identity']
assert ready['pid']==policy['pid'] and ready['physical_gpu']==1 and ready['container_cuda_device']==0
import subprocess
gpu_rows=[line.split(',') for line in subprocess.check_output(
    ['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True).splitlines()]
actual={str(i['pid']):[{'gpu_uuid':v[1].strip(),'used_memory_mib':v[2].strip()}
    for v in gpu_rows if int(v[0].strip())==i['pid']] for i in (ident,policy)}
assert binding.UUIDS[1] in [v['gpu_uuid'] for v in actual[str(pid)]]
assert binding.UUIDS[0] in [v['gpu_uuid'] for v in actual[str(policy['pid'])]]
assert all(v['gpu_uuid'] in binding.UUIDS for rows in actual.values() for v in rows)
d.update(execution_target={'ssh_alias':'h20_8','physical_gpus':[1,7],
    'container_cuda_to_physical':{'0':1,'1':7}},actual_gpu_processes=actual,
    policy_identity=policy,policy_model_ready_ref={'path':str(r/'server/model_ready.json'),
    'sha256':hashlib.sha256((r/'server/model_ready.json').read_bytes()).hexdigest()})
with p.open('x') as f:""",
)
exec(compile(text, str(path) + "::h20_gpu1_7", "exec"), globals())
