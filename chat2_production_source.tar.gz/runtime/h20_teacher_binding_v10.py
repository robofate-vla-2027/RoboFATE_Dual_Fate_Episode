"""Future matched teacher entries with the one retained Classify source."""
from pathlib import Path
import sys

path = Path(__file__).with_name("h20_teacher_binding_v9.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v9"', '"native_teacher_h20_v10"'),
    ('"collect_teacher_h20_v9"', '"collect_teacher_h20_v10"'),
    ('"prepare_teacher_h20_v9"', '"prepare_teacher_h20_v10"'),
    ('"_refate_h20_teacher_native_scope_v9"', '"_refate_h20_teacher_native_scope_v10"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::retained_classify_storage", "exec"), globals())

from h20_classify_metadata_storage_v1 import install_runtime
from h20_retained_classify_storage_v1 import install
install_runtime()
install(sys.modules[__name__])
