"""Recognize the verified pre-replay metadata failure only for resource closure."""
from pathlib import Path

NATIVE_SHA = "48e97cd2d6dfabd2d053dae56c4628226074f28221aa1cf560363f7748cfd93d"


def metadata_scope_pre_actor(context, failure, comparison, artifacts, source_sha):
    if source_sha != NATIVE_SHA or comparison is not None:
        return False
    if not isinstance(failure, dict) or not isinstance(artifacts, dict):
        return False
    if len(artifacts) != 7 or any(v is not False for v in artifacts.values()):
        return False
    if not (type(context.get("t1")) is int and type(context.get("native_limit")) is int
            and 0 < context["t1"] < context["native_limit"]
            and context.get("remaining_steps") == context["native_limit"] - context["t1"]):
        return False
    expected = dict(
        source_id=context.get("source_id"), run_id=context.get("run_id"),
        type="RuntimeError", message="Noncanonical/out-of-scope metadata",
        stage="initial_boundary_saved", native_used=0, actual_control_steps=0,
        native_success=False, native_done=False, qualified=False,
        provider_retry_allowed=False)
    return all(type(failure.get(k)) is type(v) and failure.get(k) == v for k, v in expected.items())


def source():
    path = Path(__file__).with_name("observe_teacher_terminal_h20_v1.py")
    text = path.read_text()
    old = 'exec(compile(text, str(Path(original.__file__)) + "::actual_h20_source", "exec"), globals())'
    assert text.count(old) == 1
    extra = """
text = execution.edit(
    text,
    "pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha) or pre_aux",
    "pre_metadata=metadata_scope_pre_actor(c,failure,comparison,artifacts,native_source_sha)\\n"
    "pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha) or pre_aux or pre_metadata")
text = execution.edit(
    text, "p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json');",
    "d['actor_role_observation']['pre_replay_metadata_scope_failure_verified']=pre_metadata\\n"
    "p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json');")
"""
    return text.replace(old, extra + "\n" + old)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::pre_replay_resource_observation", "exec"), globals())
