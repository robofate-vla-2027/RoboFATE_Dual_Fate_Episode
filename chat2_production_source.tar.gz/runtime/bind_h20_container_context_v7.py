"""Same paired v6 Native binding, with the diagnostic-only v7 collector."""
from pathlib import Path

path = Path(__file__).with_name("bind_h20_container_context_v1.py")
text = path.read_text()
for old, new, count in (
    ("h20_container_binding_v1", "h20_container_binding_v6", 1),
    ("collect_h20_container_v1", "collect_h20_container_v7", 2),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::readonly_memory_diagnostics", "exec"), globals())
