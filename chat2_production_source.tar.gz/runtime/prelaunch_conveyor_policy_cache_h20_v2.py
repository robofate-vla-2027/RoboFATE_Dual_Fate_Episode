"""Original Conveyor700 prelaunch, restricted to the next prepared L19."""
from prelaunch_conveyor_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = "c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_pick_from_conveyor_by_image_l19_h20_baseline_0020_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Conveyor19_original_collector", "exec"), globals())
