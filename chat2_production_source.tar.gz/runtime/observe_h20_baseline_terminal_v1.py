"""Reuse the actual saved readback; never decode the trajectory again."""
from pathlib import Path
import h20_runtime_binding_v1 as binding

binding.host()
path = Path(__file__).with_name("baseline_terminal_handoff_v1.py")
text = path.read_text()
for old, new in (
    ("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026",
     str(binding.A)),
    ("/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs",
     str(binding.D / "teacher/runs")),
    ("import collect_recording_content_v1 as collection", "import collect_h20_container_v4 as collection"),
    ("fg=collection.core.foreground", "fg=collection.binding.foreground"),
):
    text = binding.edit(text, old, new)
exec(compile(text, str(path) + "::h20_saved_readback", "exec"), globals())
