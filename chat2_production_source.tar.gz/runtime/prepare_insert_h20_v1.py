"""Bind original Insert preparation to the current owned prior publication."""
import hashlib
import io
import json
from pathlib import Path
import re
import sys

import h20_container_binding_v7 as binding
import prepare_insert_sequence_handoff_v1 as original

binding.host()
layout, prior_id = int(sys.argv[1]), sys.argv[2]
assert re.fullmatch(r"c2_insert_tubes_l\d+_h20_baseline_\d{4}_01a16807", prior_id)
prior = binding.D / "teacher/runs" / prior_id
dispatch = json.loads((prior / "DISPATCH_001.json").read_bytes())
assert dispatch["task"] == "insert_tubes" and dispatch["execution_owner"] == binding.OWNER


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


split = dispatch["split_manifest"]
assert ref(Path(split["path"])) == split
sequence = ref(prior / "SEQUENCE_EXTENSION_001.json")
raw = binding.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/insert_tubes_{layout}.json"
assert 8 <= layout < 53
sys.stdin = io.StringIO(json.dumps({
    "execution_owner": binding.OWNER, "task": "insert_tubes", "encoded_seed": layout,
    "expected_raw_sha256": ref(raw)["sha256"], "prior_split_ref": split,
    "prior_sequence_ref": sequence,
}))
original.main()
