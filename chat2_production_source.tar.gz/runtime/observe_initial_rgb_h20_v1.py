"""Check one saved initial RGB set; reuse its receipt without decoding again."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sys

import numpy as np
from PIL import Image


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    assert os.uname().nodename == "20250103-instance"
    assert os.environ["REFATE_SSH_ALIAS"] == "h20_8"
    owner = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
    assert os.environ["REFATE_EXECUTION_OWNER"] == owner
    run_id = sys.argv[1]
    assert re.fullmatch(r"c2_[a-z0-9_]+_h20_baseline_[0-9]{4}_01a16807", run_id)
    run = Path("/data/refate_chat2_20261106_01a19072/teacher/runs") / run_id
    context = ref(run / "CONTEXT_001.json")
    assert json.loads((run / "CONTEXT_001.json").read_bytes())["execution_owner"] == owner
    output = run / "MAIN_INITIAL_RGB_CHECK_001.json"
    if output.exists():
        saved = json.loads(output.read_bytes())
        assert saved["context"] == context and saved["run_id"] == run_id
        print(json.dumps(saved))
        return
    with (run / "native_observations.jsonl").open() as stream:
        boundary = json.loads(next(stream))
    assert boundary["index"] == boundary["control_index"] == 0
    initial = Path(boundary["observation_dir"])
    assert initial == run / "initial"
    metadata = json.loads((initial / "observation.json").read_bytes())
    stats = json.loads((initial / "image_stats.json").read_bytes())
    frames = []
    with np.load(initial / "arrays.npz", allow_pickle=False) as arrays:
        for camera in ("cam_head", "cam_left_wrist", "cam_right_wrist"):
            array = arrays[metadata["vision"][camera]["color"]["npz_key"]]
            with Image.open(initial / (camera + ".png")) as image:
                assert image.mode == "RGB" and image.size == (640, 480)
                png = np.asarray(image)
                assert array.shape == png.shape == (480, 640, 3)
                assert array.dtype == png.dtype == np.uint8
                assert np.array_equal(array, png)
            digest = hashlib.sha256(array.tobytes()).hexdigest()
            assert digest == stats[camera]["sha256"]
            constant = bool(float(array.std()) == 0.0)
            assert constant == stats[camera]["constant_pixel_values"]
            frames.append({
                "camera": camera, "shape": list(array.shape), "dtype": str(array.dtype),
                "raw_rgb_sha256": digest, "npz_png_equal": True,
                "constant_pixel_values": constant, "diagnostic_preserved": True,
            })
    contract = json.loads((run / "recording_contract.json").read_bytes())
    assert contract["visual_hz"] == 25 and contract["low_level_ticks_per_native"] == 10
    value = {
        "schema": "refate.actual_initial_rgb_check.v1",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "run_id": run_id, "context": context, "frames": frames,
        "scope": "One initial saved RGB set only, not a full trajectory qualification",
        "metadata": ref(initial / "observation.json"), "contract": contract,
        "actual_constant_frame_seen": any(row["constant_pixel_values"] for row in frames),
        "sample_qualified": False, "full_readback_repeated": False,
        "scientific_count_change": 0,
    }
    with output.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    print(json.dumps(value))


if __name__ == "__main__":
    main()
