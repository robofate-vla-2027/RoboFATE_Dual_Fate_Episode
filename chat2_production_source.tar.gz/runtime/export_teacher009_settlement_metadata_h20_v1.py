"""Export existing settlement metadata through the Stack400 teacher binding."""
from pathlib import Path

path = Path(__file__).with_name("export_teacher008_settlement_metadata_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v8") == 1
exec(compile(text.replace("h20_teacher_binding_v8", "h20_teacher_binding_v9"),
             str(path) + "::stack400", "exec"), globals())
