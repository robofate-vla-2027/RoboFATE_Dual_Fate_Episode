"""Existing metadata-only first-action observer for Bottles L35 on release038."""
from pathlib import Path

path = Path(__file__).with_name("observe_swap_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_swap_T_l[0-6]_h20_baseline_[0-9]{4}_01a16807",
     "c2_put_bottles_into_dustbin_l35_h20_baseline_0036_01a16807"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_025.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
    ('start["native_budget"] == 400', 'start["native_budget"] == 700'),
    ("native_total=400", "native_total=700"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Bottles35_metadata_only", "exec"), globals())
