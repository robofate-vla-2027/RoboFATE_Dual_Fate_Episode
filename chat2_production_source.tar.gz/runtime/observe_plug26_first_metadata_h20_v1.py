"""Existing metadata-only first-action observer for Plug L26 on release038."""
from pathlib import Path

path = Path(__file__).with_name("observe_swap_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_swap_T_l[0-6]_h20_baseline_[0-9]{4}_01a16807",
     "c2_plug_in_charger_l26_h20_baseline_0027_01a16807"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_025.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Plug26_metadata_only", "exec"), globals())
