"""Expose the original ffmpeg privately without changing Native video settings."""
import h20_container_binding_v3 as _prior
from h20_container_binding_v3 import *

_text = _prior._text


def environment(run, reference):
    policy, native = _prior.environment(run, reference)
    native["PATH"] = str(D / "runtime/ffmpeg_bin") + ":" + native["PATH"]
    return policy, native


foreground.environment = environment
