#!/bin/bash
set -euo pipefail
umask 077
test "$(hostname)" = 20250103-instance
test "${REFATE_SSH_ALIAS-}" = h20_8
test "${REFATE_EXECUTION_OWNER-}" = 01a19072-9e5e-7e02-b77a-8f115cfc9bd0
D=/data/refate_chat2_20261106_01a19072
R=/vla/mxk/projects/ReFATE/coordination/20261106_chat2_h20_01a19072
B=/data/agent_rsi_validation_20261022_01a161cf
Q=$B/data/dual_fate/chat1_01a16338/dm05
IMAGE=sha256:6a4c9e60293b728751d23b916ad5aac4142e47751f2fde39fee1811ad56b176a
id=${1:?A unique CPU check or registered run ID is required}
shift
[[ "$id" =~ ^(cpu_container_[0-9]+|c2_[a-z0-9_]+_01a16807|c2_swap_T_l[0-6]_(h20_baseline|evo_common_teacher)_[0-9]{4}_01a16807)$ ]]
test "$#" -ge 1
name=refate-chat2-01a19072-$id
record=$D/container_records/$id
test ! -e "$record"
mkdir -p "$record"
export CUDA_VISIBLE_DEVICES=1,7
export NVIDIA_VISIBLE_DEVICES=GPU-d2150afd-372d-4c5f-de58-fb675e6ef7a9,GPU-b34ba2c2-7c64-ec8e-a6bd-83c10d3ff526
docker image inspect "$IMAGE" --format '{{.Id}}' > "$record/image.id"
test "$(cat "$record/image.id")" = "$IMAGE"
REFATE_CONTAINER_RECORD="$record" PYTHONPATH="$D/runtime" "$B/envs/native-thin/bin/python" - <<'PY'
import datetime, json, os
from pathlib import Path
import h20_runtime_binding_v1 as binding
r = Path(os.environ["REFATE_CONTAINER_RECORD"])
record = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": binding.OWNER, "hostname": os.uname().nodename,
    "allocation": binding.allocation(), "memory": binding.memory_headroom(120),
    "pid": os.getppid(), "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
}
record["launcher_start_ticks"] = int(Path(f"/proc/{record['pid']}/stat").read_text().rsplit(")", 1)[1].split()[19])
with (r/"host_admission.json").open("x") as f:
    json.dump(record, f, indent=2)
PY
# Restrict device nodes, preserve actual host identity/PIDs, and mount shared assets read-only.
set +e
docker run --name "$name" --cidfile "$record/container.cid" \
    --label refate.owner="$REFATE_EXECUTION_OWNER" --label refate.role=chat2 \
    --label refate.run="$id" --runtime=nvidia --gpus "\"device=$NVIDIA_VISIBLE_DEVICES\"" \
    --network=host --pid=host --uts=host --cap-drop=ALL \
    --security-opt=no-new-privileges --memory=480g --memory-swap=480g \
    --shm-size=8g --read-only --tmpfs /tmp:rw,size=8g \
    -e NVIDIA_VISIBLE_DEVICES -e NVIDIA_DRIVER_CAPABILITIES=all \
    -e CUDA_VISIBLE_DEVICES=0,1 -e REFATE_SSH_ALIAS -e REFATE_EXECUTION_OWNER \
    -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONUNBUFFERED=1 \
    -e PYTHONPATH="$D/runtime" \
    -e HOME="$D/runtime/container_home" \
    -v "$D:$D:rw" -v "$R/source_tree:$R/source_tree:ro" \
    -v "$B/envs/native-thin:$B/envs/native-thin:ro" \
    -v /mnt/demottt_h20_8_eval_20261012_isaac:/mnt/demottt_h20_8_eval_20261012_isaac:ro \
    -v "$Q/venv:$Q/venv:ro" -v "$Q/assets/DM05-MEM-Robodojo-Sim:$Q/assets/DM05-MEM-Robodojo-Sim:ro" \
    -v /vla/mxk/envs/fastwam:/vla/mxk/envs/fastwam:ro \
    -v "$B/assets/robodojo:$B/assets/robodojo:ro" \
    -v /usr/local/cuda-12.5:/usr/local/cuda-12.5:ro \
    -v /usr/share/nvidia/nvoptix.bin:/usr/share/nvidia/nvoptix.bin:ro \
    -v /etc/vulkan/icd.d/nvidia_icd.json:/etc/vulkan/icd.d/nvidia_icd.json:ro \
    -w "$D/native" "$IMAGE" "$@" > "$record/console.log" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$record/exit"
if test -s "$record/container.cid"; then
    docker inspect "$(cat "$record/container.cid")" > "$record/container.inspect.json"
fi
tail -n 28 "$record/console.log"
exit "$rc"
