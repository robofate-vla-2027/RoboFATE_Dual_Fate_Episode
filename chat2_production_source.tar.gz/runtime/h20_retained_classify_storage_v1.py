"""Reuse the migrated-source reader for Classify L24, retaining Bottles support."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("h20_retained_bottles_storage_v1.py")
    text = path.read_text()
    for old, new, count in (
        ("c2_put_bottles_into_dustbin_l31_common_baseline_0032_01a16807",
         "c2_classify_objects_l24_common_baseline_0001_01a16807", 1),
        ("put_bottles_into_dustbin_b0_l31_e96af0f6b935aa36",
         "classify_objects_b0_l24_d8c5a39d821b9898", 1),
        ("_refate_retained_bottles_v1", "_refate_retained_classify_v1", 2),
        ("bottles_audit_batch_020", "classify_audit_batch_023", 1),
        ("bottles_l31_batch_019", "classify_l24_batch_022", 1),
        ("len(inventory) == 6315", "len(inventory) == 9915", 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new)
    old = '''    failure.__dict__.update(_migrated_source_id=SOURCE_ID, _verify_migration=verify_migration)
    exec(compile(ast.Module(body=[node], type_ignores=[]),
                 __file__ + "::verified_source_copy_projection", "exec"), failure.__dict__)
'''
    new = '''    previous_project = failure.project
    namespace = dict(failure.__dict__)
    namespace.update(_migrated_source_id=SOURCE_ID, _verify_migration=verify_migration)
    exec(compile(ast.Module(body=[node], type_ignores=[]),
                 __file__ + "::verified_source_copy_projection", "exec"), namespace)
    classify_project = namespace["project"]

    def project(summary_ref):
        if runtime.document(runtime.read_pin(summary_ref)).get("source_id") == SOURCE_ID:
            return classify_project(summary_ref)
        return previous_project(summary_ref)

    failure.project = project
'''
    assert text.count(old) == 1
    return text.replace(old, new)


exec(compile(source(), __file__ + "::classify_l24_paths", "exec"), globals())
