"""Existing private policy cache restricted to the original Bottles700 task."""
from policy_cache_seed_plug_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "plug_in_charger"',
         'context["task"] == "put_bottles_into_dustbin"'),
        ('context["native_total_steps"] == 400',
         'context["native_total_steps"] == 700'),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    return text


def install(run):
    scope = {"__file__": __file__}
    exec(compile(source(), __file__ + "::Bottles700_cache_only", "exec"), scope)
    return scope["install"](run)
