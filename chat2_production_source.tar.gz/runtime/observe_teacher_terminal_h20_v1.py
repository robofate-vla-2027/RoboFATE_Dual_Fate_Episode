"""Reuse original teacher terminal/readback evidence with exact H20 source pins."""
import hashlib
from pathlib import Path
import h20_teacher_binding_v2 as binding
import teacher_terminal_handoff_v7 as original

execution = binding.execution
execution.previous.host()
text = original.source()
old = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher"
for before, after in (
    (old + "/perdon_adapter_20261026", str(execution.A)),
    (old + "/runs", str(execution.D / "teacher/runs")),
    ("import collect_teacher_content_v6 as collect", "collect = binding.collection"),
    ("hashlib.sha256(collect.native.text.encode()).hexdigest()",
     "hashlib.sha256(binding._text.encode()).hexdigest()"),
):
    text = execution.edit(text, before, after)
old_sha = "e9d1f23b5ae9dc931bc8615f2f163fc02e4ba0b7ed0564d2b9fc56ab52d0dcdb"
new_sha = hashlib.sha256(binding._text.encode()).hexdigest()
assert new_sha == "48e97cd2d6dfabd2d053dae56c4628226074f28221aa1cf560363f7748cfd93d"
text = execution.edit(text, old_sha, new_sha, count=2)
exec(compile(text, str(Path(original.__file__)) + "::actual_h20_source", "exec"), globals())
