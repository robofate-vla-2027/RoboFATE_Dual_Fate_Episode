"""Keep the exercised Stack400 cache and collector11 for original L7."""
from prelaunch_stack_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = r"c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_stack_blocks_by_language_l7_h20_baseline_0008_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Stack7_same_cache_and_collector", "exec"), globals())
