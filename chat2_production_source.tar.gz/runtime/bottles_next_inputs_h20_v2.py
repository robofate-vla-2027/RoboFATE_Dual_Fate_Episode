"""Keep the original source-order rule and use the repaired future binder."""
from pathlib import Path

path = Path(__file__).with_name("bottles_next_inputs_h20_v1.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261107_016.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261107_017.json")
exec(compile(text, str(path) + "::release017", "exec"), globals())
