"""Original Classify metadata export after the closed L38 loading interruption."""
from classify_next_inputs_h20_v2 import source as previous_source


RUN = "c2_classify_objects_l38_h20_baseline_0001_01a16807"


def loading_timeout_checks(terminal, run_id):
    assert run_id == terminal["run_id"] == RUN
    assert terminal["schema"] == "refate.actual_policy_startup_interruption.v1"
    assert terminal["safe_for_next_simulator"] is True
    assert terminal["native_process_started"] is True
    assert terminal["native_terminal"] is terminal["native_failure_proven"] is False
    assert terminal["policy_model_ready"] is False
    assert terminal["observations_committed"] == 1
    assert terminal["actual_controls_observed"] == 0
    assert terminal["new_positive"] == terminal["new_negative"] == 0
    assert terminal["reusable_DM_failure"] is terminal["source_retry_allowed"] is False
    assert terminal["loading_allowance_seconds"] == 900
    assert terminal["baseline_wall_seconds"] == 2400


def source():
    text = previous_source()
    changes = (
        ("(index, predecessor_index) == (38, 32)",
         "(index, predecessor_index) == (28, 38)"),
        ('resource_run_id == "c2_classify_objects_l32_evo_common_teacher_0001_01a16807"',
         'resource_run_id == ' + repr(RUN)),
        ('"MAIN_TERMINAL_OBSERVATION_001.json"',
         '"MAIN_INTERRUPTION_SETTLEMENT_001.json"'),
        ("teacher_checks(terminal, resource_run_id)",
         "loading_timeout_checks(terminal, resource_run_id)"),
        ('"teacher/runs/c2_classify_objects_l32_h20_baseline_0001_01a16807"',
         '"teacher/runs/' + RUN + '"'),
        ('prior / "MAIN_SETTLEMENT_001.json"',
         'prior / "MAIN_INTERRUPTION_SETTLEMENT_001.json"'),
        ('out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)',
         'asset_path = host.D / "migration/DM05_SEQUENTIAL_READ_20261107_001.json"\n'
         'out["asset_read_ref"] = ref(asset_path)\n'
         'out["asset_read"] = document(out["asset_read_ref"])\n'
         'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'),
    )
    for old, new in changes:
        count = 2 if old == 'prior / "MAIN_SETTLEMENT_001.json"' else 1
        assert text.count(old) == count, old
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L38_closed_interruption_L28", "exec"), globals())
