"""Frozen DM0.5 plus a single bounded diagnostic of its first real prediction."""
import hashlib
from pathlib import Path

path = Path(__file__).with_name("policy_h20_container_v1.py")
raw = path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == "28f8610c2f457d3ba46f14be20564f9a65efc3039aba21f91606e8f8f235fc89"
text = raw.decode()
old = "            actions = self._native_predict(payload)"
new = """            if query_id == 1:
                import faulthandler
                with Path(audit.name).with_name("first_prediction_stack.txt").open("x") as diagnostic:
                    faulthandler.dump_traceback_later(30, repeat=False, file=diagnostic)
                    try:
                        actions = self._native_predict(payload)
                    finally:
                        faulthandler.cancel_dump_traceback_later()
            else:
                actions = self._native_predict(payload)"""
assert text.count(old) == 1
text = text.replace(old, new, 1)
exec(compile(text, str(path) + "::first_prediction_diagnostic_only", "exec"), globals())

