"""Original Plug boundary inputs after the genuinely settled L25 interruption."""
from plug_next_inputs_h20_v4 import source as previous_source

PRIOR_SHA = "6e3263cfa803bda6d192694f38d229c9899dea3e42e290588398325f03d10b8a"


def validate_predecessor(value, digest):
    expected = {
        "schema": "refate.actual_interrupted_baseline.v1",
        "task": "plug_in_charger",
        "source_id": "plug_in_charger_b0_l25_9a7f44a82f87fd28",
        "run_id": "c2_plug_in_charger_l25_h20_baseline_0026_01a16807",
        "native_terminal": False, "native_success": False,
        "full_readback_passed": False, "reusable_DM_failure": False,
        "source_retry_allowed": False, "safe_for_next_simulator": True,
        "new_positive": 0, "new_negative": 0,
        "primary_failure_preserved": True, "baseline_wall_seconds": 2400,
        "source_started": True, "native_process_started": True,
    }
    assert digest == PRIOR_SHA
    assert all(type(value.get(k)) is type(v) and value[k] == v
               for k, v in expected.items())


def source():
    text = previous_source()
    for old, new in (
        ("RUNTIME_H20_CHAT2_CONTENT_20261108_036.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
        ('assert mode == "inputs" and index == 25',
         'assert mode in ("check", "inputs") and index == 26'),
        ('"native_total": 400', '"native_budget": 400'),
        ('physical_prior = host.D / "teacher/runs" / prior_id / "MAIN_SETTLEMENT_001.json"',
         'physical_prior = host.D / "teacher/runs" / prior_id / "MAIN_INTERRUPTION_SETTLEMENT_001.json"'),
        ('assert source_predecessor["first_readback_passed"] and source_predecessor["safe_for_next_simulator"]',
         'validate_predecessor(source_predecessor, ref(physical_prior)["sha256"])'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::settled_interruption_not_DM_failure", "exec"),
         globals())
