"""Original teacher metadata preparation paired with the Plug storage release."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v6.py")
text = path.read_text()
for old, new in (
    ("RUNTIME_H20_CHAT2_TEACHER_20261106_005.json", "RUNTIME_H20_CHAT2_TEACHER_20261107_006.json"),
    ("h20_teacher_binding_v5", "h20_teacher_binding_v6"),
    ("collect_teacher_h20_v5.py", "collect_teacher_h20_v6.py"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::plug_metadata_storage", "exec"), globals())
