"""Freeze paired future entries; no simulator, model, source reservation or CAS."""
import datetime
import hashlib
import json
from pathlib import Path

import collect_h20_container_v9 as collector
import bind_h20_container_context_v9 as binder

b = collector.binding
b.previous.host()
D = b.D
assert collector.original.core.foreground is binder.collection.core.foreground is b.foreground
assert "native_h20_container_v6.py" in b._text


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


import collection_append_binding_v1 as append
prepared_path = b.A / "task_sources/plug_in_charger/PREPARATION_L23_APPEND_001.json"
prepared = append.document(ref(prepared_path))
layout = append.load_native_layout(prepared)
assert prepared["native_step_limit"] == 400 and prepared["source"]["layout_id"] == 23

import h20_teacher_binding_v6 as teacher
import teacher_catalog_binding_v13 as catalog
assert catalog.load_native_layout(prepared) == layout
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
assert hashlib.sha256(teacher._text.encode()).hexdigest() == (
    "2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376")

cpu = save(D / "migration/PLUG_PAIRED_ENTRY_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "actual_metadata_CPU_only_not_simulation",
    "prepared": ref(prepared_path), "native_total": 400,
    "matched_baseline_collector_native_binder": True,
    "matched_teacher_collector_native_preparer": True,
    "metadata_decoder_shared": True, "raw_layout_unchanged": True,
    "native_model_API_calls": False, "qualified_samples": 0,
})


def freeze(prior_name, expected_sha, new_name, names, changes):
    prior = D / "runtime" / prior_name
    assert ref(prior)["sha256"] == expected_sha
    value = json.loads(prior.read_bytes())
    pins = {pin["path"]: pin for pin in value["runtime_files"]}
    for pin in pins.values():
        teacher.storage.runtime.read_pin(pin)
    for name in names:
        pin = ref(D / "runtime" / name)
        teacher.storage.runtime.read_pin(pin)
        pins[pin["path"]] = pin
    value.update(changes)
    value.update(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        prior_plug_storage_release=ref(prior), runtime_files=list(pins.values()),
        plug_metadata_cpu=cpu, actual_adoption=False, actual_positive_published=False,
        change_scope="Only Plug refate metadata path values are reversibly mapped "
                     "after original byte/hash checks; no raw layout/RGB, task, "
                     "physics, action, scoring, budget, source order or teacher change.")
    return save(D / "runtime" / new_name, value)


shared = ("h20_plug_metadata_storage_v1.py", "prepare_plug_h20_v1.py",
          "freeze_plug_h20_v1.py")
baseline = freeze(
    "RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
    "dc287094ba90c4823046cc10e6cbd2900ac7a954a805f00a1f9343fa79401e76",
    "RUNTIME_H20_CHAT2_CONTENT_20261107_014.json",
    shared + ("h20_container_binding_v8.py", "collect_h20_container_v9.py",
              "native_h20_container_v6.py", "bind_h20_container_context_v9.py"),
    {"foreground_entry": str(D / "runtime/collect_h20_container_v9.py"),
     "native_entry": str(D / "runtime/native_h20_container_v6.py"),
     "context_builder": ref(D / "runtime/bind_h20_container_context_v9.py"),
     "cpu_check": cpu})
teacher_release = freeze(
    "RUNTIME_H20_CHAT2_TEACHER_20261106_005.json",
    "37bb720ded2aa54d1e834eaa3799ed1e7df35ee9ad7a5bf5569f9d4f6225f0eb",
    "RUNTIME_H20_CHAT2_TEACHER_20261107_006.json",
    shared + ("h20_teacher_binding_v6.py", "collect_teacher_h20_v6.py",
              "native_teacher_h20_v6.py", "prepare_teacher_h20_v6.py",
              "prepare_teacher_metadata_h20_v7.py", "launch_bound_teacher_release006.sh"),
    {"foreground_entry": str(D / "runtime/collect_teacher_h20_v6.py"),
     "native_entry": str(D / "runtime/native_teacher_h20_v6.py"),
     "preparation_entry": str(D / "runtime/prepare_teacher_h20_v6.py"),
     "launch_environment_binding": ref(D / "runtime/launch_bound_teacher_release006.sh")})
print(json.dumps({"baseline_release": baseline, "teacher_release": teacher_release,
                  "cpu": cpu, "actual_adoption": False}))
