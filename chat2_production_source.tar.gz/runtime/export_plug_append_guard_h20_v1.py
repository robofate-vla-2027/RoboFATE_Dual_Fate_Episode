"""Export existing Plug metadata validation, without ledger or trajectory reads."""
import base64
import datetime
import hashlib
import json
from pathlib import Path
import sys

import h20_teacher_binding_v15 as teacher
import collection_append_ledger_compat_v1 as compat
from h20_insert_metadata_binding_v1 import locations, MAPPINGS

host = teacher.execution
host.previous.host()
request = json.load(sys.stdin)
assert request["source_id"] == "plug_in_charger_b0_l26_f78582b2268e95e6"
assert len(request["rows"]) <= 53
documents = {}
validated_preparations = []


def add(pin):
    raw = teacher.storage.runtime.read_pin(pin)
    assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
    mapped = locations(pin)
    value = locations(json.loads(raw))
    entry = {"ref": pin, "mapped_ref": mapped,
             "raw_b64": base64.b64encode(raw).decode()}
    if mapped["path"] in documents:
        assert documents[mapped["path"]] == entry
    documents[mapped["path"]] = entry
    return value


current = locations(request["current_split_ref"])
compat.binding.lineage(current)
here = current
lineage_refs = []
while True:
    assert len(lineage_refs) < 48 and here not in lineage_refs
    lineage_refs.append(here)
    manifest = add(here)
    if here == compat.binding.BASE_REF:
        break
    here = manifest["collection_append"]["prior_split"]

for row in request["rows"]:
    assert row["task"] == "plug_in_charger" and row["host"] == "perdon-hou"
    prepared = add(row["source_preparation_ref"])
    assert prepared["source"]["source_id"] == row["source_id"]
    assert prepared["source"]["group_id"] == request["group_id"]
    compat.binding.load_native_layout(prepared)
    validated_preparations.append(locations(row["source_preparation_ref"]))

record = {
    "schema": "refate.original_plug_append_guard_metadata.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_id": request["source_id"], "ledger_snapshot_revision": request["ledger_revision"],
    "group_id": request["group_id"], "mappings": MAPPINGS,
    "documents": list(documents.values()), "validated_preparations": validated_preparations,
    "validated_lineage_refs": lineage_refs, "current_split_ref": current,
    "base_ref": compat.binding.BASE_REF,
    "append_schema": compat.binding.SCHEMA,
    "original_schema": compat.previous.binding.SCHEMA,
    "sentinel": compat.binding.previous.SENTINEL,
    "ledger_read_or_written": False, "model_API_or_simulator_called": False,
    "RGB_decoded": False,
}
path = host.D / "migration/PLUG_L26_APPEND_GUARD_METADATA_001.json"
with path.open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record))
