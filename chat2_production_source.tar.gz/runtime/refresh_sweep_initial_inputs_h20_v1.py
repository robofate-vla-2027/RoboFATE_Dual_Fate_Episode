"""Refresh initial admission only; preserve all preparation and prior receipts."""
from sweep_initial_inputs_loading_h20_v1 import source as previous_source

text = previous_source()
for old, new in (
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", "RESOURCE_PRECHECK_002.json"),
    ("BOUNDARY_INPUTS_001.json", "BOUNDARY_INPUTS_002.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::fresh_admission_no_preparation_or_launch", "exec"), globals())
