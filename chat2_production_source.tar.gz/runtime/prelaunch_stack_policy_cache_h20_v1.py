"""Original Stack Kit cache, matched collector and private executable policy cache."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prelaunch_kit_cache_tmpfs_v1.py").read_text()
    for old, new in (
        ('ENTRY = D / "runtime/collect_h20_container_v10.py"',
         'ENTRY = D / "runtime/collect_h20_container_v11.py"'),
        ('    cache = place_cache(run, scratch)',
         '    cache = place_cache(run, scratch)\n'
         '    import policy_cache_seed_stack_h20_v1\n'
         '    policy_cache_seed_stack_h20_v1.install(run)'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Stack400_private_policy_cache", "exec"), globals())
