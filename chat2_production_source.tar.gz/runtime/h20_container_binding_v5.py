"""Bind the byte-identical installed Conveyor extension at its H20 path."""
import h20_container_binding_v4 as _prior
from h20_container_binding_v4 import *
import native_extension_binding as extensions

extensions.ROOT = Path("/mnt/demottt_h20_8_eval_20261012_isaac/lib/python3.11/site-packages/isaacsim/exts/isaacsim.asset.gen.conveyor")
extensions.HERE = A / "h20_conveyor_extension_20261106"
_text = edit(_prior._text, str(D / "runtime/native_h20_container_v2.py"),
             str(D / "runtime/native_h20_container_v3.py"))
foreground = previous.load_source("_refate_h20_container_v5_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "POLICY", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))
