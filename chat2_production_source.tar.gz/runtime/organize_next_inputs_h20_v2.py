"""Existing ordered Organize boundary export, retaining the collector11 core."""
from pathlib import Path

path = Path(__file__).with_name("organize_next_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_033.json"),
    ("collect_h20_container_v8.py", "collect_h20_container_v11.py"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Organize_release033", "exec"), globals())
