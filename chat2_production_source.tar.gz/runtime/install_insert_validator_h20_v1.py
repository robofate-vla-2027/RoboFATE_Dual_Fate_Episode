"""Apply the same byte-preserving installer to the frozen validator closure."""
from pathlib import Path

path = Path(__file__).with_name("install_insert_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("insert_metadata_batch_011", "insert_validator_batch_012"),
    ("INSERT_METADATA_VERIFICATION_001", "INSERT_VALIDATOR_VERIFICATION_001"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::frozen_validator_dependencies", "exec"), globals())
