"""Existing metadata workflow with only the Sweep tag and matching entries."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v14.py")
text = path.read_text()
for old, new, count in (
    ("h20_teacher_binding_v13", "h20_teacher_binding_v14", 1),
    ("RUNTIME_H20_CHAT2_TEACHER_20261108_013.json",
     "RUNTIME_H20_CHAT2_TEACHER_20261108_014.json", 1),
    ("collect_teacher_h20_v13.py", "collect_teacher_h20_v14.py", 1),
    ("teacher_catalog_swap_h20_v1", "teacher_catalog_sweep_h20_v1", 1),
    ("'swap_T':'SWAPT'}", "'swap_T':'SWAPT','sweep_blocks':'SWEEP'}", 1),
):
    assert text.count(old) == count, old
    text = text.replace(old, new, count)
exec(compile(text, __file__ + "::sweep1000_metadata", "exec"), globals())
