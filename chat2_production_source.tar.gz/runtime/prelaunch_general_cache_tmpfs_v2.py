"""Same General cache placement for future unsealed sequence members."""
from prelaunch_general_cache_tmpfs_v1 import source as previous_source


def source():
    text = previous_source()
    old = r"c2_general_pickup_l26_h20_baseline_0001_01a16807"
    new = r"c2_general_pickup_l(?:2[7-9]|[34][0-9]|5[0-2])_h20_baseline_0001_01a16807"
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General_future_same_cache", "exec"), globals())
