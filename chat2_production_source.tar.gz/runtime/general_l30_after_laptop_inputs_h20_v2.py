"""Use General L29's actual interruption settlement, never a fabricated baseline end."""
from general_l30_after_laptop_inputs_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = 'prior_settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")'
    assert text.count(old) == 2
    text = text.replace(old, 'prior_settlement_ref = ref(prior / "MAIN_INTERRUPTION_SETTLEMENT_001.json")')
    old = 'assert document(prior_settlement_ref)["source_id"] == old["source_id"]'
    new = '''prior_terminal = document(prior_settlement_ref)
assert prior_terminal["source_id"] == old["source_id"]
assert prior_terminal["schema"] == "refate.actual_interrupted_baseline.v1"
assert prior_terminal["native_terminal"] is False
assert prior_terminal["native_success"] is False
assert prior_terminal["safe_for_next_simulator"] is True'''
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::actual_prior_interruption", "exec"), globals())
