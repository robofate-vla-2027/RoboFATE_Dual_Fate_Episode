"""Publish only a future Sweep1000 task/cache binding; keep production core frozen."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import unittest
import h20_container_binding_v10 as binding

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_025.json"
assert ref(old)["sha256"] == "7aa0632b627d198f45091eef142c3bd89939b7e5de7e775300264a29c6e11a53"
release = json.loads(old.read_bytes())
assert release["native_wall_seconds"] == 2400 and release["teacher_wall_seconds"] == 3600
assert ref(Path(release["container_launcher"]["path"])) == release["container_launcher"]
assert re.fullmatch(r"c2_[a-z0-9_]+_01a16807", "c2_sweep_blocks_l0_h20_baseline_0001_01a16807")
import test_sweep_cache_context_cpu_v2 as tests

log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 4
cpu = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    data_kind="synthetic_CPU_Sweep1000_context_not_scientific_data",
    synthetic_tests_passed=4, tests=log.getvalue(), task="sweep_blocks",
    native_total_steps=1000, baseline_wall_seconds=2400, teacher_wall_seconds=3600,
    model_loading_allowance_seconds=900, model_request_timeout_seconds=120,
    compiled_cache_logic_unchanged=True, model_calls=False, gpu_execution_calls=False,
    simulator_calls=False, actual_model_prediction_verified=False, actual_adoption=False,
    initial_preparation=ref(d / "migration/SWEEP_L0_PREPARATION_CPU_001.json"),
    container_launcher_unchanged=True,
    failed_initial_test_preserved="test_sweep_cache_context_cpu_v1.py",
)
cp = d / "migration/SWEEP_COMPILED_CACHE_CONTEXT_CPU_001.json"
with cp.open("x") as f:
    json.dump(cpu, f, indent=2)
    f.write("\n")
release.update(
    at=cpu["at"], prior_sweep_cache_release=ref(old), sweep_cache_cpu=ref(cp),
    prelaunch_entry=ref(d / "runtime/prelaunch_sweep_policy_cache_h20_v1.py"),
    actual_adoption=False,
    change_scope="Sweep original1000 budget and explicit initial0..6 source names only. "
    "Identical compiled-cache copy and collector11/Native8/policy2/readers/context13/launcher5. "
    "No physics, renderer, model, RGB or wall-time change; no scientific state reuse.",
)
for name in ("policy_cache_seed_sweep_h20_v1.py", "prelaunch_sweep_policy_cache_h20_v1.py",
             "test_sweep_cache_context_cpu_v1.py", "test_sweep_cache_context_cpu_v2.py",
             "prepare_sweep_initial_h20_v1.py", "publish_sweep_release026_cpu_v1.py"):
    release["runtime_files"].append(ref(d / "runtime" / name))
path = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"
with path.open("x") as f:
    json.dump(release, f, indent=2)
    f.write("\n")
print(json.dumps(dict(release=ref(path), sweep_cache_cpu=ref(cp),
                     prelaunch=release["prelaunch_entry"], actual_adoption=False)))
