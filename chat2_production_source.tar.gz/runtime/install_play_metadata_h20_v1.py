"""Verify and install the transferred Play metadata without changing bytes."""
from pathlib import Path

path = Path(__file__).with_name("install_insert_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("insert_metadata_batch_011.manifest.json", "play_metadata_batch_017.manifest.json"),
    ("assert len(manifest) == 4", "assert len(manifest) == 41"),
    ("INSERT_METADATA_VERIFICATION_001.json", "PLAY_METADATA_VERIFICATION_001.json"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::play_verified_metadata", "exec"), globals())

