"""Read existing recording metadata only; never decode or qualify RGB here."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys
import h20_runtime_binding_v1 as binding

binding.host()
run = sys.argv[1]
assert re.fullmatch(r"c2_swap_T_l[0-6]_h20_baseline_[0-9]{4}_01a16807", run)
D = binding.D
R = D / "teacher/runs" / run
ref = lambda p: dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
load = lambda p: json.loads(p.read_bytes())
p = load(R / "recording_progress.json")
cam = load(R / "camera_000001.json")
contract = load(R / "recording_contract.json")
start_path = R / "ACTUAL_START_OBSERVATION_001.json"
start = load(start_path)
w = p["writer"]
assert start["physical_policy_gpu"] == 1 and start["physical_simulation_gpu"] == 7
assert start["native_budget"] == 400
mask = "GPU-d2150afd-372d-4c5f-de58-fb675e6ef7a9,GPU-b34ba2c2-7c64-ec8e-a6bd-83c10d3ff526"
assert cam["actual_gpu_uuid"] == mask
assert not w["failed"]
assert contract["visual_hz"] == 25 and contract["physical_dt_s"] == 0.004
assert contract["low_level_ticks_per_native"] == 10
shapes = {k: v["shape"] for k, v in cam["cameras"].items()}
assert len(shapes) == 3 and all(x == [480, 640, 3] for x in shapes.values())
assert p["low_level_controls"] == 10 * p["native_actions"]
assert p["actual_rgb_capture_sets"] == p["native_actions"] + 1
out = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    data_kind="actual_partial_normal_collection_not_full_qualification",
    run_id=run, source_id=start["source_id"], context=ref(R / "CONTEXT_001.json"),
    release=ref(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_025.json"),
    camera_metadata=ref(R / "camera_000001.json"), camera_metadata_gpu_mask=mask,
    actual_GPU_binding_evidence=ref(start_path), camera_shapes=shapes,
    native_actions=p["native_actions"], low_level_controls=p["low_level_controls"],
    submitted_observations=w["submitted_boundaries"],
    committed_observations=w["committed_boundaries"], writer_failed=w["failed"],
    native_total=400, baseline_wall_seconds=2400, teacher_wall_seconds=3600,
    recording_contract=ref(R / "recording_contract.json"), RGB_redecoded=False,
    full_readback_verified=False, scientific_quota_delta=0,
    real_constant_frame_scenario_verified=False,
)
path = R / "MAIN_FIRST_SEGMENT_OBSERVATION_001.json"
with path.open("x") as f:
    json.dump(out, f, indent=2)
    f.write("\n")
out["evidence_ref"] = ref(path)
print(json.dumps(out))
