"""Use the original teacher binding with the Sweep-only catalog extension."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v13.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_storage_swap_v1", "h20_teacher_storage_sweep_v1"),
    ('"native_teacher_h20_v13"', '"native_teacher_h20_v14"'),
    ('"collect_teacher_h20_v13"', '"collect_teacher_h20_v14"'),
    ('"prepare_teacher_h20_v13"', '"prepare_teacher_h20_v14"'),
    ('"_refate_h20_teacher_native_scope_v13"', '"_refate_h20_teacher_native_scope_v14"'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::sweep_catalog_only", "exec"), globals())
