"""Original actual-start observer with H20 paths and measured authorized devices."""
from pathlib import Path
import h20_teacher_binding_v2 as binding

execution = binding.execution
execution.previous.host()
path = execution.A / "teacher_start_observe_v1.py"
text = path.read_text()
text = execution.edit(
    text,
    "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs",
    str(execution.D / "teacher/runs"),
)
text = execution.edit(text, "physical_policy_gpu=0,physical_simulation_gpu=1",
                      "physical_policy_gpu=1,physical_simulation_gpu=7")
text = execution.edit(
    text, "with p.open('x') as f:",
    """import subprocess
rows = [line.split(',') for line in subprocess.check_output(
    ['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory',
     '--format=csv,noheader,nounits'],text=True).splitlines()]
actual = [{'gpu_uuid':v[1].strip(),'used_memory_mib':v[2].strip()}
          for v in rows if int(v[0].strip()) == pid]
assert execution.UUIDS[1] in [v['gpu_uuid'] for v in actual]
assert all(v['gpu_uuid'] in execution.UUIDS for v in actual)
d.update(execution_owner=execution.OWNER,execution_target={
    'ssh_alias':'h20_8','physical_gpus':[1,7],
    'container_cuda_to_physical':{'0':1,'1':7}},
    actual_gpu_processes={str(pid):actual})
with p.open('x') as f:""")
exec(compile(text, str(path) + "::h20_start_devices", "exec"), globals())
