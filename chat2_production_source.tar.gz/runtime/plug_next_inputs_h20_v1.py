"""Reuse actual H20 resource checks and the original Plug source predecessor."""
from pathlib import Path

path = Path(__file__).with_name("organize_next_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_container_binding_v7", "h20_container_binding_v8"),
    ('binding.A.parent / f"preparations/ORGANIZE_L{index}_COMMON_PREPARATION_001.json"',
     'binding.A / f"task_sources/plug_in_charger/PREPARATION_L{index}_APPEND_001.json"'),
    ("organize_table", "plug_in_charger"),
    ('prepared["native_step_limit"] == 1000', 'prepared["native_step_limit"] == 400'),
    ('"native_total": 1000', '"native_total": 400'),
    ("ORGANIZE_L{index}_PREPARATION_CPU_001.json", "PLUG_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json", "RUNTIME_H20_CHAT2_CONTENT_20261107_014.json"),
    ("collect_h20_container_v8.py", "collect_h20_container_v9.py"),
):
    assert old in text
    text = text.replace(old, new)
seam = 'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'
assert text.count(seam) == 1
text = text.replace(seam, '''
import base64
historical_root = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")
if index == 23:
    prior_id = "c2_plug_in_charger_l22_common_baseline_0023_01a16807"
    physical_prior = binding.A.parent / "runs" / prior_id / "MAIN_SETTLEMENT_001.json"
    source_predecessor_ref = ref(physical_prior)
    source_predecessor_ref["path"] = str(historical_root / physical_prior.relative_to(host.PROJECT))
else:
    prior_id = f"c2_plug_in_charger_l{index-1}_h20_baseline_{index:04d}_01a16807"
    physical_prior = host.D / "teacher/runs" / prior_id / "MAIN_SETTLEMENT_001.json"
    source_predecessor_ref = ref(physical_prior)
source_predecessor = json.loads(physical_prior.read_bytes())
assert source_predecessor["task"] == "plug_in_charger"
assert source_predecessor["first_readback_passed"] and source_predecessor["safe_for_next_simulator"]
resource_kind = ("closed_teacher_resource_v1" if "_evo_common_teacher_" in resource_run_id
                 else "closed_baseline_resource_v1")
boundary = {
    "schema": "refate.actual_boundary_preparation.v1", "at": resource["at"],
    "next_preparation": {"prepared": prepared, "ref": ref(prepared_path)},
    "resource_precheck": {"summary": resource, "ref": out["resource_ref"]},
    "settlement": {"source_id": source_predecessor["source_id"],
                   "settlement_ref": source_predecessor_ref, "safe_for_next_simulator": True},
    "last_teacher_settlement": None,
    "resource_predecessor": {
        "schema": resource_kind, "source_id": terminal["source_id"],
        "run_id": terminal["run_id"], "summary_ref": terminal["summary_ref"],
        "settlement_ref": ref(resource_path), "safe_for_next_simulator": True,
        "ref": ref(resource_path)},
    "runtime_release": ref(release_path),
    "metadata_adapter": ref(binding.A / "owner_reservation_handoff_v1.py"),
    "native_kit_extensions": [], "teacher_supplement_present": True,
}
out["boundary_ref"] = save(run / "MAIN_BOUNDARY_001.json", boundary)
out["boundary"] = boundary
out["release"] = release
documents = []
for pin in (out["boundary_ref"], ref(release_path), ref(prepared_path),
            ref(cpu_path), out["resource_ref"], ref(resource_path)):
    raw = Path(pin["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
    documents.append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
out["documents"] = documents
''' + seam)
exec(compile(text, str(path) + "::plug_original_boundary", "exec"), globals())
