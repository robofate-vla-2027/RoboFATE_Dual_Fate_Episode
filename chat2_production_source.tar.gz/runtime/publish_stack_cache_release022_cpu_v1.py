"""Pin the same cache implementation to Stack's original400-step entry."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest

import h20_container_binding_v10 as binding
import policy_cache_seed_h20_v2 as general
import policy_cache_seed_stack_h20_v1 as stack
import prelaunch_stack_policy_cache_h20_v1 as prelaunch
import test_stack_cache_context_cpu_v1 as tests

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
expected = general.source().replace('context["task"] == "general_pickup"',
                                    'context["task"] == "stack_blocks_by_language"')
expected = expected.replace('context["native_total_steps"] == 200',
                            'context["native_total_steps"] == 400')
assert stack.source() == expected
text = prelaunch.source()
compile(text, "CPU_Stack400_prelaunch", "exec")
assert 'value["native_total_steps"] == 400' in text
assert 'value["native_wall_seconds"] == 2400' in text
assert 'ENTRY = D / "runtime/collect_h20_container_v11.py"' in text
assert 'policy_cache_seed_stack_h20_v1.install(run)' in text
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 4
cpu = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
           data_kind="synthetic_CPU_Stack_context_only_not_scientific_data",
           synthetic_tests_passed=result.testsRun, tests=log.getvalue(),
           compiled_cache_logic_unchanged=True, task="stack_blocks_by_language",
           native_total_steps=400, baseline_wall_seconds=2400, teacher_wall_seconds=3600,
           model_loading_allowance_seconds=900, model_request_timeout_seconds=120,
           model_calls=False, gpu_calls=False, simulator_calls=False,
           actual_model_prediction_verified=False, latency_improvement_verified=False,
           mapping_cpu=ref(d / "migration/POLICY_COMPILED_CACHE_MAPPING_CPU_001.json"))
cp = d / "migration/STACK_COMPILED_CACHE_CONTEXT_CPU_001.json"
with cp.open("x") as stream:
    json.dump(cpu, stream, indent=2)
    stream.write("\n")
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_021.json"
release = json.loads(old.read_bytes())
release.update(at=cpu["at"], prior_stack_cache_release=ref(old), stack_cache_cpu=ref(cp),
               prelaunch_entry=ref(d / "runtime/prelaunch_stack_policy_cache_h20_v1.py"),
               actual_adoption=False,
               change_scope="Same executable private cache copy, restricted to original Stack400. "
               "Same collector/native/policy/readers and original budgets; no model or scientific-state changes.")
for name in ("policy_cache_seed_stack_h20_v1.py", "prelaunch_stack_policy_cache_h20_v1.py"):
    release["runtime_files"].append(ref(d / "runtime" / name))
new = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_022.json"
with new.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(release=ref(new), stack_cache_cpu=ref(cp),
                     prelaunch=release["prelaunch_entry"], actual_adoption=False)))
