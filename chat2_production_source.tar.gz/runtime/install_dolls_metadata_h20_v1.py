"""Install twenty transferred metadata files without changing their bytes."""
from pathlib import Path

path = Path(__file__).with_name("install_insert_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("insert_metadata_batch_011.manifest.json", "dolls_metadata_batch_015.manifest.json"),
    ("assert len(manifest) == 4", "assert len(manifest) == 20"),
    ("INSERT_METADATA_VERIFICATION_001.json", "DOLLS_METADATA_VERIFICATION_001.json"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::dolls_and_general_metadata", "exec"), globals())
