"""Freeze Sweep's catalog-only extension, preserving the previous release."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest
import h20_runtime_binding_v1 as host

host.host()
import test_teacher_sweep_binding_cpu_v1 as tests
import h20_teacher_binding_v14 as teacher
from teacher_history_pre_actor_catalog014_v1 import NATIVE_SHA

D = teacher.execution.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_013.json"
assert ref(prior)["sha256"] == "63cc9d8ce32e54ce7fbc9212839acaf82a74d4c71a2b6030fcb078fbb9644a5f"
release = json.loads(prior.read_bytes())
assert (release["model"], release["reasoning_effort"]) == ("gt-6-as-a", "xhigh")
assert release["teacher_wall_seconds"] == release["native_wall_seconds"] == 3600
assert release["baseline_wall_seconds_unchanged"] == 2400
native_sha = hashlib.sha256(teacher._text.encode()).hexdigest()
assert native_sha == NATIVE_SHA
pins = {p["path"]: p for p in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
old_launch = D / "runtime/launch_bound_teacher_release013.sh"
launch_text = old_launch.read_text()
assert launch_text.count("collect_teacher_h20_v13.py") == 1
new_launch = D / "runtime/launch_bound_teacher_release014.sh"
with new_launch.open("x") as stream:
    stream.write(launch_text.replace("collect_teacher_h20_v13.py", "collect_teacher_h20_v14.py"))
new_launch.chmod(0o700)
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(
    unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 6
names = (
    "teacher_catalog_sweep_h20_v1.py", "h20_teacher_storage_sweep_v1.py",
    "h20_teacher_binding_v14.py", "native_teacher_h20_v14.py",
    "collect_teacher_h20_v14.py", "prepare_teacher_h20_v14.py",
    "prepare_teacher_metadata_h20_v15.py", "teacher_history_pre_actor_catalog014_v1.py",
    "observe_teacher_terminal_h20_v17.py", "observe_teacher014_start_h20_v1.py",
    "observe_teacher014_first_h20_v1.py", "export_teacher014_settlement_metadata_h20_v1.py",
    "test_teacher_sweep_binding_cpu_v1.py", "freeze_teacher_sweep_catalog_h20_v1.py",
    "launch_bound_teacher_release014.sh",
)
for name in names:
    p = D / "runtime" / name
    if p.suffix == ".py":
        compile(p.read_text(), str(p), "exec")
    pins[str(p)] = ref(p)


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/SWEEP_TEACHER_CATALOG_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "CPU catalog/configuration only, not actual restoration or execution",
    "tests_passed": result.testsRun, "test_log": log.getvalue(),
    "task": "sweep_blocks", "original_native_total": 1000,
    "effective_native_source_sha256": native_sha, "matched_effective_entries": True,
    "real_t1_restoration_verified": False, "real_model_API_or_simulator_called": False,
    "new_scientific_samples": 0, "actual_adoption": False,
})
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_sweep_catalog_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v14.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v14.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v14.py"),
    metadata_preparation_entry=str(D / "runtime/prepare_teacher_metadata_h20_v15.py"),
    launch_environment_binding=ref(new_launch),
    matched_baseline=ref(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"),
    sweep_task_binding_cpu=cpu, effective_native_source_sha256=native_sha,
    actual_adoption=False, actual_teacher_takeover_verified=False,
    actual_positive_published=False, actual_sweep_teacher_execution_verified=False,
    change_scope="Add only original Sweep1000 catalog and matching future bindings; "
                 "preserve teacher013 repairs, data rules, source ownership, model, "
                 "physics, teacher3600/baseline2400 and every previous release.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_014.json", release)
print(json.dumps({"teacher_release": output, "cpu": cpu, "actual_adoption": False,
                  "baseline_release": release["matched_baseline"]}))
