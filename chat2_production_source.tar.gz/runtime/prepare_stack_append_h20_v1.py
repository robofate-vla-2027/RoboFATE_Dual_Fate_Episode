"""Bind the frozen monotonic preparer to Stack L7; no remote ledger writes."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import types

import h20_teacher_binding_v15 as runtime
from h20_insert_private_metadata_v1 import metadata_locations
import profiled_append_handoff_v1 as frozen

HELPER_SHA = "8704de2dc4f19553179f75e992e1857ed501b376393460055903a7884dee862d"
OLD_SHA = "43cfdaa52c79378d55cba09c25847b7620d1dc6938ea2053821088a1ac69e120"
execution = runtime.execution
execution.previous.host()
text = Path(frozen.__file__).read_text()
for old, new in (
    (OLD_SHA, HELPER_SHA),
    ("import configured_source_registration_v2_20261031 as metadata",
     "import configured_stack_source_registration_h20_v1 as metadata"),
):
    assert text.count(old) == 1
    text = text.replace(old, new, 1)
original = types.ModuleType("_stack_profiled_preparation_handoff")
original.__file__ = frozen.__file__
exec(compile(text, __file__ + "::original_handoff_with_Stack_profile", "exec"),
     original.__dict__)
old_root = str(original.ROOT)
original.ROOT = execution.A.parent
original.ADAPTER = execution.A
original.ARCHIVE = original.ROOT / original.ARCHIVE.relative_to(Path(old_root))
original.reused.ROOT = original.ROOT
original.reused.ADAPTER = original.ADAPTER
sys.path.insert(0, str(original.ROOT / "preparations"))
import configured_stack_source_registration_h20_v1 as registration

registration.io.ROOT = execution.A / "task_sources/sort_nesting_dolls_by_size"
registration.io.NATIVE = execution.NATIVE
registration.NATIVE = execution.NATIVE
read_document = registration.document
registration.document = lambda pin: metadata_locations(read_document(metadata_locations(pin)))
archived_script = original.script


def prepare_script(mode, archive):
    assert mode == "prepare", "The original ledger assistant runs on Mac only"
    source = archived_script(mode, archive)
    for old, new in (
        (old_root, str(original.ROOT)),
        ("import configured_source_registration_v2_20261031 as m",
         "import configured_stack_source_registration_h20_v1 as m"),
        (OLD_SHA, HELPER_SHA),
    ):
        assert source.count(old) == 1
        source = source.replace(old, new, 1)
    return source


original.script = prepare_script


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    assert sys.argv[1:] == ["7"]
    root = execution.A / "task_sources/stack_blocks_by_language"
    arguments = {
        "execution_owner": execution.OWNER, "operation": "prepare",
        "task": "stack_blocks_by_language", "layout": 7,
        "prior_manifest": ref(root / "SPLIT_MANIFEST_001.json"),
        "cpu_receipt": ref(Path(__file__).with_name("STACK_APPEND_PROFILE_CPU_001.json")),
    }
    captured = io.StringIO()
    sys.stdin = io.StringIO(json.dumps(arguments))
    with contextlib.redirect_stdout(captured):
        original.main()
    result = json.loads(captured.getvalue())
    prepared = registration.document(result["preparation_ref"])
    import task_configured_binding as configured
    raw = configured.load_native_layout(prepared)
    assert raw == json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes())
    manifest = registration.lineage(result["append_manifest"], arguments["task"])
    assert manifest["initial_source_sequence"] == list(range(8))
    assert manifest["original_partition"]["reserved_final"] == [53, 54]
    assert prepared["native_step_limit"] == 400
    assert not result["source_started"] and not result["source_reserved"]
    print(json.dumps(result))
