"""Install only the four transferred metadata files, without changing bytes."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil

import h20_runtime_binding_v1 as binding

binding.host()
root = binding.PROJECT.parent
manifest_path = root / "transfer/insert_metadata_batch_011.manifest.json"
manifest = json.loads(manifest_path.read_bytes())
prefix = Path("users/maxiangkai/projects/ReFATE")
assert len(manifest) == 4
assert shutil.disk_usage(binding.PROJECT).free > sum(x["bytes"] for x in manifest.values()) + 64 * 1024**2
rows = []
for name, expected in manifest.items():
    relative = Path(name).relative_to(prefix)
    source = root / "dependency_tree" / name
    target = binding.PROJECT / relative
    raw = source.read_bytes()
    assert len(raw) == expected["bytes"]
    assert hashlib.sha256(raw).hexdigest() == expected["sha256"]
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw
    else:
        with target.open("xb") as stream:
            stream.write(raw)
    assert target.read_bytes() == raw
    rows.append({"path": str(target), **expected})
receipt = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": binding.OWNER, "source_host": "nb-dn22t489hz-0",
    "bridge_host": "20250106-instance", "destination_host": "20250103-instance",
    "file_count": len(rows), "bytes": sum(x["bytes"] for x in rows),
    "files": rows, "mac_payload_relay": False, "original_documents_changed": False,
    "source_preparation_repeated": False, "source_launched": False,
}
path = binding.D / "migration/INSERT_METADATA_VERIFICATION_001.json"
with path.open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps({"verified_files": len(rows), "bytes": receipt["bytes"],
                  "receipt": str(path), "source_launched": False}))
