"""Export original Classify references through the verified storage copy."""
from pathlib import Path

path = Path(__file__).with_name("export_retained_bottles_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v7", "h20_teacher_binding_v10"),
    ("h20_retained_bottles_storage_v1", "h20_retained_classify_storage_v1"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::classify_original_references", "exec"), globals())
