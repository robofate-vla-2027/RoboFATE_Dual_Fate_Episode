"""Same runtime/environment, with the diagnostic-enabled Native entry."""
import h20_container_binding_v2 as _prior
from h20_container_binding_v2 import *

_text = edit(_prior._text, str(D / "runtime/native_h20_container_v1.py"),
             str(D / "runtime/native_h20_container_v2.py"))
foreground = previous.load_source("_refate_h20_container_v3_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "POLICY", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))

