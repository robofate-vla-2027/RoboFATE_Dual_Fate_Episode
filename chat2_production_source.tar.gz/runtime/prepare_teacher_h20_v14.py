"""Original preparation with the matched Sweep task catalog."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_h20_v13.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v13") == 1
exec(compile(text.replace("h20_teacher_binding_v13", "h20_teacher_binding_v14"),
             __file__ + "::sweep_catalog", "exec"), globals())
