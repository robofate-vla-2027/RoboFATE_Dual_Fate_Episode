"""Publish only SwapT400 cache/context and explicit run-name bindings."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest

import h20_container_binding_v10 as binding
import prelaunch_swap_policy_cache_h20_v1 as prelaunch
import test_swap_cache_context_cpu_v1 as tests

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_024.json"
assert ref(old)["sha256"] == "9f8e6a73a30e155dc35cbd70fa27c2ae9417312658147808f9c0ace2a1dcee78"
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 4
old_launcher = (d / "runtime/launch_container_v3.sh").read_text()
new_launcher = (d / "runtime/launch_container_v4.sh").read_text()
old_guard = "c2_[a-z0-9_]+_01a16807"
new_guard = old_guard + "|c2_swap_T_l[0-6]_(h20_baseline|evo_common_teacher)_[0-9]{4}_01a16807"
assert old_launcher.count(old_guard) == 1
assert old_launcher.replace(old_guard, new_guard, 1) == new_launcher
cpu = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    data_kind="synthetic_CPU_SwapT400_context_not_scientific_data",
    synthetic_tests_passed=result.testsRun, tests=log.getvalue(),
    task="swap_T", native_total_steps=400, baseline_wall_seconds=2400,
    teacher_wall_seconds=3600, model_loading_allowance_seconds=900,
    model_request_timeout_seconds=120, compiled_cache_logic_unchanged=True,
    model_calls=False, gpu_execution_calls=False, simulator_calls=False,
    actual_model_prediction_verified=False, actual_adoption=False,
    initial_preparation=ref(d / "migration/SWAP_L0_PREPARATION_CPU_001.json"),
    launcher_change="Only explicit initial SwapT names; all execution and device controls unchanged",
)
cp = d / "migration/SWAP_COMPILED_CACHE_CONTEXT_CPU_001.json"
with cp.open("x") as stream:
    json.dump(cpu, stream, indent=2)
    stream.write("\n")
release = json.loads(old.read_bytes())
release.update(
    at=cpu["at"], prior_swap_cache_release=ref(old), swap_cache_cpu=ref(cp),
    prelaunch_entry=ref(d / "runtime/prelaunch_swap_policy_cache_h20_v1.py"),
    container_launcher=ref(d / "runtime/launch_container_v4.sh"), actual_adoption=False,
    change_scope="SwapT original400 budget, identical compiled cache and collector11/Native8/"
    "policy2/readers, context13. Exact uppercase task run-name allowance only. "
    "No task/model/physics/renderer/time-limit changes or scientific state reuse.",
)
for name in ("policy_cache_seed_swap_h20_v1.py", "prelaunch_swap_policy_cache_h20_v1.py",
             "launch_container_v4.sh", "stage_swap_run_storage_h20_v2.py"):
    release["runtime_files"].append(ref(d / "runtime" / name))
path = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_025.json"
with path.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(release=ref(path), swap_cache_cpu=ref(cp),
                      prelaunch=release["prelaunch_entry"], actual_adoption=False)))
