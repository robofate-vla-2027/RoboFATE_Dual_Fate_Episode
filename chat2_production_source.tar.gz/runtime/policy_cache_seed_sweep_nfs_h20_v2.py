"""Use the per-run NFS bind already writable inside the restricted container."""
from policy_cache_seed_sweep_nfs_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = ('parent = Path("/vla/mxk/projects/ReFATE/coordination/'
           '20261106_chat2_h20_01a19072/private_policy_compiled_cache")')
    assert text.count(old) == 1
    return text.replace(old, 'parent = run / "runtime/private_policy_compiled_cache"', 1)


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::existing_rw_run_bind", "exec"), namespace)
    return namespace["install"](run)
