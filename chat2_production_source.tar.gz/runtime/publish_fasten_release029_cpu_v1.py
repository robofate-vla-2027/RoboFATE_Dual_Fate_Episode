"""Freeze task-only cache/prelaunch binding after bounded offline CPU checks."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if event in ("socket.__new__", "subprocess.Popen", "os.system", "os.kill", "os.killpg"):
        raise RuntimeError("Synthetic source comparisons only; no live peers or models")


sys.addaudithook(deny_live)
import h20_teacher_binding_v14 as runtime
import policy_cache_seed_sweep_nfs_h20_v2 as old_cache
import policy_cache_seed_fasten_h20_v1 as cache
import prelaunch_sweep_policy_cache_h20_v3 as old_launch
import prelaunch_fasten_policy_cache_h20_v1 as launch
import task_configured_binding as configured
import teacher_catalog_sweep_h20_v1 as teacher

host = runtime.execution.previous
host.host()
D = host.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_028.json"
assert ref(prior)["sha256"] == "0f007b606da2d89e6bd3c7fa4f4ea5b33c5584dd2e42fdda66c7d6abdebd9f30"
expected = old_cache.source().replace(
    'context["task"] == "sweep_blocks"', 'context["task"] == "fasten_screws"', 1).replace(
    'context["native_total_steps"] == 1000', 'context["native_total_steps"] == 1900', 1)
assert cache.source() == expected
compile(cache.source(), "synthetic_cache_compile_not_execution", "exec")
expected = old_launch.source().replace(
    "policy_cache_seed_sweep_nfs_h20_v2", "policy_cache_seed_fasten_h20_v1", 2).replace(
    "c2_sweep_blocks_l[0-6]_h20_baseline_000[1-7]_01a16807",
    "c2_fasten_screws_l7_h20_baseline_0001_01a16807", 1).replace(
    'value["native_total_steps"] == 1000', 'value["native_total_steps"] == 1900', 1)
assert launch.source() == expected
compile(launch.source(), "synthetic_prelaunch_compile_not_execution", "exec")
preparation = runtime.execution.A / "task_sources/fasten_screws/PREPARATION_L7_CONFIGURED_001.json"
prepared = json.loads(preparation.read_bytes())
layout = configured.load_native_layout(prepared)
assert teacher.load_native_layout(prepared) == layout
assert prepared["native_step_limit"] == 1900 and prepared["source"]["layout_id"] == 7
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
assert type(release["runtime_files"]) is list
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 4, "task_only_cache_source_equality": True,
    "task_only_prelaunch_source_equality": True, "actual_configured_loader_passed": True,
    "actual_teacher_loader_passed": True, "model_API_simulator_calls": 0,
    "source_preparation": ref(preparation), "native_budget": 1900,
    "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "container_path_mapping_reused": release["sweep_shared_compiled_cache_cpu"],
    "actual_Fasten_launch_verified": False,
}
cpu_ref = save(D / "migration/FASTEN_CACHE_BINDING_CPU_001.json", cpu)
files = [ref(D / "runtime" / name) for name in (
    "policy_cache_seed_fasten_h20_v1.py", "prelaunch_fasten_policy_cache_h20_v1.py",
    "publish_fasten_release029_cpu_v1.py")]
release["runtime_files"].extend(files)
release.update(
    at=at, prior_fasten_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_fasten_policy_cache_h20_v1.py"),
    fasten_cache_cpu=cpu_ref, actual_adoption=False,
    change_scope="Fasten L7 task/1900/run binding only. Same cache placement, collector11, "
                 "Native8, content/RNG/readers, model, RTX and original timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_029.json", release)
print(json.dumps({"release": output, "CPU": cpu_ref, "actual_adoption": False}))
