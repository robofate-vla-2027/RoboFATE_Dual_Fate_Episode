"""Storage-only adapter around the existing Organize append helper."""
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_runtime_binding_v1 as execution
import common_runtime as runtime
import task_family_binding as family

original_root = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")
previous_read_pin = runtime.read_pin
mapped_pins = []


def storage_read_pin(ref):
    p = Path(ref["path"])
    if p.is_relative_to(original_root):
        mapped = {"path": str(execution.PROJECT / p.relative_to(original_root)),
                  "sha256": ref["sha256"]}
        raw = previous_read_pin(mapped)
        mapped_pins.append({"historical": ref, "execution": mapped})
        return raw
    return previous_read_pin(ref)


runtime.read_pin = storage_read_pin
# Import the original teacher metadata reader before the append can write anything.
import teacher_catalog_binding_v4


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def differences(a, b, path=""):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            child = path + "/" + key
            out.extend([child] if key not in a or key not in b else differences(a[key], b[key], child))
        return out
    if isinstance(a, list):
        if len(a) != len(b):
            return [path + "/length"]
        return [p for i, (x, y) in enumerate(zip(a, b))
                for p in differences(x, y, path + "/" + str(i))]
    return [] if a == b else [path]


index = int(sys.argv[1])
prior_path = Path(sys.argv[2])
prior = json.loads(prior_path.read_bytes())
assert prior["initial_source_sequence"] == list(range(index))
assert prior["reserved_layouts_read"] == []
assert index not in prior["original_partition"]["reserved_final"]
layout_path = execution.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/organize_table_{index}.json"
raw = json.loads(layout_path.read_bytes())
current = family.family(raw)
group = "organize_table/task_content_family/" + current["content_sha256"]
inputs = {"execution_owner": execution.OWNER, "prior_manifest": ref(prior_path),
          "layout": index, "raw_sha256": ref(layout_path)["sha256"]}
if group not in prior["families"]:
    candidates = []
    for ordinal in prior["initial_source_sequence"]:
        path = Path(prior["layouts"][str(ordinal)]["layout_ref"]["path"])
        old = family.family(json.loads(path.read_bytes()))
        paths = differences(old["normalized_layout"], current["normalized_layout"])
        candidates.append({"layout": ordinal, "different_nonpose_paths": paths})
    closest = min(candidates, key=lambda x: (len(x["different_nonpose_paths"]), x["layout"]))
    assert closest["different_nonpose_paths"]
    labels = [g["split"] for g in prior["families"].values()]
    count = len(labels) + 1
    target = min(count - 1, max(1, count // 5))
    inputs["new_family_split"] = "student_dev" if labels.count("student_dev") < target else "student_train"
    inputs["new_family_review"] = {
        "new_layout": index, "new_group": group, "outcomes_read": False,
        "next_original_ordinal": True, "closest_existing": closest,
        "reserved_layouts_read": [], "criterion": "full layout excluding original rigid/geometry initial pose",
    }
record = execution.D / f"migration/ORGANIZE_L{index}_PREPARATION_INPUT_001.json"
with record.open("x") as f:
    json.dump(inputs, f, indent=2)
helper = execution.A / "prepare_next_organize_handoff_v1.py"
text = helper.read_text()
old = str(original_root / "coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher")
assert text.count(old) == 2
text = text.replace(old, str(execution.A.parent))
sys.stdin = io.StringIO(json.dumps(inputs))
exec(compile(text, str(helper) + "::h20_storage_only", "exec"),
     {"__name__": "__main__", "__file__": str(helper)})

