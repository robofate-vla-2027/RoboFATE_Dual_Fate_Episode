"""Verify the one transferred source, preserving all historical file bytes."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

import h20_runtime_binding_v1 as binding

binding.host()
root = binding.PROJECT.parent
run_id = "c2_put_bottles_into_dustbin_l31_common_baseline_0032_01a16807"
relative_run = Path("coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs") / run_id
prefix = Path("users/maxiangkai/projects/ReFATE")
manifest_path = root / "transfer/bottles_l31_batch_019.manifest.json"
manifest = json.loads(manifest_path.read_bytes())
assert len(manifest) == 6440
assert sum(row["bytes"] for row in manifest.values()) == 820754661
physical = root / "run_data" / run_id
logical = binding.D / "teacher/runs" / run_id
historical_copy = binding.PROJECT / relative_run
assert not logical.exists() and not physical.exists() and not historical_copy.exists()
assert shutil.disk_usage(root).free > 4 * 1024**3
rows = []
for name, expected in manifest.items():
    relative = Path(name).relative_to(prefix)
    source = root / "dependency_tree" / name
    target = (physical / relative.relative_to(relative_run)
              if relative.is_relative_to(relative_run) else binding.PROJECT / relative)
    raw = source.read_bytes()
    assert len(raw) == expected["bytes"]
    assert hashlib.sha256(raw).hexdigest() == expected["sha256"]
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw
    else:
        shutil.copy2(source, target)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected["sha256"]
    rows.append({"path": str(target), **expected})
for path in (logical, historical_copy):
    path.mkdir(parents=True)
    subprocess.run(["mount", "--bind", str(physical), str(path)], check=True)
    assert path.resolve(strict=True) == path
    assert (path / "CONTEXT_001.json").read_bytes() == (physical / "CONTEXT_001.json").read_bytes()
receipt = {
    "schema": "refate.retained_source.storage_migration.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": binding.OWNER, "source_host": "nb-dn22t489hz-0",
    "bridge_host": "20250106-instance", "execution_host": "20250103-instance",
    "run_id": run_id, "file_count": len(rows), "bytes": sum(x["bytes"] for x in rows),
    "transfer_manifest": {"path": str(manifest_path),
                          "sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()},
    "physical": str(physical), "logical": str(logical), "historical_copy": str(historical_copy),
    "files": rows, "all_bytes_verified": True, "source_launched": False,
    "mac_payload_relay": False, "original_documents_changed": False,
    "ctime_backdated": False, "full_payload_decoded": False,
}
output = binding.D / "migration/BOTTLES_L31_STORAGE_VERIFICATION_001.json"
with output.open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: receipt[key] for key in
                  ("file_count", "bytes", "logical", "physical", "all_bytes_verified")}))
