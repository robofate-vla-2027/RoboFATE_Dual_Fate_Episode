"""Same pinned bookkeeping export for L35; no remote ledger execution."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("export_bottles_registration_metadata_h20_v1.py").read_text()
    assert text.count("assert index == 34") == 1
    return text.replace("assert index == 34", "assert index == 35", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L35_metadata_only", "exec"), globals())
