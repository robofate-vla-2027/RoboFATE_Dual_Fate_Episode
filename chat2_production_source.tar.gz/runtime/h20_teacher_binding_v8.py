"""Match full source identities after reversible layout-path normalization."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v7.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v7"', '"native_teacher_h20_v8"'),
    ('"collect_teacher_h20_v7"', '"collect_teacher_h20_v8"'),
    ('"prepare_teacher_h20_v7"', '"prepare_teacher_h20_v8"'),
    ('"_refate_h20_teacher_native_scope_v7"', '"_refate_h20_teacher_native_scope_v8"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::retained_bottles_storage", "exec"), globals())

from h20_source_identity_paths_v1 import install
import sys
install(sys.modules[__name__])
