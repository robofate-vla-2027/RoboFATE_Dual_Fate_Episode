"""Address-only binding of the saved profiled preparer; no remote registration."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_teacher_binding_v15 as runtime
from h20_insert_private_metadata_v1 import metadata_locations
import profiled_append_handoff_v1 as original

execution = runtime.execution
execution.previous.host()
old_root = str(original.ROOT)
original.ROOT = execution.A.parent
original.ADAPTER = execution.A
original.ARCHIVE = original.ROOT / original.ARCHIVE.relative_to(Path(old_root))
original.reused.ROOT = original.ROOT
original.reused.ADAPTER = original.ADAPTER
sys.path.insert(0, str(original.ROOT / "preparations"))
import configured_source_registration_v2_20261031 as registration

registration.io.ROOT = execution.A / "task_sources/sort_nesting_dolls_by_size"
registration.io.NATIVE = execution.NATIVE
registration.NATIVE = execution.NATIVE
read_original_document = registration.document


def document(reference):
    return metadata_locations(read_original_document(metadata_locations(reference)))


registration.document = document
archived_script = original.script


def prepare_script(mode, archive):
    assert mode == "prepare", "Ledger registration runs only on the Mac"
    text = archived_script(mode, archive)
    assert text.count(old_root) == 1
    return text.replace(old_root, str(original.ROOT), 1)


original.script = prepare_script


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    index = int(sys.argv[1])
    assert index == 33
    root = execution.A / "task_sources/put_bottles_into_dustbin"
    arguments = {
        "execution_owner": execution.OWNER, "operation": "prepare",
        "task": "put_bottles_into_dustbin", "layout": index,
        "prior_manifest": ref(root / "SPLIT_APPEND_L32_001.json"),
        "cpu_receipt": ref(original.ROOT / "preparations/CONFIGURED_SOURCE_REGISTRATION_V2_CPU_001.json"),
    }
    captured = io.StringIO()
    sys.stdin = io.StringIO(json.dumps(arguments))
    with contextlib.redirect_stdout(captured):
        original.main()
    result = json.loads(captured.getvalue())
    prepared = registration.document(result["preparation_ref"])
    import task_configured_binding as configured
    raw = configured.load_native_layout(prepared)
    assert raw == json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes())
    manifest = registration.lineage(result["append_manifest"], arguments["task"])
    assert manifest["initial_source_sequence"] == list(range(34))
    assert manifest["original_partition"]["reserved_final"] == [53, 54]
    assert prepared["native_step_limit"] == 700
    assert not result["source_started"] and not result["source_reserved"]
    print(json.dumps(result))
