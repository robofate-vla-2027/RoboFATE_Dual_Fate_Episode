"""Matched release003 metadata with genuine teacher/baseline resource closure."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v2.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_TEACHER_20261106_002.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_TEACHER_20261106_003.json")
old = 'exec(compile(text, str(path) + "::exact_code_scope", "exec"), globals())'
assert text.count(old) == 1
extra = '''
old_check = '    assert terminal["first_readback_passed"]'
new_check = """    if terminal.get("schema") == "refate.actual_terminal_observation.v1":
        from dolls_next_inputs_h20_v2 import teacher_checks
        teacher_checks(terminal, terminal["run_id"])
    elif terminal.get("schema") == "refate.teacher_prelaunch_interruption.v1":
        assert terminal["native_started"] is terminal["foreground_started"] is False
        assert terminal["model_or_api_called"] is False
        assert terminal["container_state"]["Running"] is False
        assert terminal["container_state"]["Pid"] == 0
        assert terminal["launcher_original_process_absent"]
        assert all(not Path(p).exists() for p in terminal["absent_paths"])
    else:
        assert terminal["first_readback_passed"]"""
assert text.count(old_check) == 1
text = text.replace(old_check, new_check, 1)
'''
text = text.replace(old, extra + "\n" + old)
exec(compile(text, str(path) + "::readonly_guest_python_release003", "exec"), globals())

