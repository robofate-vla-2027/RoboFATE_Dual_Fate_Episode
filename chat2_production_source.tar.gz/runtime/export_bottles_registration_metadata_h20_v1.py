"""Export pinned source bookkeeping only; the original ledger remains on Mac."""
import base64
import hashlib
import json
from pathlib import Path
import sys
import h20_runtime_binding_v1 as host


def packet(path):
    raw = path.read_bytes()
    assert 0 < len(raw) < 1024**2
    return {"ref": {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()},
            "raw_b64": base64.b64encode(raw).decode()}


if __name__ == "__main__":
    host.host()
    index = int(sys.argv[1])
    assert index == 34
    teacher = host.A.parent
    root = host.A / "task_sources/put_bottles_into_dustbin"
    paths = [root / "SPLIT_MANIFEST_001.json"]
    paths += [root / f"SPLIT_APPEND_L{i}_001.json" for i in range(7, index + 1)]
    handoff_path = root / f"APPEND_L{index}_EXECUTION_HANDOFF_01a19072_001.json"
    paths += [
        root / f"PREPARATION_L{index}_CONFIGURED_001.json", handoff_path,
        teacher / f"preparations/put_bottles_into_dustbin_L{index}_SOURCE_REGISTRATION_PREPARATION_001.json",
        teacher / "preparations/CONFIGURED_SOURCE_REGISTRATION_V2_CPU_001.json",
    ]
    handoff = json.loads(handoff_path.read_bytes())
    path = handoff["handoff"]["path"].replace(
        "/mnt/workspace/users/maxiangkai/projects/ReFATE", str(host.PROJECT), 1)
    paths.append(Path(path))
    bundle = {
        "execution_owner": host.OWNER, "ledger_included": False,
        "RGB_actions_models_included": False,
        "documents": [packet(path) for path in paths],
        "registration_helper": packet(teacher / "preparations/configured_source_registration_v2_20261031.py"),
        "io_helper": packet(teacher / "preparations/dolls_source_registration_20261030.py"),
        "registration_archive": packet(teacher / "preparations/MAIN_PROFILED_SOURCE_METADATA_HELPERS_20261031_001.json"),
    }
    print(json.dumps(bundle, separators=(",", ":")))
