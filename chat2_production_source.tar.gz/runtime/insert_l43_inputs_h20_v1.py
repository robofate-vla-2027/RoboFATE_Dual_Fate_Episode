"""Read the already prepared Insert source; optionally bind its next boundary."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

import h20_insert_metadata_binding_v1 as storage
import h20_runtime_binding_v1 as binding
import common_owner_reservation_v3 as original

binding.host()
A, D = binding.A, binding.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def checked(reference):
    path = Path(storage.locations(reference["path"]))
    assert ref(path)["sha256"] == reference["sha256"]
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


prior = A.parent / "runs/c2_insert_tubes_l42_common_baseline_0046_01a16807"
dispatch = json.loads((prior / "DISPATCH_001.json").read_bytes())
settlement = json.loads((prior / "MAIN_SETTLEMENT_001.json").read_bytes())
assert settlement["native_success"] and settlement["first_readback_passed"]
prepared_path = A.parent / "preparations/INSERT_L43_H20_STORAGE_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
historical = json.loads(prepared_path.with_name("INSERT_L43_COMMON_PREPARATION_001.json").read_bytes())
assert storage.locations(prepared, inverse=True) == historical
storage.sequence.load_native_layout(prepared)
cp = {
    "source_id": dispatch["source_id"],
    "prepared": checked(dispatch["source_preparation"]),
    "preparation_ref": dispatch["source_preparation"],
    "settlement_ref": storage.locations(ref(prior / "MAIN_SETTLEMENT_001.json"), inverse=True),
    "split_ref": dispatch["split_manifest"],
    "split": checked(dispatch["split_manifest"]),
    "sequence_ref": storage.locations(ref(prior / "SEQUENCE_EXTENSION_001.json"), inverse=True),
}
assert historical["provenance"]["prior_split"] == cp["split_ref"]
assert historical["provenance"]["prior_sequence"] == cp["sequence_ref"]
release_path = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_012.json"
release = json.loads(release_path.read_bytes())
out = {
    "preparation": prepared, "preparation_ref": ref(prepared_path),
    "insert_prefix_checkpoint": cp, "release_ref": ref(release_path),
    "cpu_ref": ref(D / "migration/INSERT_L43_STORAGE_CPU_001.json"),
    "foreground_entry": release["foreground_entry"],
    "run_id": "c2_insert_tubes_l43_h20_baseline_0047_01a16807",
    "native_started": False,
}
if sys.argv[1] == "boundary":
    predecessor = json.load(sys.stdin)
    resource = {
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hostname": "20250103-instance", "allocation": binding.allocation(),
        "memory": binding.memory_headroom(120), "native_started": False,
    }
    import shutil
    assert shutil.disk_usage(D).free > 30 * 1024**3
    run = D / "teacher/runs" / out["run_id"]
    run.mkdir()
    resource_ref = write(run / "RESOURCE_PRECHECK_001.json", resource)
    extension = {
        "schema": "refate.insert.source_sequence_extension.v1",
        "data_kind": "preparation_only", "owner_chat": binding.OWNER,
        **prepared["sequence_extension_proposal"],
        "qualification": False, "source_issued": False, "launch_authority": False,
        "predecessor_disposition": cp["settlement_ref"],
    }
    extension_ref = write(run / "SEQUENCE_EXTENSION_001.json", extension)
    manifest = original.append_manifest(prepared, cp["split"], extension_ref, resource["at"])
    manifest_ref = write(run / "SPLIT_MANIFEST_L43_001.json", manifest)
    out.update(
        resource=resource, resource_ref=resource_ref,
        current_resource_predecessor=predecessor,
        publication={"at": resource["at"], "manifest": manifest,
                     "manifest_ref": manifest_ref, "extension_ref": extension_ref})
else:
    assert sys.argv[1] == "metadata"
print(json.dumps(out))
