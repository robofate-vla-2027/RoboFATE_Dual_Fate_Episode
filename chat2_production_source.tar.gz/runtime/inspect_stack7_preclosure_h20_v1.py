"""Inspect a bounded saved prefix with the frozen preclosure rule; no RGB decode."""
import ast
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import sys

import h20_teacher_binding_v15 as binding
import teacher_prepare_metadata_handoff_v6 as original

binding.execution.previous.host()
assert sys.argv[1:] == ["c2_stack_blocks_by_language_l7_h20_baseline_0008_01a16807"]
run = binding.execution.D / "teacher/runs" / sys.argv[1]
summary_path = run / "readback_once_001/SUMMARY.json"
summary_raw = summary_path.read_bytes()
summary = json.loads(summary_raw)
assert summary["file_recording_readback_passed"] and summary["native_success"] is False
assert summary["native_steps"] == 400 and summary["actual_controls"] == 4000
assert summary["decoded_observation_count"] == 401
source = original.source()
node = next(n for n in ast.parse(source).body
            if isinstance(n, ast.FunctionDef) and n.name == "verify_preclosure")
scope = {}
exec(compile(ast.get_source_segment(source, node), __file__ + "::frozen_rule", "exec"), scope)
with (run / "native_actions.jsonl").open() as stream:
    actions = [json.loads(line) for line in itertools.islice(stream, 160)]
candidates = []
for arm in ("left", "right"):
    for index in range(3, len(actions) - 2):
        try:
            key = scope["verify_preclosure"](actions, index, arm)
        except AssertionError:
            continue
        candidates.append({
            "t1": index, "arm": arm,
            "gripper_values": [actions[i]["action"][key][0]
                               for i in range(index - 3, index + 3)],
        })
        break
print(json.dumps({
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_run": sys.argv[1], "native_limit": 400,
    "source_complete_failure_readback_passed": True,
    "observed_prefix_rows": len(actions),
    "first_original_preclosure_candidates": sorted(candidates, key=lambda c: c["t1"]),
    "main_only_recorded_prefix_analysis": True,
    "teacher_prepared_reserved_or_started": False, "RGB_redecoded": False,
    "readback_ref": {"path": str(summary_path),
                     "sha256": hashlib.sha256(summary_raw).hexdigest()},
    "rule_source_sha256": hashlib.sha256(source.encode()).hexdigest(),
}))
