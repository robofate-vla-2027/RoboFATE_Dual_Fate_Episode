"""Use verified Bottles metadata decoding in the original capacity binder."""
from pathlib import Path

path = Path(__file__).with_name("bind_h20_container_context_v11.py")
text = path.read_text()
old = 'exec(compile(text, str(path) + "::original_positive_gap_H20", "exec"), globals())'
assert text.count(old) == 1
text = text.replace(old, """
old = 'text = previous.text'
assert text.count(old) == 1
text = text.replace(old, '''text = previous.text
text = binding.edit(text, "prepared = read(dispatch['source_preparation'])",
    "import task_source_binding as metadata\\\\n    prepared = metadata.original.decode(runtime.read_pin(dispatch['source_preparation']))")
text = binding.edit(text, "Path(dispatch_ref['path']) == run / 'DISPATCH_001.json'",
    "Path(dispatch_ref['path']) in (run / 'DISPATCH_001.json', run / 'DISPATCH_RUNTIME_REBIND_001.json')")
''')
exec(compile(text, str(path) + "::verified_metadata_decode", "exec"), globals())
""")
exec(compile(text, str(path) + "::bottles_binder_decode", "exec"), globals())
