"""Single normal frozen-DM episode through the shared Evo Native recording core."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback

import common_recording_content_v2 as recording
import node_native as node
import source_binding
import collection_append_binding_v1 as source_sequence_binding
import transport_rng_isolation_v1 as transport_rng_isolation

DEPLOY = node.NATIVE/'XPolicyLab/policy/OpenDM/deploy.py'
DEPLOY_SHA = '9ae70e54161a4a79aa42ea49ed81837fff93b2a6c31469c2c4e5454457cf822a'


def load_context(path, digest):
    from common_runtime import document, read_pin
    context = document(read_pin({'path':str(path),'sha256':digest}))
    node.need(context.get('schema') == 'refate.evo.common_baseline.v1'
              and context.get('data_kind') == 'actual'
              and context.get('execution_owner') == node.stage.OWNER
              and context.get('campaign') == 'refate-20261022-97baf70d5128', 'Wrong actual run context')
    node.need(context.get('ledger_authorization',{}).get('source_reserved') is True
              and context['ledger_authorization']['source_id'] == context['source_id']
              and context['ledger_authorization']['run_id'] == context['run_id'], 'Fresh main source reservation required')
    prepared = context['preparation']
    node.need(context['task'] == prepared['source']['task']
              and context['source_id'] == prepared['source']['source_id']
              and context['native_total_steps'] == prepared['native_step_limit'], 'Source/native budget mismatch')
    node.need(prepared['renderer_profile'] == prepared['prospective_teacher_renderer_profile'] == node.PROFILE,
              'New DM and teacher must share the common renderer profile')
    source_sequence_binding.load_native_layout(prepared)
    for ref in context['runtime_files']:
        read_pin(ref)
    return context


class PolicyView:
    def __init__(self, task, recorder, publish, run_id):
        self.task, self.recorder, self.publish = task, recorder, publish
        self.deploy_cfg = {'evaluation_id':run_id}

    def get_obs(self):
        self.recorder.writer.check()
        return self.task.public_observation()

    def take_action(self, action):
        return recording.execute_action(self.task, self.recorder, self.publish, action, role='DM0.5')

    def is_episode_end(self):
        self.recorder.writer.check()
        return self.task.done


def original_dm_loop():
    raw = node.pinned(DEPLOY, DEPLOY_SHA)
    spec = importlib.util.spec_from_file_location('_refate_original_OpenDM_deploy', DEPLOY)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw,str(DEPLOY),'exec'),module.__dict__)
    return module.eval_one_episode


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--context',required=True,type=Path)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--policy-ready',required=True,type=Path)
    args=parser.parse_args(argv)
    context=load_context(args.context,args.sha256)
    run=Path(context['run_dir'])
    node.need(run == node.stage.SHARED/'runs'/context['run_id'] and run.is_dir(), 'Wrong owned run root')
    node.need(not any((run/n).exists() for n in ('native_started.json','result.json','failure.json','dense')),
              'Started/uncertain context cannot execute again')
    from h20_runtime_binding_v1 import optix_metadata
    optix=optix_metadata()
    modules=recording.load_core(); core=modules['collect_source']; task=recorder=client=None
    core.write(run/'native_started.json',{'pid':os.getpid(),'wall_ns':time.time_ns(),'context_ref':{'path':str(args.context),'sha256':args.sha256}})
    started=time.perf_counter()
    core.write(run/'source_identity.json',context['preparation']['source'])
    try:
        core.write(run/'transport_rng_isolation.json',transport_rng_isolation.install())
        # The process-private supported OptiX binding is prepared by the foreground launcher.
        core.write(run/'nvoptix_container_asset.json',optix)
        from node_experience_binding import install_native
        cls=install_native()
        task=cls(context['task'],seed=context['preparation']['source']['encoded_seed'])
        modules['rtx_profile'].configure(task,node.PROFILE,evidence_path=run/'renderer_raw_observations.jsonl')
        task.reset()
        core.write(run/'actual_initial_binding.json',node.verify_initial(task,context['preparation']))
        observed_layout=task.native.seed_manager.get_seed_scene_info(task.ordinal)
        expected_layout=source_sequence_binding.load_native_layout(context['preparation'])
        node.need(source_binding.same(core.scalar(observed_layout), expected_layout), 'Actual initialized source layout differs')
        core.write(run/'initialized_layout.json',observed_layout)
        recorder,publish=recording.initialize_recording(task,run,core_modules=modules,runtime_capture=recording.runtime_snapshot)
        initialization=time.perf_counter()-started
        core.write(run/'native_boundary_ready.json',{'native_used':task.control_steps,'control_ticks':recorder.control_index,'wall_ns':time.time_ns(),'phase':'actual_initial_boundary_saved_before_policy_load'})
        policy_wait=time.monotonic()
        while not args.policy_ready.exists():
            recorder.writer.check()
            if time.monotonic()-policy_wait>900:
                raise TimeoutError('Policy not ready within original900s loading allowance')
            time.sleep(.25)
        core.write(run/'native_policy_wait.json',{'seconds':time.monotonic()-policy_wait,'native_used':task.control_steps,'physical_time_unchanged_from_initial':task.native.sim.sim.current_time == recorder.last_observation_time})
        from client_server.ws.model_client import WsModelClient
        ready=json.loads(args.policy_ready.read_text())
        node.need(ready['alias']=='h20_8' and ready['hostname']=='20250103-instance'
                  and ready['physical_gpu']==1 and ready['trainable_parameters']==0, 'Wrong frozen policy service')
        client=WsModelClient(url=ready['url'],evaluation_id=context['run_id'],trial_id=context['run_id'],
                             ws_ping_interval_s=120,ws_ping_timeout_s=120,max_connect_attempts=1)
        core.write(run/'ready.json',{'native_used':0,'native_limit':task.native.step_lim,'native_step_limit':task.native.step_lim,'rtx_profile':node.PROFILE,
                                    'physics_gpu':7,'policy_gpu':1,'physics_cuda_logical_device':1,'actual_shared_recorder':True,'qualified':False})
        timer=time.perf_counter()
        original_dm_loop()(PolicyView(task,recorder,publish,context['run_id']),client)
        core.wait_for_native_publication(recorder,task.control_steps)
        node.need(task.done and task.control_steps>0,'No native terminal outcome')
        result={'status':'native_terminal','native_success':bool(task.success),'terminated':bool(task.terminated),
                'truncated':bool(task.truncated),'native_steps':task.control_steps,'native_step_limit':task.native.step_lim,
                'actual_control_steps':recorder.control_index,'rtx_profile':node.PROFILE,'mode':'independent_baseline',
                'source_id':context['source_id'],'task':context['task'],'qualified':False,'counted_in_quota':False}
        core.write(run/'result.json',result)
        recorder.close()
        core.write(run/'timing_summary.json',{'initialization_reset':initialization,'baseline_loop_wall_s':time.perf_counter()-timer,
            'native_actions':task.control_steps,'actual_low_level_controls':recorder.control_index,
            'main_phase_seconds':recorder.phases,'writer_metrics':recorder.writer.metrics,
            'elapsed_wall_s':time.perf_counter()-started,
            'overlap_note':'Writer encode/write is overlapped; not added to main or total wall time.'})
        print(json.dumps(result),flush=True)
    except BaseException as error:
        if recorder is not None:
            recorder.writer.fail(error)
        core.write(run/'failure.json',{'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),
            'source_id':context['source_id'],'run_id':context['run_id'],'classification':'infrastructure_or_user_interruption',
            'native_failure_proven':False,'last_actual_executed_tick':recorder.control_index if recorder else None,
            'actual_native_success':bool(task.success) if task is not None else None,
            'actual_native_done':bool(task.done) if task is not None else None,'retry_allowed':False,'qualified':False})
        raise
    finally:
        primary=sys.exception(); errors=[]
        if recorder is not None and not recorder.closed_attempted:
            try:recorder.close()
            except BaseException as error:errors.append(error)
        if client is not None:
            try:client.close()
            except BaseException as error:errors.append(error)
        core.write(run/'preclose.json',{'pid':os.getpid(),'wall_ns':time.time_ns(),'native_steps':task.control_steps if task else None,
            'cleanup_errors':[repr(e) for e in errors],'primary_error':repr(primary) if primary else None})
        if task is not None:
            try:task.close()
            except BaseException as error:errors.append(error)
        if errors:
            if primary is not None:
                for e in errors:primary.add_note('Cleanup: '+repr(e))
            else:raise errors[0]
    return 0


if __name__=='__main__':
    raise SystemExit(main())
