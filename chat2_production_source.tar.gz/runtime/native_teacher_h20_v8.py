"""Original Native teacher with retained Bottles metadata storage."""
from pathlib import Path
import sys
import h20_teacher_binding_v8 as binding
import native_init_evidence_v1 as evidence

if __name__ == "__main__":
    context = Path(sys.argv[sys.argv.index("--context") + 1])
    evidence.install(binding.execution.node, context.parent)
    raise SystemExit(binding.native.main())
