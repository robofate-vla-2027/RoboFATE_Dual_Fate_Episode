"""Original boundary logic for L34 after L33's independent native success."""
from bottles_next_inputs_h20_v3 import source as previous_source


def source():
    text = previous_source()
    assert text.count("index == 33") == 1
    text = text.replace("index == 33", "index == 34", 1)
    start = text.index("prior_teacher_path = ")
    end = text.index("resource_kind = ", start)
    block = text[start:end]
    assert "assert prior_teacher[\"source_id\"] == source_predecessor[\"source_id\"]" in block
    text = text[:start] + (
        'assert source_predecessor["native_success"] is True\n'
        'assert terminal["source_id"] == source_predecessor["source_id"]\n'
    ) + text[end:]
    old = '"last_teacher_settlement": prior_teacher["summary_ref"],'
    assert text.count(old) == 1
    return text.replace(old, '"last_teacher_settlement": None,', 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L34_after_DM_success", "exec"), globals())
