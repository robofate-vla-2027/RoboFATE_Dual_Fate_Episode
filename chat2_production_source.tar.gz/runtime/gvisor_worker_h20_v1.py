"""Original owned gVisor supervisor, adapting only its exact-host guard."""
import sys
import h20_runtime_binding_v1 as binding

binding.host()
path = binding.stage.REPAIR / "gvisor_worker.py"
sys.path.insert(0, str(path.parent))
text = binding.edit(path.read_text(), "socket.gethostname()!='nb-5pl2apckdj-0'",
                    "socket.gethostname()!='20250103-instance'")
exec(compile(text, str(path) + "::h20_host", "exec"), globals())
