"""Offline Organize1000 binding checks; no model, API, simulator or ledger."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if (event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname") or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline binding check attempted a live external effect")


sys.addaudithook(deny_live)
import h20_teacher_binding_v14 as runtime
import policy_cache_seed_fasten_h20_v1 as prior_cache
import policy_cache_seed_organize_h20_v1 as cache
import prelaunch_fasten_policy_cache_h20_v1 as prior_launch
import prelaunch_organize_policy_cache_h20_v1 as launch
import task_configured_binding as configured

runtime.execution.previous.host()
D = runtime.execution.previous.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_032.json"
assert ref(prior)["sha256"] == "c4171b83beecc40612493067e660450bf7e2c9a4cd2c0b7c6bf66cd9d035b544"
assert cache.source() == prior_cache.source().replace(
    'context["task"] == "fasten_screws"', 'context["task"] == "organize_table"', 1
).replace('context["native_total_steps"] == 1900', 'context["native_total_steps"] == 1000', 1)
assert launch.source() == prior_launch.source().replace(
    "policy_cache_seed_fasten_h20_v1", "policy_cache_seed_organize_h20_v1", 2
).replace(
    "c2_fasten_screws_l7_h20_baseline_0001_01a16807",
    "c2_organize_table_l25_h20_baseline_0026_01a16807", 1
).replace('value["native_total_steps"] == 1900', 'value["native_total_steps"] == 1000', 1)
compile(cache.source(), "offline_Organize1000_cache_source", "exec")
compile(launch.source(), "offline_Organize25_prelaunch_source", "exec")
preparation = runtime.execution.A.parent / "preparations/ORGANIZE_L25_COMMON_PREPARATION_001.json"
assert ref(preparation)["sha256"] == "be3cd66e647d5a1cf1b7452c4de1275c84a921cf44643a7f5181f0afa290ac70"
prepared = json.loads(preparation.read_bytes())
raw_layout = configured.load_native_layout(prepared)
assert configured.previous.base.original.same(
    raw_layout, json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes()))
assert prepared["native_step_limit"] == 1000 and prepared["source"]["layout_id"] == 25
assert prepared["source"]["source_sequence"] == list(range(26))
assert prepared["source"]["required_accounted_prefix"] == list(range(25))
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = save(D / "migration/ORGANIZE_L25_CACHE_BINDING_CPU_001.json", {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 5, "task_only_cache_source_equality": True,
    "task_only_prelaunch_source_equality": True, "frozen_source_order_retained": True,
    "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
    "model_API_simulator_calls": 0, "source_preparation": ref(preparation),
    "native_budget": 1000, "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "actual_Organize_L25_launch_verified": False, "reservation_or_launch_authority": False,
})
release["runtime_files"].extend(ref(D / "runtime" / name) for name in (
    "policy_cache_seed_organize_h20_v1.py", "prelaunch_organize_policy_cache_h20_v1.py",
    "publish_organize_release033_cpu_v1.py",
))
release.update(
    at=at, prior_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_organize_policy_cache_h20_v1.py"),
    organize_cache_cpu=cpu, actual_adoption=False,
    change_scope="Organize L25/native1000 task and run binding only. Preserve collector11, "
                 "Native8, writable compiled cache, content/RNG/readers, model, RTX and timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_033.json", release)
print(json.dumps({"release": output, "CPU": cpu, "actual_adoption": False}))
