"""Place only a new run's disposable Kit cache in its existing private tmpfs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sys

D = Path("/data/refate_chat2_20261106_01a19072")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
ENTRY = D / "runtime/collect_h20_container_v10.py"


def place_cache(run, scratch):
    assert not (run / "foreground_started.json").exists()
    cache = run / "runtime/kit/cache"
    assert not cache.exists() and not cache.is_symlink(), "Never replace an existing cache"
    assert not scratch.exists() and not scratch.is_symlink()
    scratch.mkdir(mode=0o700)
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.symlink_to(scratch, target_is_directory=True)
    assert cache.resolve() == scratch.resolve() and cache.is_dir()
    return cache


def main():
    assert os.uname().nodename == "20250103-instance"
    assert os.environ["REFATE_SSH_ALIAS"] == "h20_8"
    assert os.environ["REFATE_EXECUTION_OWNER"] == OWNER
    assert os.environ["CUDA_VISIBLE_DEVICES"] == "0,1"
    assert os.environ["NVIDIA_VISIBLE_DEVICES"] == (
        "GPU-d2150afd-372d-4c5f-de58-fb675e6ef7a9,GPU-b34ba2c2-7c64-ec8e-a6bd-83c10d3ff526")
    assert sys.argv[1:2] == ["--context"] and sys.argv[3:4] == ["--sha256"]
    assert len(sys.argv) == 5
    context = Path(sys.argv[2])
    raw = context.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == sys.argv[4]
    value = json.loads(raw)
    run_id = value["run_id"]
    assert re.fullmatch(r"c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807", run_id)
    assert value["execution_owner"] == OWNER and value["native_wall_seconds"] == 2400
    assert value["native_total_steps"] == 400
    run = D / "teacher/runs" / run_id
    assert context == run / "CONTEXT_001.json"
    mounts = Path("/proc/self/mountinfo").read_text().splitlines()
    assert any(row.split()[4] == "/tmp" and row.split(" - ", 1)[1].split()[0] == "tmpfs"
               for row in mounts), "Use the existing container-private tmpfs only"
    space = os.statvfs("/tmp")
    assert space.f_bavail * space.f_frsize >= 4 * 1024**3
    scratch = Path("/tmp") / ("refate-kit-cache-" + run_id)
    cache = place_cache(run, scratch)
    receipt = {
        "schema": "refate.prelaunch_disposable_cache_binding.v1",
        "data_kind": "actual_prelaunch_not_scientific_sample",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": OWNER, "run_id": run_id,
        "context": {"path": str(context), "sha256": sys.argv[4]},
        "cache_link": str(cache), "private_tmpfs_target": str(scratch),
        "existing_cache_replaced": False, "old_runs_modified": False,
        "rgb_or_state_storage_changed": False, "renderer_settings_changed": False,
        "original_collector": str(ENTRY), "native_started": False,
        "native_wall_seconds": 2400, "budget_clock_origin_changed": False,
        "performance_benefit_verified": False,
    }
    with (run / "PRELAUNCH_KIT_CACHE_TMPFS_001.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    os.execv(sys.executable, [sys.executable, str(ENTRY), *sys.argv[1:]])


if __name__ == "__main__":
    main()
