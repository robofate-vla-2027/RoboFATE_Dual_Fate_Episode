"""Pin the unchanged baseline components to the original laptop800 launch."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest

import h20_container_binding_v10 as binding
import policy_cache_seed_h20_v2 as original
import policy_cache_seed_laptop_h20_v1 as laptop
import prelaunch_laptop_policy_cache_h20_v1 as prelaunch
import test_laptop_cache_context_cpu_v1 as tests

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_022.json"
assert ref(old)["sha256"] == "35f392b862eebf408675fdddabb08d0e7c6edc573156cc2ecce0da569b0df65e"
expected = original.source().replace(
    'context["task"] == "general_pickup"',
    'context["task"] == "store_laptop_and_headphones"')
expected = expected.replace('context["native_total_steps"] == 200',
                            'context["native_total_steps"] == 800')
assert laptop.source() == expected
compile(prelaunch.source(), "CPU_laptop800_prelaunch", "exec")
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 7
cpu = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "data_kind": "synthetic_CPU_laptop_context_only_not_scientific_data",
    "synthetic_tests_passed": result.testsRun, "tests": log.getvalue(),
    "compiled_cache_logic_unchanged": True, "task": "store_laptop_and_headphones",
    "native_total_steps": 800, "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "model_loading_allowance_seconds": 900, "model_request_timeout_seconds": 120,
    "model_calls": False, "gpu_execution_calls": False, "simulator_calls": False,
    "actual_model_prediction_verified": False, "latency_improvement_verified": False,
    "mapping_cpu": ref(d / "migration/POLICY_COMPILED_CACHE_MAPPING_CPU_001.json"),
    "initial_preparation": ref(d / "migration/LAPTOP_L0_PREPARATION_CPU_001.json"),
}
cp = d / "migration/LAPTOP_COMPILED_CACHE_CONTEXT_CPU_001.json"
with cp.open("x") as stream:
    json.dump(cpu, stream, indent=2)
    stream.write("\n")
release = json.loads(old.read_bytes())
release.update(
    at=cpu["at"], prior_laptop_cache_release=ref(old), laptop_cache_cpu=ref(cp),
    prelaunch_entry=ref(d / "runtime/prelaunch_laptop_policy_cache_h20_v1.py"),
    actual_adoption=False,
    change_scope="Only the laptop800 task/context and initial-source launch binding. "
                 "Same compiled-cache implementation, collector, Native, policy, readers "
                 "and original wall/loading/request budgets. No model or scientific-state changes.",
)
for name in ("policy_cache_seed_laptop_h20_v1.py", "prelaunch_laptop_policy_cache_h20_v1.py"):
    release["runtime_files"].append(ref(d / "runtime" / name))
new = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_023.json"
with new.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps({"release": ref(new), "laptop_cache_cpu": ref(cp),
                  "prelaunch": release["prelaunch_entry"], "actual_adoption": False}))
