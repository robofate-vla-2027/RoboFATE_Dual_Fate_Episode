"""Keep frozen compiled bytes; place future Sweep cache on private shared storage."""
from policy_cache_seed_sweep_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = 'parent = D / "private_policy_compiled_cache"'
    new = ('parent = Path("/vla/mxk/projects/ReFATE/coordination/'
           '20261106_chat2_h20_01a19072/private_policy_compiled_cache")')
    assert text.count(old) == 1
    return text.replace(old, new, 1)


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::private_shared_cache_only", "exec"), namespace)
    return namespace["install"](run)
