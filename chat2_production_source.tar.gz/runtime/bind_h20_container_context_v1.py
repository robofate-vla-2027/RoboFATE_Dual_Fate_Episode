"""Use the original source/context checks with the restricted-container entry."""
import h20_container_binding_v1 as binding
import collect_h20_container_v1
import bind_recording_content_v1 as previous

historical_preparer_allowed = previous.historical_preparer_allowed
text = previous.text
text = binding.edit(
    text,
    "dispatch.get('host') == 'perdon-hou' and dispatch.get('expected_hostname') == 'nb-5pl2apckdj-0'",
    "dispatch.get('host') == 'perdon-hou' and dispatch.get('execution_ssh_alias') == 'h20_8' and dispatch.get('expected_hostname') == '20250103-instance'",
)
text = binding.edit(
    text, "str(stage.HERE / 'collect_recording_content_v1.py')",
    repr(str(binding.D / "runtime/collect_h20_container_v1.py")),
)
text = binding.edit(
    text, "import collect_recording_content_v1 as collection\n",
    "import collect_recording_content_v1 as collection\ncollection.core.foreground = binding.foreground\ncollection.core.finish = binding.finish\n",
)
exec(compile(text, __file__ + "::original_binder", "exec"), globals())

