"""Original complete-predecessor Plug inputs for L27 on baseline038."""
from plug_next_inputs_h20_v4 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("RUNTIME_H20_CHAT2_CONTENT_20261108_036.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
        ('assert mode == "inputs" and index == 25',
         'assert mode in ("check", "inputs") and index == 27'),
        ('"native_total": 400', '"native_budget": 400'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Plug27_complete_predecessor", "exec"), globals())
