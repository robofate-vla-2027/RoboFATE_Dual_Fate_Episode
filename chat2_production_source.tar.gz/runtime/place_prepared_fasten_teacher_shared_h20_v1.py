"""Original private teacher storage binder, restricted to Fasten L7."""
from place_prepared_stack_teacher_shared_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("c2_stack_blocks_by_language_l([2-6])_evo_common_teacher_(0001)_01a16807",
         "c2_fasten_screws_l(7)_evo_common_teacher_(0001)_01a16807"),
        ('inputs["task"] == "stack_blocks_by_language"', 'inputs["task"] == "fasten_screws"'),
        ('inputs["native_limit"] == 400 and inputs["remaining_steps"] == 400 - inputs["t1"]',
         'inputs["native_limit"] == 1900 and inputs["remaining_steps"] == 1900 - inputs["t1"]'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Fasten_teacher_metadata_only", "exec"), globals())
