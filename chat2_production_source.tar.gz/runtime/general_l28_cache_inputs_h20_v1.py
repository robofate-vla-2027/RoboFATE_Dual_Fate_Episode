"""Exact next original General source after its settled zero-control interruption."""
from general_next_inputs_h20_v4 import source as previous_source


def late_prediction_checks(terminal):
    assert terminal["schema"] == "refate.actual_interrupted_baseline.v1"
    assert terminal["run_id"] == "c2_general_pickup_l27_h20_baseline_0001_01a16807"
    assert terminal["safe_for_next_simulator"] and terminal["policy_model_ready"]
    assert terminal["last_actual_executed_tick"] == 0
    assert terminal["native_terminal"] is terminal["native_success"] is False
    assert terminal["first_prediction_seconds"] > terminal["model_request_default_seconds"] == 120
    assert terminal["final_reset_completed"] is True and terminal["source_retry_allowed"] is False


def source():
    text = previous_source()
    for old, new, count in (
        ("assert 27 <= index < 53", "assert index == 28", 1),
        ('"MAIN_SETTLEMENT_001.json"', '"MAIN_INTERRUPTION_SETTLEMENT_001.json"', 3),
        ("baseline_checks(terminal)", "late_prediction_checks(terminal)", 1),
        ('terminal["safe_for_next_simulator"] and terminal["first_readback_passed"]',
         'terminal["safe_for_next_simulator"] and not terminal["full_readback_passed"]', 1),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_019.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_020.json", 1),
        ('out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)',
         'out["cache_cpu_ref"] = release["cache_cpu_check"]\n'
         'out["cache_cpu"] = document(out["cache_cpu_ref"])\n'
         'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General28_original_sequence", "exec"), globals())

