"""Same General entry, with private compiled-cache reuse before the original start."""
from prelaunch_general_cache_tmpfs_v4 import source as previous_source


def source():
    text = previous_source()
    old = "    cache = place_cache(run, scratch)"
    assert text.count(old) == 1
    return text.replace(old, old + "\n    import policy_cache_seed_h20_v1\n"
                        "    policy_cache_seed_h20_v1.install(run)", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::private_compiled_cache_only", "exec"), globals())

