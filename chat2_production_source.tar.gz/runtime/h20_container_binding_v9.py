"""Original restricted runtime with process-local Plug metadata storage paths."""
import h20_container_binding_v8 as _prior
from h20_container_binding_v8 import *
import h20_bottles_metadata_storage_v1 as bottles_storage

bottles_storage.install_runtime()
_text = edit(_prior._text, str(D / "runtime/native_h20_container_v6.py"),
             str(D / "runtime/native_h20_container_v7.py"))
foreground = previous.load_source("_refate_h20_container_v9_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "POLICY", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))
