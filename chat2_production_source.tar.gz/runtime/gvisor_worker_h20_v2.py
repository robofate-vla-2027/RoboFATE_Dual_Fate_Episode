"""Original owned supervisor with a container-private chroot temporary directory."""
import json
from pathlib import Path
import sys

import h20_runtime_binding_v1 as binding
from h20_gvisor_tmp_v1 import bind_private_tmp

binding.host()
run = Path(sys.argv[1])
assert run.resolve(strict=True) == run
assert run.parent == binding.D / "teacher/sessions"
with (run / "oci/RUNSC_TMP_BINDING_001.json").open("x") as stream:
    json.dump(bind_private_tmp(), stream, indent=2)
path = binding.stage.REPAIR / "gvisor_worker.py"
sys.path.insert(0, str(path.parent))
text = binding.edit(path.read_text(), "socket.gethostname()!='nb-5pl2apckdj-0'",
                    "socket.gethostname()!='20250103-instance'")
exec(compile(text, str(path) + "::h20_private_container_tmp", "exec"), globals())
