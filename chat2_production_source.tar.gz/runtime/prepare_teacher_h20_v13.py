"""Original context builder with the matched SwapT task catalog."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_h20_v8.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v8") == 1
exec(compile(text.replace("h20_teacher_binding_v8", "h20_teacher_binding_v13"),
             str(path) + "::swap_catalog", "exec"), globals())
