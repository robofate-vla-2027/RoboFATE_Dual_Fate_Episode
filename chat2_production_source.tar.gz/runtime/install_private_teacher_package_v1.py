"""Extract the verified official archive privately; never run its installer."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import tarfile
import tempfile

D = Path("/data/refate_chat2_20261106_01a19072")
OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
assert socket.gethostname() == "20250103-instance"
assert os.environ["REFATE_SSH_ALIAS"] == "h20_8"
assert os.environ["REFATE_EXECUTION_OWNER"] == OWNER
archive = D / "migration/codex-package-x86_64-unknown-linux-musl.tar.gz"
expected = "4844f087f2e1c62adab5c2d5ed52e945c87f67da7c585cd1b975ed3aa3b0163c"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
dest = D / "runtime/teacher_package_0.151.0-alpha.7.1"
receipt = D / "migration/EXACT_TEACHER_PACKAGE_PRIVATE_INSTALL_001.json"
assert not dest.exists() and not receipt.exists()
staging = Path(tempfile.mkdtemp(prefix=".teacher-package-stage-", dir=dest.parent))
with tarfile.open(archive, "r:gz") as stream:
    members = stream.getmembers()
    assert len(members) == 11
    assert sum(m.size for m in members) == 346982015
    names = set()
    for member in members:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and ".." not in path.parts
        assert member.isfile() or member.isdir()
        assert member.name not in names
        assert member.mode & 0o7000 == 0
        names.add(member.name)
    stream.extractall(staging, members=members)
metadata = json.loads((staging / "codex-package.json").read_bytes())
assert metadata == {
    "layoutVersion": 1, "version": "0.151.0-alpha.7.1",
    "target": "x86_64-unknown-linux-musl", "variant": "codex",
    "entrypoint": "bin/codex", "resourcesDir": "codex-resources",
    "pathDir": "codex-path",
}
files = {}
for path in sorted(staging.rglob("*")):
    if path.is_file():
        files[str(path.relative_to(staging))] = {
            "size": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
assert os.access(staging / "bin/codex", os.X_OK)
assert not dest.exists()
staging.rename(dest)
record = {
    "schema": "refate.chat2.private_teacher_package.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": OWNER, "hostname": socket.gethostname(),
    "archive": {"path": str(archive), "sha256": expected},
    "destination": str(dest), "metadata": metadata, "files": files,
    "generic_installer_executed": False, "shared_environment_modified": False,
    "model_or_api_called": False, "teacher_started": False,
}
with receipt.open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({"receipt": str(receipt), "destination": str(dest),
                  "files": len(files), "teacher_started": False}))
