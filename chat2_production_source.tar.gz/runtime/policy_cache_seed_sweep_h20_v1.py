"""Original compiled-cache placement for Sweep's original1000-step context."""
from policy_cache_seed_stack_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "stack_blocks_by_language"', 'context["task"] == "sweep_blocks"'),
        ('context["native_total_steps"] == 400', 'context["native_total_steps"] == 1000'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::Sweep1000_original_budget", "exec"), namespace)
    return namespace["install"](run)
