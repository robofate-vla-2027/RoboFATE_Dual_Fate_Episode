"""Prepare one original Stack source; no model, simulator, or ledger execution."""
import copy
import datetime
import hashlib
import json
from pathlib import Path

TASK = "stack_blocks_by_language"
PLAN_SHA = "d75af4dd4a6121a9ffe5d9580406cca24c8820ca08516f4b690d45dd38e0a325"


def manifest(partition, rows):
    """Keep the original collection IDs; do not inspect sealed layouts."""
    train, dev, sealed = (partition[k] for k in ("train", "development", "reserved_final"))
    sequence = train + dev
    assert sequence == list(range(7)) and sealed == [53, 54]
    assert set(train).isdisjoint(dev) and set(sequence).isdisjoint(sealed)
    assert [row["layout_id"] for row in rows] == sequence
    families, layouts, conflicts = {}, {}, {}
    seen = set()
    for value in rows:
        row = copy.deepcopy(value)
        index, group = row["layout_id"], row["group_id"]
        planned = "student_train" if index in train else "student_dev"
        entry = families.setdefault(group, {
            "group_id": group, "split": planned, "layouts": []})
        if entry["split"] != planned:
            conflicts[group] = {"rule": "same_family_kept_in_training",
                                "planned_splits": ["student_train", "student_dev"]}
            entry["split"] = "student_train"
        digest = row["initialization_content_sha256"]
        row["initialization_distinct_from_preceding"] = digest not in seen
        seen.add(digest)
        layouts[str(index)] = row
        entry["layouts"].append({"layout_id": index, "bank": 0,
                                 **row["layout_ref"]})
    for row in layouts.values():
        row["split"] = families[row["group_id"]]["split"]
    for group in families.values():
        for row in group["layouts"]:
            row["split"] = group["split"]
    return {
        "schema": "refate.split_manifest.v1", "task": TASK,
        "initial_source_sequence": sequence,
        "original_partition": copy.deepcopy(partition),
        "layouts": layouts, "families": families, "group_conflicts": conflicts,
        "layout_to_group": {k: v["group_id"] for k, v in layouts.items()},
        "preserved_all_original_memberships": not conflicts,
        "sealed_content_not_read": True, "launch_authority": False,
        "scope": "Original initial collection sequence; no new evaluation claims",
    }


def main():
    import h20_teacher_binding_v8 as runtime
    import source_binding as source
    import task_configured_binding as configured
    import task_family_binding as family

    execution = runtime.execution
    host = execution.previous
    host.host()
    assert host.OWNER == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
    plan_path = host.PROJECT / "coordination/20261021_agent_data_collection/PLAN.json"
    plan_raw = plan_path.read_bytes()
    assert hashlib.sha256(plan_raw).hexdigest() == PLAN_SHA
    plan = source.decode(plan_raw)
    partition = plan["source_partitions"][TASK]
    root = execution.A / "task_sources" / TASK
    receipt_path = host.D / "migration/STACK_L0_PREPARATION_CPU_001.json"
    assert not root.exists() and not receipt_path.exists(), "Reuse existing preparation"
    task_path = execution.NATIVE / "task/RoboDojo/tasks" / (TASK + ".py")

    def ref(path):
        return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

    task_ref = ref(task_path)
    module = configured.source_module(TASK, 400, task_ref)
    assert module.task_budget(TASK)[0] == 400
    rows, raw_layouts = [], {}
    for index in partition["train"] + partition["development"]:
        assert index not in partition["reserved_final"]
        path = execution.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{TASK}_{index}.json"
        raw = path.read_bytes()
        layout = source.decode(raw)
        raw_layouts[index] = raw
        group = TASK + "/task_content_family/" + family.family(layout)["content_sha256"]
        rows.append({
            "layout_id": index, "native_bank": 0,
            "layout_ref": {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()},
            "initialization_content_sha256":
                hashlib.sha256(source.canonical(layout).encode()).hexdigest(),
            "group_id": group,
        })
    split = manifest(partition, rows)
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    split.update(
        campaign_id=module.sequence.CAMPAIGN, owner_chat=module.OWNER,
        execution_owner=host.OWNER, frozen_at=at,
        previous_plan={"path": str(plan_path), "sha256": PLAN_SHA})

    def put(path, value):
        with path.open("x") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
        return ref(path)

    root.mkdir()
    metadata = {
        "schema": "refate.selected_task_metadata.v1", "data_kind": "preparation_only",
        "at": at, "task": TASK, "task_implementation": task_ref, "native_budget": 400,
        "original_plan": split["previous_plan"], "original_partition": partition,
        "selected_layout_refs": [row["layout_ref"] for row in rows],
        "family_algorithm": "full_layout_except_Rigid_Geometry_initial_pose_v1",
        "sealed_content_read": False, "model_calls": 0, "native_started": False,
        "execution_owner": host.OWNER,
    }
    split["metadata_evidence"] = put(root / "METADATA_001.json", metadata)
    split_ref = put(root / "SPLIT_MANIFEST_001.json", split)
    prepared, layout = configured.prepare_source(
        task=TASK, layout_id=0, split_ref=split_ref, native_total=400, task_ref=task_ref)
    assert layout == source.decode(raw_layouts[0])
    preparation_ref = put(root / "PREPARATION_L0_CONFIGURED_001.json", prepared)
    assert configured.load_native_layout(prepared) == layout
    receipt = {
        "schema": "refate.actual_metadata_preparation.v1",
        "data_kind": "actual_source_metadata_not_execution", "at": at,
        "execution_owner": host.OWNER, "task": TASK,
        "source_id": prepared["source"]["source_id"], "native_total": 400,
        "preparation_ref": preparation_ref, "split_ref": split_ref,
        "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
        "group_count": len(split["families"]), "group_conflicts": split["group_conflicts"],
        "unread_sealed_layout_ids": [53, 54], "native_started": False,
        "source_registered": False, "source_reserved": False, "model_calls": 0,
        "runtime_files_modified": False, "preparation_helper": ref(Path(__file__)),
    }
    receipt_ref = put(receipt_path, receipt)
    print(json.dumps({**receipt, "receipt_ref": receipt_ref}))


if __name__ == "__main__":
    main()
