"""Read-only container counters; diagnostic failure never changes qualification."""
import datetime
import json
from pathlib import Path
import sys
import time


def snapshot(proc_root=Path("/proc"), cgroup_root=Path("/sys/fs/cgroup"), *, synthetic=False):
    mem = {}
    for line in (proc_root / "meminfo").read_text().splitlines():
        key, value = line.split(":", 1)
        if key in ("MemTotal", "MemAvailable", "CommitLimit", "Committed_AS",
                   "SwapTotal", "SwapFree", "Dirty", "Writeback"):
            mem[key] = int(value.split()[0]) * 1024
    rows = []
    for line in (proc_root / "self/cgroup").read_text().splitlines():
        _, controllers, relative = line.split(":", 2)
        if ".." in Path(relative).parts:
            raise ValueError("Unexpected cgroup path")
        if not controllers:
            base = cgroup_root
            names = ("memory.current", "memory.peak", "memory.max", "memory.events",
                     "memory.stat", "memory.swap.current", "memory.swap.max", "memory.pressure")
        elif "memory" in controllers.split(","):
            base = cgroup_root / "memory"
            names = ("memory.usage_in_bytes", "memory.max_usage_in_bytes",
                     "memory.limit_in_bytes", "memory.failcnt", "memory.oom_control",
                     "memory.stat", "memory.memsw.usage_in_bytes", "memory.memsw.limit_in_bytes")
        else:
            continue
        current = base / relative.lstrip("/")
        if not (current / names[0]).is_file():
            current = base
        while current == base or current.is_relative_to(base):
            values = {}
            for name in names:
                path = current / name
                if path.is_file():
                    raw = path.read_text()
                    if len(raw) > 65536:
                        raise ValueError("Unbounded memory diagnostic")
                    values[name] = int(raw.strip()) if raw.strip().isdigit() else raw.strip()
            if values:
                rows.append({"path": str(current), "values": values})
            if current == base:
                break
            current = current.parent
    overcommit = {}
    for name in ("overcommit_memory", "overcommit_ratio"):
        path = proc_root / "sys/vm" / name
        if path.is_file():
            overcommit[name] = int(path.read_text().strip())
    return {
        "schema": "refate.readonly_memory_diagnostic.v1",
        "data_kind": "synthetic_cpu_fixture" if synthetic else "actual_diagnostic_not_qualification",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wall_ns": time.time_ns(), "host_memory_bytes": mem,
        "cgroups": rows, "overcommit_settings": overcommit,
        "memory_reclaimed": False, "limits_modified": False,
    }


def record(run, phase):
    try:
        value = snapshot()
        value.update(run_id=run.name, phase=phase)
        with (run / ("memory_diagnostic_" + phase + ".json")).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
    except Exception as error:
        print("Read-only memory diagnostic failed: " + repr(error), file=sys.stderr, flush=True)
