"""Reuse the checked storage/family wrapper with the original Conveyor preparer."""
from pathlib import Path

path = Path(__file__).with_name("prepare_organize_h20_v2.py")
text = path.read_text()
for old, new, count in (
    ("organize_table", "pick_from_conveyor_by_image", 2),
    ("ORGANIZE_L", "CONVEYOR_L", 1),
    ("prepare_next_organize_handoff_v1.py", "prepare_next_conveyor_handoff_v1.py", 1),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::conveyor_same_family_rules", "exec"), globals())
