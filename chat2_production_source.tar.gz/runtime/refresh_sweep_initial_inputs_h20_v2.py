"""Supply the original interruption validator to the admission-only wrapper."""
from pathlib import Path
from closed_policy_loading_resource_h20_v1 import loading_checks

path = Path(__file__).with_name("refresh_sweep_initial_inputs_h20_v1.py")
exec(compile(path.read_text(), __file__ + "::preserved_v1_wrapper", "exec"), globals())
