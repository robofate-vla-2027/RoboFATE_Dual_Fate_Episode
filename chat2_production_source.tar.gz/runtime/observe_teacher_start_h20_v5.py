"""Original start evidence with the caller's immutable active context name."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_start_h20_v1.py")
text = path.read_text().replace("h20_teacher_binding_v2", "h20_teacher_binding_v6")
seam = 'exec(compile(text, str(path) + "::h20_start_devices", "exec"), globals())'
assert text.count(seam) == 1
text = text.replace(seam, """
text = execution.edit(text, "run/'CONTEXT_001.json'",
                      "run/x.get('context_name','CONTEXT_001.json')")
""" + seam)
exec(compile(text, str(path) + "::active_context", "exec"), globals())
