"""Original Native teacher with the Stack400 task binding."""
from pathlib import Path

path = Path(__file__).with_name("native_teacher_h20_v8.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v8") == 1
exec(compile(text.replace("h20_teacher_binding_v8", "h20_teacher_binding_v9"),
             str(path) + "::stack400", "exec"), globals())
