"""Reuse the exact compiled-cache implementation for original SwapT400 contexts."""
from policy_cache_seed_stack_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = 'context["task"] == "stack_blocks_by_language"'
    assert text.count(old) == 1
    return text.replace(old, 'context["task"] == "swap_T"', 1)


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::SwapT400_original_budget", "exec"), namespace)
    return namespace["install"](run)
