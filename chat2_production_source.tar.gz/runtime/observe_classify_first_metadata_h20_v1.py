"""Existing partial readback observer for Classify1100 and release030."""
from pathlib import Path

path = Path(__file__).with_name("observe_fasten_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_fasten_screws_l7_h20_baseline_0001_01a16807",
     "c2_classify_objects_l10_h20_baseline_0001_01a16807"),
    ('start["native_budget"] == 1900', 'start["native_budget"] == 1100'),
    ("native_total=1900", "native_total=1100"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_029.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_030.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Classify10_metadata_only", "exec"), globals())
