"""Existing catalog-correct metadata export using the future teacher binding."""
import sys
import h20_teacher_binding_v15 as binding

sys.modules["h20_teacher_binding_v14"] = binding
import prepare_teacher_metadata_h20_v16 as previous
import teacher_catalog_sweep_h20_v1 as catalog


def main():
    text = previous.main_source()
    old = "collect_teacher_h20_v14.py"
    assert text.count(old) == 1
    text = text.replace(old, "collect_teacher_h20_v15.py", 1)
    scope = dict(previous.previous.__dict__)
    scope.update(
        __file__=__file__,
        RELEASE=binding.execution.D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261109_016.json",
        _metadata_task_totals=dict(catalog.TASK_TOTALS),
    )
    assert scope["binding"] is binding
    exec(compile(text, __file__ + "::same_metadata_future_binding", "exec"), scope)
    scope["main"]()


if __name__ == "__main__":
    assert len(sys.argv) == 1
    main()

