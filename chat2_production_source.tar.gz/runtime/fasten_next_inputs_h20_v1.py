"""Original boundary exporter with Fasten's retained L6 and next L7 metadata."""
from pathlib import Path
from dolls_next_inputs_h20_v2 import source as previous_source, teacher_checks


def source():
    text = previous_source()
    for old, new in (
        ("import h20_container_binding_v7 as execution", "import h20_container_binding_v10 as execution"),
        ("assert 15 <= index < 28", "assert index == 7"),
        ('task = "sort_nesting_dolls_by_size"', 'task = "fasten_screws"'),
        ("if index == 15:", "if index == 7:"),
        ('f"runs/c2_{task}_l14_common_baseline_0015_01a16807"',
         'f"runs/c2_{task}_l6_common_baseline_0001_01a16807"'),
        ('prepared["native_step_limit"] == 1050', 'prepared["native_step_limit"] == 1900'),
        ('manifest["original_partition"]["reserved_final"] == [28, 29]',
         'manifest["original_partition"]["reserved_final"] == [53, 54]'),
        ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json", "RUNTIME_H20_CHAT2_CONTENT_20261108_029.json"),
        ('f"migration/DOLLS_L{index}_PREPARATION_CPU_001.json"',
         'f"migration/FASTEN_L{index}_PREPARATION_CPU_001.json"'),
        ('f"c2_{task}_l{index}_h20_baseline_{index+1:04d}_01a16807"',
         'f"c2_{task}_l{index}_h20_baseline_0001_01a16807"'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    old = 'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'
    new = '''import base64
from h20_insert_metadata_binding_v1 import MAPPINGS
out["manifest"] = manifest
out["append_cpu"] = cpu
out["metadata_path_mappings"] = list(MAPPINGS)
out["documents"] = []
for pin in (cpu_ref, cpu["prior_manifest"], prepared["provenance"]["split"],
            cpu["original_manifest"], ref(prepared_path)):
    raw = Path(pin["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
    out["documents"].append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'''
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Fasten_L7_only", "exec"), globals())
