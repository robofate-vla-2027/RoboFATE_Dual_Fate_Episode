"""Existing chat2 collector with the paired Insert-aware H20 entry."""
import argparse
import json
from pathlib import Path
import h20_container_binding_v6 as binding
import collect_insert_sequence_content_v1 as original

original.core.foreground = binding.foreground
original.core.finish = binding.finish
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--context", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--settle-only", action="store_true")
    args = parser.parse_args()
    result = original.collect(args.context, args.sha256, settle_only=args.settle_only)
    print(json.dumps(result, indent=2), flush=True)
    if result["bridge_status"] == "failed" or result["readback_error"] is not None:
        raise SystemExit(1)
