"""Keep first-action checks while accepting a separately frozen rebind context."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_first_h20_v1.py")
text = path.read_text().replace("h20_teacher_binding_v3", "h20_teacher_binding_v5")
seam = 'exec(compile(text, str(path) + "::h20_private_data", "exec"), globals())'
assert text.count(seam) == 1
text = text.replace(seam, """
assert text.count("run/'CONTEXT_001.json'") == 2
text = text.replace("run/'CONTEXT_001.json'",
                    "run/x.get('context_name','CONTEXT_001.json')")
""" + seam)
exec(compile(text, str(path) + "::active_context", "exec"), globals())
