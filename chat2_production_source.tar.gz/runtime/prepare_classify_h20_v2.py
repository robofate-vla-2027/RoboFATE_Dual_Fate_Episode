"""Use the matched teacher catalog during original Classify preparation."""
from pathlib import Path

path = Path(__file__).with_name("prepare_classify_h20_v1.py")
text = path.read_text()
old = "import h20_container_binding_v9 as execution"
assert text.count(old) == 1
text = text.replace(
    old, "import h20_teacher_binding_v10 as runtime\nexecution = runtime.execution", 1
)
exec(compile(text, str(path) + "::matched_teacher_catalog", "exec"), globals())
