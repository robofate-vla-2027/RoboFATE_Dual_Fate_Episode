"""Reuse the original first actual teacher-action observer on the private root."""
from pathlib import Path
import h20_teacher_binding_v3 as binding

binding.execution.previous.host()
path = binding.execution.A / "teacher_first_observe_v1.py"
text = path.read_text()
old = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/runs"
assert text.count(old) == 1
text = text.replace(old, str(binding.execution.D / "teacher/runs"), 1)
exec(compile(text, str(path) + "::h20_private_data", "exec"), globals())

