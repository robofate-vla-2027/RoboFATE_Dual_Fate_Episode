"""Record closed prelaunch failure without claiming Native or model execution."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import h20_runtime_binding_v1 as binding

binding.host()
run_id = sys.argv[1]
root = binding.D / "teacher/runs" / run_id
record = binding.D / "container_records" / run_id
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
context = json.loads((root / "CONTEXT_001.json").read_bytes())
assert context["run_id"] == run_id and context["execution_owner"] == binding.OWNER
cid = (record / "container.cid").read_text().strip()
container = json.loads(subprocess.check_output(["docker", "inspect", cid]))[0]
assert container["Id"] == cid and not container["State"]["Running"]
assert container["State"]["Pid"] == 0 and container["State"]["ExitCode"] == 1
assert (record / "exit").read_text().strip() == "1"
assert container["Config"]["Labels"]["refate.owner"] == binding.OWNER
assert container["Config"]["Labels"]["refate.run"] == run_id
absent = ("foreground_started.json", "native_started.json", "owned_native.json",
          "owned_policy.json", "initial", "dense", "server/model_ready.json",
          "ready.json", "result.json", "recording_progress.json")
assert all(not (root / name).exists() for name in absent)
console = (record / "console.log").read_text()
assert "OSError: [Errno 30] Read-only file system:" in console
assert "20261106_chat2_h20_01a19072/private_policy_compiled_cache" in console
admission = json.loads((record / "host_admission.json").read_bytes())
assert admission["boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
stat = Path("/proc") / str(admission["pid"]) / "stat"
assert not stat.exists() or int(stat.read_text().rsplit(")", 1)[1].split()[19]) != admission["launcher_start_ticks"]
value = {
    "schema": "refate.actual_container_prelaunch_interruption.v1", "data_kind": "actual",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": binding.OWNER, "source_owner": context["source_owner"],
    "task": context["task"], "source_id": context["source_id"], "run_id": run_id,
    "context": ref(root / "CONTEXT_001.json"), "failure_ref": ref(record / "console.log"),
    "container_inspect_ref": ref(record / "container.inspect.json"),
    "container_id": cid, "container_created": container["Created"],
    "container_finished": container["State"]["FinishedAt"],
    "native_process_started": False, "source_started": False, "writer_started": False,
    "policy_started": False, "observations_committed": 0, "actual_controls_observed": 0,
    "native_terminal": False, "native_success": False, "native_failure_proven": False,
    "safe_for_next_simulator": True, "actual_foreground_tool_returncode": 1,
    "new_positive": 0, "new_negative": 0, "full_readback_passed": False,
    "reusable_DM_failure": False, "source_retry_allowed": False,
    "foreground_to_observation_seconds": None,
    "failure": "OSError30 in cache prelaunch; destination outside container's writable mounts",
    "confirmed_cause": "Host-only mapping probe did not verify container mount visibility",
    "absent_paths": [str(root / name) for name in absent],
    "scientific_execution_started": False, "model_or_api_called": False,
}
target = root / "MAIN_PRELAUNCH_INTERRUPTION_SETTLEMENT_001.json"
with target.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
value["settlement_ref"] = ref(target)
print(json.dumps(value))
