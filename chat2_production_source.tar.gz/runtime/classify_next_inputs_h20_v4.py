"""Classify L10 after settled L28, with Fasten L7 as resource predecessor."""
from classify_next_inputs_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("h20_teacher_binding_v11", "h20_teacher_binding_v14", 1),
        ("(index, predecessor_index) == (38, 32)", "(index, predecessor_index) == (10, 28)", 1),
        ('resource_run_id == "c2_classify_objects_l32_evo_common_teacher_0001_01a16807"',
         'resource_run_id == "c2_fasten_screws_l7_evo_common_teacher_0001_01a16807"', 1),
        ("teacher/runs/c2_classify_objects_l32_h20_baseline_0001_01a16807",
         "teacher/runs/c2_classify_objects_l28_h20_baseline_0001_01a16807", 1),
        ('prior / "MAIN_SETTLEMENT_001.json"', 'prior / "MAIN_INTERRUPTION_SETTLEMENT_002.json"', 2),
        ("RUNTIME_H20_CHAT2_CONTENT_20261107_017.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261108_030.json", 1),
        ("b180c8531d7d3f4f8eb3b3ae567a867828c77d1e9947f275ceb3159775631764",
         "6db925692df011ba4cc0ae511dc97279020894aaaf2b49977f9fa0e5a84bdc80", 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Classify10_after_settled28", "exec"), globals())
