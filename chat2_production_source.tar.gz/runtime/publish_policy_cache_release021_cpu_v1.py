"""Publish only the checked private cache backing change, not a latency claim."""
import datetime
import hashlib
import json
from pathlib import Path
import tempfile

import h20_container_binding_v10 as binding
import policy_cache_seed_h20_v2 as cache
import prelaunch_general_cache_tmpfs_v6 as prelaunch
from policy_cache_seed_h20_v1 import MANIFEST

binding.previous.host()
d = binding.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
probe_path = d / "migration/CACHE_MAPPING_CPU_001/RESULT.json"
probe = json.loads(probe_path.read_bytes())
assert probe["paths"]["/tmp"]["noexec"] and not probe["paths"]["/tmp"]["mapping_passed"]
assert probe["paths"][str(probe_path.parent)]["mapping_passed"]
assert not any(probe[k] for k in ("model_calls", "gpu_calls", "simulator_calls",
                                  "network_calls", "mapped_bytes_executed"))
manifest = json.loads(MANIFEST.read_bytes())
before = cache.verified_payloads(manifest)
with tempfile.TemporaryDirectory(prefix="cache_mapping_cpu_", dir=d / "migration") as temporary:
    root = Path(temporary)
    mapping = cache.check_mapping(root)
    result = cache.stage(manifest, root / "staged",
                         {"triton": root / "logical/triton", "cuda": root / "logical/cuda"})
    assert cache.verified_payloads(manifest) == before
    changed = set(result["rewritten_group_paths_only"])
    for relative, raw in before.items():
        if relative not in changed:
            assert (root / "staged" / relative).read_bytes() == raw
text = prelaunch.source()
compile(text, "CPU_cache_mapping_prelaunch_expansion", "exec")
assert 'ENTRY = D / "runtime/collect_h20_container_v11.py"' in text
assert 'value["native_wall_seconds"] == 2400' in text
assert 'value["native_total_steps"] == 200' in text
assert "policy_cache_seed_h20_v2.install(run)" in text
cpu = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    data_kind="CPU_cache_mapping_not_scientific_data",
    cache_manifest=ref(MANIFEST), compiled_artifacts_byte_identical=True,
    source_cache_unchanged=True, only_group_child_paths_relocated=True,
    files=result["files"], bytes=result["bytes"], group_paths_relocated=len(changed),
    synthetic_tests_passed=8, backing_mapping_probe_ref=ref(probe_path), **mapping,
    real_compiled_artifacts_executed=False, model_calls=False, gpu_calls=False,
    simulator_calls=False, observation_or_action_or_rng_state_reused=False,
    original_request_timeout_seconds=120, model_loading_allowance_seconds=900,
    baseline_wall_seconds=2400, teacher_wall_seconds=3600,
    actual_latency_improvement_verified=False, actual_future_source_started=False)
cp = d / "migration/POLICY_COMPILED_CACHE_MAPPING_CPU_001.json"
with cp.open("x") as stream:
    json.dump(cpu, stream, indent=2)
    stream.write("\n")
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_020.json"
release = json.loads(old.read_bytes())
release.update(at=cpu["at"], prior_cache_mapping_release=ref(old),
               cache_cpu_check=ref(cp), prelaunch_entry=ref(d / "runtime/prelaunch_general_cache_tmpfs_v6.py"),
               actual_adoption=False,
               change_scope="Only move private compiled policy cache from noexec tmpfs to "
               "chat2-private executable data directory. No mount/security changes. "
               "Collector, policy, model, RNG, physics, RGB, readers and timeouts unchanged.")
for name in ("policy_cache_seed_h20_v2.py", "prelaunch_general_cache_tmpfs_v6.py"):
    release["runtime_files"].append(ref(d / "runtime" / name))
new = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_021.json"
with new.open("x") as stream:
    json.dump(release, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(release=ref(new), cache_cpu=ref(cp), mapping_probe=ref(probe_path),
                     prelaunch=release["prelaunch_entry"], actual_adoption=False)))
