"""Prepare one next source from the existing frozen Stack initial split."""
import datetime
import hashlib
import json
from pathlib import Path
import sys


def main():
    import h20_teacher_binding_v8 as runtime
    import source_binding as source
    import task_configured_binding as configured

    execution = runtime.execution
    host = execution.previous
    host.host()
    index = int(sys.argv[1])
    assert 1 <= index <= 6
    task = "stack_blocks_by_language"
    root = execution.A / "task_sources" / task
    prior = json.loads((root / "PREPARATION_L0_CONFIGURED_001.json").read_bytes())
    split_ref = prior["provenance"]["split"]

    def read(reference):
        raw = Path(reference["path"]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == reference["sha256"]
        return source.decode(raw)

    def put(path, value):
        with path.open("x") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
        return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

    split = read(split_ref)
    assert split["initial_source_sequence"] == list(range(7))
    assert split["original_partition"]["reserved_final"] == [53, 54]
    assert prior["native_step_limit"] == 400
    task_ref = prior["provenance"]["task_implementation"]
    preparation_path = root / f"PREPARATION_L{index}_CONFIGURED_001.json"
    receipt_path = host.D / f"migration/STACK_L{index}_PREPARATION_CPU_001.json"
    assert not preparation_path.exists() and not receipt_path.exists(), "Reuse existing preparation"
    prepared, layout = configured.prepare_source(
        task=task, layout_id=index, split_ref=split_ref, native_total=400, task_ref=task_ref)
    assert prepared["source"]["source_sequence"] == list(range(7))
    assert prepared["source"]["required_accounted_prefix"] == list(range(index))
    assert layout == read(split["layouts"][str(index)]["layout_ref"])
    assert configured.load_native_layout(prepared) == layout
    preparation_ref = put(preparation_path, prepared)
    receipt = {
        "schema": "refate.actual_metadata_preparation.v1",
        "data_kind": "actual_source_metadata_not_execution",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": host.OWNER, "task": task,
        "source_id": prepared["source"]["source_id"], "native_total": 400,
        "preparation_ref": preparation_ref, "split_ref": split_ref,
        "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
        "unread_sealed_layout_ids": [53, 54], "native_started": False,
        "source_registered": False, "source_reserved": False, "model_calls": 0,
        "runtime_files_modified": False, "existing_split_unchanged": True,
    }
    receipt_ref = put(receipt_path, receipt)
    print(json.dumps({**receipt, "receipt_ref": receipt_ref}))


if __name__ == "__main__":
    main()
