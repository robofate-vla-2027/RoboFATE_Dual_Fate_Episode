"""Same runtime, admitting only its own Insert sequence publication locations."""
import h20_container_binding_v6 as _prior
from h20_container_binding_v6 import *
import h20_insert_private_metadata_v1 as private_insert_metadata

_text = edit(_prior._text, str(D / "runtime/native_h20_container_v4.py"),
             str(D / "runtime/native_h20_container_v5.py"))
foreground = previous.load_source("_refate_h20_container_v7_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "POLICY", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))
