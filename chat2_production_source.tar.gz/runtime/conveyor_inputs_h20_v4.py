"""Actual Conveyor storage and native-extension inputs with baseline038."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_inputs_h20_v3.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261108_034.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json", 1)
exec(compile(text, __file__ + "::Conveyor_original_schema_release038", "exec"), globals())
