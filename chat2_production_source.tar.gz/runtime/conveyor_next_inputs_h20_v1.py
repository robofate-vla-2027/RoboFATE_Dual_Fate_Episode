"""Existing ordered boundary export, using the saved Conveyor18 CPU receipt."""
from pathlib import Path

path = Path(__file__).with_name("organize_next_inputs_h20_v1.py")
text = path.read_text()
for old, new, count in (
    ('mode in ("check", "inputs") and 23 <= index < 53', 'mode == "inputs" and index == 18', 1),
    ("ORGANIZE_L", "CONVEYOR_L", 2),
    ("organize_table", "pick_from_conveyor_by_image", 2),
    ('prepared["native_step_limit"] == 1000', 'prepared["native_step_limit"] == 700', 1),
    ("PREPARATION_CPU_001.json", "CACHE_BINDING_CPU_001.json", 1),
    ('cpu["preparation"]', 'cpu["source_preparation"]', 1),
    ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_034.json", 1),
    ("collect_h20_container_v8.py", "collect_h20_container_v11.py", 1),
):
    assert text.count(old) == count, old
    text = text.replace(old, new, count)
exec(compile(text, __file__ + "::Conveyor18_saved_CPU", "exec"), globals())
