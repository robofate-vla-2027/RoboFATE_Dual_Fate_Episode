"""Original Organize prelaunch, restricted to the next prepared L26 source."""
from prelaunch_organize_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = "c2_organize_table_l25_h20_baseline_0026_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_organize_table_l26_h20_baseline_0027_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Organize26_original_collector", "exec"), globals())
