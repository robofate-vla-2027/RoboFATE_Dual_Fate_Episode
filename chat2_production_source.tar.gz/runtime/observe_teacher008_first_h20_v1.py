"""Read first-action evidence through the same teacher008 binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_first_h20_v2.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v5") == 1
text = text.replace("h20_teacher_binding_v5", "h20_teacher_binding_v8")
exec(compile(text, str(path) + "::teacher008", "exec"), globals())
