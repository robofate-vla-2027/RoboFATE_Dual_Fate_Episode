"""Read bounded compiled artifacts only after verifying their original run is closed."""
import datetime
import hashlib
import json
from pathlib import Path

import h20_runtime_binding_v1 as binding

binding.host()
d = binding.D
run = d / "teacher/runs/c2_general_pickup_l27_h20_baseline_0001_01a16807"
for role in ("native", "policy"):
    identity = json.loads((run / f"owned_{role}.json").read_bytes())["identity"]
    assert identity["boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    stat = Path(f"/proc/{identity['pid']}/stat")
    assert not stat.exists() or int(stat.read_text().rsplit(")", 1)[1].split()[19]) != identity["start_ticks"]
inspection = json.loads((d / "container_records" / run.name / "container.inspect.json").read_bytes())[0]
assert inspection["Config"]["Labels"]["refate.owner"] == binding.OWNER
assert inspection["Config"]["Labels"]["refate.run"] == run.name
assert not inspection["State"]["Running"]
roots = {"triton": run / "runtime/cache/triton", "cuda": run / "runtime/home/.nv"}
rows = []
for kind, root in roots.items():
    assert root.is_dir() and not root.is_symlink()
    for path in sorted(root.rglob("*")):
        assert not path.is_symlink()
        if path.is_dir():
            continue
        assert path.is_file()
        relative = path.relative_to(root)
        if kind == "cuda":
            assert relative.parts[0] == "ComputeCache"
        else:
            assert path.suffix in (".source", ".ttir", ".ttgir", ".llir", ".ptx",
                                   ".cubin", ".json", ".so")
        raw = path.read_bytes()
        rows.append(dict(relative=str(Path(kind) / relative), bytes=len(raw),
                         sha256=hashlib.sha256(raw).hexdigest(), mtime_ns=path.stat().st_mtime_ns))
assert len(rows) <= 256 and sum(row["bytes"] for row in rows) <= 32 * 1024**2
software_paths = [
    binding.POLICY_ENV / "lib/python3.10/site-packages/triton/runtime/cache.py",
    binding.POLICY_ENV / "lib/python3.10/site-packages/triton/__init__.py",
    d / "runtime/policy_h20_container_v1.py",
    d / "native/XPolicyLab/policy/OpenDM/scripts/robodojo_dm05_history.py",
]
software = [dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in software_paths]
value = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             execution_owner=binding.OWNER, source_run=run.name,
             roots={k: str(p) for k, p in roots.items()}, files=rows,
             bytes=sum(row["bytes"] for row in rows), software=software,
             owned_processes_closed=True, scientific_state_reused=False,
             model_weights_included=False, frames_or_actions_included=False,
             latency_cause_proven=False, future_latency_improvement_verified=False)
target = d / "migration/GENERAL_L27_COMPILED_CACHE_MANIFEST_001.json"
with target.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
print(json.dumps(dict(manifest={"path": str(target),
                              "sha256": hashlib.sha256(target.read_bytes()).hexdigest()},
                      files=len(rows), bytes=value["bytes"], scientific_state_reused=False)))

