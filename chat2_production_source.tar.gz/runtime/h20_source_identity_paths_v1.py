"""Compare original identities exactly after reversible layout-path mapping."""
from copy import deepcopy


def normalize(value, mapper):
    out = deepcopy(value)
    if not isinstance(out, dict):
        return out
    if "resolved_layout_path" in out:
        prior = out["resolved_layout_path"]
        out["resolved_layout_path"] = mapper(prior)
        if out["resolved_layout_path"] != prior:
            assert mapper(out["resolved_layout_path"], inverse=True) == prior
    pin = out.get("layout_ref")
    if isinstance(pin, dict) and "path" in pin:
        prior = pin["path"]
        pin["path"] = mapper(prior)
        if pin["path"] != prior:
            assert mapper(pin["path"], inverse=True) == prior
    return out


def compare(value, expected, original, mapper):
    return original(normalize(value, mapper), normalize(expected, mapper))


def install(binding):
    from h20_insert_metadata_binding_v1 import locations
    restore = binding.preparation.restore
    original = restore._identity_source_id
    if getattr(original, "_refate_layout_paths_v1", False):
        return

    def identity(value, expected):
        return compare(value, expected, original, locations)

    identity._refate_layout_paths_v1 = True
    restore._identity_source_id = identity
