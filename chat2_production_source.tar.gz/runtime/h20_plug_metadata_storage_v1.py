"""Process-local Plug metadata paths; frozen bytes and raw layouts stay intact."""
from copy import deepcopy

TASK = "plug_in_charger"


def verify_storage_only(before, after, mapper):
    assert type(before) is type(after)
    if isinstance(before, dict):
        assert before.keys() == after.keys()
        for key in before:
            verify_storage_only(before[key], after[key], mapper)
    elif isinstance(before, list):
        assert len(before) == len(after)
        for left, right in zip(before, after):
            verify_storage_only(left, right, mapper)
    elif before != after:
        assert isinstance(before, str)
        assert mapper(before) == after and mapper(after, inverse=True) == before


def translate(value, mapper):
    if not isinstance(value, dict):
        return value
    schema = value.get("schema", "")
    source = value.get("source", {})
    task = value.get("task", source.get("task") if isinstance(source, dict) else None)
    if not isinstance(schema, str) or not schema.startswith("refate.") or task != TASK:
        return value
    translated = mapper(deepcopy(value))
    verify_storage_only(value, translated, mapper)
    return translated


def install(metadata, mapper):
    previous = metadata.original.decode
    if getattr(previous, "_refate_plug_storage_v1", False):
        return

    def decode(raw):
        return translate(previous(raw), mapper)

    decode._refate_plug_storage_v1 = True
    metadata.original.decode = decode


def install_runtime():
    from h20_insert_metadata_binding_v1 import locations
    import task_source_binding as metadata
    install(metadata, locations)
