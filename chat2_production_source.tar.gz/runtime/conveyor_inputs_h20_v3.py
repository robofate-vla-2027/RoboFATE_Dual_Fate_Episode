"""Original Conveyor storage/extension inputs through the matched release034."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ("RUNTIME_H20_CHAT2_CONTENT_20261106_010.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_034.json"),
    ('"cpu_ref": release["cpu_check"]', '"cpu_ref": release["conveyor_cache_cpu"]'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Conveyor_original_schema_release034", "exec"), globals())
