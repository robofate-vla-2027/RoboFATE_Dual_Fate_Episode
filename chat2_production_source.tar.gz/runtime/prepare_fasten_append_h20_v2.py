"""Prepare only Fasten L8, preserving and verifying the complete L7 append."""
from pathlib import Path
from prepare_fasten_append_h20_v1 import TASK, ORIGINAL_SHA, NORMALIZER_SHA, merge


def source():
    text = Path(__file__).with_name("prepare_fasten_append_h20_v1.py").read_text()
    checks = '''    assert original["initial_source_sequence"] == list(range(7))
    assert prior["initial_source_sequence"] == list(range(8))
    append = prior["collection_append"]
    assert append["added_layout"] == 7 and append["prior_sequence"] == list(range(7))
    legacy = read(append["prior_split"])
    assert legacy["layout_to_group"] == original["layout_to_group"]
    assert legacy["families"] == original["families"]
    assert prior == merge(legacy, prior["layouts"]["7"], append["prior_split"],
                          append["at"], append["metadata_helper"])
    assert ref(Path(append["metadata_helper"]["path"])) == append["metadata_helper"]'''
    old = '''    assert prior["initial_source_sequence"] == original["initial_source_sequence"] == list(range(7))
    assert prior["layout_to_group"] == original["layout_to_group"]
    assert prior["families"] == original["families"]'''
    edits = (
        ('assert index == 7, "Only the next original Fasten source is prepared here"',
         'assert index == 8, "Only the next original Fasten L8 is prepared here"'),
        ('"SPLIT_LEGACY_VIEW_L6_001.json"', '"SPLIT_APPEND_L7_001.json"'),
        ('"SPLIT_APPEND_L7_001.json"\n    prep_path', '"SPLIT_APPEND_L8_001.json"\n    prep_path'),
        ('"PREPARATION_L7_CONFIGURED_001.json"', '"PREPARATION_L8_CONFIGURED_001.json"'),
        ('"migration/FASTEN_L7_PREPARATION_CPU_001.json"',
         '"migration/FASTEN_L8_PREPARATION_CPU_001.json"'),
        (old, checks),
        ('for i in range(7))', 'for i in range(index))'),
        ('prepared["source"]["source_sequence"] == list(range(8))',
         'prepared["source"]["source_sequence"] == list(range(index + 1))'),
        ('prepared["source"]["required_accounted_prefix"] == list(range(7))',
         'prepared["source"]["required_accounted_prefix"] == list(range(index))'),
        ('"source_sequence": list(range(8)), "required_accounted_prefix": list(range(7))',
         '"source_sequence": list(range(index + 1)), "required_accounted_prefix": list(range(index))'),
    )
    for old, new in edits:
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::verified_L7_to_L8", "exec"), globals())
