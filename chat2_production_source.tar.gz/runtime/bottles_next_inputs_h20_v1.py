"""Reuse existing Bottles preparation with separate source/resource predecessors."""
from pathlib import Path

path = Path(__file__).with_name("plug_next_inputs_h20_v1.py")
text = path.read_text()
for old, new in (
    ('"h20_container_binding_v8"', '"h20_container_binding_v9"'),
    ("plug_in_charger", "put_bottles_into_dustbin"),
    ("PREPARATION_L{index}_APPEND_001.json", "PREPARATION_L{index}_CONFIGURED_001.json"),
    ('prepared["native_step_limit"] == 400', 'prepared["native_step_limit"] == 700'),
    ('"native_total": 400', '"native_total": 700'),
    ("PLUG_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json", "BOTTLES_L{index}_ACTUAL_BASELINE_LOADER_CHECK_001.json"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261107_014.json", "RUNTIME_H20_CHAT2_CONTENT_20261107_016.json"),
    ("collect_h20_container_v9.py", "collect_h20_container_v10.py"),
    ("if index == 23:", "if index == 32:"),
    ("c2_put_bottles_into_dustbin_l22_common_baseline_0023_01a16807",
     "c2_put_bottles_into_dustbin_l31_common_baseline_0032_01a16807"),
    ('ref(binding.A / "owner_reservation_handoff_v1.py")',
     'ref(binding.A / "owner_positive_gap_reservation_v1.py")'),
):
    assert old in text
    text = text.replace(old, new)
seam = 'exec(compile(text, str(path) + "::plug_original_boundary", "exec"), globals())'
assert text.count(seam) == 1
extra = '''
old = "prepared = json.loads(prepared_path.read_bytes())"
assert text.count(old) == 1
text = text.replace(old,
    "import collection_append_binding_v1 as append_metadata\\n"
    "prepared = append_metadata.document({'path':str(prepared_path),"
    "'sha256':hashlib.sha256(prepared_path.read_bytes()).hexdigest()})", 1)
old = "run.mkdir()"
assert text.count(old) == 1
text = text.replace(old, old + "\\nresource.update(run_id=run_id, source_id=prepared['source']['source_id'])", 1)
old = '"last_teacher_settlement": None,'
new = ('"last_teacher_settlement": (terminal["summary_ref"] '
       'if resource_kind == "closed_teacher_resource_v1" '
       'and terminal["source_id"] == source_predecessor["source_id"] else None),')
assert text.count(old) == 1
text = text.replace(old, new, 1)
old = 'resource_path = host.D / "teacher/runs" / resource_run_id / resource_name'
assert text.count(old) == 1
text = text.replace(old,
    'if len(sys.argv) > 4:\\n'
    '    resource_name = sys.argv[4]\\n'
    '    assert resource_name.startswith("MAIN_TERMINAL_OBSERVATION_") and resource_name.endswith(".json") and "/" not in resource_name\\n'
    + old, 1)
'''
text = text.replace(seam, extra + "\n" + seam, 1)
exec(compile(text, str(path) + "::existing_Bottles_preparation", "exec"), globals())
