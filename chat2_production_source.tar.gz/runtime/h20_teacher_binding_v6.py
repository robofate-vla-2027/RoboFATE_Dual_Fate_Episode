"""Original teacher with the same process-local Plug metadata storage binding."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v5.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v5"', '"native_teacher_h20_v6"'),
    ('"collect_teacher_h20_v5"', '"collect_teacher_h20_v6"'),
    ('"prepare_teacher_h20_v5"', '"prepare_teacher_h20_v6"'),
    ('"_refate_h20_teacher_native_scope_v5"', '"_refate_h20_teacher_native_scope_v6"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::plug_metadata_storage", "exec"), globals())

from h20_plug_metadata_storage_v1 import install_runtime
install_runtime()
