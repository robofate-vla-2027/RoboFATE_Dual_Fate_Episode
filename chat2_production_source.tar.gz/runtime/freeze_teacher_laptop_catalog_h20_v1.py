"""Freeze only the task-catalog extension after targeted offline CPU checks."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest

import test_teacher_laptop_binding_cpu_v1 as tests
import h20_teacher_binding_v12 as teacher
from teacher_history_pre_actor_catalog012_v1 import NATIVE_SHA

teacher.execution.previous.host()
D = teacher.execution.D
ref = lambda path: {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
native_sha = hashlib.sha256(teacher._text.encode()).hexdigest()
assert native_sha == NATIVE_SHA
assert teacher._text.index("history=common_teacher.load_causal_history(") < (
    teacher._text.index("model=teacher_worker_binding.model("))
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(
    unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 6
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_011.json"
assert ref(prior)["sha256"] == "6c6346beb5cc1036a2f68d53bcc4e88b35eeeb4d8aa862ed1fe9c41ff995734e"
release = json.loads(prior.read_bytes())
assert release["model"] == "gt-6-as-a" and release["reasoning_effort"] == "xhigh"
assert release["teacher_wall_seconds"] == release["native_wall_seconds"] == 3600
assert release["baseline_wall_seconds_unchanged"] == 2400
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
names = (
    "teacher_catalog_laptop_h20_v1.py", "h20_teacher_storage_laptop_v1.py",
    "h20_teacher_binding_v12.py", "native_teacher_h20_v12.py",
    "collect_teacher_h20_v12.py", "prepare_teacher_h20_v12.py",
    "prepare_teacher_metadata_h20_v13.py", "teacher_history_pre_actor_catalog012_v1.py",
    "observe_teacher_terminal_h20_v15.py", "observe_teacher012_start_h20_v1.py",
    "observe_teacher012_first_h20_v1.py", "export_teacher012_settlement_metadata_h20_v1.py",
    "test_teacher_laptop_binding_cpu_v1.py", "freeze_teacher_laptop_catalog_h20_v1.py",
    "launch_bound_teacher_release012.sh",
)
for name in names:
    path = D / "runtime" / name
    if path.suffix == ".py":
        compile(path.read_text(), str(path), "exec")
    pin = ref(path)
    pins[pin["path"]] = pin


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/LAPTOP_TEACHER_CATALOG_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "CPU task catalog and configured metadata, not real restoration or execution",
    "tests_passed": result.testsRun, "test_log": log.getvalue(),
    "task": "store_laptop_and_headphones", "original_native_total": 800,
    "effective_native_source_sha256": native_sha, "matched_effective_entries": True,
    "native_content_change": "Only imports of the catalog extended by Laptop800",
    "prior_causal_history_repair_retained": True,
    "real_t1_restoration_verified": False, "real_model_API_or_simulator_called": False,
    "new_scientific_samples": 0, "actual_adoption": False,
})
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_laptop_catalog_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v12.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v12.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v12.py"),
    metadata_preparation_entry=str(D / "runtime/prepare_teacher_metadata_h20_v13.py"),
    launch_environment_binding=ref(D / "runtime/launch_bound_teacher_release012.sh"),
    matched_baseline=ref(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_023.json"),
    laptop_task_binding_cpu=cpu, effective_native_source_sha256=native_sha,
    actual_adoption=False, actual_teacher_takeover_verified=False,
    actual_positive_published=False, actual_laptop_teacher_execution_verified=False,
    change_scope="Add only original Laptop800 catalog and matching future entry/metadata "
                 "bindings. Preserve teacher011 repairs, data rules, physics, model, "
                 "source ownership, teacher3600/baseline2400 and all old releases. "
                 "CPU checks do not verify real articulated t1 restoration.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_012.json", release)
print(json.dumps({
    "teacher_release": output, "cpu": cpu, "actual_adoption": False,
    "baseline_release": release["matched_baseline"],
}))
