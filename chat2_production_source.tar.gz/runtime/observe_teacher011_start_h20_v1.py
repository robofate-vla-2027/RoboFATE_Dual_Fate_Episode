"""Original actual-start observation through the matched teacher011 binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher010_start_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v10") == 1
exec(compile(text.replace("h20_teacher_binding_v10", "h20_teacher_binding_v11"),
             str(path) + "::causal_history_binding", "exec"), globals())
