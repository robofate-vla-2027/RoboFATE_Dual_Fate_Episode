"""Host/path-only binding of the successful chat2 content-v6 teacher."""
import ast
from pathlib import Path
import sys

import h20_teacher_storage_v1 as storage
import h20_container_binding_v4 as execution

stage = execution.stage
assert stage.OWNER == execution.OWNER
stage.PACKAGE = execution.D / "runtime/teacher_package_0.151.0-alpha.7.1"
stage.RUNSC = stage.REPAIR.parent / "teacher_environment_runtime_01a167a6/runsc"

text = execution.edit(
    Path(stage.__file__).read_text(),
    "socket.gethostname() == 'nb-5pl2apckdj-0'",
    "socket.gethostname() == '20250103-instance' and os.environ.get('REFATE_SSH_ALIAS') == 'h20_8'",
)
function = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == "stage")
exec(compile(ast.Module(body=[function], type_ignores=[]),
             __file__ + "::original_isolation_stage_host", "exec"), stage.__dict__)

import gvisor_resources as resources

text = Path(resources.__file__).read_text()
for old, new, count in (
    ("'nb-5pl2apckdj-0'", "'20250103-instance'", 1),
    ("== 'perdon-hou'", "== 'h20_8'", 1),
    ("127.0.0.1:28181", "127.0.0.1:29181", 2),
):
    text = execution.edit(text, old, new, count=count)
exec(compile(text, __file__ + "::original_resources_host_port", "exec"), resources.__dict__)
resources.SUPERVISOR = execution.D / "runtime/gvisor_worker_h20_v1.py"

text = execution.edit(
    storage.native_teacher_content_v6.text,
    "socket.gethostname()=='nb-5pl2apckdj-0' and os.environ.get('REFATE_SSH_ALIAS')=='perdon-hou'",
    "socket.gethostname()=='20250103-instance' and os.environ.get('REFATE_SSH_ALIAS')=='h20_8'",
)
native = execution.previous.load_source("_refate_h20_teacher_native_v1", text)
native.__file__ = str(execution.D / "runtime/native_teacher_h20_v1.py")

text = execution.edit(storage.collect_teacher_content_v6.text,
                      "127.0.0.1:28181", "127.0.0.1:29181")
text = execution.edit(text, "('127.0.0.1',28181)", "('127.0.0.1',29181)")
text = execution.edit(text, "stage.HERE/'native_teacher_content_v6.py'",
                      repr(str(execution.D / "runtime/native_teacher_h20_v1.py")))
collection = execution.previous.load_source("_refate_h20_teacher_collection_v1", text)
collection.__file__ = str(execution.D / "runtime/collect_teacher_h20_v1.py")
collection.native = native
collection.base = execution.foreground

preparation = execution.previous.load_source(
    "_refate_h20_teacher_preparation_v1", storage.prepare_teacher_content_v6.text)
preparation.__file__ = str(execution.D / "runtime/prepare_teacher_h20_v1.py")
preparation.native_shared_teacher = native
