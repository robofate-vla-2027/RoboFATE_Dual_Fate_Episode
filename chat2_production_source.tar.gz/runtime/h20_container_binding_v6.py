"""Same restricted runtime, with reversible Insert metadata storage binding."""
import h20_container_binding_v5 as _prior
from h20_container_binding_v5 import *
import h20_insert_metadata_binding_v1 as insert_storage

_text = edit(_prior._text, str(D / "runtime/native_h20_container_v3.py"),
             str(D / "runtime/native_h20_container_v4.py"))
foreground = previous.load_source("_refate_h20_container_v6_foreground", _text)
for _name in ("host", "allocation", "environment", "helpers", "POLICY", "CONFIG",
              "POLICY_PYTHON", "NATIVE_PYTHON", "LOCK"):
    setattr(foreground, _name, getattr(_prior.foreground, _name))
