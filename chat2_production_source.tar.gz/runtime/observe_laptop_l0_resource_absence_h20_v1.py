"""Read-only resource reconciliation; never synthesize a lifecycle or data verdict."""
import copy
import datetime
import hashlib
import json
from pathlib import Path

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
RUN = "c2_store_laptop_and_headphones_l0_evo_common_teacher_0001_01a16807"
SESSION = "202611071632_c2_laptop_l0_evo_0001"


def validate(terminal, owned, state, checks, matches):
    assert terminal["execution_owner"] == owned["execution_owner"] == OWNER
    assert terminal["run_id"] == RUN and owned["session"] == SESSION
    assert terminal["actual_foreground_tool_returncode"] == 1
    assert terminal["summary"]["native_result"] is None
    assert terminal["summary"]["qualified_positive"] is False
    assert terminal["summary"]["new_positive"] == terminal["summary"]["new_negative"] == 0
    assert owned["runsc"]["supervisor_pid"] == owned["supervisor"]["pid"]
    assert owned["runsc"]["parent_pid"] == owned["worker"]["pid"]
    assert state["id"] == state["sandbox"]["id"] == owned["runsc"]["container_id"]
    assert {r["role"] for r in checks} == {
        "foreground", "native", "worker", "supervisor", "runsc", "gofer", "sandbox"
    }
    assert all(type(r["identity"]["pid"]) is int and r["identity"]["pid"] > 0
               and r["original_process_absent"] is True for r in checks)
    assert not matches


def main():
    import h20_runtime_binding_v1 as binding
    binding.host()
    d = binding.D
    run = d / "teacher/runs" / RUN
    session = d / "teacher/sessions" / SESSION
    ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    original = run / "MAIN_TERMINAL_OBSERVATION_001.json"
    terminal = json.loads(original.read_bytes())
    owned_path = session / "agent/owned_process.json"
    owned = json.loads(owned_path.read_bytes())
    state_path = session / "oci/state/refate-teacher_sandbox:refate-teacher.state"
    state_raw = state_path.read_bytes()
    state = json.loads(state_raw)
    assert state["saver"]["rootDir"] == str(state_path.parent)
    st = state_path.parent.stat()
    assert (st.st_dev, st.st_ino) == (
        owned["runsc"]["state_device"], owned["runsc"]["state_inode"])
    identities = [(r["role"], r["identity"]) for r in terminal["own_process_checks"]]
    identities += [(role, owned[role]) for role in ("worker", "supervisor")]
    identities.append(("runsc", {
        "pid": owned["runsc"]["pid"],
        "start_ticks": int(owned["runsc"]["proc_stat"].rsplit(")", 1)[1].split()[19]),
        "boot_id": owned["supervisor"]["boot_id"],
    }))
    identities += [(role, {"pid": pid}) for role, pid in (
        ("gofer", state["goferPid"]), ("sandbox", state["sandbox"]["pid"]))]
    checks = []
    for role, identity in identities:
        # Require absence even for a reused PID; do not signal or infer ownership.
        absent = not Path(f"/proc/{identity['pid']}").exists()
        checks.append(dict(role=role, identity=identity, original_process_absent=absent))
    matches = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            command = (proc / "cmdline").read_bytes()
        except FileNotFoundError:
            continue
        if any(token.encode() in command for token in (str(run), str(session))):
            matches.append(int(proc.name))
    validate(terminal, owned, state, checks, matches)
    out = copy.deepcopy(terminal)
    out.update(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        original_terminal_observation=ref(original),
        own_process_checks=checks,
        safe_for_next_simulator=True,
        resource_reconciliation=dict(
            kind="actual_read_only_absence_not_successful_shutdown",
            owned_process=ref(owned_path), stale_runsc_state=ref(state_path),
            scoped_live_process_matches=matches, signals_sent=False,
            stale_runtime_files_preserved=True, lifecycle_missing=True,
            scientific_outcome_unchanged=True, original_error_preserved=True,
        ),
    )
    assert not (session / "oci/LIFECYCLE.json").exists()
    assert state_path.read_bytes() == state_raw
    out.pop("evidence_ref", None)
    path = run / "MAIN_RESOURCE_ABSENCE_001.json"
    with path.open("x") as stream:
        json.dump(out, stream, indent=2)
        stream.write("\n")
    out["evidence_ref"] = ref(path)
    print(json.dumps(out))


if __name__ == "__main__":
    main()
