"""Export the original source references through their verified storage copy."""
import base64
import json
from pathlib import Path
import sys
import h20_teacher_binding_v7 as binding
from h20_retained_bottles_storage_v1 import OLD_RUN, SOURCE_ID

binding.execution.previous.host()
retained = json.load(sys.stdin)
assert retained["source_id"] == SOURCE_ID
documents = []
loaded = {}
for key in ("context", "manifest", "settlement", "readback"):
    pin = retained[key]
    assert Path(pin["path"]).is_relative_to(OLD_RUN)
    raw = binding.storage.runtime.read_pin(pin)
    loaded[key] = json.loads(raw)
    assert loaded[key]["source_id"] == SOURCE_ID
    documents.append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
assert loaded["readback"]["file_recording_readback_passed"]
assert loaded["readback"]["native_success"] is False
assert loaded["settlement"]["safe_for_next_simulator"]
assert loaded["settlement"]["summary_ref"] == retained["readback"]
print(json.dumps({"retained": retained, "documents": documents,
                  "RGB_decoded": False, "source_replayed": False, "model_or_API_called": False}))
