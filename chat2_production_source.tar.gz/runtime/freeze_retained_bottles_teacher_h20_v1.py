"""CPU-only adopted-entry/storage check and immutable future teacher binding."""
import datetime
import hashlib
import itertools
import json
from pathlib import Path

import h20_teacher_binding_v7 as teacher
import failure_summary_report_size_v1 as failure
from h20_retained_bottles_storage_v1 import RUN, OLD_RUN, SOURCE_ID, D

teacher.execution.previous.host()
r = teacher.preparation.restore


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


summary = failure.project(r.ref(RUN / "readback_once_001/SUMMARY.json"))
context, manifest = (r.ref(RUN / name) for name in ("CONTEXT_001.json", "SOURCE_MANIFEST_001.json"))
assert context["path"] == str(OLD_RUN / "CONTEXT_001.json")
material = r.source_material(context, manifest, summary, t1=33)
assert material["source_id"] == SOURCE_ID and material["native_limit"] == 700
assert material["profile"]["remaining_native_steps"] == 667
assert material["source"] == str(RUN)
with (RUN / "native_actions.jsonl").open() as stream:
    actions = [json.loads(line) for line in itertools.islice(stream, 36)]
values = [a["action"]["left_ee_joint_state"][0] for a in actions[30:36]]
assert all(value > .99 for value in values[:3]) and values[3] < .99 and values[5] < values[3]
assert actions[32]["native_count_after"] == 33
import teacher_catalog_binding_v13 as catalog
layout = catalog.load_native_layout(material["source_preparation"])
assert layout
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
assert hashlib.sha256(teacher._text.encode()).hexdigest() == "2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376"
cpu = save(D / "migration/BOTTLES_L31_MIGRATED_ENTRY_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "actual_source_metadata_CPU_only_not_restore_or_simulation",
    "source_id": SOURCE_ID, "source_context": context, "source_manifest": manifest,
    "projected_first_readback": summary, "t1": 33, "remaining_steps": 667,
    "original_native_total": 700, "left_gripper_indices30_35": values,
    "matched_teacher_entries": True, "raw_layout_unchanged": True,
    "source_baseline_rerun": False, "full_RGB_decode": False,
    "actual_restore_verified": False, "API_or_model_called": False, "qualified_samples": 0,
})
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_006.json"
assert ref(prior)["sha256"] == "715ffddb79962fd0963c9fd128578354ed53353b01fcff859f683e7a3b480f8c"
release = json.loads(prior.read_bytes())
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
for name in ("h20_bottles_metadata_storage_v1.py", "h20_retained_bottles_storage_v1.py",
             "h20_teacher_binding_v7.py", "native_teacher_h20_v7.py",
             "collect_teacher_h20_v7.py", "prepare_teacher_h20_v7.py",
             "prepare_teacher_metadata_h20_v8.py", "launch_bound_teacher_release007.sh",
             "freeze_retained_bottles_teacher_h20_v1.py"):
    pin = ref(D / "runtime" / name)
    pins[pin["path"]] = pin
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_retained_source_storage_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v7.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v7.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v7.py"),
    launch_environment_binding=ref(D / "runtime/launch_bound_teacher_release007.sh"),
    retained_source_cpu=cpu, actual_adoption=False, actual_positive_published=False,
    change_scope="Bottles metadata paths and byte-verified old-source storage mapping only; "
                 "new destination signatures preserve actual ctime. Original source ledger "
                 "references, RGB, state, action, scoring, renderer, budget and teacher unchanged.")
output = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261107_007.json", release)
print(json.dumps({"teacher_release": output, "cpu": cpu, "actual_adoption": False}))
