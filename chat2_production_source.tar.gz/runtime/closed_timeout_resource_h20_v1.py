"""Validate closed, incomplete Native timeouts without qualifying their data."""

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def timeout_checks(evidence):
    assert evidence["schema"] == "refate.actual_interrupted_baseline.v1"
    assert evidence["data_kind"] == "actual"
    assert evidence["execution_owner"] == OWNER
    assert evidence["timeout_error"]["type"] == "TimeoutExpired"
    assert evidence["native_wall_seconds"] == 2400
    assert evidence["safe_for_next_simulator"] is True
    for key in ("native_terminal", "native_success", "native_failure_proven",
                "full_readback_passed", "reusable_DM_failure"):
        assert evidence[key] is False, key
    assert evidence["new_positive"] == evidence["new_negative"] == 0
    assert evidence["execution_counts_are_last_saved_observation_not_final_counts"] is True
    checks = evidence["process_closure"]["checks"]
    assert len(checks) == 2 and {row["role"] for row in checks} == {"native", "policy"}
    for row in checks:
        assert row["original_process_absent"] is True
        identity = row["identity"]
        assert all(type(identity[key]) is int and identity[key] > 0
                   for key in ("pid", "start_ticks"))
        assert isinstance(identity["boot_id"], str) and identity["boot_id"]
    return checks
