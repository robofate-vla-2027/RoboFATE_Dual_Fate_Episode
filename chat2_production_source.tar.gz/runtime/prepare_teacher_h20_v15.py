"""Use the original metadata preparer with the matched future binding."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_h20_v13.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v13") == 1
exec(compile(text.replace("h20_teacher_binding_v13", "h20_teacher_binding_v15"),
             __file__ + "::future_optional_tool_config", "exec"), globals())

