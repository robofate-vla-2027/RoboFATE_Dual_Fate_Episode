"""Reuse the original next-source checks for L38 after the H20 L32 source."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("classify_next_inputs_h20_v1.py").read_text()
    old_path_view = '''prior_settlement_ref["path"] = (
    "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/"
    "20261022_collection_chat2_01a16338/teacher/shared_teacher/runs/"
    "c2_classify_objects_l24_common_baseline_0001_01a16807/MAIN_SETTLEMENT_001.json"
)'''
    for old, new in (
        ("import h20_teacher_binding_v10 as teacher",
         "import h20_teacher_binding_v11 as teacher"),
        ("(index, predecessor_index) == (32, 24)",
         "(index, predecessor_index) == (38, 32)"),
        ('resource_run_id == "c2_classify_objects_l24_evo_common_teacher_0001_01a16807"',
         'resource_run_id == "c2_classify_objects_l32_evo_common_teacher_0001_01a16807"'),
        ('"MAIN_TERMINAL_OBSERVATION_002.json"', '"MAIN_TERMINAL_OBSERVATION_001.json"'),
        ('prior = execution.A.parent / "runs/c2_classify_objects_l24_common_baseline_0001_01a16807"',
         'prior = host.D / "teacher/runs/c2_classify_objects_l32_h20_baseline_0001_01a16807"'),
        (old_path_view,
         'assert prior_settlement_ref["path"] == str(prior / "MAIN_SETTLEMENT_001.json")'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L38_after_H20_L32", "exec"), globals())
