"""Original Classify boundary checks for L51 after its settled L10 teacher."""
from classify_next_inputs_h20_v4 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("(index, predecessor_index) == (10, 28)", "(index, predecessor_index) == (51, 10)", 1),
        ('resource_run_id == "c2_fasten_screws_l7_evo_common_teacher_0001_01a16807"',
         'resource_run_id == "c2_classify_objects_l10_evo_common_teacher_0001_01a16807"', 1),
        ("teacher/runs/c2_classify_objects_l28_h20_baseline_0001_01a16807",
         "teacher/runs/c2_classify_objects_l10_h20_baseline_0001_01a16807", 1),
        ("MAIN_INTERRUPTION_SETTLEMENT_002.json", "MAIN_SETTLEMENT_001.json", 2),
        ("RUNTIME_H20_CHAT2_CONTENT_20261108_030.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261108_031.json", 1),
        ("6db925692df011ba4cc0ae511dc97279020894aaaf2b49977f9fa0e5a84bdc80",
         "40a07af2ee2210715fb165b29086cef066efe752dac101aa93348c5cc7337b7a", 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Classify51_after_settled10", "exec"), globals())
