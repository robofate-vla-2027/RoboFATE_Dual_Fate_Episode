"""Original collector plus before/after read-only cgroup diagnostic receipts."""
import argparse
import json
from pathlib import Path
import h20_container_binding_v6 as binding
import collect_insert_sequence_content_v1 as original
import memory_diagnostics_h20_v1 as memory

original.core.foreground = binding.foreground
original.core.finish = binding.finish
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--context", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--settle-only", action="store_true")
    args = parser.parse_args()
    context = json.loads(binding.previous.read_pin({"path": str(args.context), "sha256": args.sha256}))
    run = Path(context["run_dir"])
    binding.need(context["execution_owner"] == binding.OWNER and run.parent == binding.D / "teacher/runs",
                 "Owned diagnostic scope required")
    if not args.settle_only:
        memory.record(run, "before")
    try:
        result = original.collect(args.context, args.sha256, settle_only=args.settle_only)
    finally:
        if not args.settle_only:
            memory.record(run, "after")
    print(json.dumps(result, indent=2), flush=True)
    if result["bridge_status"] == "failed" or result["readback_error"] is not None:
        raise SystemExit(1)
