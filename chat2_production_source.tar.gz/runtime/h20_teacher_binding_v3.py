"""Future teacher binding: exact frozen restore-code scope, unchanged data scope."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v2.py")
text = path.read_text()
for old, new, count in (
    ("native_teacher_h20_v2", "native_teacher_h20_v3", 2),
    ("collect_teacher_h20_v2", "collect_teacher_h20_v3", 1),
    ("prepare_teacher_h20_v2", "prepare_teacher_h20_v3", 1),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::exact_code_scope", "exec"), globals())

_text = execution.edit(
    _text,
    "api=restore.load(material,core_modules=modules)",
    "api=restore.load(material,core_modules=modules)\n"
    "    from h20_restore_code_scope_v1 import install as install_code_scope\n"
    "    core.write(run/'restore_code_scope_binding.json',install_code_scope(api.support,modules))",
)
native = execution.previous.load_source("_refate_h20_teacher_native_scope_v3", _text)
native.__file__ = str(execution.D / "runtime/native_teacher_h20_v3.py")
collection.native = native
preparation.native_shared_teacher = native

