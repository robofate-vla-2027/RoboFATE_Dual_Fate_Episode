"""Original guarded NFS placement, only for the first Classify L24 teacher."""
import place_prepared_stack_teacher_shared_h20_v1 as previous


def source():
    text = previous.source()
    for old, new in (
        (r"c2_stack_blocks_by_language_l([2-6])_evo_common_teacher_(0001)_01a16807",
         r"c2_classify_objects_l(24)_evo_common_teacher_(0001)_01a16807"),
        ('inputs["task"] == "stack_blocks_by_language"',
         'inputs["task"] == "classify_objects"'),
        ('inputs["native_limit"] == 400 and inputs["remaining_steps"] == 400 - inputs["t1"]',
         'inputs["native_limit"] == 1100 and inputs["remaining_steps"] == 1100 - inputs["t1"]'),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new)
    return text


exec(compile(source(), __file__ + "::classify_unbound_metadata_only", "exec"), globals())
