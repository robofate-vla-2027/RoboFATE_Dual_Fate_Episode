"""Bounded read-only CPU diagnostic of libraries mapped by the closed L2 policy."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import h20_runtime_binding_v1 as binding


def main():
    binding.host()
    run = "c2_sweep_blocks_l2_h20_baseline_0003_01a16807"
    root = binding.D / "teacher/runs" / run
    closed = json.loads((root / "MAIN_INTERRUPTION_SETTLEMENT_001.json").read_bytes())
    assert closed["safe_for_next_simulator"] and not closed["source_retry_allowed"]
    evidence = root / "MAIN_FIRST_PREDICTION_WAIT_001.json"
    paths = json.loads(evidence.read_bytes())["mapped_math_libraries"]
    prefix = "/data/agent_rsi_validation_20261022_01a161cf/data/dual_fate/chat1_01a16338/dm05/venv/"
    selected = [Path(p) for p in paths if p.startswith(prefix)]
    assert len(selected) == 8 and len(set(selected)) == 8
    total = sum(p.stat().st_size for p in selected)
    assert total < 3 * 1024**3
    available = next(
        int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
        if line.startswith("MemAvailable:")
    )
    assert available > total + 8 * 1024**3
    target = binding.D / "migration/SWEEP_L2_MAPPED_LIBRARY_READ_CPU_001.json"
    assert not target.exists(), "Do not repeat a completed diagnostic"
    started = time.monotonic()
    rows = []
    for path in selected:
        assert time.monotonic() - started < 180
        before = path.stat()
        digest = hashlib.sha256()
        count = 0
        at = time.monotonic()
        with path.open("rb") as stream:
            while chunk := stream.read(2 * 1024**2):
                digest.update(chunk)
                count += len(chunk)
                assert time.monotonic() - started < 180
        after = path.stat()
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns
        )
        assert count == before.st_size
        row = {
            "path": str(path), "bytes": count, "sha256": digest.hexdigest(),
            "seconds": time.monotonic() - at, "mtime_ns": before.st_mtime_ns,
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    value = {
        "schema": "refate.read_only_dependency_diagnostic.v1",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": binding.OWNER, "hostname": os.uname().nodename,
        "source_evidence": str(evidence),
        "source_evidence_sha256": hashlib.sha256(evidence.read_bytes()).hexdigest(),
        "buffer_bytes": 2 * 1024**2, "bytes_read": total,
        "elapsed_seconds": time.monotonic() - started, "libraries": rows,
        "model_calls": 0, "gpu_calls": 0, "source_files_modified": False,
        "root_cause_established": False, "scientific_quota_delta": 0,
    }
    with target.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"receipt": str(target), "elapsed_seconds": value["elapsed_seconds"]}))


if __name__ == "__main__":
    assert len(sys.argv) == 1
    main()
