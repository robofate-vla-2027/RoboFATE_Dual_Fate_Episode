"""Existing writable compiled cache, scoped to the original Play1200 task."""
from policy_cache_seed_conveyor_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "pick_from_conveyor_by_image"',
         'context["task"] == "play_stacking_toy"'),
        ('context["native_total_steps"] == 700',
         'context["native_total_steps"] == 1200'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::Play1200_cache_only", "exec"), namespace)
    return namespace["install"](run)
