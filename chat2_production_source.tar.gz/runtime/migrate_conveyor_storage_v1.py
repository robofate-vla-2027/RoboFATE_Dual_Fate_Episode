"""Bind copied Conveyor metadata to H20 paths without changing source identity."""
import datetime
import hashlib
import json
from pathlib import Path

import h20_runtime_binding_v1 as binding

binding.host()
root = binding.A / "task_sources/pick_from_conveyor_by_image"
old_path = root / "SPLIT_MANIFEST_L11_APPEND_001.json"
old_raw = old_path.read_bytes()
assert hashlib.sha256(old_raw).hexdigest() == "41c43e0afa11a5f5767b580ff5d5c57dd21273f600e5f0ee8acc40ce8b134a31"
old = json.loads(old_raw)
assert old["initial_source_sequence"] == old["materialized_layouts"] == list(range(12))
assert old["original_partition"]["reserved_final"] == [53, 54]
pairs = [
    ("/mnt/workspace/users/maxiangkai/projects/ReFATE", str(binding.PROJECT)),
    ("/vla/mxk/projects/Robodojo", str(binding.NATIVE)),
]
changes = []


def map_value(value, pairs, record=False):
    if isinstance(value, dict):
        return {key: map_value(item, pairs, record) for key, item in value.items()}
    if isinstance(value, list):
        return [map_value(item, pairs, record) for item in value]
    if isinstance(value, str):
        for old_root, new_root in pairs:
            if value == old_root or value.startswith(old_root + "/"):
                new = new_root + value[len(old_root):]
                if record:
                    changes.append({"historical": value, "execution": new})
                return new
    return value


new = map_value(old, pairs, True)
assert map_value(new, [(b, a) for a, b in pairs]) == old
for row in new["layouts"].values():
    ref = row["layout_ref"]
    assert hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest() == ref["sha256"]
target = root / "SPLIT_MANIFEST_L11_H20_STORAGE_001.json"
with target.open("x") as f:
    json.dump(new, f, indent=2)
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
record = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "schema": "refate.chat2.source_storage_binding.v1",
    "execution_owner": binding.OWNER, "logical_node_key": "perdon-hou",
    "task": "pick_from_conveyor_by_image", "execution_ssh_alias": "h20_8",
    "historical_manifest": {
        "path": "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026/task_sources/pick_from_conveyor_by_image/SPLIT_MANIFEST_L11_APPEND_001.json",
        "sha256": hashlib.sha256(old_raw).hexdigest(),
    },
    "byte_identical_original_copy": ref(old_path), "execution_manifest": ref(target),
    "path_changes": changes, "inverse_mapping_equals_original": True,
    "raw_layout_hashes_match": True, "source_sequence_and_groups_unchanged": True,
    "source_started": False, "reservation_issued": False,
}
rp = binding.D / "migration/CONVEYOR_L11_STORAGE_BINDING_001.json"
with rp.open("x") as f:
    json.dump(record, f, indent=2)
print(json.dumps({"manifest": ref(target), "storage_binding": ref(rp),
                  "source_sequence": list(range(12)), "reserved_final": [53, 54]}))
