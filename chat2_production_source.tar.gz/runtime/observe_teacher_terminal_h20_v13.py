"""Original terminal observer plus the verified pre-model history-failure case."""
import hashlib
from pathlib import Path
import h20_teacher_binding_v10 as binding
import teacher_terminal_handoff_v7 as original
from teacher_history_pre_actor_h20_v1 import NATIVE_SHA, extend_source

execution = binding.execution
execution.previous.host()
assert hashlib.sha256(binding._text.encode()).hexdigest() == NATIVE_SHA
assert binding._text.index("history=common_teacher.load_causal_history(") < (
    binding._text.index("model=teacher_worker_binding.model(")
)
text = original.source()
old = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher"
for before, after in (
    (old + "/perdon_adapter_20261026", str(execution.A)),
    (old + "/runs", str(execution.D / "teacher/runs")),
    ("import collect_teacher_content_v6 as collect", "collect = binding.collection"),
    ("hashlib.sha256(collect.native.text.encode()).hexdigest()",
     "hashlib.sha256(binding._text.encode()).hexdigest()"),
):
    text = execution.edit(text, before, after)
text = execution.edit(
    text, "e9d1f23b5ae9dc931bc8615f2f163fc02e4ba0b7ed0564d2b9fc56ab52d0dcdb",
    NATIVE_SHA, count=2,
)
text = execution.edit(text, "run/'CONTEXT_001.json'",
                      "run/x.get('context_name','CONTEXT_001.json')", count=2)
exec(compile(extend_source(text), __file__ + "::pre_model_history_failure", "exec"), globals())
