"""Existing metadata workflow plus SwapT's tag and matched catalog."""
from pathlib import Path

path = Path(__file__).with_name("prepare_teacher_metadata_h20_v11.py")
text = path.read_text()
for old, new, count in (
    ("h20_teacher_binding_v10", "h20_teacher_binding_v13", 2),
    ("RUNTIME_H20_CHAT2_TEACHER_20261107_010.json",
     "RUNTIME_H20_CHAT2_TEACHER_20261108_013.json", 1),
    ("collect_teacher_h20_v10.py", "collect_teacher_h20_v13.py", 1),
    ("from teacher_catalog_stack_h20_v1 import",
     "from teacher_catalog_swap_h20_v1 import", 1),
    ("'stack_blocks_by_language':'STACK'}",
     "'stack_blocks_by_language':'STACK','store_laptop_and_headphones':'LAPTOP','swap_T':'SWAPT'}", 1),
):
    assert text.count(old) == count, old
    text = text.replace(old, new, count)
exec(compile(text, str(path) + "::swap400_metadata", "exec"), globals())
