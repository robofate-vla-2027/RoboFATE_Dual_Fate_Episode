"""Reuse saved readback with the matched future private-metadata collector."""
from pathlib import Path

path = Path(__file__).with_name("observe_h20_baseline_terminal_v1.py")
text = path.read_text()
old = "import collect_h20_container_v4 as collection"
assert text.count(old) == 1
text = text.replace(old, "import collect_h20_container_v8 as collection")
exec(compile(text, str(path) + "::matched_v8_collector", "exec"), globals())
