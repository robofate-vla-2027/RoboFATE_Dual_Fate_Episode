"""New immutable runtime binding for the same never-started reserved attempt."""
from copy import deepcopy
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import h20_teacher_binding_v5 as binding

binding.execution.previous.host()
D = binding.execution.D
RUN = "c2_pick_from_conveyor_by_image_l15_evo_common_teacher_0001_01a16807"
run = D / "teacher/runs" / RUN


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


old_path = run / "CONTEXT_001.json"
old = json.loads(old_path.read_bytes())
old_dispatch = binding.preparation.restore.document(old["dispatch_ref"])
session = Path(old["runtime_binding"]["run_dir"])
assert old["run_id"] == old_dispatch["run_id"] == RUN
assert old["native_limit"] == 700 and old["t1"] == 10 and old["remaining_steps"] == 690
assert old["native_wall_seconds"] == old["actor_wall_s"] == 3600
assert session.parent == D / "teacher/sessions"
assert old["runtime_release"]["sha256"] == "3a7fbb68f05bb3967c7abba92797675b69a7664115d067320ad305b69b1e9a2b"
markers = ("foreground_started.json", "native_started.json", "owned_native.json",
           "teacher_ready.json", "actual_t1_verified.json", "native_actions.jsonl",
           "result.json", "failure.json", "foreground_error.json", "resource_selection.json",
           "memory_before.json", "native_wait.json", "process_cleanup.json", "dense",
           "runtime", "initial", "teacher_ipc", "teacher_readback_001")
with binding.execution.foreground.LOCK.open("r+") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert all(not (run / name).exists() for name in markers)
    assert all(not (session / name).exists() for name in ("agent", "runtime", "oci"))
    assert (session / "inputs").is_dir() and not (D / "container_records" / RUN).exists()
    release_path = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261106_005.json"
    release = json.loads(release_path.read_bytes())
    dispatch = deepcopy(old_dispatch)
    dispatch["runtime_release"] = ref(release_path)
    context = deepcopy(old)
    context["runtime_release"] = dispatch["runtime_release"]
    context["runtime_files"] = deepcopy(release["runtime_files"])
    context["runtime_binding"]["runtime_files"] = deepcopy(release["runtime_files"])
    assert {k: v for k, v in dispatch.items() if k != "runtime_release"} == {
        k: v for k, v in old_dispatch.items() if k != "runtime_release"}
    context["dispatch_ref"] = write(run / "DISPATCH_RUNTIME_REBIND_001.json", dispatch)
    context_ref = write(run / "CONTEXT_RUNTIME_REBIND_001.json", context)
    actual, material = binding.native.load_context(Path(context_ref["path"]), context_ref["sha256"])
    assert actual == context and material["source_id"] == context["source_id"]
    import shared_dependency_binding
    shared_dependency_binding.paired_reader()
    shared_dependency_binding.decoder()
    static = dict(
        schema="refate.shared_evo.actual_context_static_check.v1", context_ref=context_ref,
        source_id=context["source_id"], checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        native_limit=700, t1=10, remaining=690, actual_Native_started=False,
        actual_teacher_started=False, original_worker_session_binding=True,
        original_reader_and_decoder_imported=True, original_inputs_prepared=True, qualified=False)
    static_ref = write(run / "STATIC_PRELAUNCH_RUNTIME_REBIND_001.json", static)
    result = dict(
        schema="refate.chat2.unstarted_runtime_rebind.v1",
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        execution_owner=binding.execution.OWNER, run_id=RUN, source_id=context["source_id"],
        session_id=dispatch["session_id"], context_ref=context_ref, static_check_ref=static_ref,
        original_context=ref(old_path), original_dispatch=old["dispatch_ref"],
        dispatch_ref=context["dispatch_ref"], dispatch=dispatch, runtime_release=context["runtime_release"],
        launch_markers={name: False for name in markers}, exclusive_native_lock_available=True,
        session_inputs_reused=True, actual_launch_issued=False, budgets_and_clocks_unchanged=True,
        original_error={"type": "ValueError", "message": "Foreign metadata",
                        "stage": "release004 preparation load_context before launch"})
    result["evidence_ref"] = write(run / "UNSTARTED_RUNTIME_REBIND_001.json", result)
    print(json.dumps(result))
