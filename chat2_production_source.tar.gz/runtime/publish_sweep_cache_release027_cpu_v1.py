"""Freeze a cache-location-only binding after narrow synthetic CPU checks."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import h20_runtime_binding_v1 as host
import policy_cache_seed_sweep_h20_v1 as old_cache
import policy_cache_seed_sweep_nfs_h20_v1 as new_cache
import prelaunch_sweep_policy_cache_h20_v1 as old_launch
import prelaunch_sweep_policy_cache_h20_v2 as new_launch

host.host()
D = host.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
expected = old_cache.source().replace(
    'parent = D / "private_policy_compiled_cache"',
    'parent = Path("/vla/mxk/projects/ReFATE/coordination/'
    '20261106_chat2_h20_01a19072/private_policy_compiled_cache")', 1)
assert new_cache.source() == expected
assert new_launch.source() == old_launch.source().replace(
    "policy_cache_seed_sweep_h20_v1", "policy_cache_seed_sweep_nfs_h20_v1", 2)
tree = ast.parse(new_cache.source())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "install")
conditions = [n for n in function.body if isinstance(n, ast.Assert)
              and "context" in {a.id for a in ast.walk(n) if isinstance(a, ast.Name)}]
assert len(conditions) == 2


def check(context):
    for condition in conditions:
        assert eval(compile(ast.Expression(condition.test), "synthetic_context", "eval"),
                    {"context": context, "OWNER": "synthetic_owner"})


context = dict(task="sweep_blocks", native_total_steps=1000,
               native_wall_seconds=2400, execution_owner="synthetic_owner")
check(context)
for key, value in (("task", "swap_T"), ("native_total_steps", 400),
                   ("native_wall_seconds", 7200), ("execution_owner", "other")):
    try:
        check(dict(context, **{key: value}))
    except AssertionError:
        pass
    else:
        raise AssertionError("Invalid synthetic context accepted")
for source in (new_cache.source(), new_launch.source()):
    compile(source, "future_cache_binding", "exec")
mapping_path = Path("/vla/mxk/projects/ReFATE/coordination/20261106_chat2_h20_01a19072/"
                    "migration_io_diagnostics/SWEEP_POLICY_CACHE_NFS_EXEC_MAPPING_CPU_001.json")
mapping = json.loads(mapping_path.read_bytes())
assert mapping["file_executable_mapping_passed"] and not mapping["mapped_bytes_executed"]
prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"
assert ref(prior)["sha256"] == "1617770592903d1af1df155ccbcd6c6c7544d85e5b41d025346168da631025fe"
release = json.loads(prior.read_bytes())
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    host.read_pin(pin)
for name in ("policy_cache_seed_sweep_nfs_h20_v1.py",
             "prelaunch_sweep_policy_cache_h20_v2.py",
             "publish_sweep_cache_release027_cpu_v1.py"):
    path = D / "runtime" / name
    pins[str(path)] = ref(path)


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/SWEEP_SHARED_COMPILED_CACHE_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "data_kind": "synthetic_CPU_binding_not_scientific_data",
    "source_change_only_cache_parent": True,
    "prelaunch_change_only_cache_import": True,
    "valid_context_passed": True, "invalid_contexts_rejected": 4,
    "executable_mapping": ref(mapping_path), "model_GPU_API_simulator_calls": False,
    "actual_latency_benefit_verified": False, "root_cause_established": False,
    "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "model_loading_allowance_seconds": 900, "model_request_default_seconds": 120,
})
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_sweep_shared_cache_release=ref(prior), runtime_files=list(pins.values()),
    prelaunch_entry=ref(D / "runtime/prelaunch_sweep_policy_cache_h20_v2.py"),
    sweep_shared_compiled_cache_cpu=cpu,
    actual_adoption=False, actual_positive_published=False,
    change_scope="Only future Sweep private compiled-cache backing moves from /data "
                 "to the owner's executable shared directory. Frozen cache bytes, "
                 "collector11/Native8/policy2, readers, model, RNG and budgets unchanged. "
                 "The next distinct source must verify actual benefit; no L0 replay.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_027.json", release)
print(json.dumps({"release": output, "cpu": cpu,
                  "prelaunch": release["prelaunch_entry"], "actual_adoption": False}))
