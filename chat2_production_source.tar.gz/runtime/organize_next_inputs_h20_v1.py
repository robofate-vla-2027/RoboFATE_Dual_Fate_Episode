"""Use the actual existing loader and separate source/resource predecessors."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys
import h20_container_binding_v7 as binding
from dolls_next_inputs_h20_v2 import teacher_checks
from closed_baseline_resource_v1 import baseline_checks

host = binding.previous
host.host()
mode, index = sys.argv[1], int(sys.argv[2])
assert mode in ("check", "inputs") and 23 <= index < 53
prepared_path = binding.A.parent / f"preparations/ORGANIZE_L{index}_COMMON_PREPARATION_001.json"
prepared = json.loads(prepared_path.read_bytes())
source = prepared["source"]
assert source["task"] == "organize_table" and source["layout_id"] == index
assert source["source_sequence"] == list(range(index + 1))
assert source["required_accounted_prefix"] == list(range(index))
assert prepared["native_step_limit"] == 1000


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu_path = host.D / f"migration/ORGANIZE_L{index}_PREPARATION_CPU_001.json"
if mode == "check":
    binding.foreground.baseline.source_sequence_binding.load_native_layout(prepared)
    record = {
        "preparation": ref(prepared_path), "actual_installed_loader_passed": True,
        "source_sequence": source["source_sequence"], "native_total": 1000,
        "native_or_model_or_API_called": False, "scientific_data": False,
    }
    print(json.dumps({"CPU_check": save(cpu_path, record), **record}))
    raise SystemExit(0)

cpu = json.loads(cpu_path.read_bytes())
assert cpu["preparation"] == ref(prepared_path) and cpu["actual_installed_loader_passed"]
resource_run_id = sys.argv[3]
resource_name = ("MAIN_TERMINAL_OBSERVATION_001.json"
                 if "_evo_common_teacher_" in resource_run_id else "MAIN_SETTLEMENT_001.json")
resource_path = host.D / "teacher/runs" / resource_run_id / resource_name
terminal = json.loads(resource_path.read_bytes())
if "_evo_common_teacher_" in resource_run_id:
    teacher_checks(terminal, resource_run_id)
else:
    baseline_checks(terminal)
assert terminal["safe_for_next_simulator"] and terminal["execution_owner"] == host.OWNER
release_path = host.D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_013.json"
release = json.loads(release_path.read_bytes())
assert release["native_wall_seconds"] == 2400 and release["teacher_wall_seconds"] == 3600
assert release["foreground_entry"] == str(host.D / "runtime/collect_h20_container_v8.py")
manifest_ref = prepared["provenance"]["split"]
manifest = json.loads(host.read_pin(manifest_ref))
assert manifest["initial_source_sequence"] == list(range(index + 1))
assert manifest["original_partition"]["reserved_final"] == [53, 54]
resource = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": "20250103-instance", "allocation": host.allocation(),
    "memory": host.memory_headroom(120), "native_started": False,
}
assert shutil.disk_usage(host.D).free > 30 * 1024**3
run_id = f"c2_organize_table_l{index}_h20_baseline_{index+1:04d}_01a16807"
run = host.D / "teacher/runs" / run_id
run.mkdir()
out = {
    "run_id": run_id, "release_ref": ref(release_path), "resource": resource,
    "resource_ref": save(run / "RESOURCE_PRECHECK_001.json", resource),
    "cpu_ref": ref(cpu_path), "preparation": prepared, "preparation_ref": ref(prepared_path),
    "manifest": manifest, "manifest_ref": manifest_ref,
    "foreground_entry": release["foreground_entry"], "native_started": False,
    "current_resource_predecessor": ref(resource_path), "terminal": terminal,
}
out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)
print(json.dumps(out))
