"""Existing collector11 prelaunch for the prepared original Conveyor L18."""
from prelaunch_fasten_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_fasten_h20_v1", "policy_cache_seed_conveyor_h20_v1", 2),
        ("c2_fasten_screws_l7_h20_baseline_0001_01a16807",
         "c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807", 1),
        ('value["native_total_steps"] == 1900',
         'value["native_total_steps"] == 700', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Conveyor18_original_collector", "exec"), globals())
