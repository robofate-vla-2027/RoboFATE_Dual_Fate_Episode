"""Use the original context checks with the matching Insert-aware entry."""
from pathlib import Path

path = Path(__file__).with_name("bind_h20_container_context_v1.py")
text = path.read_text()
for old, new, count in (
    ("h20_container_binding_v1", "h20_container_binding_v6", 1),
    ("collect_h20_container_v1", "collect_h20_container_v6", 2),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::insert_storage_binding", "exec"), globals())
