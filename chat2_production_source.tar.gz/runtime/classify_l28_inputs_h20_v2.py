"""Select the actual completed asset-check receipt without rewriting an old one."""
from classify_l28_inputs_h20_v1 import loading_timeout_checks, source as previous_source


def source():
    text = previous_source()
    old = 'asset_path = host.D / "migration/DM05_SEQUENTIAL_READ_20261107_001.json"'
    new = '''asset_path = Path(sys.argv[4])
assert asset_path.parent == host.D / "migration"
assert asset_path.name in (
    "DM05_SEQUENTIAL_READ_20261107_001.json",
    "DM05_SEQUENTIAL_READ_20261107_002.json",
)'''
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::explicit_asset_read_receipt", "exec"), globals())
