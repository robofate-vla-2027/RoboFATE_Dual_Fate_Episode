"""Freeze a future-only optional-tool binding; no model or simulator probes."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import types


def offline(event, args):
    if event in ("subprocess.Popen", "os.system", "os.exec", "socket.connect",
                 "socket.bind", "socket.getaddrinfo", "os.kill", "os.killpg"):
        raise RuntimeError("CPU configuration check forbids external effects: " + event)


sys.addaudithook(offline)
import h20_teacher_binding_v15 as teacher
from teacher_web_search_disabled_h20_v1 import SETTING

teacher.execution.previous.host()
D = teacher.execution.D
ref = lambda p: {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_014.json"
assert ref(prior)["sha256"] == "0faf42cae66037960876299e534f0464a32a48ba3b14b886a76e39b316079e0f"
release = json.loads(prior.read_bytes())
assert (release["model"], release["reasoning_effort"]) == ("gt-6-as-a", "xhigh")
assert release["teacher_wall_seconds"] == release["native_wall_seconds"] == 3600
assert release["baseline_wall_seconds_unchanged"] == 2400
native_sha = hashlib.sha256(teacher._text.encode()).hexdigest()
assert native_sha == release["effective_native_source_sha256"]
assert teacher.collection.native is teacher.preparation.native_shared_teacher is teacher.native
assert teacher.stage.stage.__globals__["original_command"] is teacher.stage.original_command
assert teacher.resources.stage is teacher.stage
cfg = types.SimpleNamespace(
    baseline=True, playground=None, protocol="workspace-session-v1",
    agent=types.SimpleNamespace(preset="codex", model="gt-6-as-a", reasoning_effort="xhigh"),
    test=types.SimpleNamespace(budget=100, submission_timeout_sec=1200),
)
command = teacher.stage.original_command(cfg)
old_command_path = (D / "teacher/sessions/202611090624_c2_conveyor_l19_evo_0001/command.json")
old_command = json.loads(old_command_path.read_bytes())
assert command[:-3] + command[-1:] == old_command
assert command[-3:-1] == ["-c", SETTING]
assert "native_teacher_h20_v15.py" in teacher.native.__file__
pins = {p["path"]: p for p in release["runtime_files"]}
for p in pins.values():
    teacher.storage.runtime.read_pin(p)
old_launch = D / "runtime/launch_bound_teacher_release014.sh"
text = old_launch.read_text()
assert text.count("collect_teacher_h20_v14.py") == 1
new_launch = D / "runtime/launch_bound_teacher_release015.sh"
with new_launch.open("x") as stream:
    stream.write(text.replace("collect_teacher_h20_v14.py", "collect_teacher_h20_v15.py", 1))
new_launch.chmod(0o700)
for name in (
    "teacher_web_search_disabled_h20_v1.py", "h20_teacher_binding_v15.py",
    "collect_teacher_h20_v15.py", "native_teacher_h20_v15.py",
    "prepare_teacher_h20_v15.py", "test_teacher_search_disabled_cpu_v1.py",
    "freeze_teacher_search_disabled_h20_v1.py", "launch_bound_teacher_release015.sh",
):
    p = D / "runtime" / name
    if p.suffix == ".py":
        compile(p.read_text(), str(p), "exec")
    pins[str(p)] = ref(p)


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = save(D / "migration/TEACHER_SEARCH_DISABLED_ACTUAL_BINDING_CPU_001.json", {
    "at": at, "data_kind": "synthetic_CPU_configuration_not_scientific_data",
    "stage_and_resource_call_chain_matched": True,
    "only_argv_delta": ["-c", SETTING], "comparison_command": ref(old_command_path),
    "teacher_model_effort_permissions_route_and_native_source_unchanged": True,
    "effective_native_source_sha256": native_sha, "native_model_API_calls": False,
    "provider_refused_L19_replayed": False, "actual_adoption": False,
})
release.update(
    at=at, prior_optional_tool_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v15.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v15.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v15.py"),
    launch_environment_binding=ref(new_launch),
    optional_tool_configuration={"web_search": "disabled", "actual_binding_CPU": cpu},
    change_scope="Future chat2 teacher only: omit unsupported optional web search. "
                 "No replay of L19; native source, all budgets, model, effort, API route, "
                 "permissions, recording/readers and old releases unchanged.",
    actual_adoption=False, actual_teacher_takeover_verified=False,
    actual_positive_published=False,
)
pin = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261109_015.json", release)
print(json.dumps({"teacher_release": pin, "cpu": cpu, "actual_adoption": False}))

