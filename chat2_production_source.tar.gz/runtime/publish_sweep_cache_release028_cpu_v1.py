"""Same cache binding tests, now using the actually checked container RW path."""
from pathlib import Path

path = Path(__file__).with_name("publish_sweep_cache_release027_cpu_v1.py")
text = path.read_text()
start = text.index("expected = old_cache.source().replace(")
end = text.index("assert new_cache.source() == expected", start)
text = text[:start] + '''expected = old_cache.source().replace(
    'parent = Path("/vla/mxk/projects/ReFATE/coordination/'
    '20261106_chat2_h20_01a19072/private_policy_compiled_cache")',
    'parent = run / "runtime/private_policy_compiled_cache"', 1)
''' + text[end:]
start = text.index("mapping_path = Path(")
end = text.index("mapping = json.loads(", start)
text = text[:start] + 'mapping_path = D / "migration/SWEEP_RUN_CACHE_CONTAINER_CPU_001.json"\n' + text[end:]
changes = (
    ("import policy_cache_seed_sweep_h20_v1 as old_cache",
     "import policy_cache_seed_sweep_nfs_h20_v1 as old_cache"),
    ("import policy_cache_seed_sweep_nfs_h20_v1 as new_cache",
     "import policy_cache_seed_sweep_nfs_h20_v2 as new_cache"),
    ("import prelaunch_sweep_policy_cache_h20_v1 as old_launch",
     "import prelaunch_sweep_policy_cache_h20_v2 as old_launch"),
    ("import prelaunch_sweep_policy_cache_h20_v2 as new_launch",
     "import prelaunch_sweep_policy_cache_h20_v3 as new_launch"),
    ('"policy_cache_seed_sweep_h20_v1", "policy_cache_seed_sweep_nfs_h20_v1", 2)',
     '"policy_cache_seed_sweep_nfs_h20_v1", "policy_cache_seed_sweep_nfs_h20_v2", 2)'),
    ('prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"',
     'prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_027.json"'),
    ("1617770592903d1af1df155ccbcd6c6c7544d85e5b41d025346168da631025fe",
     "575bd60e0c1dad28cd4f4bb613a3faace6220fa835e99c049eec6ba03a37d97e"),
    ('"policy_cache_seed_sweep_nfs_h20_v1.py"', '"policy_cache_seed_sweep_nfs_h20_v2.py"'),
    ('"prelaunch_sweep_policy_cache_h20_v2.py"', '"prelaunch_sweep_policy_cache_h20_v3.py"'),
    ('"publish_sweep_cache_release027_cpu_v1.py"', '"publish_sweep_cache_release028_cpu_v1.py"'),
    ("SWEEP_SHARED_COMPILED_CACHE_CPU_001.json", "SWEEP_RUN_COMPILED_CACHE_BINDING_CPU_001.json"),
    ('"runtime/prelaunch_sweep_policy_cache_h20_v2.py"',
     '"runtime/prelaunch_sweep_policy_cache_h20_v3.py"'),
    ('output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_027.json", release)',
     'output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_028.json", release)'),
    ('"Only future Sweep private compiled-cache backing moves from /data "\n'
     '                 "to the owner\'s executable shared directory. Frozen cache bytes, "',
     '"Fix only the cache parent to the existing container-writable per-run NFS bind. "\n'
     '                 "The actual restricted-container CPU mapping test passed. Frozen cache bytes, "'),
    ('"The next distinct source must verify actual benefit; no L0 replay."',
     '"The next distinct source must verify latency benefit; no L0/L1 replay."'),
)
for old, new in changes:
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::container_visible_RW_cache", "exec"), globals())
