"""Original Native loop, compatible userspace and restricted GPU namespace."""
import h20_container_binding_v1 as binding
if __name__=='__main__':
    raise SystemExit(binding.baseline_module.main())
