"""Keep all closure checks; recognize the evidenced pre-actor identity failure."""
from pathlib import Path
from h20_pre_actor_identity_failure_v1 import verified as verified_identity_pre_actor

path = Path(__file__).with_name("observe_teacher_terminal_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v2", "h20_teacher_binding_v7"),
    ("48e97cd2d6dfabd2d053dae56c4628226074f28221aa1cf560363f7748cfd93d",
     "2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
seam = 'exec(compile(text, str(Path(original.__file__)) + "::actual_h20_source", "exec"), globals())'
assert text.count(seam) == 1
extra = '''
text = execution.edit(text, "run/'CONTEXT_001.json'",
                      "run/x.get('context_name','CONTEXT_001.json')", count=2)
old = "pre_actor=verified_pre_actor_failure(c,failure,comparison,artifacts,native_source_sha) or pre_aux"
text = execution.edit(text, old, old + " or verified_identity_pre_actor(c,failure,artifacts,native_source_sha)")
text = execution.edit(text, "p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json')",
    "d['pre_actor_identity_failure'] = dict(verified=verified_identity_pre_actor(c,failure,artifacts,native_source_sha),"
    "actor_artifacts=artifacts,native_source_sha=native_source_sha)\\n"
    "p=run/x.get('output_name','MAIN_TERMINAL_OBSERVATION_001.json')")
'''
text = text.replace(seam, extra + "\n" + seam)
exec(compile(text, str(path) + "::observed_identity_pre_actor", "exec"), globals())
