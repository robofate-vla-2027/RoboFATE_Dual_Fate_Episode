"""Use the original positive-gap capacity binder with the matched H20 runtime."""
from pathlib import Path

path = Path(__file__).with_name("bind_h20_container_context_v1.py")
text = path.read_text()
for old, new, count in (
    ("h20_container_binding_v1", "h20_container_binding_v9", 1),
    ("collect_h20_container_v1", "collect_h20_container_v10", 2),
    ("import bind_recording_content_v1 as previous",
     "import bind_positive_gap_context_v1 as previous\n"
     "dispatch_slots_valid = previous.dispatch_slots_valid\n"
     "capacity_adapter = previous.capacity_adapter", 1),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::original_positive_gap_H20", "exec"), globals())
