"""Original resource/source split, bound to prepared Bottles L33 on release038."""
from plug_next_inputs_h20_v6 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("plug_in_charger", "put_bottles_into_dustbin"),
        ("PREPARATION_L{index}_APPEND_001.json", "PREPARATION_L{index}_CONFIGURED_001.json"),
        ("PLUG_L{index}_CACHE_BINDING_CPU_001.json", "BOTTLES_L{index}_CACHE_BINDING_CPU_001.json"),
        ("index == 27", "index == 33"),
        ('prepared["native_step_limit"] == 400', 'prepared["native_step_limit"] == 700'),
        ('"native_budget": 400', '"native_budget": 700'),
        ('"owner_reservation_handoff_v1.py"', '"owner_positive_gap_reservation_v1.py"'),
    ):
        assert text.count(old) >= 1, old
        text = text.replace(old, new)
    old = 'resource_kind = ("closed_teacher_resource_v1"'
    assert text.count(old) == 1
    text = text.replace(old, '''prior_teacher_path = host.D / "teacher/runs/c2_put_bottles_into_dustbin_l32_evo_common_teacher_0001_01a16807/MAIN_TERMINAL_OBSERVATION_001.json"
prior_teacher = json.loads(prior_teacher_path.read_bytes())
assert prior_teacher["source_id"] == source_predecessor["source_id"]
assert prior_teacher["safe_for_next_simulator"] is True
assert prior_teacher["run_id"] == "c2_put_bottles_into_dustbin_l32_evo_common_teacher_0001_01a16807"
''' + old, 1)
    old = '''"last_teacher_settlement": (terminal["summary_ref"] if resource_kind == "closed_teacher_resource_v1" and terminal["source_id"] == source_predecessor["source_id"] else None),'''
    assert text.count(old) == 1
    return text.replace(old, '"last_teacher_settlement": prior_teacher["summary_ref"],', 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Bottles33_original_predecessors", "exec"), globals())

