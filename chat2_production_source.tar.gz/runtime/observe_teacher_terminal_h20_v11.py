"""Original terminal rules pinned to the actually deployed Stack009 wrapper."""
from pathlib import Path

NATIVE_WRAPPER_SHA256 = "f1e14823fd6c21b4d136dc1689fe03c8847b650d519518301c00f433b3f484e2"


def source():
    path = Path(__file__).with_name("observe_teacher_terminal_h20_v5.py")
    text = path.read_text()
    for old, new in (
        ("h20_teacher_binding_v5", "h20_teacher_binding_v9"),
        ("2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376",
         NATIVE_WRAPPER_SHA256),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::actual_stack009_pin", "exec"), globals())
