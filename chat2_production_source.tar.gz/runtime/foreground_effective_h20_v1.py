"""One owned foreground baseline, using existing frozen policy/resource helpers."""
from __future__ import annotations
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

from h20_runtime_binding_v1 import baseline_module as baseline
import node_native as node

P=node.stage.SESSION.parents[1]
W=P/'worktrees/r6_payload_preparation_parent_20261011_152237'
FIX=P/'coordination/20261022_rtx_restore_01a1619b/application_gpu_trace_008_01a161f7'
LOCK=P/'coordination/20261013_xr1_takeover/dm05_in_place_20261015/run.lock'
POLICY=W/'scripts/refate_integration/xr1_policy_service.py'
CONFIG=W/'configs/runtime/refate_xr1_native.yaml'
POLICY_PYTHON=Path('/vla/mxk/envs/opendm_20260925/bin/python')
NATIVE_PYTHON=node.NATIVE/'.runtime-env/bin/python'


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())


def host():
    node.need(os.environ.get('REFATE_SSH_ALIAS')=='perdon-hou' and socket.gethostname()=='nb-5pl2apckdj-0',
              'Exact assigned alias/hostname required')


def helpers():
    path=node.NATIVE/'deployment/policy_eval_20260925/run_policy_suite.py'
    raw=node.pinned(path,'ba8fc157e3e9e49d37351188ccf2d22bc48574ea364cc5722fe944df26962a6c')
    sys.path.insert(0,str(path.parent))
    spec=importlib.util.spec_from_file_location('_refate_existing_resources',path)
    module=importlib.util.module_from_spec(spec);exec(compile(raw,str(path),'exec'),module.__dict__)
    return module


def identity(pid):
    raw=Path(f'/proc/{pid}/stat').read_text();tail=raw.rsplit(')',1)[1].split()
    return {'pid':pid,'start_ticks':int(tail[19]),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'process_group':int(tail[2])}


def allocation():
    assignments={k:v for k,v in os.environ.items() if k.startswith(('SLURM_','PBS_','LSB_'))}
    for key in ('SLURM_STEP_GPUS','SLURM_JOB_GPUS'):
        if key in assignments:
            node.need({'0','1'}.issubset(set(assignments[key].split(','))), 'Allocation does not include physical0/1')
    text=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total,utilization.gpu',
                                  '--format=csv,noheader,nounits'],text=True)
    devices={int(row.split(',')[0]):[x.strip() for x in row.split(',')] for row in text.splitlines()}
    for i,uuid in enumerate(node.GPUS):
        node.need(devices[i][1]==uuid and int(devices[i][2]) >= (45000 if i==0 else 35000), 'Actual UUID/headroom differs')
    processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True)
    return {'gpu_rows':text,'existing_processes':processes,'scheduler_environment':assignments,
            'NVIDIA_VISIBLE_DEVICES':os.environ.get('NVIDIA_VISIBLE_DEVICES'),
            'authorized_physical_gpus':[0,1],'cuda_logical_to_physical':{'0':0,'1':1},
            'vulkan_requested_physical_gpu':1,'peer_processes_are_not_managed':True}


def environment(run, reference):
    base={k:v for k,v in os.environ.items() if not k.startswith(('REFATE_','ROBODOJO_'))}
    runtime=run/'runtime'
    for name in ('home','tmp','cache','torch_extensions','kit','xdg'):
        (runtime/name).mkdir(parents=True,exist_ok=True)
    base.update(REFATE_SSH_ALIAS='perdon-hou',REFATE_RTX_OWNER_CHAT=node.stage.OWNER,
        PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',PYTHONFAULTHANDLER='1',
        OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8',
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
        HOME=str(runtime/'home'),TMPDIR=str(runtime/'tmp'),XDG_CACHE_HOME=str(runtime/'cache'),
        XDG_RUNTIME_DIR=str(runtime/'xdg'),CUDA_DEVICE_ORDER='PCI_BUS_ID')
    policy=dict(base,CUDA_VISIBLE_DEVICES='0',LD_LIBRARY_PATH=reference.policy_library_path(),
        HF_HOME=str(runtime/'cache/hf'),TRITON_CACHE_DIR=str(runtime/'cache/triton'),
        TORCHINDUCTOR_CACHE_DIR=str(runtime/'cache/inductor'),WANDB_MODE='offline',
        NO_ALBUMENTATIONS_UPDATE='1',PYTHONPATH=f'{node.NATIVE}:{node.NATIVE}/XPolicyLab')
    native=dict(base,CUDA_VISIBLE_DEVICES='0,1',NVIDIA_VISIBLE_DEVICES=','.join(node.GPUS),
        LD_LIBRARY_PATH='/usr/local/nvidia/lib:/usr/local/nvidia/lib64',
        ROBODOJO_PHYSICAL_GPU='1',TORCH_EXTENSIONS_DIR=str(runtime/'torch_extensions'),
        VK_ICD_FILENAMES='/etc/vulkan/icd.d/nvidia_icd.json',OMNI_KIT_ACCEPT_EULA='YES',ACCEPT_EULA='Y',
        PYTHONNOUSERSITE='1',VK_LAYER_PATH=str(FIX/'copy_staging_lifecycle_007'),
        VK_INSTANCE_LAYERS='VK_LAYER_REFATE_image_copy_staging',REFATE_VK_COPY_MODE='stage',
        REFATE_VK_COPY_LOG=str(run/'copy_layer.log'),OMNI_VULKAN_ENV_SKIP='0',
        PYTHONPATH=f'{node.stage.UPSTREAM}:{node.stage.HERE}:{node.NATIVE}:{node.NATIVE}/XPolicyLab:{node.NATIVE}/third_party/IsaacLab/source/isaaclab:{node.NATIVE}/third_party/IsaacLab/source/isaaclab_tasks:{node.NATIVE}/third_party/curobo',
        EMBODIEDEVO_ROBODOJO_KIT_ARGS=f'--portable-root {runtime}/kit --enable isaacsim.sensors.camera --enable isaacsim.replicator.behavior --/exts/omni.kit.renderer.core/autostartImGuiRenderer=false --/persistent/rtx/modes/rt/enabled=true --/persistent/rtx/modes/pt/enabled=true')
    from optix_binding import process_lookup_environment,resolve_cached_binding
    overrides=process_lookup_environment(resolve_cached_binding())
    if 'LD_LIBRARY_PATH' in overrides:
        overrides['LD_LIBRARY_PATH'] += ':'+native['LD_LIBRARY_PATH']
    native.update(overrides)
    return policy,native


def main(argv=None):
    host();parser=argparse.ArgumentParser();parser.add_argument('--context',type=Path,required=True)
    parser.add_argument('--sha256',required=True);args=parser.parse_args(argv)
    context=baseline.load_context(args.context,args.sha256);run=Path(context['run_dir']);ref=helpers()
    node.need(not (run/'foreground_started.json').exists(), 'Started/uncertain context cannot rerun')
    node.pinned(POLICY,'06b4b3934ef1dfd19d935e99c09d93b48f92c0474ef2cc8de87a8e30284e0252')
    node.pinned(CONFIG,'5d4597ac1ffc422363dbe93b54bc47028d1adb81da854ffcfae22f12f2170d3e')
    disk=os.statvfs(run);rootdisk=os.statvfs('/')
    node.need(disk.f_bavail*disk.f_frsize > 25*1024**3 and rootdisk.f_bavail*rootdisk.f_frsize > 256*1024**2,
              'Insufficient project/root safety margin')
    policy_env,native_env=environment(run,ref)
    lock=LOCK.open('r+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    write(run/'resource_selection.json',allocation());write(run/'memory_before.json',ref.memory_headroom(120))
    write(run/'foreground_started.json',{'identity':identity(os.getpid()),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                       'context_ref':{'path':str(args.context),'sha256':args.sha256}})
    children={};owned={};logs=[]
    def interrupted(signum,frame):raise KeyboardInterrupt(f'User/foreground signal {signum}')
    for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupted)
    def launch(role,cmd,env):
        host();allocation();log=(run/('stdout.log' if role=='native' else 'policy.log')).open('x');logs.append(log)
        process=subprocess.Popen(cmd,env=env,cwd=run,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children[role]=process;owned[role]=identity(process.pid)
        write(run/('owned_'+role+'.json'),{'identity':owned[role],'command':cmd,'role':role,'parent_pid':os.getpid()})
        return process
    try:
        ready=run/'server/model_ready.json'
        native=launch('native',[str(NATIVE_PYTHON),'-B',str('/data/refate_chat2_20261106_01a19072/runtime/native_h20_v1.py'),'--context',str(args.context),
                               '--sha256',args.sha256,'--policy-ready',str(ready)],native_env)
        native_start=time.monotonic()
        boundary=run/'native_boundary_ready.json'
        while not boundary.exists():
            node.need(native.poll() is None,'Native exited before the first saved boundary; no DM was loaded')
            if time.monotonic()-native_start>context['native_wall_seconds']:
                raise TimeoutError('Original Native wall budget exhausted during startup')
            time.sleep(.25)
        node.need(native.poll() is None,'Native stopped at startup boundary; no DM launch')
        policy=launch('policy',[str(POLICY_PYTHON),'-B',str(POLICY),'--config',str(CONFIG),'--run',str(run/'server'),'--port','0'],policy_env)
        deadline=time.monotonic()+900
        while not ready.exists():
            node.need(native.poll() is None and policy.poll() is None,'Owned process exited before policy readiness')
            if time.monotonic()>deadline or time.monotonic()-native_start>context['native_wall_seconds']:
                raise TimeoutError('Original policy/Native wall allowance exhausted')
            time.sleep(.25)
        meta=json.loads(ready.read_text());node.need(meta['pid']==policy.pid and meta['trainable_parameters']==0 and meta['physical_gpu']==1,'Wrong policy readiness')
        remaining=context['native_wall_seconds']-(time.monotonic()-native_start)
        node.need(remaining>0,'Original Native wall budget exhausted')
        native_rc=native.wait(timeout=remaining)
        write(run/'native_wait.json',{'pid':native.pid,'returncode':native_rc,'original_process_absent':not Path(f'/proc/{native.pid}').exists(),
                                     'wall_ns':time.time_ns(),'data_qualification':'not_decided_by_exit_code'})
        return native_rc
    except BaseException as error:
        write(run/'foreground_error.json',{'type':type(error).__name__,'message':str(error),'wall_ns':time.time_ns(),
            'data_status':'not_decided_by_host_failure','retry_allowed':False})
        raise
    finally:
        cleanup={}
        for role in ('native','policy'):
            process=children.get(role)
            if process is None:continue
            if process.poll() is None:
                node.need(identity(process.pid)==owned[role], 'Refuse signal to changed process identity')
                ref.stop_owned(process)
            cleanup[role]={'identity':owned[role],'returncode':process.wait(),
                           'original_process_absent':not Path(f'/proc/{process.pid}').exists()}
        write(run/'process_cleanup.json',cleanup)
        for log in logs:log.close()
        lock.close()


if __name__=='__main__':raise SystemExit(main())
