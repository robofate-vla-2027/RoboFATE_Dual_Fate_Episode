"""Match future teacher entries to the private-tmp owned supervisor."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v3.py")
text = path.read_text()
for old, new, count in (
    ("native_teacher_h20_v3", "native_teacher_h20_v4", 2),
    ("collect_teacher_h20_v3", "collect_teacher_h20_v4", 1),
    ("prepare_teacher_h20_v3", "prepare_teacher_h20_v4", 1),
    ("_refate_h20_teacher_native_scope_v3", "_refate_h20_teacher_native_scope_v4", 1),
):
    assert text.count(old) == count
    text = text.replace(old, new)
exec(compile(text, str(path) + "::private_container_tmp", "exec"), globals())
import gvisor_resources as resources

resources.SUPERVISOR = execution.D / "runtime/gvisor_worker_h20_v2.py"
