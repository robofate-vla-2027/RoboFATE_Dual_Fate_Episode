"""Existing metadata-only observer bound to Play L18, native1200, release035."""
from pathlib import Path

path = Path(__file__).with_name("observe_swap_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_swap_T_l[0-6]_h20_baseline_[0-9]{4}_01a16807",
     "c2_play_stacking_toy_l18_h20_baseline_0019_01a16807"),
    ('start["native_budget"] == 400', 'start["native_budget"] == 1200'),
    ("native_total=400", "native_total=1200"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_025.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_035.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Play18_metadata_only", "exec"), globals())
