"""Validate a derived address binding of existing L43; no source preparation."""
import datetime
import hashlib
import json

import h20_insert_metadata_binding_v1 as storage

execution = storage.execution
original_path = execution.A.parent / "preparations/INSERT_L43_COMMON_PREPARATION_001.json"
raw = original_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == "2c8fd820486e2fc44edc257b03bf607670f5b76683cf4dc7b8fcedad4b2a2d39"
original = json.loads(raw)
mapped = storage.locations(original)
assert storage.locations(mapped, inverse=True) == original
assert mapped["source"]["source_id"] == "insert_tubes_b0_l43_168c25ab2ef8b97f"
assert mapped["native_step_limit"] == 500
assert mapped["source"]["required_accounted_prefix"] == list(range(43))
assert mapped["original_partition"]["reserved_final"] == [53, 54]
actual_layout = storage.sequence.load_native_layout(mapped)
assert storage.sequence._helpers()[0].digest_layout(actual_layout) == original["source"]["initialization_content_sha256"]
path = original_path.with_name("INSERT_L43_H20_STORAGE_PREPARATION_001.json")
with path.open("x") as stream:
    json.dump(mapped, stream, indent=2)
    stream.write("\n")


def ref(p):
    return {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


receipt = {
    "schema": "refate.chat2.existing_source_storage_cpu.v1",
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "execution_owner": execution.OWNER, "historical_preparation": ref(original_path),
    "execution_preparation": ref(path), "binding": ref(execution.D / "runtime/h20_insert_metadata_binding_v1.py"),
    "source_id": original["source"]["source_id"], "native_budget": 500,
    "original_raw_layout_unchanged": True, "inverse_mapping_equals_original": True,
    "original_context_validator_passed": True, "source_preparation_repeated": False,
    "registered": False, "reserved": False, "launched": False,
    "real_model_api_native_calls": False, "scientific_samples": 0,
}
record = execution.D / "migration/INSERT_L43_STORAGE_CPU_001.json"
with record.open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps({"receipt": ref(record), "preparation": ref(path), "launched": False}))
