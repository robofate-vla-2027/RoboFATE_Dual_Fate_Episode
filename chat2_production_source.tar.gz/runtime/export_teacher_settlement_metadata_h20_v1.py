"""Export bounded saved accounting documents; never run ledger code remotely."""
import base64
import hashlib
import json
from pathlib import Path
import sys
import h20_teacher_binding_v3 as binding

binding.execution.previous.host()
terminal = json.loads(Path(sys.argv[1]).read_bytes())
assert terminal["execution_owner"] == binding.execution.OWNER
context_ref = terminal["context"]
context = binding.preparation.restore.document(context_ref)
assert context["run_id"] == terminal["run_id"]
run = Path(context["run_dir"])
assert run.parent == binding.execution.D / "teacher/runs"
documents = {}


def add(pin):
    raw = binding.storage.runtime.read_pin(pin)
    assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
    if pin["path"] in documents:
        assert documents[pin["path"]]["ref"] == pin
    documents[pin["path"]] = {"ref": pin, "raw_b64": base64.b64encode(raw).decode()}
    return json.loads(raw)


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


add(context_ref)
summary = add(terminal["summary_ref"])
assert summary == terminal["summary"]
add(ref(run / "process_cleanup.json"))
if summary["qualified_positive"]:
    for pin in (
        summary["publication"]["manifest"], summary["publication"]["publication_receipt"],
        summary["native_result_ref"], context["source_context_ref"],
        context["dispatch_ref"], summary["readback_ref"],
    ):
        add(pin)
safety = Path(context["runtime_binding"]["run_dir"]) / "agent/provider_safety.json"
absent = []
if safety.exists():
    add(ref(safety))
else:
    absent.append(str(safety))
record = {
    "run_id": context["run_id"], "context": context_ref,
    "documents": list(documents.values()), "absent_paths": absent,
    "ledger_included": False, "payloads_included": False,
}
path = run / "LOCAL_SETTLEMENT_METADATA_001.json"
with path.open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record))

