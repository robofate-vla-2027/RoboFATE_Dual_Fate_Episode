"""Existing Classify prelaunch with only the frozen L51 run binding changed."""
from prelaunch_classify_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    old = "c2_classify_objects_l10_h20_baseline_0001_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_classify_objects_l51_h20_baseline_0001_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Classify_L51_original_collector", "exec"), globals())
