"""Matched teacher entries with the bounded H20 Conveyor source-context path."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_binding_v4.py")
text = path.read_text()
for old, new in (
    ('"native_teacher_h20_v4"', '"native_teacher_h20_v5"'),
    ('"collect_teacher_h20_v4"', '"collect_teacher_h20_v5"'),
    ('"prepare_teacher_h20_v4"', '"prepare_teacher_h20_v5"'),
    ('"_refate_h20_teacher_native_scope_v4"', '"_refate_h20_teacher_native_scope_v5"'),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
exec(compile(text, str(path) + "::conveyor_source_context", "exec"), globals())

import teacher_native_extension_v1 as conveyor
from h20_teacher_conveyor_context_v1 import install

install(conveyor, execution.D / "teacher/runs", execution.OWNER)
