"""Original source metadata preparer with Sweep's original1000-step budget."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_stack_initial_h20_v1.py").read_text()
    for old, new, count in (
        ('TASK = "stack_blocks_by_language"', 'TASK = "sweep_blocks"', 1),
        ("STACK_L0_PREPARATION_CPU_001.json", "SWEEP_L0_PREPARATION_CPU_001.json", 1),
        ("400", "1000", 5),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_Sweep1000_metadata", "exec"), globals())
