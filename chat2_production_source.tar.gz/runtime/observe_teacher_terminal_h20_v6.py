"""Original terminal rules and native source, with an immutable active context."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_terminal_h20_v1.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v2", "h20_teacher_binding_v6"),
    ("48e97cd2d6dfabd2d053dae56c4628226074f28221aa1cf560363f7748cfd93d",
     "2cc4a910911b19cce2273b6f13a17f1ba8397df9f3ed1cb0b5547284da59b376"),
):
    assert text.count(old) == 1
    text = text.replace(old, new)
seam = 'exec(compile(text, str(Path(original.__file__)) + "::actual_h20_source", "exec"), globals())'
assert text.count(seam) == 1
text = text.replace(seam, """
text = execution.edit(text, "run/'CONTEXT_001.json'",
                      "run/x.get('context_name','CONTEXT_001.json')", count=2)
""" + seam)
exec(compile(text, str(path) + "::active_context", "exec"), globals())
