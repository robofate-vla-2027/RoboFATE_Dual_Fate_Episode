"""Carry the genuine settled teacher summary for the same prior Plug source."""
from pathlib import Path

path = Path(__file__).with_name("plug_next_inputs_h20_v2.py")
text = path.read_text()
seam = 'exec(compile(text, str(path) + "::future_resource_identity", "exec"), globals())'
assert text.count(seam) == 1
text = text.replace(seam, '''
old = '"last_teacher_settlement": None,'
new = \'''\"last_teacher_settlement\": (
        terminal[\"summary_ref\"] if resource_kind == \"closed_teacher_resource_v1\"
        and terminal[\"source_id\"] == source_predecessor[\"source_id\"] else None),\'''
assert text.count(old) == 1
text = text.replace(old, new, 1)
''' + seam, 1)
exec(compile(text, str(path) + "::settled_teacher_summary_reference", "exec"), globals())
