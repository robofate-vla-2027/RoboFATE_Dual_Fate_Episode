"""Original actual-start observer through the matched teacher012 binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher010_start_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v10") == 1
exec(compile(text.replace("h20_teacher_binding_v10", "h20_teacher_binding_v12"),
             str(path) + "::catalog012", "exec"), globals())
