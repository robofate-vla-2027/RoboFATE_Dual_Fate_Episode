"""Use the original Plug append preparer with reversible metadata-only paths."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_teacher_binding_v6 as runtime
import collection_append_binding_v1 as binding

execution = runtime.execution
execution.previous.host()


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


index = int(sys.argv[1])
assert 23 <= index < 53
root = execution.A / "task_sources/plug_in_charger"
prior_path = root / f"PREPARATION_L{index - 1}_APPEND_001.json"
prior = binding.document(ref(prior_path))
binding.load_native_layout(prior)
assert prior["source"]["layout_id"] == index - 1 and prior["native_step_limit"] == 400
receipt_path = execution.D / f"migration/PLUG_L{index}_PREPARATION_CPU_001.json"
assert not receipt_path.exists(), "Reuse the already saved preparation receipt"
assert not (root / f"PREPARATION_L{index}_APPEND_001.json").exists()
helper = execution.A / "prepare_next_plug_handoff_v1.py"
text = helper.read_text()
historical = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/perdon_adapter_20261026"
assert text.count(historical) == 1
text = text.replace(historical, str(execution.A), 1)
sys.stdin = io.StringIO(json.dumps({
    "execution_owner": execution.OWNER, "current_preparation": ref(prior_path),
}))
captured = io.StringIO()
with contextlib.redirect_stdout(captured):
    exec(compile(text, str(helper) + "::h20_storage_only", "exec"),
         {"__name__": "__main__", "__file__": str(helper)})
result = json.loads(captured.getvalue())
prepared = binding.document(result["preparation_ref"])
raw = binding.load_native_layout(prepared)
import teacher_catalog_binding_v13 as teacher
assert teacher.load_native_layout(prepared) == raw
assert prepared["source"]["layout_id"] == index
record = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "data_kind": "actual_metadata_CPU_only",
    "preparation": result, "historical_predecessor_copy": ref(prior_path),
    "original_preparer": ref(helper), "execution_binding": ref(Path(__file__)),
    "metadata_path_binding": ref(execution.D / "runtime/h20_plug_metadata_storage_v1.py"),
    "native_total": 400, "actual_append_loader_passed": True,
    "actual_teacher_metadata_loader_passed": True, "raw_layout_unchanged": True,
    "sealed_content_read": False, "native_model_API_calls": False,
    "registered": False, "reserved": False, "launched": False,
}
with receipt_path.open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({"preparation": result, "CPU_receipt": ref(receipt_path)}))
