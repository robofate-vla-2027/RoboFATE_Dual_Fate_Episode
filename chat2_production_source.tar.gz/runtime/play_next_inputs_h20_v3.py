"""Ordered Play metadata on the already adopted release038."""
from pathlib import Path

path = Path(__file__).with_name("play_next_inputs_h20_v2.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261108_035.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json", 1)
exec(compile(text, __file__ + "::release038_Play_inputs", "exec"), globals())

