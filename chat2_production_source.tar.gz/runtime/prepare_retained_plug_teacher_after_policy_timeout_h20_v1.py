"""Reuse teacher014 preparation; a closed L25 resource is not the L24 source."""

SOURCE_RUN = "c2_plug_in_charger_l24_h20_baseline_0025_01a16807"
TEACHER_RUN = "c2_plug_in_charger_l24_evo_common_teacher_0001_01a16807"
RESOURCE_RUN = "c2_plug_in_charger_l25_h20_baseline_0026_01a16807"


def validate_predecessor(arguments, terminal, closed_checks):
    assert arguments["source_run"] == SOURCE_RUN
    assert arguments["run_id"] == TEACHER_RUN
    assert arguments["task"] == terminal["task"] == "plug_in_charger"
    assert terminal["run_id"] == RESOURCE_RUN
    assert terminal["source_id"] == "plug_in_charger_b0_l25_9a7f44a82f87fd28"
    assert not terminal["reusable_DM_failure"] and not terminal["source_retry_allowed"]
    closed_checks(terminal)


def adapt_main(text):
    old = '    elif terminal.get("schema") == "refate.teacher_prelaunch_interruption.v1":'
    assert text.count(old) == 1
    new = '''    elif terminal.get("schema") == "refate.actual_interrupted_baseline.v1":
        from closed_primary_policy_timeout_resource_h20_v1 import checks
        _validate_retained_predecessor(arguments, terminal, checks)
''' + old
    text = text.replace(old, new, 1)
    old = '"resource_ref", "runtime_release", "split_manifest", "settlement_ref"):'
    assert text.count(old) == 1
    return text.replace(
        old, '"resource_ref", "runtime_release", "split_manifest", "settlement_ref", '
        '"current_resource_predecessor"):', 1)


if __name__ == "__main__":
    import prepare_teacher_metadata_h20_v16 as previous
    scope = previous.previous.__dict__
    scope["_metadata_task_totals"] = dict(previous.catalog.TASK_TOTALS)
    scope["_validate_retained_predecessor"] = validate_predecessor
    exec(compile(adapt_main(previous.main_source()),
                 __file__ + "::resource_only_extension", "exec"), scope)
    scope["main"]()
