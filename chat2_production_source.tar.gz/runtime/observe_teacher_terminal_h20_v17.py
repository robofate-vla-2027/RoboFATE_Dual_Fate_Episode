"""Original terminal checks through matched teacher014 and its Native pin."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_terminal_h20_v16.py")
text = path.read_text()
for old, new in (
    ("h20_teacher_binding_v13", "h20_teacher_binding_v14"),
    ("teacher_history_pre_actor_catalog013_v1", "teacher_history_pre_actor_catalog014_v1"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::catalog014_terminal", "exec"), globals())
