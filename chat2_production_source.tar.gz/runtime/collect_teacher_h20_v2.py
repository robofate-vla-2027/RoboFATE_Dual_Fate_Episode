"""Original content-v6 collector on the matched private H20 teacher binding."""
import h20_teacher_binding_v2 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())
