"""Address-only use of the original frozen Classify next-source preparer."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys


def deny_live_effects(event, args):
    if event in {"socket.__new__", "subprocess.Popen", "os.system", "os.posix_spawn",
                 "os.kill", "os.killpg"}:
        raise RuntimeError("CPU metadata preparation forbids real peer/process effects")


sys.addaudithook(deny_live_effects)
import h20_container_binding_v9 as execution
from h20_insert_private_metadata_v1 import metadata_locations
from h20_classify_metadata_storage_v1 import install_runtime
import prepare_classify_legacy_handoff_v2 as original

install_runtime()
execution.previous.host()
original.ROOT = execution.A.parents[2]
original.ADAPTER = execution.A
original.ORIGINAL = metadata_locations(original.ORIGINAL)


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    layout, previous = map(int, sys.argv[1:])
    directory = execution.A / "task_sources/classify_objects"
    prepared_path = directory / f"PREPARATION_L{layout}_CONFIGURED_001.json"
    receipt_path = execution.D / f"migration/CLASSIFY_L{layout}_PREPARATION_CPU_001.json"
    assert not prepared_path.exists() and not receipt_path.exists(), "Reuse existing preparation"
    prior = directory / f"PREPARATION_L{previous}_CONFIGURED_001.json"
    manifest_path = Path(original.ORIGINAL["path"])
    manifest_before = manifest_path.read_bytes()
    assert ref(manifest_path) == original.ORIGINAL
    request = {"execution_owner": execution.OWNER, "layout": layout,
               "prior_preparation_ref": ref(prior)}
    captured = io.StringIO()
    sys.stdin = io.StringIO(json.dumps(request))
    with contextlib.redirect_stdout(captured):
        original.main()
    result = json.loads(captured.getvalue())
    prepared = json.loads(prepared_path.read_bytes())
    import task_configured_binding as configured
    raw_layout = configured.load_native_layout(prepared)
    layout_ref = metadata_locations(prepared["source"]["layout_ref"])
    assert ref(Path(layout_ref["path"])) == layout_ref
    assert raw_layout == json.loads(Path(layout_ref["path"]).read_bytes())
    assert prepared["native_step_limit"] == 1100
    assert manifest_path.read_bytes() == manifest_before
    receipt = {
        "schema": "refate.actual_metadata_preparation.v1",
        "data_kind": "actual_source_metadata_not_execution",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "execution_owner": execution.OWNER, "task": "classify_objects",
        "source_id": prepared["source"]["source_id"], "native_total": 1100,
        "preparation_ref": ref(prepared_path), "predecessor_preparation": ref(prior),
        "original_manifest": original.ORIGINAL, "original_result": result,
        "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
        "original_manifest_unchanged": True, "sealed_content_read": False,
        "native_started": False, "source_registered": False, "source_reserved": False,
        "model_calls": 0, "original_helper": ref(Path(original.__file__)),
        "execution_binding": ref(Path(__file__)),
    }
    with receipt_path.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({**receipt, "receipt_ref": ref(receipt_path)}))


if __name__ == "__main__":
    main()
