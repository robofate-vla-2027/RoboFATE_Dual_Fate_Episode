"""Original foreground teacher with the retained Classify source binding."""
from pathlib import Path

path = Path(__file__).with_name("collect_teacher_h20_v8.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v8") == 1
exec(compile(text.replace("h20_teacher_binding_v8", "h20_teacher_binding_v10"),
             str(path) + "::stack400", "exec"), globals())
