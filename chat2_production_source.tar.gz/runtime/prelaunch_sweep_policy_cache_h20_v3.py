"""Same collector, using the container's existing writable per-run NFS bind."""
from prelaunch_sweep_policy_cache_h20_v2 import source as previous_source


def source():
    text = previous_source()
    old = "policy_cache_seed_sweep_nfs_h20_v1"
    assert text.count(old) == 2
    return text.replace(old, "policy_cache_seed_sweep_nfs_h20_v2", 2)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::existing_rw_run_bind", "exec"), globals())
