"""Validate a closed zero-control loading interruption, never a DM failure."""

OWNER = "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"


def loading_checks(evidence):
    assert evidence["schema"] == "refate.actual_policy_startup_interruption.v1"
    assert evidence["data_kind"] == "actual"
    assert evidence["execution_owner"] == OWNER
    assert evidence["loading_allowance_seconds"] == 900
    assert evidence["baseline_wall_seconds"] == 2400
    assert evidence["failure_detail"]["type"] == "TimeoutError"
    assert evidence["failure_detail"]["message"] == (
        "Policy not ready within original900s loading allowance")
    assert evidence["safe_for_next_simulator"] is True
    for key in ("native_terminal", "native_success", "native_failure_proven",
                "full_readback_passed", "reusable_DM_failure",
                "source_retry_allowed", "policy_model_ready"):
        assert evidence[key] is False, key
    assert evidence["new_positive"] == evidence["new_negative"] == 0
    assert evidence["observations_committed"] == 1
    assert evidence["actual_controls_observed"] == 0
    assert evidence["writer_failed"] is True
    checks = []
    for role, key in (("native", "owned_native_identity"),
                      ("policy", "policy_process_identity"),
                      ("foreground", "foreground_identity")):
        identity = evidence[key]
        assert all(type(identity[k]) is int and identity[k] > 0
                   for k in ("pid", "start_ticks"))
        assert isinstance(identity["boot_id"], str) and identity["boot_id"]
        checks.append({"role": role, "identity": identity})
    return checks

