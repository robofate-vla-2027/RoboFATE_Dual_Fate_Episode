"""Closed primary prediction timeout is never a reusable native DM failure."""
from pathlib import Path


def checks(e):
    assert e["schema"] == "refate.actual_interrupted_baseline.v1"
    assert e["execution_owner"] == "01a19072-9e5e-7e02-b77a-8f115cfc9bd0"
    assert e["primary_failure_preserved"] and e["safe_for_next_simulator"]
    assert e["policy_model_ready"] and e["source_started"]
    assert e["baseline_wall_seconds"] == 2400
    assert e["model_loading_allowance_seconds"] == 900
    assert e["model_request_default_seconds"] == 120
    assert e["failure_detail"]["type"] == "WsError"
    assert e["failure_detail"]["message"] == "timeout waiting for MessageType.CALL_RESULT"
    assert e["observations_submitted"] == e["observations_committed"] == 1
    assert e["last_actual_executed_tick"] == 0
    assert e["new_positive"] == e["new_negative"] == 0
    for key in ("native_terminal", "native_success", "native_failure_proven",
                "full_readback_passed", "reusable_DM_failure", "source_retry_allowed"):
        assert e[key] is False, key
    for ident in e["owned_process_identities"].values():
        assert type(ident["pid"]) is int and type(ident["start_ticks"]) is int
        assert ident["boot_id"] == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        p = Path("/proc") / str(ident["pid"]) / "stat"
        if p.exists():
            assert int(p.read_text().rsplit(")", 1)[1].split()[19]) != ident["start_ticks"]

