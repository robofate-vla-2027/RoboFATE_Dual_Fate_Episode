"""Existing collector11 prelaunch, restricted to prepared General L31."""
from prelaunch_fasten_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_fasten_h20_v1", "policy_cache_seed_general_h20_v1", 2),
        ("c2_fasten_screws_l7_h20_baseline_0001_01a16807",
         "c2_general_pickup_l31_h20_baseline_0001_01a16807", 1),
        ('value["native_total_steps"] == 1900', 'value["native_total_steps"] == 200', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General_L31_original_collector", "exec"), globals())
