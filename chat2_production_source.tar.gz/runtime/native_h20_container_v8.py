"""Same Native loop; preserve original execution failure and record secondary reset."""
from pathlib import Path
import sys
import h20_container_binding_v10 as binding
import native_init_evidence_v1 as evidence
import native_primary_error_diagnostic_v1 as primary

if __name__ == "__main__":
    context = Path(sys.argv[sys.argv.index("--context") + 1])
    evidence.install(binding.node, context.parent)
    primary.install(binding.baseline_module, context.parent)
    raise SystemExit(binding.baseline_module.main())

