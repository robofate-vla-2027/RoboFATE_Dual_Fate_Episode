"""Reuse the original source-cut/resource preparation at a safe H20 boundary."""
import base64
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import types

import h20_teacher_binding_v2 as binding
import teacher_prepare_metadata_handoff_v6 as original
import teacher_reserve_handoff_v6 as reserve

execution = binding.execution
OLD = "/mnt/workspace/users/maxiangkai/projects/ReFATE/coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher"
RELEASE = execution.D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261106_001.json"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def source():
    text = original.source()
    for old, new, count in (
        (OLD + "/perdon_adapter_20261026", str(execution.A), 4),
        (OLD + "/runs", str(execution.D / "teacher/runs"), 2),
        (OLD + "/preparations", str(execution.D / "teacher/preparations"), 1),
        ("import collect_teacher_content_v6 as collect", "collect = _host_metadata_collector", 1),
        ("('127.0.0.1',28181)", "('127.0.0.1',29181)", 1),
        ("hostname='nb-5pl2apckdj-0'", "hostname='20250103-instance'", 1),
        ("ssh_endpoint='root@116.198.70.4:1122'", "ssh_endpoint='root@116.196.106.22:22'", 1),
    ):
        text = execution.edit(text, old, new, count=count)
    old = (
        "release=r.ref(Path(" + repr(str(execution.A / "TEACHER_FASTEN_CONTENT_RELEASE_20261101_01a19072.json"))
        + "));assert release['sha256']=='7d3a95a691030d7d3dc5707c619ab9da9e11c61fd1bab49af2bec4b491e73e46'")
    text = execution.edit(text, old, "release = _teacher_release_ref")
    text = execution.edit(
        text, "resource_ref=write(run/'RESOURCE_PRECHECK_001.json',resource);",
        "resource.update(execution_ssh_alias='h20_8',physical_gpus=[1,7],"
        "logical_node_key='perdon-hou',memory=_host_memory(),"
        "current_resource_predecessor=_resource_predecessor);"
        "resource_ref=write(run/'RESOURCE_PRECHECK_001.json',resource);")
    return text


def main():
    execution.previous.host()
    arguments = json.load(sys.stdin)
    predecessor = arguments.pop("current_resource_predecessor")
    terminal = binding.preparation.restore.document(predecessor)
    assert terminal["safe_for_next_simulator"] and terminal["execution_owner"] == execution.OWNER
    assert terminal["first_readback_passed"]
    release_ref = ref(RELEASE)
    release = json.loads(RELEASE.read_bytes())
    assert release["foreground_entry"] == str(execution.D / "runtime/collect_teacher_h20_v2.py")
    assert release["teacher_wall_seconds"] == 3600
    for pin in release["runtime_files"]:
        binding.storage.runtime.read_pin(pin)
    host_metadata = types.SimpleNamespace(
        host=execution.previous.host, allocation=execution.previous.allocation,
        LOCK=execution.foreground.LOCK, identity=execution.foreground.identity)
    output = io.StringIO()
    scope = {
        "__name__": "__main__", "__file__": str(Path(original.__file__)),
        "_host_metadata_collector": types.SimpleNamespace(base=host_metadata),
        "_teacher_release_ref": release_ref, "_resource_predecessor": predecessor,
        "_host_memory": lambda: execution.previous.memory_headroom(120),
    }
    sys.stdin = io.StringIO(json.dumps(arguments))
    with contextlib.redirect_stdout(output):
        exec(compile(source(), __file__ + "::original_metadata_on_h20", "exec"), scope)
    result = json.loads(output.getvalue())
    result["current_resource_predecessor"] = predecessor
    run = execution.D / "teacher/runs" / result["run_id"]
    docs = []
    for key in ("selection_ref", "source_context", "source_manifest", "source_readback",
                "resource_ref", "runtime_release", "split_manifest", "settlement_ref"):
        pin = result[key]
        raw = binding.storage.runtime.read_pin(pin)
        docs.append({"ref": pin, "raw_b64": base64.b64encode(raw).decode()})
    result["documents"] = docs
    helper = reserve.source().encode()
    result["original_reservation_source"] = {
        "sha256": hashlib.sha256(helper).hexdigest(),
        "raw_b64": base64.b64encode(helper).decode(),
        "origin": ref(Path(reserve.__file__)),
    }
    result["task_totals"] = dict(binding.storage.teacher_catalog_binding_v13.TASK_TOTALS)
    result["remote_sessions"] = sorted(p.name for p in (execution.D / "teacher/sessions").iterdir())
    result["future_run_files_absent"] = all(
        not (run / name).exists() for name in ("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json"))
    result["execution_owner"] = execution.OWNER
    result["ledger_included"] = False
    result["teacher_started"] = False
    with (run / "PREPARATION_METADATA_H20_001.json").open("x") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
