"""Keep the L32 source predecessor; use the actual closed Stack L4 resource."""
from classify_next_inputs_h20_v2 import source as original_source


def source():
    text = original_source()
    old = 'resource_run_id == "c2_classify_objects_l32_evo_common_teacher_0001_01a16807"'
    new = 'resource_run_id == "c2_stack_blocks_by_language_l4_evo_common_teacher_0001_01a16807"'
    assert text.count(old) == 1
    return text.replace(old, new, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Stack4_resource_only", "exec"), globals())
