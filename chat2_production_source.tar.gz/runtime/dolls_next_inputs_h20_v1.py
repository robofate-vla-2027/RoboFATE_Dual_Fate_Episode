"""Dolls boundary metadata; historical source and current resource stay distinct."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

import h20_container_binding_v7 as execution
from h20_insert_private_metadata_v1 import metadata_locations
from closed_baseline_resource_v1 import baseline_checks
import task_configured_binding as configured

host = execution.previous
host.host()
index, resource_run_id = int(sys.argv[1]), sys.argv[2]
assert 15 <= index < 28
assert re.fullmatch(r"c2_[a-z0-9_]+_h20_baseline_\d{4}_01a16807", resource_run_id)
task = "sort_nesting_dolls_by_size"


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def document(reference):
    return json.loads(host.read_pin(metadata_locations(reference)))


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


resource_ref = ref(host.D / "teacher/runs" / resource_run_id / "MAIN_SETTLEMENT_001.json")
terminal = document(resource_ref)
baseline_checks(terminal)
assert terminal["execution_owner"] == host.OWNER
assert terminal["safe_for_next_simulator"] and terminal["first_readback_passed"]
if index == 15:
    prior = execution.A.parent / f"runs/c2_{task}_l14_common_baseline_0015_01a16807"
    historical_root = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")
    prior_settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")
    prior_settlement_ref["path"] = str(
        historical_root / Path(prior_settlement_ref["path"]).relative_to(host.PROJECT))
else:
    prior = host.D / f"teacher/runs/c2_{task}_l{index-1}_h20_baseline_{index:04d}_01a16807"
    prior_settlement_ref = ref(prior / "MAIN_SETTLEMENT_001.json")
prior_dispatch = json.loads((prior / "DISPATCH_001.json").read_bytes())
previous = {"ref": prior_dispatch["source_preparation"],
            "prepared": document(prior_dispatch["source_preparation"])}
old = previous["prepared"]["source"]
assert old["task"] == task and old["layout_id"] == index - 1
assert document(prior_settlement_ref)["source_id"] == old["source_id"]
prepared_path = execution.A / f"task_sources/{task}/PREPARATION_L{index}_CONFIGURED_001.json"
prepared = json.loads(prepared_path.read_bytes())
configured.load_native_layout(prepared)
assert prepared["source"]["required_accounted_prefix"] == old["source_sequence"]
assert prepared["source"]["source_sequence"] == list(range(index + 1))
assert prepared["native_step_limit"] == 1050
manifest = document(prepared["provenance"]["split"])
assert manifest["original_partition"]["reserved_final"] == [28, 29]
release_path = host.D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_013.json"
release = json.loads(release_path.read_bytes())
cpu_ref = ref(host.D / f"migration/DOLLS_L{index}_PREPARATION_CPU_001.json")
cpu = document(cpu_ref)
assert cpu["actual_configured_loader_passed"] and cpu["raw_layout_unchanged"]
resource = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": "20250103-instance", "allocation": host.allocation(),
    "memory": host.memory_headroom(120), "native_started": False,
}
assert shutil.disk_usage(host.D).free > 30 * 1024**3
run_id = f"c2_{task}_l{index}_h20_baseline_{index+1:04d}_01a16807"
run = host.D / "teacher/runs" / run_id
run.mkdir()
admission_ref = save(run / "RESOURCE_PRECHECK_001.json", resource)
out = {
    "run_id": run_id, "preparation": prepared, "preparation_ref": ref(prepared_path),
    "previous": previous, "prior_settlement_ref": prior_settlement_ref,
    "prior_source_id": old["source_id"], "current_resource_predecessor": resource_ref,
    "terminal": terminal, "release_ref": ref(release_path), "release": release,
    "cpu_ref": cpu_ref, "resource": resource, "resource_ref": admission_ref,
    "native_started": False,
}
out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)
print(json.dumps(out))
