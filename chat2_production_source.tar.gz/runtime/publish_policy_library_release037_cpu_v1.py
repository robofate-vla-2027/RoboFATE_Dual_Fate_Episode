"""Publish a future baseline binding after identical copies are complete."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if (event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname") or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline release publication attempted a live external effect")


def main():
    sys.addaudithook(deny_live)
    import h20_container_binding_v10 as binding
    import verify_policy_library_copies_h20_v1 as libraries

    binding.previous.host()
    d = binding.D

    def ref(path):
        return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())

    prior = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_036.json"
    assert ref(prior)["sha256"] == "6153e9ec8798dd3b79af200f9e640ab18132a27e8fa1d957f2d589621f749f64"
    copies = libraries.ROOT / "VERIFIED_COPIES_001.json"
    record = json.loads(copies.read_bytes())
    assert len(libraries.verify(record, libraries.ROOT, libraries.SOURCE)) == 8
    release = deepcopy(json.loads(prior.read_bytes()))
    assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
    assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
    assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
    assert release["native_entry"].endswith("/native_h20_container_v8.py")
    assert release["container_launcher"]["sha256"] == (
        "e9ed5388f762232042e60fc0f2ac37109e74c283b8126c33fdfeb9ed3d7873b9")
    launcher = d / "runtime/launch_container_v6.sh"
    assert ref(launcher)["sha256"] == (
        "ddbcfd38cab814a39f5796274167dd42afdeb3b11ef990f3c4084e379d5c643d")
    prelaunch = d / "runtime/prelaunch_sweep_policy_cache_h20_v3.py"
    pin = next(p for p in release["runtime_files"] if p["path"] == str(prelaunch))
    assert ref(prelaunch) == pin
    for name in (
        "launch_container_v6.sh", "verify_policy_library_copies_h20_v1.py",
        "publish_policy_library_release037_cpu_v1.py",
    ):
        path = d / "runtime" / name
        assert all(p["path"] != str(path) for p in release["runtime_files"])
        if path.suffix == ".py":
            compile(path.read_bytes(), str(path), "exec")
        release["runtime_files"].append(ref(path))
    release.update(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        prior_runtime_release=ref(prior), container_launcher=ref(launcher),
        prelaunch_entry=str(prelaunch), identical_library_copies=ref(copies),
        library_copy_count=8, actual_adoption=False,
        prediction_latency_fixed=False, root_cause_established=False,
        change_scope="Only identical-byte read-only library mounts in the private chat2 "
                     "baseline container and the existing Sweep prelaunch selection. "
                     "Preserve collector11, Native8, policy2, content/RNG/readers, "
                     "model weights, CUDA/RTX mapping and all original budgets.",
    )
    output = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261109_037.json"
    with output.open("x") as stream:
        json.dump(release, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps(dict(release=ref(output), identical_libraries=8,
                         actual_adoption=False, model_API_GPU_simulator_calls=0)))


if __name__ == "__main__":
    main()
