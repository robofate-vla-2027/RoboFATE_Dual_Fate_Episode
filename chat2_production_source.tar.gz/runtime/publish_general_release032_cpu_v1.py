"""Offline General200 binding only; no model, API, simulator or ledger calls."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if (event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname") or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline binding check attempted a live external effect")


sys.addaudithook(deny_live)
import h20_teacher_binding_v14 as runtime
import policy_cache_seed_fasten_h20_v1 as prior_cache
import policy_cache_seed_general_h20_v1 as cache
import prelaunch_fasten_policy_cache_h20_v1 as prior_launch
import prelaunch_general_policy_cache_h20_v1 as launch
import task_configured_binding as configured

runtime.execution.previous.host()
D = runtime.execution.previous.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_031.json"
assert ref(prior)["sha256"] == "40a07af2ee2210715fb165b29086cef066efe752dac101aa93348c5cc7337b7a"
assert cache.source() == prior_cache.source().replace(
    'context["task"] == "fasten_screws"', 'context["task"] == "general_pickup"', 1
).replace('context["native_total_steps"] == 1900', 'context["native_total_steps"] == 200', 1)
assert launch.source() == prior_launch.source().replace(
    "policy_cache_seed_fasten_h20_v1", "policy_cache_seed_general_h20_v1", 2
).replace(
    "c2_fasten_screws_l7_h20_baseline_0001_01a16807",
    "c2_general_pickup_l31_h20_baseline_0001_01a16807", 1
).replace('value["native_total_steps"] == 1900', 'value["native_total_steps"] == 200', 1)
compile(cache.source(), "offline_General200_cache_source", "exec")
compile(launch.source(), "offline_General31_prelaunch_source", "exec")
preparation = runtime.execution.A / "task_sources/general_pickup/PREPARATION_L31_CONFIGURED_001.json"
assert ref(preparation)["sha256"] == "4c6f912d1e2548a312a78278a8140c4d8942725b0f2a8aa96a0576d0114641ca"
prepared = json.loads(preparation.read_bytes())
raw_layout = configured.load_native_layout(prepared)
assert configured.previous.base.original.same(
    raw_layout, json.loads(Path(prepared["source"]["layout_ref"]["path"]).read_bytes()))
assert prepared["native_step_limit"] == 200 and prepared["source"]["layout_id"] == 31
sequence = prepared["source"]["source_sequence"]
assert prepared["source"]["required_accounted_prefix"] == sequence[:sequence.index(31)]
assert sequence[sequence.index(31) - 1] == 30
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = save(D / "migration/GENERAL_L31_CACHE_BINDING_CPU_001.json", {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 5, "task_only_cache_source_equality": True,
    "task_only_prelaunch_source_equality": True, "frozen_source_order_retained": True,
    "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
    "model_API_simulator_calls": 0, "source_preparation": ref(preparation),
    "native_budget": 200, "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "actual_General_L31_launch_verified": False, "reservation_or_launch_authority": False,
})
release["runtime_files"].extend(ref(D / "runtime" / name) for name in (
    "policy_cache_seed_general_h20_v1.py", "prelaunch_general_policy_cache_h20_v1.py",
    "publish_general_release032_cpu_v1.py",
))
release.update(
    at=at, prior_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_general_policy_cache_h20_v1.py"),
    general_cache_cpu=cpu, actual_adoption=False,
    change_scope="General L31/native200 task and run binding only. Preserve collector11, "
                 "Native8, writable compiled cache, content/RNG/readers, model, RTX and timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_032.json", release)
print(json.dumps({"release": output, "CPU": cpu, "actual_adoption": False}))
