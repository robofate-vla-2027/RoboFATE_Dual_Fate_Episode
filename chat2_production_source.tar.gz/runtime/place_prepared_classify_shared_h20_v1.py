"""Existing per-run storage binding for unstarted Classify L10 metadata."""
from pathlib import Path

path = Path(__file__).with_name("place_prepared_fasten_shared_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_fasten_screws_l(7)_h20_baseline_(0001)_01a16807",
     "c2_classify_objects_l(10)_h20_baseline_(0001)_01a16807"),
    ("int(match[1]) == 7 and int(match[2]) == 1",
     "int(match[1]) == 10 and int(match[2]) == 1"),
    ('prepared["source"]["task"] == "fasten_screws"',
     'prepared["source"]["task"] == "classify_objects"'),
    ('prepared["native_step_limit"] == 1900', 'prepared["native_step_limit"] == 1100'),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Classify10_prepared_metadata_only", "exec"), globals())
