"""Keep the existing cache placement and collector for initial laptop sources."""
from prelaunch_stack_policy_cache_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_stack_h20_v1", "policy_cache_seed_laptop_h20_v1", 2),
        ("c2_stack_blocks_by_language_l[1-6]_h20_baseline_000[2-7]_01a16807",
         "c2_store_laptop_and_headphones_l[0-6]_h20_baseline_000[1-7]_01a16807", 1),
        ('value["native_total_steps"] == 400', 'value["native_total_steps"] == 800', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::laptop800_same_cache_and_collector", "exec"), globals())
