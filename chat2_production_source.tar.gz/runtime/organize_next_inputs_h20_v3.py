"""Original Organize metadata export with the completed private-copy evidence."""
from pathlib import Path

def source():
    text = Path(__file__).with_name("organize_next_inputs_h20_v1.py").read_text()
    for old, new in (
        ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261109_037.json"),
        ("collect_h20_container_v8.py", "collect_h20_container_v11.py"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    seam = 'out["boundary_inputs_ref"] = save(run / "BOUNDARY_INPUTS_001.json", out)'
    assert text.count(seam) == 1
    addition = """import base64
copies = Path(release["identical_library_copies"]["path"])
raw = copies.read_bytes()
assert hashlib.sha256(raw).hexdigest() == release["identical_library_copies"]["sha256"]
assert (copies.parent / "STAGING_RESUME_003.actual_returncode").read_text().strip() == "0"
out["library_copy_packet"] = {"ref": ref(copies), "raw_b64": base64.b64encode(raw).decode()}
out["library_copy_actual_returncode"] = 0
out["release"] = release
"""
    return text.replace(seam, addition + seam, 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Organize26_library_copy_metadata", "exec"),
         globals())
