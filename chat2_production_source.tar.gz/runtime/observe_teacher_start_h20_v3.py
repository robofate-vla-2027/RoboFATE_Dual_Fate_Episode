"""Observe the actual release004 processes without changing start semantics."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher_start_h20_v2.py")
text = path.read_text()
old = '"h20_teacher_binding_v3"'
assert text.count(old) == 1
text = text.replace(old, '"h20_teacher_binding_v4"')
exec(compile(text, str(path) + "::private_container_tmp", "exec"), globals())
