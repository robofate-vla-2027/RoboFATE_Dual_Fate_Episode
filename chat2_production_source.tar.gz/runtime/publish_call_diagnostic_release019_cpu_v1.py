"""Publish the paired diagnostic binding only after CPU source expansion checks."""
import datetime
import hashlib
import json
from pathlib import Path

import h20_container_binding_v10 as binding
import collect_h20_container_v11 as collector
import bind_h20_container_context_v13 as binder
import prelaunch_general_cache_tmpfs_v4 as cache
import general_after_call_timeout_inputs_h20_v1 as inputs

binding.previous.host()
assert collector.original.core.foreground is binding.foreground
assert collector.original.core.finish is binding.finish
assert binding.foreground.POLICY == binding.D / "runtime/policy_h20_container_v2.py"
text = cache.source()
compile(text, "CPU_only_cache", "exec")
assert 'ENTRY = D / "runtime/collect_h20_container_v11.py"' in text
assert 'value["native_total_steps"] == 200' in text
compile(inputs.source(), "CPU_only_inputs", "exec")
d = binding.D
ref = lambda p: dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
try:
    import prelaunch_general_cache_tmpfs_v3
except AssertionError as error:
    failed = dict(
        at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="unlaunched_prelaunch_source_expansion", error_type=type(error).__name__,
        release018_used_for_collection=False, real_launch=False,
        correction="prelaunch_general_cache_tmpfs_v4.py exact expansion")
    with (d / "migration/CALL_DIAGNOSTIC_PRELAUNCH018_CPU_FAILURE_001.json").open("x") as stream:
        json.dump(failed, stream, indent=2)
else:
    raise AssertionError("Expected preserved unlaunched v3 seam failure")
cpu = json.loads((d / "migration/CALL_DIAGNOSTIC_PAIRED_ENTRY_CPU_001.json").read_bytes())
cpu.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    cache_entry_expansion_verified=True, metadata_input_expansion_verified=True,
    prior_cpu_check=ref(d / "migration/CALL_DIAGNOSTIC_PAIRED_ENTRY_CPU_001.json"))
p = d / "migration/CALL_DIAGNOSTIC_PAIRED_ENTRY_CPU_002.json"
with p.open("x") as stream:
    json.dump(cpu, stream, indent=2)
old = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_018.json"
r = json.loads(old.read_bytes())
r["prior_unlaunched_diagnostic_release"] = ref(old)
r["runtime_files"] = [
    row for row in r["runtime_files"] if not row["path"].endswith("/prelaunch_general_cache_tmpfs_v3.py")]
r["runtime_files"].append(ref(d / "runtime/prelaunch_general_cache_tmpfs_v4.py"))
r.update(cpu_check=ref(p), at=cpu["at"], actual_adoption=False)
new = d / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261107_019.json"
with new.open("x") as stream:
    json.dump(r, stream, indent=2)
print(json.dumps(dict(release=ref(new), cpu=ref(p),
                     cache_entry_expansion_verified=True, actual_adoption=False)))

