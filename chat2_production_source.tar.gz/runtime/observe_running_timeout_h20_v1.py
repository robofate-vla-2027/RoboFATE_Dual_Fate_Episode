"""Observe one closed original Native timeout without decoding partial RGB."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

import h20_runtime_binding_v1 as host
from closed_timeout_resource_h20_v1 import timeout_checks

host.host()
x = json.load(sys.stdin)
assert x["run_id"] == "c2_sort_nesting_dolls_by_size_l27_h20_baseline_0028_01a16807"
assert x["tool_returncode"] == 255
run = host.D / "teacher/runs" / x["run_id"]


def read(name):
    return json.loads((run / name).read_bytes())


def ref(name):
    path = run / name
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


context, failure, cleanup = (
    read("CONTEXT_001.json"), read("foreground_error.json"), read("process_cleanup.json"))
assert ref("CONTEXT_001.json")["sha256"] == (
    "17408f83910902a116fbc69e426cc232568639c24cfe9accf343441b662ed6f4")
assert context["execution_owner"] == host.OWNER
assert context["run_id"] == x["run_id"] and context["native_total_steps"] == 1050
assert context["native_wall_seconds"] == 2400
assert failure["type"] == "TimeoutExpired"
assert "native_h20_container_v7.py" in failure["message"]
assert not (run / "result.json").exists(), "Use original complete-result settlement"
checks = []
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
for role in ("native", "policy"):
    item = cleanup[role]
    identity = item["identity"]
    assert identity == read("owned_" + role + ".json")["identity"]
    process = Path("/proc") / str(identity["pid"]) / "stat"
    try:
        fields = process.read_text().rsplit(")", 1)[1].split()
    except FileNotFoundError:
        fields = None
    same = fields is not None and boot == identity["boot_id"] and int(
        fields[19]) == identity["start_ticks"]
    assert item["original_process_absent"] is True and not same
    checks.append({"role": role, "identity": identity,
                   "original_process_absent": True, "returncode": item.get("returncode")})
progress = read("recording_progress.json")
writer = read("writer_close.json") if (run / "writer_close.json").exists() else None
at = datetime.datetime.now(datetime.timezone.utc)
start = read("foreground_started.json")["at"]
record = {
    "schema": "refate.actual_interrupted_baseline.v1", "data_kind": "actual",
    "at": at.isoformat(), "execution_owner": host.OWNER,
    "task": context["task"], "source_id": context["source_id"], "run_id": context["run_id"],
    "context": ref("CONTEXT_001.json"), "failure_ref": ref("foreground_error.json"),
    "timeout_error": failure, "native_terminal": False, "native_success": False,
    "native_failure_proven": False, "writer_failed": writer["failed"] if writer else None,
    "writer_close": writer, "writer_close_missing": writer is None,
    "process_closure": {"ref": ref("process_cleanup.json"), "checks": checks},
    "safe_for_next_simulator": True, "actual_foreground_tool_returncode": x["tool_returncode"],
    "read_only_attach_returncode": x.get("read_only_attach_returncode"),
    "new_positive": 0, "new_negative": 0, "full_readback_passed": False,
    "full_readback_repeated": False, "reusable_DM_failure": False,
    "native_wall_seconds": 2400, "native_budget": 1050,
    "last_actual_executed_tick": progress["low_level_controls"],
    "last_committed_boundary": progress["writer"]["last_committed_boundary"],
    "execution_counts_are_last_saved_observation_not_final_counts": True,
    "last_saved_recording_progress": progress,
    "foreground_started_at": start,
    "foreground_to_observation_seconds":
        (at - datetime.datetime.fromisoformat(start)).total_seconds(),
    "source_retry_allowed": False,
}
path = run / "MAIN_INTERRUPTION_SETTLEMENT_001.json"
timeout_checks(record)
if path.exists():
    record = json.loads(path.read_bytes())
    timeout_checks(record)
    assert record["context"] == ref("CONTEXT_001.json")
    assert record["failure_ref"] == ref("foreground_error.json")
else:
    with path.open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
record["settlement_ref"] = ref(path.name)
print(json.dumps(record))
