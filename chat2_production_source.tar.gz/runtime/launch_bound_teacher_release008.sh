#!/bin/bash
set -euo pipefail
test "$(hostname)" = 20250103-instance
test "${REFATE_SSH_ALIAS-}" = h20_8
test "${REFATE_EXECUTION_OWNER-}" = 01a19072-9e5e-7e02-b77a-8f115cfc9bd0
test "$#" -eq 3
id=$1
digest=$2
context_name=$3
[[ "$context_name" =~ ^CONTEXT_(001|RUNTIME_REBIND_001)\.json$ ]]
[[ "$id" =~ ^c2_[a-z0-9_]+_evo_common_teacher_[0-9]{4}_01a16807$ ]]
[[ "$digest" =~ ^[0-9a-f]{64}$ ]]
D=/data/refate_chat2_20261106_01a19072
R=$D/teacher/runs/$id
test ! -e "$R/foreground_started.json"
test ! -e "$R/native_started.json"
test ! -e "$D/container_records/$id"
export CUDA_VISIBLE_DEVICES=1,7
export MODEL_UPSTREAM=http://127.0.0.1:29181
exec bash "$D/runtime/launch_teacher_container_v4.sh" "$id" \
    /data/agent_rsi_validation_20261022_01a161cf/envs/native-thin/bin/python \
    "$D/runtime/collect_teacher_h20_v8.py" \
    --context "$R/$context_name" --sha256 "$digest"
