"""Pin the Classify task-only binding of the already used release029 core."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if event.startswith(("socket.", "subprocess.")) or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline binding check attempted a live external effect")


sys.addaudithook(deny_live)
import h20_teacher_binding_v14 as runtime
import policy_cache_seed_fasten_h20_v1 as prior_cache
import policy_cache_seed_classify_h20_v1 as cache
import prelaunch_fasten_policy_cache_h20_v1 as prior_launch
import prelaunch_classify_policy_cache_h20_v1 as launch
import task_configured_binding as configured
import teacher_catalog_sweep_h20_v1 as teacher

host = runtime.execution.previous
host.host()
D = host.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_029.json"
assert ref(prior)["sha256"] == "543ca583514cfb3de774aeb62c6dd8236a3c169e07e762c39ee8e7820fb617e1"
assert cache.source() == prior_cache.source().replace(
    'context["task"] == "fasten_screws"', 'context["task"] == "classify_objects"', 1
).replace('context["native_total_steps"] == 1900', 'context["native_total_steps"] == 1100', 1)
assert launch.source() == prior_launch.source().replace(
    "policy_cache_seed_fasten_h20_v1", "policy_cache_seed_classify_h20_v1", 2
).replace(
    "c2_fasten_screws_l7_h20_baseline_0001_01a16807",
    "c2_classify_objects_l10_h20_baseline_0001_01a16807", 1
).replace('value["native_total_steps"] == 1900', 'value["native_total_steps"] == 1100', 1)
compile(cache.source(), "offline_cache_source", "exec")
compile(launch.source(), "offline_prelaunch_source", "exec")
preparation = runtime.execution.A / "task_sources/classify_objects/PREPARATION_L10_CONFIGURED_001.json"
prepared = json.loads(preparation.read_bytes())
assert configured.load_native_layout(prepared) == teacher.load_native_layout(prepared)
assert prepared["native_step_limit"] == 1100 and prepared["source"]["layout_id"] == 10
sequence = prepared["source"]["source_sequence"]
assert prepared["source"]["required_accounted_prefix"] == sequence[:sequence.index(10)]
assert sequence[sequence.index(10) - 1] == 28
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu_ref = save(D / "migration/CLASSIFY_L10_CACHE_BINDING_CPU_001.json", {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 5, "task_only_cache_source_equality": True,
    "task_only_prelaunch_source_equality": True, "frozen_nonascending_order_retained": True,
    "actual_configured_loader_passed": True, "actual_teacher_loader_passed": True,
    "model_API_simulator_calls": 0, "source_preparation": ref(preparation),
    "native_budget": 1100, "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "actual_Classify_launch_verified": False,
})
release["runtime_files"].extend(ref(D / "runtime" / name) for name in (
    "policy_cache_seed_classify_h20_v1.py", "prelaunch_classify_policy_cache_h20_v1.py",
    "publish_classify_release030_cpu_v1.py",
))
release.update(
    at=at, prior_classify_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_classify_policy_cache_h20_v1.py"),
    classify_cache_cpu=cpu_ref, actual_adoption=False,
    change_scope="Classify L10/native1100 task and run binding only. Preserve collector11, "
                 "Native8, writable compiled cache, content/RNG/readers, model, RTX and timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_030.json", release)
print(json.dumps({"release": output, "CPU": cpu_ref, "actual_adoption": False}))
