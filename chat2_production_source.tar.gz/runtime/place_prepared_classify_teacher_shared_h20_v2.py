"""Existing Classify1100 teacher storage placement, restricted to L10."""
from pathlib import Path

path = Path(__file__).with_name("place_prepared_classify_teacher_shared_h20_v1.py")
text = path.read_text()
old = "c2_classify_objects_l(24)_evo_common_teacher_(0001)_01a16807"
new = "c2_classify_objects_l(10)_evo_common_teacher_(0001)_01a16807"
assert text.count(old) == 1
exec(compile(text.replace(old, new, 1), __file__ + "::Classify10_teacher_metadata_only",
             "exec"), globals())
