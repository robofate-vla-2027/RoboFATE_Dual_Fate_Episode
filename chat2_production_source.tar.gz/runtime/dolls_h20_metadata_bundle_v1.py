"""Small byte-pinned bookkeeping input, never a remote ledger transaction."""
import base64
import datetime
import hashlib
import json
from pathlib import Path

import h20_runtime_binding_v1 as host

host.host()
T = host.A.parent
root = host.A / "task_sources/sort_nesting_dolls_by_size"
paths = [root / "METADATA_001.json", root / "SPLIT_MANIFEST_001.json"]
paths += [root / f"SPLIT_APPEND_L{i}_001.json" for i in range(7, 16)]
paths += [
    root / "PREPARATION_L15_CONFIGURED_001.json",
    T / "preparations/DOLLS_SOURCE_REGISTRATION_CPU_001.json",
    T / "preparations/DOLLS_L15_SOURCE_REGISTRATION_PREPARATION_001.json",
    host.D / "migration/DOLLS_L15_PREPARATION_CPU_001.json",
]
paths += [T / f"runs/c2_general_pickup_l{i}_common_baseline_0001_01a16807/MAIN_SETTLEMENT_001.json"
          for i in (21, 22, 23, 24)]
paths += [host.D / "teacher/runs/c2_general_pickup_l25_h20_baseline_0001_01a16807/MAIN_SETTLEMENT_001.json"]


def packet(path):
    assert path.resolve() == path and path.is_file()
    raw = path.read_bytes()
    assert 0 < len(raw) < 1024**2
    return {"ref": {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()},
            "raw_b64": base64.b64encode(raw).decode()}


bundle = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "data_kind": "bookkeeping_metadata_only",
    "execution_owner": host.OWNER,
    "documents": [packet(path) for path in paths],
    "registration_helper": packet(T / "preparations/dolls_source_registration_20261030.py"),
    "registration_archive": packet(T / "preparations/MAIN_DOLLS_APPEND_METADATA_HELPERS_20261030_2113_002.json"),
    "historical_source_bytes_unchanged": True,
    "RGB_actions_models_included": False,
    "ledger_included": False, "ledger_modified": False,
}
path = host.D / "migration/DOLLS_L15_BOOKKEEPING_METADATA_001.json"
with path.open("x") as stream:
    json.dump(bundle, stream, separators=(",", ":"))
    stream.write("\n")
print(json.dumps(bundle, separators=(",", ":")))
