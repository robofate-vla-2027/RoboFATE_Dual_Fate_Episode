"""Original metadata-only observer for Organize L26 and matched baseline037."""
from pathlib import Path

path = Path(__file__).with_name("observe_organize_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_organize_table_l25_h20_baseline_0026_01a16807",
     "c2_organize_table_l26_h20_baseline_0027_01a16807"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_033.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_037.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Organize26_metadata_only", "exec"), globals())
