"""Original context binder for prepared Play L19 and paired baseline038."""
from pathlib import Path

path = Path(__file__).with_name("bind_reserved_conveyor_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807",
     "c2_play_stacking_toy_l19_h20_baseline_0020_01a16807"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_034.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::Play19_release038", "exec"), globals())

