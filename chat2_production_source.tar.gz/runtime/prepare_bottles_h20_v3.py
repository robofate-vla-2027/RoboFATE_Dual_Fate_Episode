"""The same frozen source preparer, bound to Bottles L35."""
from prepare_bottles_h20_v2 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ("assert index == 34", "assert index == 35"),
        ("SPLIT_APPEND_L33_001.json", "SPLIT_APPEND_L34_001.json"),
        ("list(range(35))", "list(range(36))"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L35_same_preparer", "exec"), globals())
