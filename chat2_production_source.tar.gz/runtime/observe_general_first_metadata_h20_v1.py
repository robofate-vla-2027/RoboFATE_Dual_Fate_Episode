"""Existing partial metadata observer for General200 and paired release032."""
from pathlib import Path

path = Path(__file__).with_name("observe_fasten_first_metadata_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_fasten_screws_l7_h20_baseline_0001_01a16807",
     "c2_general_pickup_l31_h20_baseline_0001_01a16807"),
    ('start["native_budget"] == 1900', 'start["native_budget"] == 200'),
    ("native_total=1900", "native_total=200"),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_029.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261108_032.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::General31_metadata_only", "exec"), globals())
