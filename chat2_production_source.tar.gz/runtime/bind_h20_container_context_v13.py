"""Original verified metadata decoder with the paired diagnostic-only entry."""
from pathlib import Path

path = Path(__file__).with_name("bind_h20_container_context_v12.py")
text = path.read_text()
old = "text = path.read_text()"
assert text.count(old) == 1
text = text.replace(old, old + """
assert text.count("h20_container_binding_v9") == 1
assert text.count("collect_h20_container_v10") == 1
text = text.replace("h20_container_binding_v9", "h20_container_binding_v10", 1)
text = text.replace("collect_h20_container_v10", "collect_h20_container_v11", 1)
""", 1)
exec(compile(text, str(path) + "::diagnostic_entry_binding", "exec"), globals())

