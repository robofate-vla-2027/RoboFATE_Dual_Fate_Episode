"""Use the proven release013 storage bindings for the unchanged content teacher."""
from pathlib import Path

path = Path(__file__).with_name("h20_teacher_storage_v1.py")
text = path.read_text()
old = "import h20_container_binding_v3 as execution"
assert text.count(old) == 1
text = text.replace(old, "import h20_container_binding_v7 as execution")
exec(compile(text, str(path) + "::release013_storage", "exec"), globals())
