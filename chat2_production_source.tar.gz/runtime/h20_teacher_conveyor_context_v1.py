"""Extend only Conveyor's source-context path to the private H20 run root."""
from copy import deepcopy
from pathlib import Path
import re


def read_context(context, source, run_root, owner):
    pin = context["source_context_ref"]
    path = Path(pin["path"])
    if path.is_relative_to(source.sequence.PROJECT):
        return source.read_ref(pin)
    need = source.need
    need(context["execution_owner"] == owner, "Foreign teacher execution owner")
    need(path.is_absolute() and ".." not in path.parts and path.resolve() == path,
         "Noncanonical teacher source context")
    need(path.name == "CONTEXT_001.json" and path.parent.parent == run_root,
         "Foreign teacher source context")
    need(re.fullmatch(
        r"c2_pick_from_conveyor_by_image_l[0-9]+_h20_baseline_[0-9]{4}_01a16807",
        path.parent.name) is not None, "Foreign Conveyor source run")
    raw = source.read_ref(pin, expected_path=path)
    data = source.original.decode(raw)
    need(data["run_id"] == path.parent.name and data["run_dir"] == str(path.parent),
         "Source context/run path differs")
    need(data["execution_owner"] == owner
         and data["source_owner"] == context["source_owner"],
         "Source context ownership differs")
    return raw


def install(module, run_root, owner):
    original = module.validate
    extension = module.extension
    source = extension.source

    def validate(context):
        if context["task"] != extension.TASK:
            return original(context)
        source.need(type(context["native_limit"]) is int and context["native_limit"] == 700,
                    "Teacher Conveyor700 budget differs")
        data = source.original.decode(read_context(context, source, run_root, owner))
        source.need(data["task"] == context["task"]
                    and data["source_id"] == context["source_id"]
                    and data["native_total_steps"] == context["native_limit"],
                    "Teacher/source extension identity differs")
        source.need(extension.verify(data) is not None, "Original Conveyor extension pins missing")
        bound = deepcopy(data)
        bound["run_dir"] = context["run_dir"]
        return bound

    module.validate = validate
    return validate
