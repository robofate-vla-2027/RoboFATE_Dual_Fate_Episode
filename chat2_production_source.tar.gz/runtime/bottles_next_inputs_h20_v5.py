"""Same successful-predecessor boundary for original Bottles L35."""
from bottles_next_inputs_h20_v4 import source as previous_source


def source():
    text = previous_source()
    assert text.count("index == 34") == 1
    return text.replace("index == 34", "index == 35", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L35_after_DM_success", "exec"), globals())
