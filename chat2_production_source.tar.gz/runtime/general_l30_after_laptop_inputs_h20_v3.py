"""Match the saved L29 native-startup interruption schema precisely."""
from general_l30_after_laptop_inputs_h20_v2 import source as previous_source


def source():
    text = previous_source()
    old = '"refate.actual_interrupted_baseline.v1"'
    assert text.count(old) == 1
    return text.replace(old, '"refate.actual_native_startup_interruption.v1"', 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L29_saved_startup_interruption", "exec"), globals())
