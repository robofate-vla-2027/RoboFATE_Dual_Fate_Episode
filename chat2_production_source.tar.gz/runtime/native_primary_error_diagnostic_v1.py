"""Preserve the active primary exception when the original final reset also fails."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import traceback


def reset_preserving_primary(client, scope, run):
    primary = sys.exc_info()[1]
    try:
        return client.call(func_name="reset_evaluation", obs=scope)
    except BaseException as cleanup:
        if primary is None:
            raise
        value = {
            "primary_type": type(primary).__name__, "primary_error": str(primary),
            "cleanup_type": type(cleanup).__name__, "cleanup_error": str(cleanup),
            "cleanup_traceback": traceback.format_exc(),
            "normal_shutdown_claimed": False, "primary_rethrown": True,
        }
        try:
            with (run / "final_reset_secondary_error.json").open("x") as stream:
                json.dump(value, stream, indent=2)
                stream.write("\n")
        except BaseException as diagnostic_error:
            print("Secondary-error diagnostic write failed: " + repr(diagnostic_error), file=sys.stderr)
            traceback.print_exception(type(cleanup), cleanup, cleanup.__traceback__, file=sys.stderr)


def bind_loop(original, raw, filename, run):
    tree = ast.parse(raw)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "eval_one_episode")
    text = ast.get_source_segment(raw.decode(), node)
    old = '    finally:\n        model_client.call(func_name="reset_evaluation", obs=scope)'
    assert text.count(old) == 1
    text = text.replace(old, "    finally:\n        _refate_final_reset(model_client, scope)", 1)
    namespace = dict(original.__globals__)
    namespace["_refate_final_reset"] = lambda client, scope: reset_preserving_primary(client, scope, run)
    exec(compile(text, str(filename) + "::preserve_primary_error", "exec"), namespace)
    return namespace["eval_one_episode"]


def install(baseline, run):
    original_loader = baseline.original_dm_loop

    def load_loop():
        original = original_loader()
        raw = baseline.node.pinned(baseline.DEPLOY, baseline.DEPLOY_SHA)
        result = bind_loop(original, raw, baseline.DEPLOY, run)
        value = {
            "original_deploy": {"path": str(baseline.DEPLOY), "sha256": baseline.DEPLOY_SHA},
            "diagnostic_helper": {"path": str(Path(__file__)),
                                  "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
            "change": "Preserve primary error if the unchanged final reset also fails",
            "actions_or_resets_added": False, "request_timeout_changed": False,
            "policy_or_native_budget_changed": False, "retries_added": False,
        }
        with (run / "PRIMARY_ERROR_DIAGNOSTIC_ADOPTION_001.json").open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
        return result

    baseline.original_dm_loop = load_loop

