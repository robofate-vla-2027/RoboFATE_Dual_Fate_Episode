"""ICD symbol loading only: no Vulkan instance, device, queue or simulator."""
import ctypes as c,json
from pathlib import Path
lib=c.CDLL('libGLX_nvidia.so.0')
f=lib.vk_icdGetInstanceProcAddr;f.argtypes=[c.c_void_p,c.c_char_p];f.restype=c.c_void_p
v={x:bool(f(None,x.encode())) for x in ('vkCreateInstance','vkEnumerateInstanceExtensionProperties','vkEnumerateInstanceVersion')}
v['loaded_nvidia_paths']=sorted({x.split()[-1] for x in Path('/proc/self/maps').read_text().splitlines() if 'libnvidia' in x or 'libGLX_nvidia' in x})
print(json.dumps(v))
