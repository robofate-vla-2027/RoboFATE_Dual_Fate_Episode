"""Same real first-segment checks, paired with cache-placement release027."""
from pathlib import Path

path = Path(__file__).with_name("observe_sweep_first_metadata_h20_v1.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261108_026.json"
assert text.count(old) == 1
exec(compile(text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261108_027.json"),
             __file__ + "::cache_placement_release027", "exec"), globals())
