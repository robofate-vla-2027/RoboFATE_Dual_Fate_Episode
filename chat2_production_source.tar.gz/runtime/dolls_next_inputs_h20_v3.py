"""Original Dolls boundary checks with the already adopted release017."""
import dolls_next_inputs_h20_v2 as previous

teacher_checks = previous.teacher_checks


def source():
    text = previous.source()
    for old, new in (
        ("import h20_container_binding_v7 as execution",
         "import h20_container_binding_v9 as execution"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261106_013.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"),
    ):
        assert text.count(old) == 1
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::release017_only", "exec"), globals())
