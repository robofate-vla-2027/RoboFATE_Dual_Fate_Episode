"""Freeze only the relocated Conveyor dependency and matching chat2 entries."""
import copy
import datetime
import hashlib
import json
from pathlib import Path

import h20_container_binding_v5 as binding

D, A = binding.D, binding.A


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, data):
    raw = (json.dumps(data, indent=2) + "\n").encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, str(path)
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path)


original = json.loads((A / "NATIVE_EXTENSION_PINS_001.json").read_bytes())
pin = copy.deepcopy(original)
root = binding.extensions.ROOT
for entry, suffix in zip(pin["files"], (
        "config/extension.toml", "bin/libisaacsim.asset.gen.conveyor.plugin.so")):
    entry["path"] = str(root / suffix)
    assert ref(root / suffix)["sha256"] == entry["sha256"]
pin_ref = save(binding.extensions.HERE / "NATIVE_EXTENSION_PINS_001.json", pin)
context = {
    "task": "pick_from_conveyor_by_image", "native_total_steps": 700,
    "native_kit_extensions": ["isaacsim.asset.gen.conveyor"],
    "native_extension_pins": pin_ref,
}
assert binding.extensions.verify(context) == pin_ref
import collect_h20_container_v5 as collector
assert collector.original.core.foreground is binding.foreground
assert collector.original.core.finish is binding.finish
assert "native_h20_container_v3.py" in binding._text
receipt = {
    "schema": "refate.h20.conveyor_extension_cpu.v1",
    "data_kind": "offline_cpu_binding_check_not_scientific_data",
    "pin": pin_ref, "same_original_file_hashes": True,
    "baseline_foreground_bound": True, "matching_native_entry_bound": True,
    "real_model_api_native_calls": False, "qualified_samples": 0,
}
cpu_ref = save(D / "migration/CONVEYOR_EXTENSION_CPU_001.json", receipt)
prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_009.json"
release = json.loads(prior.read_bytes())
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    foreground_entry=str(D / "runtime/collect_h20_container_v5.py"),
    native_entry=str(D / "runtime/native_h20_container_v3.py"),
    context_builder=ref(D / "runtime/bind_h20_container_context_v5.py"),
    prior_migration_release=ref(prior), cpu_check=cpu_ref,
    native_extension_pins=pin_ref,
    binding_fix="Path-only binding of byte-identical Conveyor1.0.23 extension. "
                "Original extension checks and enable flag retained; no shared edits.",
    actual_adoption=False,
)
files = {row["path"]: row for row in release["runtime_files"]}
for name in ("h20_container_binding_v5.py", "native_h20_container_v3.py",
             "collect_h20_container_v5.py", "bind_h20_container_context_v5.py",
             "freeze_conveyor_h20_v1.py"):
    item = ref(D / "runtime" / name)
    files[item["path"]] = item
files[pin_ref["path"]] = pin_ref
release["runtime_files"] = list(files.values())
output = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261106_010.json"
assert not output.exists(), "Inspect already frozen release; do not replace it"
result = save(output, release)
print(json.dumps({"release": result, "cpu_check": cpu_ref, "extension_pin": pin_ref}))
