"""Existing writable compiled cache, bound only to original General200."""
from policy_cache_seed_fasten_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "fasten_screws"', 'context["task"] == "general_pickup"'),
        ('context["native_total_steps"] == 1900', 'context["native_total_steps"] == 200'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::General200_cache_only", "exec"), namespace)
    return namespace["install"](run)
