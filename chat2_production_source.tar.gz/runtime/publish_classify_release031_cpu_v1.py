"""Offline L51 run-binding checks; no model, network, simulator or ledger calls."""
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys


def deny_live(event, args):
    if (event.startswith(("socket.", "subprocess.")) and event != "socket.gethostname") or event in (
        "os.system", "os.exec", "os.posix_spawn", "os.fork", "os.kill", "os.killpg",
    ):
        raise RuntimeError("Offline binding check attempted a live external effect")


sys.addaudithook(deny_live)
import h20_teacher_binding_v14 as runtime
import prelaunch_classify_policy_cache_h20_v1 as previous
import prelaunch_classify_policy_cache_h20_v2 as current
import task_configured_binding as configured
import teacher_catalog_sweep_h20_v1 as teacher

runtime.execution.previous.host()
D = runtime.execution.previous.D


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


prior = D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_030.json"
assert ref(prior)["sha256"] == "6db925692df011ba4cc0ae511dc97279020894aaaf2b49977f9fa0e5a84bdc80"
assert current.source() == previous.source().replace(
    "c2_classify_objects_l10_h20_baseline_0001_01a16807",
    "c2_classify_objects_l51_h20_baseline_0001_01a16807", 1)
compile(current.source(), "offline_L51_prelaunch_source", "exec")
preparation = runtime.execution.A / "task_sources/classify_objects/PREPARATION_L51_CONFIGURED_001.json"
assert ref(preparation)["sha256"] == "2d56c2b071b12a9ae2e38cd56c54933954ca712fdeb8460a19b6b4ba3801a453"
prepared = json.loads(preparation.read_bytes())
assert configured.load_native_layout(prepared) == teacher.load_native_layout(prepared)
assert prepared["native_step_limit"] == 1100 and prepared["source"]["layout_id"] == 51
sequence = prepared["source"]["source_sequence"]
assert prepared["source"]["required_accounted_prefix"] == sequence[:sequence.index(51)]
assert sequence[sequence.index(51) - 1] == 10
release = deepcopy(json.loads(prior.read_bytes()))
assert (release["native_wall_seconds"], release["teacher_wall_seconds"]) == (2400, 3600)
assert release["cuda_visible_devices"] == "1,7" and release["physical_gpus"] == [1, 7]
assert release["foreground_entry"].endswith("/collect_h20_container_v11.py")
assert release["native_entry"].endswith("/native_h20_container_v8.py")
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
cpu = save(D / "migration/CLASSIFY_L51_CACHE_BINDING_CPU_001.json", {
    "at": at, "data_kind": "offline_CPU_binding_checks_not_scientific_data",
    "checks_passed": 5, "run_only_prelaunch_source_equality": True,
    "frozen_nonascending_order_retained": True,
    "actual_configured_loader_passed": True, "actual_teacher_loader_passed": True,
    "model_API_simulator_calls": 0, "source_preparation": ref(preparation),
    "native_budget": 1100, "baseline_wall_seconds": 2400, "teacher_wall_seconds": 3600,
    "actual_Classify_L51_launch_verified": False, "reservation_or_launch_authority": False,
})
release["runtime_files"].extend(ref(D / "runtime" / name) for name in (
    "prelaunch_classify_policy_cache_h20_v2.py", "publish_classify_release031_cpu_v1.py",
))
release.update(
    at=at, prior_classify_runtime_release=ref(prior),
    prelaunch_entry=str(D / "runtime/prelaunch_classify_policy_cache_h20_v2.py"),
    classify_cache_cpu=cpu, actual_adoption=False,
    change_scope="Classify L51 run binding only. Preserve collector11, Native8, writable "
                 "compiled cache, content/RNG/readers, model, RTX, native1100 and timeouts.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_031.json", release)
print(json.dumps({"release": output, "CPU": cpu, "actual_adoption": False}))
