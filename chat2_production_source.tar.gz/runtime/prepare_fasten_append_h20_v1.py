"""Append one Fasten source using its frozen family rule and configured core."""
import ast
from copy import deepcopy
import datetime
import hashlib
import json
from pathlib import Path
import sys

TASK = "fasten_screws"
NORMALIZER_SHA = "a9a196b944d2892ee4d2c14fb420561441e2e8c0e00706d6fa9f2f49627239cd"
ORIGINAL_SHA = "26e60fc4129aab79900cf7ea9a8a7f225a9cc6193e379231cbfa13cea78ade29"


def merge(prior, row, prior_ref, at, helper_ref):
    out = deepcopy(prior)
    sequence = prior["initial_source_sequence"]
    index = row["layout_id"]
    assert prior["task"] == TASK
    assert sequence == list(range(len(sequence)))
    assert type(index) is int and index == len(sequence) and 7 <= index < 53
    assert prior["original_partition"]["reserved_final"] == [53, 54]
    assert row["native_bank"] == 0 and row["initialization_distinct_from_preceding"]
    assert row["initialization_content_sha256"] not in {
        value["initialization_content_sha256"] for value in prior["layouts"].values()}
    assert index in prior["unadmitted_layouts"]
    group = row["group_id"]
    assert group.startswith(TASK + "/paired_asset_family/")
    family = prior["families"].get(group)
    assert row["split"] == (family["split"] if family else "student_train")
    assert row["split"] in ("student_train", "student_dev")
    out["initial_source_sequence"] = sequence + [index]
    out["unadmitted_layouts"] = [i for i in prior["unadmitted_layouts"] if i != index]
    out["layouts"][str(index)] = deepcopy(row)
    out["layout_to_group"][str(index)] = group
    if family is None:
        out["families"][group] = {
            "group_id": group, "canonical_structure_sha256": group.rsplit("/", 1)[1],
            "split": "student_train", "layouts": [],
            "use_history": "New collection member; global exposure not certified",
            "independent_eval_eligibility": "not_claimed_clean",
        }
    out["families"][group]["layouts"].append({
        "bank": 0, "layout_id": index, **deepcopy(row["layout_ref"])})
    out["collection_append"] = {
        "schema": "refate.fasten.configured_source_append.v1", "at": at,
        "prior_split": deepcopy(prior_ref), "added_layout": index,
        "prior_sequence": deepcopy(sequence), "source_partition": row["split"],
        "new_family_registered": family is None,
        "original_memberships_modified": False, "sealed_content_read": False,
        "independent_development_claimed": False, "independent_evaluation_claimed": False,
        "outcome_used": False, "metadata_helper": deepcopy(helper_ref),
        "normalization_code": deepcopy(prior["normalization_code"]),
    }
    return out


def deny_live(event, args):
    if event in {"socket.__new__", "subprocess.Popen", "os.system", "os.posix_spawn",
                 "os.kill", "os.killpg"}:
        raise RuntimeError("CPU metadata only; no live peers, models or processes")


def main():
    sys.addaudithook(deny_live)
    import h20_teacher_binding_v14 as runtime
    from h20_insert_private_metadata_v1 import metadata_locations
    import task_configured_binding as configured
    import source_binding as source

    execution = runtime.execution
    host = execution.previous
    host.host()
    index = int(sys.argv[1])
    assert index == 7, "Only the next original Fasten source is prepared here"
    root = execution.A / "task_sources" / TASK
    previous_path = root / "SPLIT_LEGACY_VIEW_L6_001.json"
    split_path = root / "SPLIT_APPEND_L7_001.json"
    prep_path = root / "PREPARATION_L7_CONFIGURED_001.json"
    receipt_path = host.D / "migration/FASTEN_L7_PREPARATION_CPU_001.json"
    assert not any(p.exists() for p in (split_path, prep_path, receipt_path)), (
        "Inspect and reuse any existing preparation; never overwrite")

    def ref(path):
        return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

    def read(pin):
        raw = Path(pin["path"]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
        return metadata_locations(json.loads(raw))

    def save(path, value):
        with path.open("x") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
        return ref(path)

    previous_ref = ref(previous_path)
    prior = read(previous_ref)
    original_ref = prior["metadata_projection"]["original_manifest"]
    assert original_ref["sha256"] == ORIGINAL_SHA
    original = read(original_ref)
    assert prior["initial_source_sequence"] == original["initial_source_sequence"] == list(range(7))
    assert prior["layout_to_group"] == original["layout_to_group"]
    assert prior["families"] == original["families"]
    assert prior["normalization_code"]["sha256"] == NORMALIZER_SHA
    normalization = Path(prior["normalization_code"]["path"]).read_bytes()
    assert hashlib.sha256(normalization).hexdigest() == NORMALIZER_SHA
    functions = [n for n in ast.parse(normalization).body
                 if isinstance(n, ast.FunctionDef) and n.name in {"canonical", "family"}]
    assert {n.name for n in functions} == {"canonical", "family"}
    import copy
    scope = {"copy": copy, "json": json}
    exec(compile(ast.Module(body=functions, type_ignores=[]),
                 str(prior["normalization_code"]["path"]) + "::pure_family_only", "exec"), scope)
    layout_path = execution.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/{TASK}_{index}.json"
    raw = layout_path.read_bytes()
    layout = json.loads(raw)
    family_hash = hashlib.sha256(scope["canonical"](scope["family"](layout))).hexdigest()
    group = TASK + "/paired_asset_family/" + family_hash
    row = {
        "layout_id": index, "native_bank": 0, "layout_ref": ref(layout_path),
        "initialization_content_sha256":
            hashlib.sha256(source.canonical(layout).encode()).hexdigest(),
        "initialization_distinct_from_preceding": True, "group_id": group,
        "split": prior["families"].get(group, {}).get("split", "student_train"),
    }
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    projected = merge(prior, row, previous_ref, at, ref(Path(__file__)))
    assert all(projected["layouts"][str(i)] == prior["layouts"][str(i)] for i in range(7))
    assert projected["families"][prior["layout_to_group"]["5"]]["split"] == "student_dev"
    assert projected["layout_to_group"]["3"] == projected["layout_to_group"]["6"]
    split_ref = save(split_path, projected)
    prepared, actual = configured.prepare_source(
        task=TASK, layout_id=index, split_ref=split_ref, native_total=1900,
        task_ref=prior["native_task_code"])
    assert configured.load_native_layout(prepared) == actual == layout
    assert layout_path.read_bytes() == raw
    assert prepared["source"]["source_sequence"] == list(range(8))
    assert prepared["source"]["required_accounted_prefix"] == list(range(7))
    prep_ref = save(prep_path, prepared)
    assert ref(previous_path) == previous_ref
    assert ref(Path(original_ref["path"])) == original_ref
    receipt = {
        "schema": "refate.actual_metadata_preparation.v1",
        "data_kind": "actual_source_metadata_not_execution", "at": at,
        "execution_owner": host.OWNER, "task": TASK, "native_total": 1900,
        "source_id": prepared["source"]["source_id"], "preparation_ref": prep_ref,
        "split_ref": split_ref, "prior_manifest": previous_ref,
        "original_manifest": original_ref, "normalization_code": prior["normalization_code"],
        "source_sequence": list(range(8)), "required_accounted_prefix": list(range(7)),
        "group_id": group, "split": row["split"],
        "actual_configured_loader_passed": True, "raw_layout_unchanged": True,
        "existing_family_memberships_unchanged": True, "original_manifest_unchanged": True,
        "sealed_layouts": [53, 54], "sealed_content_read": False,
        "native_started": False, "source_registered": False, "source_reserved": False,
        "model_calls": 0, "runtime_files_modified": False,
        "preparation_helper": ref(Path(__file__)),
    }
    receipt_ref = save(receipt_path, receipt)
    print(json.dumps({**receipt, "receipt_ref": receipt_ref}))


if __name__ == "__main__":
    main()
