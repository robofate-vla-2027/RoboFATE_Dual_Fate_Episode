"""Use the guard-only launcher derived from the exact frozen remote bytes."""
from pathlib import Path

path = Path(__file__).with_name("publish_swap_release025_cpu_v1.py")
text = path.read_text()
assert text.count("launch_container_v4.sh") == 3
text = text.replace("launch_container_v4.sh", "launch_container_v5.sh")
exec(compile(text, __file__ + "::exact_remote_launcher_origin", "exec"), globals())
