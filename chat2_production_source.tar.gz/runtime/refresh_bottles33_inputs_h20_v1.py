"""Refresh admission for prepared L33; never recreate a source or reset clocks."""
from bottles_next_inputs_h20_v3 import source

text = source()
for old, new in (
    ('assert mode in ("check", "inputs") and index == 33',
     'assert mode == "inputs" and index == 33'),
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", "RESOURCE_PRECHECK_002.json"),
    ("MAIN_BOUNDARY_001.json", "MAIN_BOUNDARY_002.json"),
    ("BOUNDARY_INPUTS_001.json", "BOUNDARY_INPUTS_002.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)

if __name__ == "__main__":
    exec(compile(text, __file__ + "::same_unstarted_source", "exec"), globals())
