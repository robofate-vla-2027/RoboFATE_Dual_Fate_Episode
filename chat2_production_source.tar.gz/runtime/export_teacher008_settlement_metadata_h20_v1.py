"""Export existing accounting documents through the matched teacher008 binding."""
from pathlib import Path

path = Path(__file__).with_name("export_teacher_settlement_metadata_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v3") == 1
text = text.replace("h20_teacher_binding_v3", "h20_teacher_binding_v8")
exec(compile(text, str(path) + "::teacher008", "exec"), globals())
