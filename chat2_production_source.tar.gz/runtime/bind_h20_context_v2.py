"""Original context binder with a separate logical role and execution target."""
import h20_runtime_binding_v1 as binding
import collect_h20_v1
import bind_recording_content_v1 as previous
text = previous.text
text = binding.edit(text,
    "dispatch.get('host') == 'perdon-hou' and dispatch.get('expected_hostname') == 'nb-5pl2apckdj-0'",
    "dispatch.get('host') == 'perdon-hou' and dispatch.get('execution_ssh_alias') == 'h20_8' and dispatch.get('expected_hostname') == '20250103-instance'")
text = binding.edit(text,"str(stage.HERE / 'collect_recording_content_v1.py')",
                    repr(str(binding.D/'runtime/collect_h20_v1.py')))
text = binding.edit(text, "import collect_recording_content_v1 as collection\n", "import collect_recording_content_v1 as collection\ncollection.core.foreground = binding.foreground\ncollection.core.finish = binding.finish\n")
text = binding.edit(text, "Path(dispatch_ref['path']) == run / 'DISPATCH_001.json'", "Path(dispatch_ref['path']) in (run / 'DISPATCH_001.json', run / 'DISPATCH_BINDING_RENEWAL_001.json')")
exec(compile(text,str(binding.D/'runtime/bind_h20_context_v2.py')+'::original_binder','exec'),globals())
