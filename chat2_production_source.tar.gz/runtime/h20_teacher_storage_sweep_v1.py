"""Preserve existing content rules, changing only the task catalog import."""
import types
from h20_teacher_storage_swap_v1 import *
import h20_teacher_storage_swap_v1 as previous
import teacher_catalog_sweep_h20_v1 as teacher_catalog_binding_v14

for _name, _count in (("native_teacher_content_v6", 3),
                      ("collect_teacher_content_v6", 1),
                      ("prepare_teacher_content_v6", 2)):
    _old = getattr(previous, _name)
    assert _old.text.count("teacher_catalog_swap_h20_v1") == _count
    _module = types.ModuleType("_refate_sweep_" + _name)
    _module.__dict__.update(_old.__dict__)
    _module.text = _old.text.replace("teacher_catalog_swap_h20_v1",
                                    "teacher_catalog_sweep_h20_v1")
    globals()[_name] = _module
