"""Run the same chat2 pipeline in compatible libc, with only physical GPUs1/7."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import h20_runtime_binding_v1 as previous
from h20_runtime_binding_v1 import D, A, B, NATIVE, UUIDS, OWNER, stage, node, edit, need, host


def allocation():
    host()
    need(os.environ.get('NVIDIA_VISIBLE_DEVICES') == ','.join(UUIDS), 'Exact container GPU UUID allowlist required')
    text = subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total,utilization.gpu','--format=csv,noheader,nounits'],text=True)
    rows = [[part.strip() for part in row.split(',')] for row in text.splitlines()]
    need(len(rows)==2 and [row[1] for row in rows]==list(UUIDS)
         and [int(row[0]) for row in rows]==[0,1], 'Container GPU enumeration is not the authorized pair')
    need(int(rows[0][2])>=45000 and int(rows[1][2])>=35000, 'Insufficient authorized GPU headroom')
    assignments={k:v for k,v in os.environ.items() if k.startswith(('SLURM_','PBS_','LSB_'))}
    for key in ('SLURM_STEP_GPUS','SLURM_JOB_GPUS'):
        if key in assignments:need({'1','7'}.issubset(set(assignments[key].split(','))), 'Scheduler allocation does not cover physical1/7')
    need(not any(k in assignments for k in ('PBS_JOBID','LSB_JOBID')), 'Unverified scheduler allocation')
    return {'gpu_rows':text,'authorized_physical_gpus':[1,7],
            'container_cuda_to_physical':{'0':1,'1':7},'gpu_uuids':list(UUIDS),
            'vulkan_requested_container_gpu':1,'vulkan_requested_physical_gpu':7,
            'scheduler_environment':assignments,'peer_processes_are_not_managed':True}


def make_app(launcher,args):
    allocation()
    class BoundLauncher(launcher):
        def _create_app(self):
            self._sim_app_config.update(active_gpu=1,physics_gpu=1,multi_gpu=False)
            return super()._create_app()
    return BoundLauncher(args,multi_gpu=False,active_gpu=1,physics_gpu=1,
                         fast_shutdown=True,renderer='RaytracedLighting')


node._h20_make_app=make_app
_text=Path(node.__file__).read_text()
_text=edit(_text,"namespace = dict(module.__dict__, _node_adjust_config=_adjust_config, _node_prepare_native=_prepare_native)",
           "namespace = dict(module.__dict__, _node_adjust_config=_adjust_config, _node_prepare_native=_prepare_native, _h20_make_app=_h20_make_app)")
_function=next(n for n in ast.parse(_text).body if isinstance(n,ast.FunctionDef) and n.name=='install')
exec(compile(ast.Module(body=[_function],type_ignores=[]),str(D/'runtime/native_container_install.py'),'exec'),node.__dict__)
_verify=node.verify_initial

def verify_initial(task,preparation):
    value=_verify(task,preparation)
    value.update(physical_policy_gpu=1,physical_simulation_gpu=7,
                 container_cuda_to_physical={'0':1,'1':7},authorized_gpu_uuids=list(UUIDS))
    return value

node.verify_initial=verify_initial
import common_recording as recording
import common_recording_content_v2 as content
_text=Path(recording.__file__).read_text()
_function=next(n for n in ast.parse(_text).body if isinstance(n,ast.FunctionDef) and n.name=='initialize_recording')
exec(compile(ast.Module(body=[_function],type_ignores=[]),str(D/'runtime/container_camera_device_check.py'),'exec'),recording.__dict__)
content.initialize_recording=recording.initialize_recording
baseline_module=previous.baseline_module
finish=previous.finish


def environment(run,reference):
    policy,native=previous.environment(run,reference)
    policy['CUDA_VISIBLE_DEVICES']='0'
    native['CUDA_VISIBLE_DEVICES']='0,1'
    native['CUDA_HOME']='/usr/local/cuda-12.5'
    native['LD_PRELOAD']='/mnt/demottt_h20_8_eval_20261012_isaac/lib/libstdc++.so.6'
    native['PATH']='/usr/local/cuda-12.5/bin:'+native['PATH']
    return policy,native


_text=previous.foreground_source
_text=edit(_text,str(D/'runtime/native_h20_v1.py'),str(D/'runtime/native_h20_container_v1.py'))
_text=edit(_text,hashlib.sha256((D/'runtime/policy_h20_v1.py').read_bytes()).hexdigest(),
           hashlib.sha256((D/'runtime/policy_h20_container_v1.py').read_bytes()).hexdigest())
foreground=previous.load_source('_refate_h20_container_foreground',_text)
foreground.host=host
foreground.allocation=allocation
foreground.environment=environment
foreground.helpers=previous.helpers
foreground.POLICY=D/'runtime/policy_h20_container_v1.py'
foreground.CONFIG=D/'runtime/policy_h20_v1.yaml'
foreground.POLICY_PYTHON=previous.POLICY_ENV/'bin/python'
foreground.NATIVE_PYTHON=B/'envs/native-thin/bin/python'
foreground.LOCK=D/'runtime/simulator.lock'
