"""Original content-v6 collector with retained Bottles metadata storage."""
import h20_teacher_binding_v8 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())
