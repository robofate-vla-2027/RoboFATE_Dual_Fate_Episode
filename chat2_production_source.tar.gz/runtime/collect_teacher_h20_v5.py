"""Original content-v6 collector with the private-tmp teacher binding."""
import h20_teacher_binding_v5 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())
