"""Original finite owned supervisor with debug logs in a synthetic run only."""
from pathlib import Path
import sys
import h20_runtime_binding_v1 as binding

binding.host()
run = Path(sys.argv[1])
assert run.parent == binding.D / "migration" and run.name.startswith("SYNTHETIC_GVISOR_CPU_")
path = binding.stage.REPAIR / "gvisor_worker.py"
sys.path.insert(0, str(path.parent))
import gvisor_support as support

original = support.prefix
log = run / "debug"
log.mkdir()
support.prefix = lambda target: original(target) + ["--debug", "--debug-log=" + str(log) + "/"]
text = binding.edit(path.read_text(), "socket.gethostname()!='nb-5pl2apckdj-0'",
                    "socket.gethostname()!='20250103-instance'")
exec(compile(text, str(path) + "::synthetic_debug_only", "exec"), globals())

