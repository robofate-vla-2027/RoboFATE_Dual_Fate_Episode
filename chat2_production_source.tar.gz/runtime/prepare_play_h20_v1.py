"""Storage-only wrapper of the original ordered Play metadata preparer."""
import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import sys

import h20_teacher_binding_v5 as runtime
from h20_insert_metadata_binding_v1 import locations
import source_binding as source
import task_family_binding as family

execution = runtime.execution
execution.previous.host()
HISTORICAL = Path("/mnt/workspace/users/maxiangkai/projects/ReFATE")
historical_adapter = HISTORICAL / execution.A.relative_to(execution.previous.PROJECT)


def ref(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def put(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
    return ref(path)


index = int(sys.argv[1])
assert 17 <= index < 53
root = execution.A / "task_sources/play_stacking_toy"
receipt_path = execution.D / f"migration/PLAY_L{index}_PREPARATION_CPU_001.json"
assert not receipt_path.exists(), "Reuse the existing preparation receipt"
assert not (root / f"PREPARATION_L{index}_COLLECTION_GROUP_001.json").exists()
prior_path = root / f"SPLIT_MANIFEST_L{index - 1}_APPEND_001.json"
prior = json.loads(prior_path.read_bytes())
assert prior["initial_source_sequence"] == list(range(index))
assert prior["original_partition"]["reserved_final"] == [53, 54]
assert prior["task"] == "play_stacking_toy"
storage_ref = None
if index == 17:
    assert ref(prior_path)["sha256"] == (
        "88f6e86b750c1f6e06480a9d3120d9d73867d4cdebf537dfd04dc4766d419173")
    mapped = locations(prior)
    assert locations(mapped, inverse=True) == prior
    for row in mapped["layouts"].values():
        assert ref(Path(row["layout_ref"]["path"])) == row["layout_ref"]
    mapped_path = root / "SPLIT_MANIFEST_L16_H20_STORAGE_001.json"
    if mapped_path.exists():
        assert json.loads(mapped_path.read_bytes()) == mapped
    else:
        put(mapped_path, mapped)
    record_path = execution.D / "migration/PLAY_L16_STORAGE_BINDING_001.json"
    record = {
        "schema": "refate.chat2.source_storage_binding.v1",
        "execution_owner": execution.OWNER,
        "logical_node_key": "perdon-hou",
        "execution_ssh_alias": "h20_8",
        "task": prior["task"],
        "historical_manifest": {
            "path": str(historical_adapter / "task_sources/play_stacking_toy" / prior_path.name),
            "sha256": ref(prior_path)["sha256"],
        },
        "byte_identical_original_copy": ref(prior_path),
        "execution_manifest": ref(mapped_path),
        "inverse_mapping_equals_original": True,
        "raw_layout_hashes_match": True,
        "source_sequence_and_groups_unchanged": True,
        "source_started": False,
        "reservation_issued": False,
    }
    if record_path.exists():
        assert json.loads(record_path.read_bytes()) == record
        storage_ref = ref(record_path)
    else:
        storage_ref = put(record_path, record)
    prior_path = mapped_path

layout_path = execution.NATIVE / f"Assets/Eval_Layout/RoboDojo/arx_x5/0/play_stacking_toy_{index}.json"
layout = source.decode(layout_path.read_bytes())
task_path = execution.NATIVE / "task/RoboDojo/tasks/play_stacking_toy.py"
assert ref(task_path)["sha256"] == "23361329ee7efe330da1f1c241415205bafed2b6c082a913659d868a80d338c3"
inputs = {
    "execution_owner": execution.OWNER,
    "layout": index,
    "native_budget": 1200,
    "prior_ref": ref(prior_path),
    "layout_ref": ref(layout_path),
    "task_ref": ref(task_path),
    "new_group": "play_stacking_toy/task_content_family/" + family.family(layout)["content_sha256"],
    "initialization_content_sha256": hashlib.sha256(source.canonical(layout).encode()).hexdigest(),
}
helper = execution.A / "prepare_next_play_handoff_v1.py"
assert ref(helper)["sha256"] == "52b29735191dea73a205ed536c98c2ee0b2b7c5e7b826578b48b510a80d16c20"
text = helper.read_text()
assert text.count(str(historical_adapter)) == 2
text = text.replace(str(historical_adapter), str(execution.A))
sys.stdin = io.StringIO(json.dumps(inputs))
captured = io.StringIO()
with contextlib.redirect_stdout(captured):
    exec(compile(text, str(helper) + "::h20_storage_only", "exec"),
         {"__name__": "__main__", "__file__": str(helper)})
result = json.loads(captured.getvalue())
prepared = json.loads(Path(result["preparation_ref"]["path"]).read_bytes())
import collection_group_binding as baseline
import teacher_catalog_binding_v13 as teacher

assert baseline.load_native_layout(prepared) == teacher.load_native_layout(prepared) == layout
receipt = {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "data_kind": "actual_metadata_CPU_only",
    "preparation": result,
    "storage_binding": storage_ref,
    "execution_binding": ref(Path(__file__)),
    "original_preparer": ref(helper),
    "actual_baseline_metadata_loader_passed": True,
    "actual_teacher_metadata_loader_passed": True,
    "raw_layout_unchanged": True,
    "native_total": 1200,
    "sealed_content_read": False,
    "native_model_API_calls": False,
    "registered": False,
    "reserved": False,
    "launched": False,
}
print(json.dumps({"preparation": result, "storage_binding": storage_ref,
                  "CPU_receipt": put(receipt_path, receipt)}))

