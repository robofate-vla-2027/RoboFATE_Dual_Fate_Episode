"""Reuse the checked bind placement for a new, unbound Stack teacher attempt."""
from pathlib import Path


def source():
    path = Path(__file__).with_name("place_prepared_stack_shared_h20_v1.py")
    text = path.read_text()
    old_checks = '''    assert inputs["run_id"] == run_id and inputs["native_started"] is False
    prepared = inputs["preparation"]
    assert prepared["source"]["task"] == "stack_blocks_by_language"
    assert prepared["source"]["layout_id"] == int(match[1])
    assert prepared["native_step_limit"] == 400
    assert inputs["terminal"]["safe_for_next_simulator"] is True'''
    new_checks = '''    assert inputs["run_id"] == run_id and inputs["teacher_started"] is False
    assert inputs["future_run_files_absent"] is True
    assert inputs["execution_owner"] == binding.OWNER
    assert inputs["task"] == "stack_blocks_by_language" and inputs["layout"] == int(match[1])
    assert inputs["native_limit"] == 400 and inputs["remaining_steps"] == 400 - inputs["t1"]
    terminal = json.loads(binding.read_pin(inputs["current_resource_predecessor"]))
    assert terminal["safe_for_next_simulator"] is True'''
    for old, new in (
        ('NAMES = frozenset(("RESOURCE_PRECHECK_001.json", "BOUNDARY_INPUTS_001.json"))',
         'NAMES = frozenset(("RESOURCE_PRECHECK_001.json", "PREPARATION_METADATA_H20_001.json"))'),
        (r"c2_stack_blocks_by_language_l([2-6])_h20_baseline_(000[3-7])_01a16807",
         r"c2_stack_blocks_by_language_l([2-6])_evo_common_teacher_(0001)_01a16807"),
        ("assert match and int(match[2]) == int(match[1]) + 1",
         "assert match and int(match[2]) == 1"),
        ('inputs = json.loads((run / "BOUNDARY_INPUTS_001.json").read_bytes())',
         'inputs = json.loads((run / "PREPARATION_METADATA_H20_001.json").read_bytes())'),
        (old_checks, new_checks),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::unbound_teacher_metadata_only", "exec"), globals())
