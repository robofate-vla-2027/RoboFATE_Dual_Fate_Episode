"""Refresh admission only for the existing unstarted Conveyor L19 preparation."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_next_inputs_h20_v1.py")
wrapper = path.read_text()
seam = 'exec(compile(text, __file__ + "::Conveyor18_saved_CPU", "exec"), globals())'
assert wrapper.count(seam) == 1
scope = {"__file__": str(path)}
exec(compile(wrapper[:wrapper.index(seam)], str(path) + "::source_only", "exec"), scope)
text = scope["text"]
for old, new in (
    ('mode == "inputs" and index == 18', 'mode == "inputs" and index == 19'),
    ("RUNTIME_H20_CHAT2_CONTENT_20261108_034.json",
     "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", "RESOURCE_PRECHECK_002.json"),
    ("BOUNDARY_INPUTS_001.json", "BOUNDARY_INPUTS_002.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::same_admission_no_repreparation", "exec"), globals())
