"""Original private General cache, expanded and checked before diagnostic launch."""
from pathlib import Path
from prelaunch_general_cache_tmpfs_v2 import source as previous_source


def source():
    text = previous_source()
    old = 'ENTRY = D / "runtime/collect_h20_container_v10.py"'
    assert text.count(old) == 1
    return text.replace(old, 'ENTRY = D / "runtime/collect_h20_container_v11.py"', 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General200_diagnostic_cache", "exec"), globals())

