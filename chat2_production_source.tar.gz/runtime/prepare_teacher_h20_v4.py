"""Prepare one committed dispatch through the matched future entry."""
import argparse
import json
from pathlib import Path
import h20_teacher_binding_v4 as binding

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dispatch", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(binding.preparation.prepare(args.dispatch), indent=2))
