"""Apply the same temporary-directory binding only in a synthetic debug run."""
import json
from pathlib import Path
import sys
import h20_runtime_binding_v1 as binding
from h20_gvisor_tmp_v1 import bind_private_tmp

binding.host()
run = Path(sys.argv[1])
assert run.parent == binding.D / "migration" and run.name.startswith("SYNTHETIC_GVISOR_CPU_")
with (run / "oci/RUNSC_TMP_BINDING_001.json").open("x") as stream:
    json.dump(bind_private_tmp(), stream, indent=2)
path = Path(__file__).with_name("gvisor_worker_h20_debug_cpu_v1.py")
exec(compile(path.read_bytes(), str(path) + "::private_container_tmp", "exec"), globals())
