"""Gather the same admission data with the matched diagnostic release."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_inputs_h20_v1.py")
text = path.read_text()
old = "RUNTIME_H20_CHAT2_CONTENT_20261106_010.json"
assert text.count(old) == 1
text = text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261106_012.json")
exec(compile(text, str(path) + "::readonly_memory_release", "exec"), globals())
