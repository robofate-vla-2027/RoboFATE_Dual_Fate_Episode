"""Original collector with the matched future optional-tool configuration."""
import h20_teacher_binding_v15 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())

