"""Original first-action observer through the matched future teacher binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher009_first_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v9") == 1
exec(compile(text.replace("h20_teacher_binding_v9", "h20_teacher_binding_v10"),
             str(path) + "::classify_storage", "exec"), globals())
