"""Use the effective Sweep catalog for metadata export; keep runtime014 intact."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

import prepare_teacher_metadata_h20_v15 as previous
import teacher_catalog_sweep_h20_v1 as catalog


def main_source():
    function = next(
        node for node in ast.parse(previous.text).body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    text = ast.get_source_segment(previous.text, function)
    old = 'result["task_totals"] = dict(binding.storage.teacher_catalog_binding_v13.TASK_TOTALS)'
    assert text.count(old) == 1
    return text.replace(old, 'result["task_totals"] = dict(_metadata_task_totals)', 1)


def pin(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def correct_existing(run_id):
    previous.execution.previous.host()
    assert re.fullmatch(r"c2_sweep_blocks_l[0-9]+_evo_common_teacher_[0-9]{4}_01a16807", run_id)
    root = previous.execution.D / "teacher/runs" / run_id
    old_path = root / "PREPARATION_METADATA_H20_001.json"
    old = json.loads(old_path.read_bytes())
    assert old["run_id"] == run_id and old["task"] == "sweep_blocks"
    assert not old["teacher_started"] and old["future_run_files_absent"]
    assert not any((root / name).exists() for name in (
        "DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json"
    ))
    totals = dict(catalog.TASK_TOTALS)
    assert totals["sweep_blocks"] == old["native_limit"] == 1000
    assert {key: totals[key] for key in old["task_totals"]} == old["task_totals"]
    assert old["remaining_steps"] == old["native_limit"] - old["t1"]
    value = dict(old)
    value["task_totals"] = totals
    value["metadata_export_correction"] = {
        "original": pin(old_path), "effective_catalog": pin(Path(catalog.__file__)),
        "exporter": pin(Path(__file__)),
        "reason": "Old metadata export omitted Sweep despite the effective catalog supporting1000.",
        "original_at_preserved": True, "source_or_budget_changed": False,
        "selection_reexecuted": False, "RGB_redecoded": False,
        "teacher_started": False,
    }
    path = root / "PREPARATION_METADATA_H20_TASK_CATALOG_002.json"
    if path.exists():
        assert json.loads(path.read_bytes()) == value
    else:
        with path.open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
    print(json.dumps(value))


if __name__ == "__main__":
    assert catalog.TASK_TOTALS["sweep_blocks"] == 1000
    if len(sys.argv) == 3 and sys.argv[1] == "--existing-run":
        correct_existing(sys.argv[2])
    else:
        assert len(sys.argv) == 1
        previous.__dict__["_metadata_task_totals"] = dict(catalog.TASK_TOTALS)
        exec(compile(main_source(), __file__ + "::metadata_export_only", "exec"), previous.__dict__)
        previous.main()
