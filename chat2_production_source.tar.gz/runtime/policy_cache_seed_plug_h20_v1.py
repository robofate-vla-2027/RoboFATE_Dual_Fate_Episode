"""Existing writable compiled cache, scoped to the original Plug400 task."""
from policy_cache_seed_play_h20_v1 import source as previous_source


def source():
    text = previous_source()
    for old, new in (
        ('context["task"] == "play_stacking_toy"',
         'context["task"] == "plug_in_charger"'),
        ('context["native_total_steps"] == 1200',
         'context["native_total_steps"] == 400'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


def install(run):
    namespace = {"__file__": __file__}
    exec(compile(source(), __file__ + "::Plug400_cache_only", "exec"), namespace)
    return namespace["install"](run)
