"""Freeze only the task-catalog extension after targeted offline CPU checks."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import unittest

import test_teacher_swap_binding_cpu_v1 as tests
import h20_teacher_binding_v13 as teacher
from teacher_history_pre_actor_catalog013_v1 import NATIVE_SHA

teacher.execution.previous.host()
D = teacher.execution.D
ref = lambda path: {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
native_sha = hashlib.sha256(teacher._text.encode()).hexdigest()
assert native_sha == NATIVE_SHA
assert teacher._text.index("history=common_teacher.load_causal_history(") < (
    teacher._text.index("model=teacher_worker_binding.model("))
log = io.StringIO()
result = unittest.TextTestRunner(stream=log).run(
    unittest.defaultTestLoader.loadTestsFromModule(tests))
assert result.wasSuccessful() and result.testsRun == 6
prior = D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_012.json"
assert ref(prior)["sha256"] == "ffa35f4040943fb572d7b08fc66185b8b14d5a871655f95e44236a62b9893917"
release = json.loads(prior.read_bytes())
assert release["model"] == "gt-6-as-a" and release["reasoning_effort"] == "xhigh"
assert release["teacher_wall_seconds"] == release["native_wall_seconds"] == 3600
assert release["baseline_wall_seconds_unchanged"] == 2400
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for pin in pins.values():
    teacher.storage.runtime.read_pin(pin)
names = (
    "teacher_catalog_swap_h20_v1.py", "h20_teacher_storage_swap_v1.py",
    "h20_teacher_binding_v13.py", "native_teacher_h20_v13.py",
    "collect_teacher_h20_v13.py", "prepare_teacher_h20_v13.py",
    "prepare_teacher_metadata_h20_v14.py", "teacher_history_pre_actor_catalog013_v1.py",
    "observe_teacher_terminal_h20_v16.py", "observe_teacher013_start_h20_v1.py",
    "observe_teacher013_first_h20_v1.py", "export_teacher013_settlement_metadata_h20_v1.py",
    "test_teacher_swap_binding_cpu_v1.py", "freeze_teacher_swap_catalog_h20_v1.py",
    "launch_bound_teacher_release013.sh", "launch_teacher_container_v5.sh",
    "prepare_swap_teacher_launchers_h20_v1.py",
)
for name in names:
    path = D / "runtime" / name
    if path.suffix == ".py":
        compile(path.read_text(), str(path), "exec")
    pin = ref(path)
    pins[pin["path"]] = pin


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
    return ref(path)


cpu = save(D / "migration/SWAP_TEACHER_CATALOG_CPU_001.json", {
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "CPU task catalog and configured metadata, not real restoration or execution",
    "tests_passed": result.testsRun, "test_log": log.getvalue(),
    "task": "swap_T", "original_native_total": 400,
    "effective_native_source_sha256": native_sha, "matched_effective_entries": True,
    "native_content_change": "Only imports of the catalog extended by SwapT400",
    "prior_causal_history_repair_retained": True,
    "real_t1_restoration_verified": False, "real_model_API_or_simulator_called": False,
    "new_scientific_samples": 0, "actual_adoption": False,
})
release.update(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    prior_swap_catalog_release=ref(prior), runtime_files=list(pins.values()),
    foreground_entry=str(D / "runtime/collect_teacher_h20_v13.py"),
    native_entry=str(D / "runtime/native_teacher_h20_v13.py"),
    preparation_entry=str(D / "runtime/prepare_teacher_h20_v13.py"),
    metadata_preparation_entry=str(D / "runtime/prepare_teacher_metadata_h20_v14.py"),
    launch_environment_binding=ref(D / "runtime/launch_bound_teacher_release013.sh"),
    container_launcher=ref(D / "runtime/launch_teacher_container_v5.sh"),
    matched_baseline=ref(D / "runtime/RUNTIME_H20_CHAT2_CONTENT_20261108_025.json"),
    swap_task_binding_cpu=cpu, effective_native_source_sha256=native_sha,
    actual_adoption=False, actual_teacher_takeover_verified=False,
    actual_positive_published=False, actual_swap_teacher_execution_verified=False,
    change_scope="Add only original SwapT400 catalog and matching future entry/metadata "
                 "bindings. Preserve teacher012 repairs, data rules, physics, model, "
                 "source ownership, teacher3600/baseline2400 and all old releases. "
                 "CPU checks do not verify real articulated t1 restoration.",
)
output = save(D / "runtime/RUNTIME_H20_CHAT2_TEACHER_20261108_013.json", release)
print(json.dumps({
    "teacher_release": output, "cpu": cpu, "actual_adoption": False,
    "baseline_release": release["matched_baseline"],
}))
