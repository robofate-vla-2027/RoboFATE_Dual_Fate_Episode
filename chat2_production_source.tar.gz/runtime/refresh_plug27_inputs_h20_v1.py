"""Refresh admission only; retain L27 preparation and original segment clocks."""
import sys
from plug_next_inputs_h20_v6 import source

serial = int(sys.argv.pop())
assert sys.argv[1:3] == ["inputs", "27"] and 2 <= serial <= 9
text = source()
for old, new in (
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", f"RESOURCE_PRECHECK_{serial:03d}.json"),
    ("BOUNDARY_INPUTS_001.json", f"BOUNDARY_INPUTS_{serial:03d}.json"),
    ("MAIN_BOUNDARY_001.json", f"MAIN_BOUNDARY_{serial:03d}.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::admission_only_no_repreparation", "exec"), globals())
