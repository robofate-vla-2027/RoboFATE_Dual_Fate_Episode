"""Original complete-baseline boundary export using compiled-cache release020."""
from general_next_inputs_h20_v4 import source as previous_source


def source():
    text = previous_source()
    old = "RUNTIME_H20_CHAT2_CONTENT_20261107_019.json"
    assert text.count(old) == 1
    return text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261107_020.json", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General_original_boundary_release020", "exec"), globals())

