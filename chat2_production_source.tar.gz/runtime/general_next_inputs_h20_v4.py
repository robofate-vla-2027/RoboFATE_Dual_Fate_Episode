"""Original next-General source export, bound to the paired diagnostic release."""
from general_next_inputs_h20_v3 import source as previous_source


def source():
    text = previous_source()
    old = "RUNTIME_H20_CHAT2_CONTENT_20261107_017.json"
    assert text.count(old) == 1
    return text.replace(old, "RUNTIME_H20_CHAT2_CONTENT_20261107_019.json", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::General_original_sequence_release019", "exec"), globals())

