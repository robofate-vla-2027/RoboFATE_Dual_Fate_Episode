"""Export the same bounded accounting evidence through release004."""
from pathlib import Path

path = Path(__file__).with_name("export_teacher_settlement_metadata_h20_v1.py")
text = path.read_text()
old = "h20_teacher_binding_v3"
assert text.count(old) == 1
text = text.replace(old, "h20_teacher_binding_v7")
exec(compile(text, str(path) + "::private_container_tmp", "exec"), globals())
