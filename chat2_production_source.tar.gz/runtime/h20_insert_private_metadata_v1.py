"""Allow only owned Insert split/sequence metadata, with original byte checks."""
import ast
from pathlib import Path
import re
from types import SimpleNamespace

import h20_insert_metadata_binding_v1 as storage

sequence = storage.sequence
D = storage.execution.D


def owned_insert_metadata(path, resolved):
    return (
        path == resolved
        and path.parent.parent == D / "teacher/runs"
        and re.fullmatch(r"c2_insert_tubes_l\d+_h20_baseline_\d{4}_01a16807", path.parent.name)
        is not None
        and (re.fullmatch(r"SPLIT_MANIFEST_L\d+_001\.json", path.name) is not None
             or path.name == "SEQUENCE_EXTENSION_001.json")
    )


text = Path(sequence.__file__).read_text()
old = "(path.is_relative_to(PROJECT) and path == resolved) or"
assert text.count(old) == 1
text = text.replace(old, "(path.is_relative_to(PROJECT) and path == resolved) or "
                    "_owned_insert_metadata(path, resolved) or")
function = next(n for n in ast.parse(text).body
                if isinstance(n, ast.FunctionDef) and n.name == "_read")
sequence._owned_insert_metadata = owned_insert_metadata
exec(compile(ast.Module(body=[function], type_ignores=[]),
             __file__ + "::original_bounded_metadata_read", "exec"), sequence.__dict__)
sequence._read._refate_owned_insert_metadata = True


def metadata_locations(value):
    if isinstance(value, dict):
        return {key: metadata_locations(item) for key, item in value.items()}
    if isinstance(value, list):
        return [metadata_locations(item) for item in value]
    if isinstance(value, str):
        mapped = storage.locations(value)
        if mapped != value:
            assert storage.locations(mapped, inverse=True) == value
        return mapped
    return value


def metadata_helpers():
    history, common, order, scene = storage.original_helpers()

    def decode(raw):
        data = common.decode(raw)
        if isinstance(data, dict) and str(data.get("schema", "")).startswith("refate."):
            return metadata_locations(data)
        return data

    return history, SimpleNamespace(decode=decode, raw_order=common.raw_order), order, scene


sequence._helpers = metadata_helpers
