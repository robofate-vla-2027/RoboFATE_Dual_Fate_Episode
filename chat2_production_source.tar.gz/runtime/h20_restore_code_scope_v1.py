"""Allow three immutable restore-code pins without widening the data boundary."""
import hashlib
import os
from pathlib import Path
import stat

CODE_HASHES = {
    "collect_source.py": "6be64f57a9688801677385d7696cd881d5baffdf35b31d68e23bcaaf74b42439",
    "observation_io.py": "a4cf9e2471b21ab1b67cc540959e91422948b991bd4135e3637717fe5ebd9734",
    "compare_physics_state.py": "c6c62635b39f4b211fd00067f1e22ce83cd791cb996cf5f262797f5834943d03",
}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def read_code_pin(path, expected):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path and not path.is_symlink(),
            "Noncanonical restore code pin")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 256 * 1024 * 1024,
                "Invalid/oversized restore code")
        raw = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(signature(before) == signature(after) == signature(path.stat())
            and len(raw) == before.st_size, "Restore code changed during read")
    require(hashlib.sha256(raw).hexdigest() == expected, "Pinned restore code changed")
    return raw


def wrap_reader(original, pins):
    pins = dict(pins)

    def read_bytes(filename):
        path = Path(filename)
        if str(path) in pins:
            return read_code_pin(path, pins[str(path)])
        return original(filename)

    return read_bytes


def install(support, core_modules):
    root = Path(support.__file__).parent
    require(str(root) == (
        "/vla/mxk/projects/ReFATE/coordination/20261106_chat2_h20_01a19072/source_tree/"
        "coordination/20261022_collection_chat2_01a16338/teacher/shared_teacher/"
        "reference_chat1/effective/native"), "Unexpected restore code root")
    require(support.ROOT == Path("/data/refate_chat2_20261106_01a19072/teacher"),
            "Unexpected restore data root")
    require(not hasattr(support, "_h20_code_scope"), "Restore code scope already installed")
    pins = {str(root / name): digest for name, digest in CODE_HASHES.items()}
    for name in ("collect_source", "observation_io"):
        require(Path(core_modules[name].__file__) == root / (name + ".py"),
                "Actual recording module path differs")
    for path, digest in pins.items():
        read_code_pin(path, digest)
    support.read_bytes = wrap_reader(support.read_bytes, pins)
    evidence = {
        "schema": "refate.chat2.restore_code_scope.v1",
        "data_root_unchanged": str(support.ROOT),
        "code_pins": [{"path": path, "sha256": digest} for path, digest in pins.items()],
        "code_only_extension": True, "source_or_budget_changed": False,
        "actual_t1_verified": False, "model_or_api_called_by_binding": False,
    }
    support._h20_code_scope = evidence
    return evidence

