"""Derive future SwapT launch guards from exact frozen teacher012 files."""
import hashlib
import json
from pathlib import Path
import re
import h20_runtime_binding_v1 as binding

binding.host()
D = Path("/data/refate_chat2_20261106_01a19072/runtime")
prior = D / "RUNTIME_H20_CHAT2_TEACHER_20261108_012.json"
assert hashlib.sha256(prior.read_bytes()).hexdigest() == (
    "ffa35f4040943fb572d7b08fc66185b8b14d5a871655f95e44236a62b9893917")
release = json.loads(prior.read_bytes())
pins = {pin["path"]: pin for pin in release["runtime_files"]}
for old_name, new_name, replacements in (
    ("launch_bound_teacher_release012.sh", "launch_bound_teacher_release013.sh", (
        ("^c2_[a-z0-9_]+_evo_common_teacher_[0-9]{4}_01a16807$",
         "^(c2_[a-z0-9_]+_evo_common_teacher_[0-9]{4}_01a16807|"
         "c2_swap_T_l[0-6]_evo_common_teacher_[0-9]{4}_01a16807)$"),
        ("launch_teacher_container_v4.sh", "launch_teacher_container_v5.sh"),
        ("collect_teacher_h20_v12.py", "collect_teacher_h20_v13.py"),
    )),
    ("launch_teacher_container_v4.sh", "launch_teacher_container_v5.sh", (
        ("^(cpu_container_[0-9]+|c2_[a-z0-9_]+_01a16807)$",
         "^(cpu_container_[0-9]+|c2_[a-z0-9_]+_01a16807|"
         "c2_swap_T_l[0-6]_evo_common_teacher_[0-9]{4}_01a16807)$"),
    )),
):
    source = D / old_name
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == pins[str(source)]["sha256"]
    text = raw.decode()
    for old, new in replacements:
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    guard = next(line for line in text.splitlines() if '[[ "$id" =~ ' in line)
    pattern = guard.split(" =~ ", 1)[1].removesuffix(" ]]")
    assert re.fullmatch(pattern, "c2_swap_T_l0_evo_common_teacher_0001_01a16807")
    assert re.fullmatch(pattern, "c2_swap_T_l6_evo_common_teacher_0007_01a16807")
    for bad in ("c2_swap_T_l7_evo_common_teacher_0008_01a16807",
                "c2_swap_T_l0_evo_common_teacher_0001_other",
                "c2_SWAP_T_l0_evo_common_teacher_0001_01a16807"):
        assert re.fullmatch(pattern, bad) is None
    output = D / new_name
    with output.open("x") as stream:
        stream.write(text)
    output.chmod(0o700)
    print(json.dumps({"path": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
                      "original_preserved": str(source), "executed": False}))
