"""Original first-action observer with the matched optional-tool binding."""
from pathlib import Path

path = Path(__file__).with_name("observe_teacher013_first_h20_v1.py")
text = path.read_text()
assert text.count("h20_teacher_binding_v13") == 1
exec(compile(text.replace("h20_teacher_binding_v13", "h20_teacher_binding_v15"),
             __file__ + "::optional_tool_binding", "exec"), globals())

