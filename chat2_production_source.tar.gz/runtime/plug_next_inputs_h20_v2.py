"""Bind future Plug resource summaries to their actual run and source."""
from pathlib import Path

path = Path(__file__).with_name("plug_next_inputs_h20_v1.py")
text = path.read_text()
seam = 'exec(compile(text, str(path) + "::plug_original_boundary", "exec"), globals())'
assert text.count(seam) == 1
text = text.replace(seam, '''
old = "run.mkdir()"
assert text.count(old) == 1
text = text.replace(old, old + "\\nresource.update(run_id=run_id, source_id=prepared['source']['source_id'])", 1)
''' + seam, 1)
exec(compile(text, str(path) + "::future_resource_identity", "exec"), globals())
