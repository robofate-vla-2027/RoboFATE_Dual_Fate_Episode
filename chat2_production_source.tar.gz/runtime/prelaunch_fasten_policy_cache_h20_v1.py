"""Existing collector11 prelaunch for the next admitted Fasten L7 only."""
from prelaunch_sweep_policy_cache_h20_v3 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_sweep_nfs_h20_v2", "policy_cache_seed_fasten_h20_v1", 2),
        ("c2_sweep_blocks_l[0-6]_h20_baseline_000[1-7]_01a16807",
         "c2_fasten_screws_l7_h20_baseline_0001_01a16807", 1),
        ('value["native_total_steps"] == 1000', 'value["native_total_steps"] == 1900', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Fasten_L7_original_collector", "exec"), globals())
