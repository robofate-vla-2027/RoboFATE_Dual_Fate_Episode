"""Same policy cache and collector11 for original Bottles L35."""
from prelaunch_bottles_policy_cache_h20_v2 import source as previous_source


def source():
    text = previous_source()
    old = "c2_put_bottles_into_dustbin_l34_h20_baseline_0035_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_put_bottles_into_dustbin_l35_h20_baseline_0036_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L35_same_collector", "exec"), globals())
