"""Original source preparer, limited to Sweep's existing initial split."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prepare_stack_existing_h20_v1.py").read_text()
    for old, new in (
        ("h20_teacher_binding_v8", "h20_teacher_binding_v14"),
        ('task = "stack_blocks_by_language"', 'task = "sweep_blocks"'),
        ("migration/STACK_L", "migration/SWEEP_L"),
        ('prior["native_step_limit"] == 400', 'prior["native_step_limit"] == 1000'),
        ("native_total=400", "native_total=1000"),
        ('"native_total": 400', '"native_total": 1000'),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::original_sweep_initial_sequence", "exec"), globals())
