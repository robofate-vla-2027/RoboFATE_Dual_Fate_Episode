"""Refresh admission only; retain the existing Play18 preparation and all clocks."""
from pathlib import Path
import sys

serial = int(sys.argv.pop())
assert sys.argv[1:3] == ["inputs", "18"] and 2 <= serial <= 9
path = Path(__file__).with_name("play_next_inputs_h20_v2.py")
wrapper = path.read_text()
seam = 'exec(compile(text, str(path) + "::matched_Play1200_inputs", "exec"), globals())'
assert wrapper.count(seam) == 1
outer = {"__file__": str(path)}
exec(compile(wrapper[:wrapper.index(seam)], str(path) + "::source_only", "exec"), outer)
wrapper = outer["text"]
seam = 'exec(compile(text, str(path) + "::play_original_boundary", "exec"), globals())'
assert wrapper.count(seam) == 1
inner = {"__file__": str(path.with_name("play_next_inputs_h20_v1.py"))}
exec(compile(wrapper[:wrapper.index(seam)], str(path) + "::expanded_source_only", "exec"), inner)
text = inner["text"]
for old, new in (
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", f"RESOURCE_PRECHECK_{serial:03d}.json"),
    ("BOUNDARY_INPUTS_001.json", f"BOUNDARY_INPUTS_{serial:03d}.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::admission_only_no_reprepare", "exec"), globals())
