"""Original Conveyor CPU publisher, retaining baseline037's identical libraries."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("publish_conveyor_release034_cpu_v1.py").read_text()
    old_files = '''    "policy_cache_seed_conveyor_h20_v1.py", "prelaunch_conveyor_policy_cache_h20_v1.py",
    "publish_conveyor_release034_cpu_v1.py",'''
    new_files = '''    "prelaunch_conveyor_policy_cache_h20_v2.py",
    "publish_conveyor_release038_cpu_v1.py",'''
    for old, new in (
        (old_files, new_files),
        ("import prelaunch_conveyor_policy_cache_h20_v1 as launch",
         "import prelaunch_conveyor_policy_cache_h20_v2 as launch"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261108_033.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261109_037.json"),
        ("9217b6a4256f6a6ecf70a0347161cea1525b00ffde1ca5844a08e6d47fa20b8d",
         "c33c1144438f3141af6077a166fd0f63ddea85c22b802adc0758be0f8074a178"),
        ("c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807",
         "c2_pick_from_conveyor_by_image_l19_h20_baseline_0020_01a16807"),
        ("offline_Conveyor18_prelaunch_source", "offline_Conveyor19_prelaunch_source"),
        ("CONVEYOR_L18_COMMON_PREPARATION_001.json", "CONVEYOR_L19_COMMON_PREPARATION_001.json"),
        ("9bcf4bf427fc1b0f77ff4bf568ca48ce84ef5b0c3f8971c7161e5e0d5524259c",
         "64ba07f20bca50daa558a6717afaa72e44f975021626c4056c8369ab6edcfd57"),
        ('prepared["source"]["layout_id"] == 18', 'prepared["source"]["layout_id"] == 19'),
        ('prepared["source"]["source_sequence"] == list(range(19))',
         'prepared["source"]["source_sequence"] == list(range(20))'),
        ('prepared["source"]["required_accounted_prefix"] == list(range(18))',
         'prepared["source"]["required_accounted_prefix"] == list(range(19))'),
        ("CONVEYOR_L18_CACHE_BINDING_CPU_001.json", "CONVEYOR_L19_CACHE_BINDING_CPU_001.json"),
        ("actual_Conveyor_L18_launch_verified", "actual_Conveyor_L19_launch_verified"),
        ('prelaunch_entry=str(D / "runtime/prelaunch_conveyor_policy_cache_h20_v1.py")',
         'prelaunch_entry=str(D / "runtime/prelaunch_conveyor_policy_cache_h20_v2.py")'),
        ("Conveyor L18/native700", "Conveyor L19/native700"),
        ("RUNTIME_H20_CHAT2_CONTENT_20261108_034.json",
         "RUNTIME_H20_CHAT2_CONTENT_20261109_038.json"),
    ):
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Conveyor19_original_library_mounts", "exec"),
         globals())
