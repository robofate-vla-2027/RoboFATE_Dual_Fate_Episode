"""Original content-v6 collector with paired Plug metadata storage."""
import h20_teacher_binding_v6 as binding

if __name__ == "__main__":
    raise SystemExit(binding.collection.main())
