"""Future teacher entry using release013 devices and privately relocated assets."""
from pathlib import Path
import sys

path = Path(__file__).with_name("h20_teacher_binding_v1.py")
text = path.read_text()
for old, new in (
    ("import h20_teacher_storage_v1 as storage",
     "import h20_teacher_storage_v2 as storage"),
    ("import h20_container_binding_v4 as execution",
     "import h20_container_binding_v7 as execution"),
    ("native_teacher_h20_v1.py", "native_teacher_h20_v2.py"),
    ("collect_teacher_h20_v1.py", "collect_teacher_h20_v2.py"),
    ("prepare_teacher_h20_v1.py", "prepare_teacher_h20_v2.py"),
):
    assert text.count(old) == (2 if old == "native_teacher_h20_v1.py" else 1)
    text = text.replace(old, new)
exec(compile(text, str(path) + "::release013_teacher", "exec"), globals())

# Keep the frozen task.toml intact; relocate only its workspace asset at load time.
sys.path.insert(0, str(stage.UPSTREAM))
import orchestrator.config as config

_load_task = config.load_task
_historical_workspace = storage.ORIGINAL_ROOT / (
    "coordination/20261022_collection_chat2_01a16338/"
    "teacher/upstream/EmbodiedEvo/tasks_baseline/RoboDojo/Workspace")
_workspace = storage.PROJECT / _historical_workspace.relative_to(storage.ORIGINAL_ROOT)


def load_task(root, *, env_task=None):
    cfg = _load_task(root, env_task=env_task)
    if Path(root) == stage.SHARED:
        assert cfg.workspace == _historical_workspace
        assert _workspace.is_dir()
        value = config.config_dict(cfg)
        assert Path(value["workspace_source"]) == _historical_workspace
        value["workspace_source"] = str(_workspace)
        cfg = config.config_from_dict(value)
    return cfg


config.load_task = load_task

import ast
import failure_summary_report_size_v1 as failure_summary

_projection = failure_summary.source()
_projection = execution.edit(
    _projection,
    "os.environ.get('REFATE_SSH_ALIAS') == 'perdon-hou'\n"
    "               and os.uname().nodename == 'nb-5pl2apckdj-0'",
    "os.environ.get('REFATE_SSH_ALIAS') == 'h20_8'\n"
    "               and os.uname().nodename == '20250103-instance'",
)
_function = next(n for n in ast.parse(_projection).body
                 if isinstance(n, ast.FunctionDef) and n.name == "project")
exec(compile(ast.Module(body=[_function], type_ignores=[]),
             __file__ + "::failure_projection_host", "exec"), failure_summary.__dict__)

# Match the already validated container nvoptix asset, without changing rendering.
_text = storage.native_teacher_content_v6.text
_text = execution.edit(
    _text,
    "socket.gethostname()=='nb-5pl2apckdj-0' and os.environ.get('REFATE_SSH_ALIAS')=='perdon-hou'",
    "socket.gethostname()=='20250103-instance' and os.environ.get('REFATE_SSH_ALIAS')=='h20_8'",
)
_text = execution.edit(
    _text,
    "        from optix_binding import resolve_cached_binding,process_asset_metadata\n"
    "        core.write(run/'nvoptix_container_asset.json',process_asset_metadata(resolve_cached_binding()))",
    "        from h20_runtime_binding_v1 import optix_metadata\n"
    "        core.write(run/'nvoptix_container_asset.json',optix_metadata())",
)
native = execution.previous.load_source("_refate_h20_teacher_native_v2", _text)
native.__file__ = str(execution.D / "runtime/native_teacher_h20_v2.py")
collection.native = native
preparation.native_shared_teacher = native
