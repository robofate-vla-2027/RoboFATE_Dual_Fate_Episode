"""Existing collector11 prelaunch restricted to the prepared Bottles L33."""
from prelaunch_plug_policy_cache_h20_v3 import source as previous_source


def source():
    text = previous_source()
    for old, new, count in (
        ("policy_cache_seed_plug_h20_v1", "policy_cache_seed_bottles_h20_v1", 2),
        ("c2_plug_in_charger_l27_h20_baseline_0028_01a16807",
         "c2_put_bottles_into_dustbin_l33_h20_baseline_0034_01a16807", 1),
        ('value["native_total_steps"] == 400', 'value["native_total_steps"] == 700', 1),
    ):
        assert text.count(old) == count, old
        text = text.replace(old, new, count)
    return text


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::Bottles33_original_collector", "exec"), globals())
