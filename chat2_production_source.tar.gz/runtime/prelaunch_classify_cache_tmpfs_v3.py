"""The same private disposable cache, parameterized only for original L28."""
from pathlib import Path


def source():
    text = Path(__file__).with_name("prelaunch_classify_cache_tmpfs_v1.py").read_text()
    old = "c2_classify_objects_l32_h20_baseline_0001_01a16807"
    assert text.count(old) == 1
    return text.replace(old, "c2_classify_objects_l28_h20_baseline_0001_01a16807", 1)


if __name__ == "__main__":
    exec(compile(source(), __file__ + "::L28_same_disposable_cache", "exec"), globals())
