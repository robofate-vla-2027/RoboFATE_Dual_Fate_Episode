"""Existing Conveyor cutoff check bound only to the recorded L19 source."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_l18_causal_selection_h20_v1.py")
text = path.read_text()
for old, new in (
    ("c2_pick_from_conveyor_by_image_l18_h20_baseline_0019_01a16807",
     "c2_pick_from_conveyor_by_image_l19_h20_baseline_0020_01a16807"),
    ("pick_from_conveyor_by_image_b0_l18_3fa06e4e9f91d205",
     "pick_from_conveyor_by_image_b0_l19_817ea42961adec26"),
    ('material["source_identity"]["layout_id"] == 18',
     'material["source_identity"]["layout_id"] == 19'),
    ("Saved ConveyorL18 only.", "Saved ConveyorL19 only."),
    ("CONVEYOR_L18_T10_CAUSAL_SELECTION_001.json",
     "CONVEYOR_L19_T10_CAUSAL_SELECTION_001.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::L19_source_metadata_only", "exec"), globals())
