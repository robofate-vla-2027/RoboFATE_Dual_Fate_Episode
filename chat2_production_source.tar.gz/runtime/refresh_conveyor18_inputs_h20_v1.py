"""Refresh only expired admission evidence; never repeat source preparation."""
from pathlib import Path

path = Path(__file__).with_name("conveyor_next_inputs_h20_v1.py")
wrapper = path.read_text()
seam = 'exec(compile(text, __file__ + "::Conveyor18_saved_CPU", "exec"), globals())'
assert wrapper.count(seam) == 1
scope = {"__file__": str(path)}
exec(compile(wrapper[:wrapper.index(seam)], str(path) + "::source_only", "exec"), scope)
text = scope["text"]
for old, new in (
    ("run.mkdir()", 'assert run.is_dir()\n'
     'assert not any((run / p).exists() for p in '
     '("DISPATCH_001.json", "CONTEXT_001.json", "foreground_started.json", '
     '"native_started.json", "native_actions.jsonl"))'),
    ("RESOURCE_PRECHECK_001.json", "RESOURCE_PRECHECK_002.json"),
    ("BOUNDARY_INPUTS_001.json", "BOUNDARY_INPUTS_002.json"),
):
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)
exec(compile(text, __file__ + "::admission_only_no_reprepare", "exec"), globals())

